# GGUF 原生后端（当前架构）

> 这是 App **当前**使用的推理架构。旧 MNN / ONNX 转换路线的文档已归档到
> `docs/legacy-mnn/`，仅供回溯。**现版本不需要任何模型转换**：导入一个
> `.gguf` 文件即可合成。
>
> **1.4 变更提示**：GPU（Vulkan）路径已整体移除，`breeze_init` 恒传 `use_gpu=0`，
> so 也不再包含 `libggml-vulkan.so`。下文凡提到 Vulkan 的段落均属 1.2/1.3 的历史记录，
> 仅用于解释为何放弃该路径；现行构建配置请看第 7 节表格中的 `BREEZE_VULKAN=OFF`。

## 1. 为什么换掉 MNN

上一版走 `PyTorch → ONNX → MNN`，需要用户在 PC / GPU 上自行转换 7 GB 权重。
后来社区出现了 [Breeze-TTS-2.cpp](https://github.com/pcloth/Breeze-TTS-2.cpp)
（ggml 实现），它把 Breeze 的**全部四个阶段**打包进单个 GGUF：

| 阶段 | 是否在同一 GGUF 内 |
| --- | --- |
| T5Gemma2 文本编码器（26L） | 是 |
| Qwen3 主干（28L） | 是 |
| 帧内 RVQ 深度解码器（12L，16 码本 / 15 步） | 是 |
| Mimi codec + 声码器（24 kHz） | 是（`codec.*` 张量前缀） |
| tokenizer | 是 |

`breeze_init(const char * gguf_path, int use_gpu)` 只接受一个路径，
`MimiCodec::init(model)` 直接从同一个模型对象读 codec 权重，因此**一个文件就够**。
现成量化版在 [`HoppouAI/Breeze-TTS-2.cpp`](https://huggingface.co/HoppouAI/Breeze-TTS-2.cpp)，
Q4_K 2.4 GB / Q8_0 3.3 GB，可直接下载。

顺带说明：MNN 侧即使有 `gguf2mnn.py` 也走不通这条路——它是 PC 端 Python 工具
（依赖 `pymnn`/`gguf`/`numpy`），本质是把权重填进**预先存在的 MNN 图骨架**，
只认标准 LLM 的张量布局与 Q4_0/Q4_1/Q6_K 量化块，官方明确「不支持多模态」，
且 ModelScope 上没有 Breeze 的 MNN 骨架。端上重写这套逻辑既不可行也不必要。

## 2. 架构

```
Kotlin / Compose（合成 · 音色 · 模型）
   │  BreezeEngine.kt
   │  System.loadLibrary("breeze_gguf") → loadLibrary("breeze")
   ▼
libbreeze.so          本工程 JNI 桥接（breeze_jni.cpp + breeze_engine.cpp）
   │  DT_NEEDED
   ▼
libbreeze_gguf.so     Breeze-TTS-2.cpp 的 C API
   ├─ GGUF 读取 / tokenizer / 长文本切分
   ├─ T5Gemma2 文本编码器
   ├─ Qwen3 主干（KV cache）
   ├─ 15 步深度解码器
   ├─ Mimi codec 编码（克隆）/ 声码器解码
   └─ ggml → libggml.so / libggml-base.so / libggml-cpu.so
   ▲
   │  单文件，无需清单
models/<档位>/model.gguf    2.4 – 5.9 GB
```

音频以 `float32 [-1,1]` 分块回调（默认 25 帧 ≈ 2 秒），JNI 层转成 PCM16 后
交给 Kotlin 的 `AudioTrack` 边生成边播，同时写 WAV。

## 3. C API 契约

声明在 `include/breeze/breeze.h`（上游 [c-api.md](https://github.com/pcloth/Breeze-TTS-2.cpp/blob/main/docs/c-api.md)）。

| 函数 | 作用 |
| --- | --- |
| `breeze_context* breeze_init(const char* gguf_path, int use_gpu)` | 加载 GGUF；`use_gpu=1` 尝试 Vulkan 再回落 CPU。**本 App 1.4 起恒传 0（纯 CPU）** |
| `void breeze_free(breeze_context*)` | 释放 |
| `int breeze_sample_rate(breeze_context*)` | 当前 24000 |
| `const char* breeze_backend_name(ctx)` | **1.2 新增**：实际后端名（1.4 恒为 `CPU`） |
| `int breeze_backend_is_gpu(ctx)` | **1.2 新增**：是否真的跑在 GPU（1.4 恒为 0） |
| `void breeze_set_threads(ctx, int n)` | 覆盖 ggml CPU 默认 4 线程，运行时可调 |
| `int breeze_warmup(ctx)` | 短空推理，**同时预热 cfg=1 与 cfg=4 两条路径**，提前完成权重换页、双 KV cache / 2 分支 depth runner 与计算管线分配 |
| `int breeze_generate(ctx, const breeze_request*, breeze_audio_cb, void* user)` | 阻塞生成，流式回调 |
| `int breeze_get_timings(ctx, breeze_timings* out)` | **1.6 新增**：上一次生成的分阶段耗时（prompt/prefill/backbone/depth/vocoder/tail/steps/flushes） |
| `int breeze_estimate_frames(ctx, const char* text)` | **1.6 新增**：按 CJK 加权的口语长度估算（codec 帧，12.5 帧/秒） |
| `int breeze_generate_wav(ctx, req, path)` | 直接写 WAV |
| `const char* breeze_last_error(void)` | 最近一次错误信息 |

`breeze_request` 在 1.5 新增三个流式字段（0 = 用引擎默认，向后兼容）：

| 字段 | 默认 | 作用 |
| --- | --- | --- |
| `chunk_first` | 4（App 用 **16**） | 首块帧数。播放端有预缓冲后，首块太小只会白付 88 帧上下文成本 |
| `chunk_max` | 25（App 用 **72**） | 稳定期每块帧数。声码器每次 flush 都要重算 88 帧上下文，块越大冗余越少 |
| `pace` | 1 | 播放快断粮时允许提前吐小块；0 关闭 |

1.6 又加了尾部保护字段：

| 字段 | 默认 | 作用 |
| --- | --- | --- |
| `pad_stop` | 16 | 连续多少帧全 pad（已经出过音频后）即收尾。模型偶尔不吐 eos 而一直吐空帧，这些帧不产音频却每帧跑一遍主干+深度解码，就是「生成完卡几十秒」的来源。0 = 用默认，负数 = 关闭 |

同一版在 `generate_chunk` 的主循环里加了 `cb(nullptr, 0)` 探针：取消不再只在 flush 时
被检查，空帧阶段也能立刻退出（否则停止后还要等完剩余令牌预算，下一次合成会报「上一段还在生成」）。

回调：`typedef int (*breeze_audio_cb)(const float* samples, int n_samples, void* user)`，
返回 `0` 继续、非 `0` 提前停止（本 App 用它实现「取消」）。
`breeze_context` **不可重入**，引擎层用 mutex 串行化；`breeze_warmup` 同样走这把锁，
与 synthesize 互斥。详细优化原理见 [`06-features-and-performance.md`](06-features-and-performance.md)。

## 4. App 请求字段映射

| App `SynthRequest` / `VoiceProfile` | `breeze_request` | 说明 |
| --- | --- | --- |
| `text` | `text` | UTF-8 文本 |
| `instruction`，为空时用 `designPrompt` | `instruction` | 情绪 / 表达指令，或音色设计描述 |
| `voice.refWav` | `ref_audio` + `ref_audio_len` | 引擎读 16-bit PCM WAV → 24 kHz 单声道 float；非 24 kHz 线性重采样 |
| `voice.refText` | `ref_text` | 克隆时必填，与 `ref_audio` 成对 |
| `seed` | `seed` | |
| `temperature` / `topP` | `temperature` / `top_p` | `0` 用 GGUF 内默认 |
| `maxFrames` | `max_new_tokens` | 帧上限 |
| `cfgScale`（默认 4.0，可在设置页 1–6 调整） | `cfg_scale` | 与 PC 端一致；`cfg=1` 关闭指令引导会让音色描述失效（1.1 的 bug）。**纯克隆且无指令时引擎自动置 1.0**，省掉第二份 KV cache |
| — | `split_chars = 0` | 用库内默认 600，长文本自动切句 |
| `chunkFrames` / `voice.codes` | 忽略 | 分块由引擎层固定（16→72 帧递增）；码本缓存由库内管理 |

`c_api.cpp` 里 `instruction` 为空时默认 `"Speak clearly and naturally."`。

## 5. 模型档位

`ModelCatalog` 中的四档，均来自 `HoppouAI/Breeze-TTS-2.cpp`：

| id | 文件 | 大小 | 说明 |
| --- | --- | --- | --- |
| `q4_k` | `breeze-tts-2-q4_k.gguf` | ~2.4 GB | 默认推荐 |
| `q6_k` | `breeze-tts-2-q6_k.gguf` | ~2.9 GB | 折中 |
| `q8_0` | `breeze-tts-2-q8_0.gguf` | ~3.3 GB | 上游推荐，接近 F16 |
| `f16` | `breeze-tts-2-f16.gguf` | ~5.9 GB | 未量化 |

仓库里的 `-dd2` / `-dd4` 变体**不建议用**：它们连深度解码器一起量化，
量化误差会沿帧反馈累积，持续生成约 45 秒后声音逐渐变闷、单薄（上游模型卡说明）。

> 注意 [cstr/breeze-tts-2-GGUF](https://huggingface.co/cstr/breeze-tts-2-GGUF)
> 这类打包**不含 codec**，需要另配 tokenizer GGUF；请用 HoppouAI / pcloth
> 的单文件完整版，否则 `breeze_init` 会失败。

## 6. 模型进入 App 的两条路径

两条路径最终都落成 `filesDir/models/<variantId>/model.gguf`，引擎按目录自动发现 `*.gguf`。

**一键下载**：`GET https://{host}/{repo}/resolve/main/{fileName}`，先取
`Content-Length` 做空间预检（×1.1），`Range` 断点续传写 `.part`；镜像
`hf-mirror.com` 失败自动回退 `huggingface.co`；下载完校验前 4 字节必须是
`GGUF`（防止把 HTML 错误页当模型），再原子改名。

**本地导入**：系统文件选择器选任意 `.gguf` → 复制到 `.part` → 校验大小与
`GGUF` 文件头 → 原子改名。完全离线，不需要 ZIP、不需要 `breeze.json` 清单。
失败会删掉 `.part`，不会留下被误判为「已安装」的半成品。

## 7. 交叉编译

```bash
ANDROID_HOME=/path/to/android-sdk ./tools/build_breeze_android.sh
```

脚本固定 `pcloth/main` + ggml commit `36da571…`，做若干补丁后交叉编译：

1. 运行时 `OUTPUT_NAME` 改成 `breeze_gguf`，避免与 JNI 库 `libbreeze.so` 同名；
2. `breeze-quantize` 可执行文件用 `BREEZE_BUILD_CLI` 包起来（Android 不需要）；
3. 给 `src/c_api.cpp` / `include/breeze/breeze.h` 注入 `breeze_set_threads`、
   `breeze_warmup`（含 CFG 双路径）、`breeze_backend_name` / `breeze_backend_is_gpu`；
4. 指定 `GGML_CPU_ARM_ARCH` 打开 ARM 量化内核；
5. **1.2 打开 Vulkan**：NDK 自带 `glslc` 生成 SPIR-V，补齐 `Vulkan-Hpp` 与
   `SPIRV-Headers` 头文件到 sysroot，`libggml.so` 静态注册 Vulkan backend。

关键 CMake 选项：

| 选项 | 值 | 原因 |
| --- | --- | --- |
| `BREEZE_VULKAN` | `OFF`（1.4 起） | 纯 CPU 构建。1.2/1.3 曾为 `ON`，因不提速、出杂音、启动崩溃而移除，见 `docs/10` |
| `GGML_VULKAN_SHADERS_GEN_TOOLCHAIN` | （历史）host toolchain | 仅 `BREEZE_VULKAN=ON` 时相关；shader 生成器在 PC 上编译，不能交叉编到 Android |
| `Vulkan_GLSLC_EXECUTABLE` | （历史）NDK `shader-tools/glslc` | 仅 `BREEZE_VULKAN=ON` 时相关 |
| `Vulkan_LIBRARY` / `Vulkan_INCLUDE_DIR` | （历史）NDK sysroot | 仅 `BREEZE_VULKAN=ON` 时相关 |
| `BREEZE_BUILD_CLI/SERVER/TESTS/MP3` | `OFF` | 只编 `libbreeze_gguf.so` |
| `GGML_NATIVE` | `OFF` | 交叉编译不能开 `-march=native` |
| `GGML_CPU_ARM_ARCH` | `armv8.6-a+dotprod+i8mm+fp16` | 启用 SDOT / I8MM / FP16 量化内核 |
| `GGML_OPENMP` | `OFF` | 避免额外的 libomp 运行时依赖 |
| `ANDROID_ABI` / `PLATFORM` | `arm64-v8a` / `android-33` | 12 GB / 骁龙 8 Elite 基线 |

产出 4 个 so（`libbreeze_gguf.so` + `libggml{, -base, -cpu}.so`），已随仓库预置在
`app/app/src/main/jniLibs/arm64-v8a/`。只改 Kotlin / JNI 业务代码时**不需要重跑此脚本**。
（1.2/1.3 还额外产出一个约 35 MB 的 `libggml-vulkan.so`，1.4 已不再生成。）

## 8. 已知限制与风险

- **Vulkan 已移除（1.4）**：1.3 曾强制 FP32 并做 GPU/CPU 对拍自检，但实测仍会在部分
  驱动上于 device 初始化阶段崩溃，且即使修好也只有约 1.30× 的理论上限（实际持平或更慢）。
  1.4 删掉整条路径，`libggml.so` 只注册 CPU backend，
  `breeze_backend_name` 恒返回 `CPU`。完整评估见 `docs/10-v1.4-remove-gpu.md`。
- **CFG 内存开销**：`cfg > 1` 需要两份 KV cache 与 2 分支深度解码，F16 档位 +
  长文本可能吃紧；纯克隆无指令时引擎自动关闭 CFG。
- **SIMD 特性已启用（1.1 起）**：配置日志确认 `HAVE_DOTPROD` / `HAVE_MATMUL_INT8` /
  `HAVE_FP16_VECTOR_ARITHMETIC` 全部通过。因为基线不含低端机，这里不做运行时多版本
  分发；若要在更老的设备上运行，必须改回 `GGML_CPU_ALL_VARIANTS` 或多套 so。
- **RTF 无沙箱数据**：用户已在真机确认能正确生成音频，但沙箱内没有 2.4 GB 权重与真机，
  「线程数 / 预热开关」的提速幅度未量化，合成页会显示每次的 RTF 供实测对比。
  上游桌面参考是 RTX 3060 + Vulkan、Q8_0 约 1.5× 实时（52 ms/帧，深度解码器占 34 ms）。
- **深度解码器是瓶颈**：每帧 15 次小图提交，属 dispatch 开销型负载，
  上游也指出 CUDA 因此反而比 Vulkan 慢。
- `breeze_last_error()` 在上游实现里是全局 `std::string`（文档写 thread-local）。
  本 App 只有一个 context 且串行合成，不受影响。
- 长文本由库内 `split_chars=600` 自动切句；C API 不暴露分块大小调节。

## 9. 许可

`libbreeze_gguf.so` 来自 Breeze-TTS-2.cpp（Apache-2.0）与 ggml（MIT）。
**GGUF 权重是 Breeze TTS 2 的量化派生模型，仍受 BreezeBlue Research and
Non-Commercial License 约束，仅限研究与非商业用途**，详见 `NOTICE.md`。
