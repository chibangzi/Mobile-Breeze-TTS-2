# 118 · 外部资料的第四次筛查：三条能落地，一条推翻我自己

上一轮（117）我说「网上没东西」说得太早。这次按「CPU 单机、单请求、Q8_0、批=1」这四个约束逐条过筛，
能用的只有三条，其中一条直接指向我们 prefill 的 1.5 s。

## 一、先说没用的，以后不再看

| 来源 | 它做的事 | 为什么对我们无效 |
| --- | --- | --- |
| Nari Labs / Qwen3-TTS 服务化（[文](http://snslive.uk/article/2531052)） | 三模块统一调度、deadline 优先级、CUDA graph、Triton kernel | 全是多请求并发下的 GPU 复用，我们是单机单流 |
| Moshi / Kyutai（[报告](https://arxiv.org/abs/2410.00037)） | 160 ms 理论延迟、Inner Monologue | 延迟靠的是 12.5 Hz 帧率 + 7B 主干，架构级，不改模型拿不到 |
| LiveSpeech（[文](https://lacuna.tiptreesystems.com/work/livespeech-low-latency-zero-shot-text-to-speech)） | parallel codebook group heads | **需要重训**，和 PersonaPlex 的 parallel depformer 同一类 |
| llama.cpp PR #30808 | KleidiAI Q8_0 **SVE** GEMV，Graviton 3 上 +18% | 只对 256-bit SVE 有效；docs/47 实测本机 HWCAP 没有 SVE |
| llama.cpp PR #27851 | k-quant tiled matmul，prefill 3–7× | 只服务 Q4_K/Q3_K，我们是 Q8_0；且 GEMV 路径反而慢到 80% |

PR #30808 那条要特别记一笔：它证明「Q8_0 GEMV 还有 18% 可挖」，但**挖法绑定 SVE**。
Oryon 只有 NEON + dotprod + i8mm，没有 SVE，所以那 18% 对我们不存在。这条判据以后可以永久引用。

## 二、能用的一：Q8_0 的 prefill 有 1.73×，而且我们可能没吃到

KleidiBench 的实测（[FINDINGS](https://github.com/yannan000/kleidibench/blob/main/docs/FINDINGS.md)，Neoverse N2 4 线程，3B 模型）：

| 量化 | KleidiAI 关 | KleidiAI 开 | 增益 |
| --- | --- | --- | --- |
| Q4_0 prefill | 70.2 tok/s | 70.9 | **1.01×** |
| Q8_0 prefill | 62.2 tok/s | 107.7 | **1.73×** |
| Q8_0 decode | 20.3 tok/s | 23.3 | 1.15× |

关键在于它的解释：**上游默认路径对 Q4_0 会做 repack，对 Q8_0 不会**。所以 Q4_0 那条 1.01×
不是「KleidiAI 没用」，是「默认路径已经做了同一件事」。Q8_0 的 1.73× 才是白捡的。

这正好是我去年判断失误的地方。docs/23 那次 `BREEZE_KLEIDIAI=ON` 编进去了 124 个 `kai_*` 符号，
但**从来没在诊断页量过 prefill**，后来因为 SME 内核报错就整体关掉了。等于把 Q8_0 的 1.73× 一起关掉了。

在我们这里的账面：

- 首声 prefill 约 **1.5 s**，走的是真 GEMM（prompt 几十到几百 token），正是 i8mm 微内核的靶心
- 1.73× → 约 **0.87 s**，首声少等 0.6 s
- decode 那 1.15× 大概率已经拿到（我们的 Q8_0 GEMV 跑到 55 GB/s，68 的 81%，靠的就是 4 行交错复排）

**但这是推断，不是实测。** 我们没有任何一个数字是「prefill 阶段的 tok/s」。
诊断页现在只有「每帧」，把 prefill 混在首帧里了。所以要做的第一件事不是重编，是**先把 prefill 单独计时**。

## 三、能用的二：声码器的 88 帧上下文在流式路径里被反复重算

看 `generation.cpp` 的流式 flush：

```cpp
j.ctx_start = j.start > ctx ? j.start - ctx : 0;   // ctx = voc.sliding_window(72) + 16
j.T = j.start + j.count - j.ctx_start;             // 实际送进图的帧数
```

`chunk` 从 `chunk_first` 起，按 `chunk + chunk/2 + 1` 长到 `chunk_max`。所以每个 chunk 的真实成本是

```
冗余倍数 = (chunk + 88) / chunk
```

chunk=8 时 **12×**，chunk=64 时 2.4×。也就是说流式的前几个 chunk，声码器 90% 的算力在重算历史。

Nari Labs 对同一问题的解法是 **codec state cache**：把每层 causal conv 的尾部激活和 transformer 的 KV 留下来，
下一块只算新增帧（[文](https://explainx.ai/blog/nari-labs-qwen3-tts-speed-cost-frontier-august-2026) 第 4 条）。
我们的 conv 全是 `conv1d_causal` / `convtr1d_causal`，天生可以带 state，改动是机械的但量大：
dpre、4 个 up 块、3 个 dblk 各 3 个 residual、dhead、dfin，十几层。

收益上限：声码器约 10 ms/帧，若能压到 2 ms，整帧 142 → 134（**−6%**）。
不如 prefill 那 0.6 s 显眼，但它是**每帧**都省的。

## 四、能用的三：两件几乎零成本的事

**① 开头那段静音**（Nari 第 1 条，值 ~80 ms）。模型起手常吐一小段近静音，我们没有任何 trim 逻辑
（`grep leading|silence|trim` 全空）。做法是在 deliver 回调里对前几个 chunk 跑 RMS 滑窗，
找到第一个超过阈值的位置再开始写播放缓冲——**不改推理、不改音质**，只影响「点下去到出声」。
风险是用户本来就要句首停顿，所以只裁句首、只裁到第一个有声样本，且阈值要能配置。

**② 线程数改成 2 不是 4**。你测出来「区别不大」，这本身就是结论。而那篇
[Audio Deadlines](https://dev.to/dima_kruglov_608741d9a416/audio-deadlines-running-on-device-tts-without-audible-glitches-kdi) 里有一条正好解释：
四线程单块更快，但功耗高、SoC 热，**十分钟会话里 2 线程 + 更大 prebuffer 往往反超 4 线程 + 小 buffer**。
我们一直只测单帧中位数，没测过「第 10 分钟的 RTF」。既然中位数没差，就按能效选 2。

## 五、顺带修正一个我自己的说法

我之前说「Q4 在 CPU 上没优势是因为指令发射受限」。KleidiBench 给了更准确的版本：
**Q4_0 的默认路径本身已经 repack 到 i8mm，Q8_0 没有**。所以 Q4 慢不是「解包指令多」，
而是「两边都已经在矩阵单元上，Q4 没有额外可省的」。结论不变（CPU 上 Q4 无用），但机理说错了，
以后别再用「Q4 费指令」解释。

## 六、建议的动作，只做一件

**先给 prefill 装个秒表，别急着重编。**

理由：现在所有关于 KleidiAI 的数字都是从 llama.cpp 3B 模型推过来的，我们的 prefill 到底多少 tok/s、
有多少时间花在 GEMM 上，一个数都没有。装表只需要在 `backbone_run` 的 prefill 段前后各取一次时钟，
把 token 数除一下，诊断页多一行。跑一次就有真数字：

- 若 prefill GEMM 占比 >60%，重编 KleidiAI 值得，预期首声 −0.5 s
- 若占比低（比如大部分时间在文本编码器），那 Q8_0 i8mm 也救不了，这条路封掉

装表成本半小时，重编 + 回归要一天。顺序不能反。
