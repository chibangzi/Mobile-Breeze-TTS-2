# 1.1 版新增功能与性能优化说明

> **历史文档**：本文记录 1.1 版。其中「Vosk 离线 ASR」一节已在 **1.2 版**被
> sherpa-onnx + SenseVoice 取代，「CPU-only / Vulkan 未启用」的结论也已被 1.2 的
> Vulkan 可选开关推翻。最新状态见 [`07-v1.2-changes.md`](07-v1.2-changes.md) 与
> [`02-gguf-backend.md`](02-gguf-backend.md)。

本版在「能正确生成音频」的基础上补齐日常使用链路，并针对**预热慢 / 生成慢**做了
原生层优化。Kotlin 侧全部使用稳定 Compose API，C++ 侧保持原有 JNI 契约。

## 一、新增功能

| # | 需求 | 实现位置 |
| --- | --- | --- |
| 1 | 生成后显示播放控件，可反复播放 | `audio/Playback.kt`（`WavPlayer`）、`ui/CommonWidgets.kt`（`PlaybackBar`）、合成页与历史页 |
| 2 | 导出 WAV 提示成功 + 显示位置，位置可设置 | `vm/AppViewModel.exportLast()`、`data/SettingsRepository.kt`、模型页「WAV 导出位置」、`MainActivity` Snackbar |
| 3 | 克隆音色 / 音色设计界面分开 | `ui/VoiceScreen.kt` 用 `TabRow` 拆成两个独立流程，各自的表单、说明与列表 |
| 4 | 克隆时自动识别参考音频文本稿 | `data/SpeechRepository.kt`（Vosk + 中文小模型），音色页「自动识别文本稿」 |
| 5 | 合成页直接读取并选择音色 | `ui/CommonWidgets.kt`（`VoiceSelector`），内嵌 `FilterChip` 列表点选即切换 |
| 6 | 底栏历史页：列表 / 播放 / 左滑删除 | `ui/HistoryScreen.kt`、`ui/CommonWidgets.kt`（`SwipeToDeleteRow`）、`data/HistoryRepository.kt` |
| 7 | 优化预热与生成速度 | 见下节 |

### 播放控件

生成完成后结果区常驻一个播放条：播放 / 暂停、进度拖动、时间显示、**重播**。
播放器用 `MediaPlayer` 读完整 WAV（与生成期的 `AudioTrack` 流式播放分开），
播完自动回到 0 ms，再点播放即从头重播。历史页点击任意条目也走同一个播放器。

### 导出位置

- 默认：`MediaStore` → `Music/BreezeTTS/`，无需任何权限。
- 自定义：模型页「选择文件夹」用系统 SAF 目录树授权，
  `takePersistableUriPermission` 持久化，重启后仍有效；导出用
  `DocumentsContract.createDocument` 在该目录建 `breeze_<时间戳>.wav`。
- 成功后 Snackbar 显示 **「导出成功：<目录>/<文件名>」**，失败显示具体原因。

### 历史

每次合成完成自动复制 preview.wav 到 `filesDir/history/<id>.wav` 并写 `index.json`，
最多保留 200 条，超出自动清理旧文件。列表项**向左滑动露出红色删除按钮**，
点击才删除（露出状态下点内容区先收起，避免误触播放）。删除同时清掉文件与索引，
若正在播放该条则先停止播放。

### 离线 ASR（自动识别文本稿）

- 引擎：[Vosk](https://alphacephei.com/vosk/) `vosk-android:0.3.47`（AAR 自带
  `libvosk.so`），模型为中文小模型 `vosk-model-small-cn-0.22`（约 42 MB）。
- 首次在音色页点「先下载离线识别模型」下载解压到 `filesDir/asr/`；
  之后识别**完全离线、音频不上传**。
- 识别结果会自动填入「参考音频的逐字文本稿」并提示人工核对。
  中文模型输出按词带空格，代码会自动拼回连续文本。
- 未安装模型 / 识别失败时优雅降级为手动填写，不阻断克隆流程。
- 模型下载源：Vosk 官方，失败自动尝试 HuggingFace 镜像。

> 注意：小模型是通用中文识别，对专有名词、方言、带噪录音会有误差，
> 克隆音色对文本稿准确性很敏感，**务必人工核对标点与字词**。

## 二、性能优化

用户反馈「预热时间有点长、生成速度有点慢」。定位后做了三件事：

### 1. 启用 ARM 量化内核（最大提速项）

原构建 `-DGGML_NATIVE=OFF` 且未指定 `-march`，ggml 只用到基础 NEON，
`q4_k` / `q6_k` / `q8_0` 的整型 GEMM 走通用实现。交叉编译时改为：

```
-DGGML_CPU_ARM_ARCH=armv8.6-a+dotprod+i8mm+fp16
```

配置日志确认 `HAVE_DOTPROD` / `HAVE_MATMUL_INT8` / `HAVE_FP16_VECTOR_ARITHMETIC`
全部通过，量化矩阵乘会走 SDOT / I8MM 指令。反汇编对比 `libggml-cpu.so`：
1.0 版 `sdot` / `smmla` / `ummla` 指令数为 **0**，1.1 版为 **1167 条**，
说明优化确实编进了产物而不只是改了 CMake 参数。骁龙 8 Elite（Oryon，ARMv9）
完全覆盖；由于基线不包含低端机，这里不做运行时多版本分发。

> 该选项写在 `tools/build_breeze_android.sh` 里，重跑脚本即可复现。

### 2. 线程数从默认 4 提到可调 6

`ggml` 的 `GGML_DEFAULT_N_THREADS = 4`，8 核旗舰机有一半算力闲置。
新增 C API `breeze_set_threads(ctx, n)`，App 在加载时按设置传入，
模型页「推理性能」里可在 1–8 线程间实时调整（**即时生效，不重新加载 2.4 GB 权重**）。
线程过多会在小矩阵上增加同步开销，界面默认 6 并说明可按体感回调。

### 3. 启动预热，把冷启动挪出「点生成」

上游 `warm_up()` 只在 server 里调用，C API 没暴露，导致首次合成时才付：

- 2.4 GB mmap 权重的缺页加载；
- ggml 计算图 / gallocr 暂存缓冲首次分配；
- 各阶段（文本编码器 / backbone prefill / 深度解码器 / 声码器）首次执行开销。

新增 C API `breeze_warmup(ctx)`：跑一次 8 token 的丢弃式生成 + 若干长度的声码器解码，
只触碰 `cfg_scale=1` 会用到的图（不建第二份 KV cache）。App 在引擎加载完成后
于后台线程执行，状态显示「正在预热引擎」，完成后才置「就绪」。
**用户首次点生成不再承担这段固定开销**。模型页可关闭自动预热。

### 其余保持

- `cfg_scale = 1`（不开 CFG，避免两份 KV cache 占内存）；
- 引擎实例常驻、`breeze_context` 用 mutex 串行化，只在 `TRIM_MEMORY_COMPLETE` 释放；
- 分块 25 帧、流式播放与写盘不变。

### 仍然存在的开销（需真机 profiling）

- 每次生成仍会重建 `BackboneState` 的 KV cache 与计算图（上游 `Graph::compute` 每次
  `ggml_gallocr_alloc_graph`）。彻底消除需要上游改为跨请求复用 prepared graph，
  改动大、风险高，本版未动。
- 深度解码器每帧 15 次小图提交，属 dispatch 开销型瓶颈。
- Vulkan 后端仍未启用（移动端驱动兼容性未验证）；Adreno GPU 是下一个可探索的加速点。
- 沙箱内没有 2.4 GB 权重与真机，**RTF 与提速幅度未实测**，请在真机上对比
  「线程数 4 / 6 / 8」和「开 / 关预热」的体感差异。

## 三、构建与依赖变化

- `versionCode 2` / `versionName 1.1`。
- 新增 Gradle 依赖 `com.alphacephei:vosk-android:0.3.47`（含 JNA AAR）。
- 新增 4 个 JNI 入口：`nativeWarmup`、`nativeSetThreads`（另两个原有）。
- `libbreeze_gguf.so` 重新交叉编译，导出 `breeze_set_threads` / `breeze_warmup`。
