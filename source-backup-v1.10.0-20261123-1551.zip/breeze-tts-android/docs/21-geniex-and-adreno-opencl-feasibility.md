# 21 · GPU 加速攻坚：GenieX 这条路能不能走，以及真正能走的那条

> 结论先说三句：
>
> 1. **GenieX 跑不了 Breeze。** 它不是通用 ggml 运行时，是「LLM/VLM 推理 SDK」。它的
>    llama.cpp 通道只认 llama.cpp 自己 `llm_arch` 表里的模型，Breeze 是四阶段自定义图，
>    加载阶段就会报 unknown architecture——连一张图都进不去，不是慢，是跑不起来。
> 2. **但它指对了一件重要的事**：Adreno 上正确的后端是 **OpenCL**，不是 Vulkan。Vulkan 在
>    这颗 SoC 上数值不可信（fp16 shared memory，且 Turnip 驱动下连 cooperative matrix 都没报出来），而 OpenCL 这条
>    是 Qualcomm 自己写进 llama.cpp 的，官方验证过 Adreno 830，且全程可以走 F32。
> 3. **值得做，但只值得做声码器**。我核对了 Breeze 用到的全部 32 处算子调用，OpenCL 缺
>    6 处，但只有 3 处挡在合成路径上（其余在深度解码的采样与克隆编码器）；主干与深度
>    解码搬上去只会更慢（GEMV 带宽瓶颈）。预期把声码器 8.1 s 压到 1.5–2.5 s，整段 RTF
>    **5.37 → 约 3.5**；要摸到 2–3 还得再叠一项「声码器不再重复解码」，而那一项必须先单独 A/B。

---

## 一、先把 GenieX 是什么说清楚

| 项 | 事实 | 来源 |
| --- | --- | --- |
| 出身 | Nexa AI 团队（2026 年被高通收购）出品，Qualcomm GENIE 的社区版，BSD-3-Clause | [qualcomm/geniex](https://github.com/qualcomm/geniex) |
| llama_cpp 通道 | 任意 HuggingFace GGUF，跑在 Hexagon NPU / **Adreno GPU（OpenCL）** / CPU | [platforms](https://geniex.aihub.qualcomm.com/en/get-started/platforms) |
| qairt 通道 | 只能跑 AI Hub 预编译包，NPU only，精度/上下文全烧死在 bundle 里 | 同上 |
| 输入模态 | **Text、Image、Audio（仅 VLM 的音频输入）** ——没有语音合成 | [models](https://geniex.aihub.qualcomm.com/en/models/supported) |
| Android SDK | `ModelManagerWrapper` + `LlmWrapper` + `LlmCreateInput(model_path, config, runtime_id, compute_unit)` | 同上 |

也就是说：GenieX 的对外接口从头到尾就是「加载一个 LLM / VLM，`generate()` 出 token」。
没有「提交任意 ggml 计算图」的入口，也没有「输出中间隐状态」「逐帧步进」的入口。

### 1.1 三层否定，逐层看

**L1 · 架构注册层。** llama.cpp 不是「读 GGUF 就能跑」，它靠 `llm_arch` 枚举 + 每种架构
手写一个 `build_<arch>_graph()`。GGUF 只是容器，`general.architecture` 认不出来就是
`unknown model architecture`，加载即失败。Breeze 的 GGUF 里装的是：

```
T5Gemma2 文本编码器(26L) → Qwen3 主干(28L) → RVQ 深度解码(12L×15 码本) → Mimi codec+声码器
```

四段串行、四套张量命名（`te.* / bb.* / dd.* / codec.*`），没有任何一段长得像 LLM 的
`blk.N.*` 布局。llama.cpp 侧不存在这个 arch，也不可能有。

**L2 · 控制流层。** 就算把主干单独切出来当一个 Qwen3 GGUF，也接不上：Breeze 每帧的流程是
「CFG 两条分支各跑一遍 → 取 cb0 → 深度解码器 15 步串行补完 15 个码本 → 组帧」，采样在
**图内部**（`ggml_top_k` + `ggml_argmax` 都在 depth 的 graph 里），参考码本与
`<ins_bos>instruction<ins_eos>` 是两段独立输入。而 llama.cpp 拥有 KV cache 和整个
采样循环，外部只能喂 token 拿 token。TTS 恰恰要求「每一帧由我决定喂什么、取什么」。

**L3 · 算子层。** 即便前两层都绕过，GenieX 的 GPU 通道就是 ggml-opencl——我们自己
`-DGGML_OPENCL=ON` 编一份就是同一个东西，还不用引它的 SDK、模型缓存目录、`geniex.json`
清单。**它的价值等于零增量**。

> **十分钟证伪**：把 Breeze 的 GGUF 直接喂给 `geniex infer`，它会停在
> `unknown model architecture`——这一步不需要改任何代码，可以先自己验一遍，再决定
> 要不要往下看我说的 OpenCL 方案。
>
> 所以：**走 GenieX 这条路 = 0%。** 但沿着它指的方向（Adreno → OpenCL）走，是正确的。

---

## 二、为什么这次和 Vulkan 那次不一样

1.3 的 Vulkan 失败是**数值**失败，不是「GPU 天生不行」：ggml-vulkan 在支持 fp16 的设备上
把 F32 激活截断成 fp16 塞进 shared memory，Breeze 声码器的 `sin(x·alpha)`（alpha 可达 1e5
量级）、`-INFINITY` mask、1920× 转置卷积全部踩中，整段变噪声。当时只能靠
`GGML_VK_DISABLE_F16` 全部退回 F32，而 Vulkan 一旦退 F32 就没有任何加速理由了。

OpenCL 这条不一样：

| | ggml-vulkan | ggml-opencl |
| --- | --- | --- |
| 谁维护 | 社区 | **Qualcomm 主导**，专为 Adreno 写 |
| 官方验证设备 | — | Adreno 750 / **810** / **830** / 840 / X1-85 / X2-90 |
| F32 路径 | 存在但被 fp16 优化路径挤压 | 原生 `mul_mat_f32`，F32×F32 是一等公民 |
| 量化 | 有 | Q4_0…Q6_K / MXFP4 / IQ4_NL 全覆盖 |

社区实测（Adreno 830 / 8 Elite 系，llama.cpp OpenCL，t/s）：

| 来源 | 模型 | CPU prefill / decode | GPU prefill / decode | 判读 |
| --- | --- | --- | --- | --- |
| PocketPal 同一 harness | Qwen3 1.7B Q4_0 | 203 / 35.6 | **416 / 27.1** | prefill 2×，decode **慢 24%** |
| llama.cpp #23736 | Qwen2.5-Coder-1.5B Q8_0 | 24.2 / 7.95 | **579 / 21.3** | prefill 24×，decode 也快 |
| 同上 | Qwen2.5-Coder-7B Q4_K_M | 24.2 / 7.95 | 89.2 / 6.60 | prefill 3.7×，decode **慢 17%** |

（[llama.cpp #23736](https://github.com/ggml-org/llama.cpp/discussions/23736)、
[PocketPal 跨引擎榜](https://pocketpal.dev/leaderboard/engines)；Qualcomm 在
[IWOCL 2025](https://www.iwocl.org/wp-content/uploads/iwocl-2025-hongqiang-wang-lamacpp-backend.pdf)
的官方口径与此一致：prefill 是 compute-bound 的 MatMul，token 生成是 bandwidth-bound 的 MatVec，
**GPU 在后者上的收益不稳定，随 kernel/编译器/线程数在 0.8–2.7× 之间摆动**。）

**结论**：GPU 在「批量矩阵乘」上稳定 2–24×，在「batch=1 的 GEMV」上不稳定且经常倒退。
这条差异决定了该搬哪一段。

---

## 三、算子对账：32 处调用，缺 6 处，只有 3 处挡在合成路径上

我把 Breeze 全部源码里的 `ggml_*` 调用提取出来（32 处），对工程固定的
ggml `36da571` 的 `ggml_opencl_supports_op()` 逐个核对：

| 阶段 | 用到的算子 | OpenCL 支持情况 |
| --- | --- | --- |
| 文本编码 | mul_mat, rope, soft_max, add, mul, norm, get_rows, reshape/permute/cont | ✅ 全支持 |
| 主干 | 同上 + rms_norm, swiglu(GLU), cpy/view | ✅ 全支持 |
| 深度解码 | 同上 + **top_k, argmax** | ❌ 这两个不在 supports_op（master 已补，pinned 未补） |
| 声码器 | conv_1d(=im2col+mul_mat), **conv_transpose_1d**, **sin**, exp, sqr, div, clamp, gelu_erf, pad, **roll** | ❌ 3 个缺失 |
| codec 编码器（仅克隆用） | 同上 + **elu** | ❌ elu 缺失，但不影响合成 |

> 复现命令：`./tools/check_opencl_op_coverage.sh`（自动取构建脚本里固定的 ggml commit，
> 拉 `ggml-opencl.cpp` 的 `supports_op` 与本地源码逐个对账）。当前输出：6 处缺口 =
> ARGMAX / TOP_K / CONV_TRANSPOSE_1D / ROLL / UNARY_SIN / UNARY_ELU。

三个缺口都很具体：

| 缺口 | 用在哪 | 补法 | 工作量 |
| --- | --- | --- | --- |
| `ROLL` | `depthwise1d_causal()` 的前向移位（`codec_conv.cpp:48`） | **不用补**。改成前置 pad `K-1` + 按 tap 取偏移视图，语义完全等价，CPU 侧还少一次全量拷贝 | 10 行 |
| `CONV_TRANSPOSE_1D` | 声码器 8 处上采样（`codec_conv.cpp:26`） | **不用补**。等价改写为「零插值 → conv_1d」，即 pad(ne2)+reshape 得到 `[C, L*s]`，再走 im2col+mul_mat | 20 行 |
| `SIN` | `snake_beta()`（`codec_decoder.cpp:14`） | 必须补 kernel。OpenCL 侧的 unary 是一张 switch 表，加一个 `sin` 分支 | 5 行 + 5 行 |

顺带一提：**`CONV_TRANSPOSE_1D` 那条改写本身就是纯 CPU 收益**。1.10 期间用真实形状测过，
标量实现的转置卷积比等价 gemm 写法慢 4–7 倍（1536→768/s8：**413 ms vs 69 ms**）。
即使 GPU 这条路最后不走，这一项也该做。

> 深度解码的 `top_k/argmax` 不用管——它本来就不该上 GPU（见下一节）。

---

## 四、架构缺口：现在的引擎是「单后端 all-or-nothing」

`src/common.cpp` 的 `Backend::init()` 只 `ggml_backend_init_by_type(GPU)` 一个后端，
`Graph::compute()` 直接 `ggml_backend_graph_compute(be.backend, gf)`，**没有
`ggml_backend_sched`**。这意味着：只要图里有一个算子不被支持，整张图 compute 就失败
（不像 llama.cpp 那样按算子切分、把不支持的丢回 CPU）。

两条路：

| 方案 | 做法 | 评价 |
| --- | --- | --- |
| A. 补 kernel | 把 3 个缺口补齐，整个声码器图直接跑 GPU | **推荐**。缺口只有 3 个，其中 2 个是改写 |
| B. 引 sched | 接 `ggml_backend_sched`，逐算子切分 | 切分点会落在 snake_beta 与每次上采样上，一次 flush 几十次 CPU↔GPU 往返，UMA 上反而更慢 |

再往上还需要「分阶段后端」：`BreezeModel` 目前只有一个 `backend`，全部权重在一个 buffer。
要只让 codec 上 GPU，得给 codec 单独一个 `Backend` + 一个 buffer（124 MB F32），
其余（主干/深度/编码器）留 CPU。改动集中在 `gguf_loader.cpp` 的 `alloc_group` 与
`model.cpp`，不碰生成逻辑。

---

## 五、收益测算（基线：1.9 实测 18.9 s / 44 帧 / RTF 5.37）

| 阶段 | 1.9 实测 | 性质 | 上 GPU 的判断 | 预期 |
| --- | --- | --- | --- | --- |
| 预填充 | 1829 ms | 一次大 GEMM | ✅ 能吃满 | 3–8× → 省 1.2–1.5 s |
| 主干 | 2317 ms | 44 帧 × CFG 双分支 GEMV | ❌ 带宽瓶颈，7B 实测慢 17% | 不动 |
| 深度解码 | 6472 ms | 660 次小图 dispatch，62 GFLOPS 已压满 CPU Q8 峰值 | ❌ 更慢，且缺 top_k/argmax | 不动 |
| 声码器 | 8116 ms | 8 次转置卷积 + 大量 conv/matmul | ✅ **唯一值得搬** | 2–4× → 3.0–4.0 s |

**单做声码器 GPU**：18.9 − 4.5 ≈ **14.4 s，RTF ≈ 4.1**（保守）
再叠预填充上 GPU：≈ **12.9 s，RTF ≈ 3.7**

**要摸到 2–3，必须再加一项**：声码器 44 帧的活现在算了 101 帧（分块 flush 每次都重算 88 帧
上下文，2.3× 冗余）。这一项是纯调度改动、不换数值，1.10 里估过 8.1 s → 3.5 s。
**但它和 GPU 是同一条链上的两个旋钮，必须分开 A/B** ——1.10 的教训就是三项一起上，
听感变差无法归因。

叠满后的账面：1.8 + 2.3 + 6.5 + 1.5 ≈ **12.1 s → RTF 3.4**；再把深度解码回退到单分支
（6.5 → 3.2）才能到 **2.6**，而单分支有发音变糊的风险。

> 一句话：**GPU 能把 RTF 从 5.4 拉到 3.5–3.9，拉不到 2–3。** 到 2–3 需要 GPU + 分块
> + 深度单分支三件事，其中两件会动音质。

---

## 六、建议的推进顺序（每步有 go/no-go）

**S0 · 离线验证（0.5–1 天，不碰 App）**
写一个 `breeze-vocbench`：只加载 GGUF 里的 `codec.*` 张量，用固定码本分别跑 CPU 与
OpenCL 的 `vocoder_decode`，输出耗时 + 与 CPU 结果的 SNR/最大误差。

- 判据：**SNR ≥ 60 dB 且 GPU ≥ 2.0×** 才继续；否则这条路直接放弃，省下后面所有工作。
- 必须测两组：F32 权重×F32 激活（安全但可能不够快）、F16 权重（快，但对应 1.10 里
  70.6 dB 那条最可疑的改动）。
- 顺手量出转置卷积占声码器的比例，决定「gemm 改写」能单独拿多少。

**S1 · 消掉两个算子缺口（1 天）**
`ROLL` 改写、`CONV_TRANSPOSE_1D` 改写为「零插值 + conv_1d」。**先只跑 CPU**，与现有
实现逐样本对拍（这两处是纯代数等价，误差应 < -100 dB）。这一步单独上线就能拿到
4–7× 的转置卷积提速。

**S2 · 补 SIN + 分阶段后端（2–3 天）**
加 unary `sin` kernel；给 codec 单独一个 OpenCL `Backend` 与 buffer；加载时预热
（Adreno 的 kernel 首次编译要几秒，必须放进 `breeze_warmup`，不能落在第一次合成里）。

**S3 · 分块策略单独 A/B（0.5 天）**
只改「短句一次解完」，不动数值，用同一段文本对比 1.9 与新版音频（波形差异 +
盲听）。这一项与 GPU 完全独立。

---

## 七、风险清单

| 风险 | 说明 | 缓解 |
| --- | --- | --- |
| **驱动差异** | Adreno OpenCL 版本随 OEM 走，`cl_khr_subgroups` 等扩展不全时会退化或崩 | 启动自检（复用 1.3 的 GPU/CPU 对拍探针），失败静默回退 CPU |
| **首次编译** | ggml-opencl 运行时编译 kernel，首次可达 5–20 s | 放进 warmup；`GGML_OPENCL_KERNEL_CACHE_DIR` 落盘缓存 |
| **数值** | im2col 输出类型跟权重走：F32 权重 → 全链路 F32（安全）；一旦改 F16 就重演 1.10 | S0 固定测 F32 基线，F16 只作为可选加速档 |
| **SoC 差异** | 只有骁龙能用；天玑/麒麟上 OpenCL 后端不可用 | 后端名带设备检测，非 Adreno 直接 CPU |
| **包体** | `libggml-opencl.so` + ICD loader 约 +3–5 MB | 可接受 |
| **许可** | OpenCL Headers/ICD Loader 为 Apache-2.0，可随包分发；`libOpenCL.so` 用系统 vendor 库 | 无阻塞 |
| **预期管理** | 用户已经因为「说快了很多结果音质变差」退过一次版本 | 每个旋钮单独交付、单独 A/B，不打包上线 |

---

## 八、我的判断

- **GenieX 当作运行时：不可行，别再花时间。** 它服务的是「LLM 聊天」，Breeze 是「四阶段
  自回归声码器流水线」，两者只共享 ggml 这一层。它唯一能给的 OpenCL/HTP kernel，我们
  直接 `-DGGML_OPENCL=ON` 就能拿到，且不受它的模型管理/SDK 约束。
- **Adreno GPU 这条路：可行，但收益被架构锁死了。** 真正能吃 GPU 的只有声码器（43%）
  和预填充（10%）；占 46% 的主干+深度解码是 GEMV，GPU 反而更慢。这不是后端没选对，
  是 TTS 逐帧自回归的物理性质。
- **最划算的第一步不是 GPU，而是 `CONV_TRANSPOSE_1D` 的 gemm 改写**：纯 CPU、代数等价、
  实测 4–7×，不依赖任何驱动。做完这一步再决定要不要为剩下的部分引 OpenCL。

如果同意，我下一步就按 S0 写 `breeze-vocbench`——它不依赖真机 GPU 也能在 PC 上先验证
数值等价（CPU 侧），你在手机上只需跑一次看倍数。
