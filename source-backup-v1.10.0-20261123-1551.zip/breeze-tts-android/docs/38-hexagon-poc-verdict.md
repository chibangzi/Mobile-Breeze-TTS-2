# ggml-hexagon 接入可行性：算子覆盖 PoC 结论

> 日期：2026-11-17
> 触发：用户提出用 llama.cpp 的 ggml-hexagon（PR #16547，FastRPC 直驱 Hexagon NPU）给 BreezeTTS 生成加速、解过热问题
> 方法：静态源码核对——把 Breeze-TTS-2.cpp 的实际算子清单，对照 llama.cpp master 的 hexagon 后端算子白名单
> 工具：`tools/check_hexagon_op_coverage.sh`（本次新建，可重跑）
> **局限：全程静态分析，未在任何真机跑过（沙箱无 KVM，起不了模拟器）。**

---

## 一、结论（先说结果）

**算子层面覆盖率很高：30 个算子里 26 个被 hexagon 支持（87%），缺口 4 个且全部集中在声码器/解码器。**

这比我上一轮基于 PR #16547 初版描述的预估要乐观——当时以为卷积大面积不支持。但「算子覆盖」只是第一道关，真正的决策障碍不在算子，而在**负载性质**：TTS 的耗时大头是逐帧自回归 decode，而 decode 是内存带宽瓶颈，NPU 的算力优势使不上劲；hexagon 最能打的 prefill（长 prompt），在 TTS 里只占很小一段。

所以结论不变，但依据更扎实了：

- ❌ **不建议把「上 hexagon」当成过热的解药或主要加速手段**——理论上收益有限，且长时间生成时 NPU 的散热表现官方明确说没验证过。
- ✅ **值得保留为一条 PoC 分支**，但必须在真机上实测三段耗时（backbone / depth / vocoder）和温度曲线后再决定，不能先验地投入移植。

---

## 二、事实核实

| 项 | 核实结果 |
|---|---|
| PR #16547 真实性 | 属实。2025-10-13 提交，10-22 合入 llama.cpp master，作者 Max Krasnyansky（高通），CODEOWNERS 里 Hexagon/OpenCL 后端 owner |
| 技术路线 | 属实。ggml-hexagon 走 FastRPC 直驱 Hexagon NPU（HTP），手写 HVX/HMX kernel，不经 QNN/QAIRT SDK；与 QNN 是并行路线 |
| 支持硬件 | Hexagon v73/v75/v79/v81，目标骁龙 Gen3 / 8-Elite / 8-Elite Gen5。**本项目基线 8 Elite = v79，正好命中** |
| 支持量化 | Q4_0 / Q8_0 / MXFP4 / FP32——与本项目模型档位兼容 |
| 成熟度 | 仍标 experimental；PR 自述「may exhibit instability or limited performance」；2026 年仍在加多 NPU、DMA/buffer 重做，演进中 |
| 用户引用的性能数字 | `46.6 tok/s / 理论 49 / prefill 1680` 来自某博客在 v81/SM8845 跑 Llama-3.2-1B Q4_0 的实测；`3.8W/12.8 vs 6.2W/7.4` 来自另一篇 MLC LLM 测试。两组来源不同，不能直接拼成「ggml-hexagon 能 3.8W 跑 46.6 tok/s」 |

---

## 三、算子覆盖实测结果

方法：从 llama.cpp master 的 `htp-kparams.cpp` → `htp_op_remap()` 提取真实算子白名单（hexagon 的 `supports_op` 是动态委托 `htp_kparams_solve()`，没有静态 switch，必须挖 remap 表），对照 Breeze 源码 `ggml_*()` 调用。

### 支持的 26 个（节选主干算子）

`mul_mat` / `mul` / `add` / `sub` / `div` / `sqr` / `norm` / `rms_norm` / `rope_ext` / `soft_max_ext` / `top_k` / `argmax` / `concat` / `repeat` / `get_rows` / `scale` / `clamp` / `roll` / `pad` / `sum_rows` / `conv_1d`（展开为 im2col+mul_mat）/ `gelu` / `gelu_erf` / `exp` / `swiglu_split` 等。

→ **backbone、depth decoder、text encoder、采样、Mimi transformer 全部命中**。当前 master 还支持 `FLASH_ATTN_EXT`、`CONV_2D/3D`、`SSM_CONV`、`GATED_DELTA_NET` 等新算子，比 PR 初版宽很多。

### 缺口的 4 个

| 算子 | 调用位置 | 性质 |
|---|---|---|
| `conv_transpose_1d` | `codec_conv.cpp:26` | 声码器反卷积（上采样） |
| `elu` ×4 | `codec_conv.cpp:34/36/73/76` | 声码器激活 |
| `sin` | `codec_decoder.cpp:14` | 解码器位置编码（RoPE 类） |
| `transpose` ×9 | `codec_conv.cpp`、`codec_decoder.cpp`、`codec.cpp` | 布局转置，集中在 codec 路径 |

**4 个缺口全部落在 `codec_conv.cpp` / `codec_decoder.cpp` / `codec.cpp`——即 Mimi 声码器与解码器。** 而这些算子在通用 NPU 后端的白名单里缺失是常态（transpose 通常靠图上 reshape 消掉，elu/sin 可加 unary 映射，conv_transpose_1d 才是真硬骨头）。

### 关键洞察

`breeze.h` 的 `breeze_timings` 把生成分成：prompt / prefill / backbone / depth / vocoder / tail。其中：

- **backbone + depth** = 逐帧自回归，每帧一次，**这是 TTS 的耗时主体**，算子全被 hexagon 支持。
- **vocoder** = 每次 flush 重解 ~88 帧 context（头文件注释明确写了 25 帧浪费 4.5×、64 帧 2.4×），含全部 4 个缺口算子，**必然 fallback CPU**。
- **prefill** = 一次性编码输入文本，hexagon 最强的部分，但 TTS 输入文本短，占比小。

也就是说：**能把 NPU 跑满的部分（prefill）用得少，用得多的部分（backbone/depth 的 decode）在 NPU 上没有算力优势，而声码器那段 NPU 根本跑不了。**

---

## 四、为什么「加速 / 解过热」的期待要打折

1. **decode 是内存带宽瓶颈，不是算力瓶颈。** 用户自己引用的数字：46.6 tok/s 已达理论上限 49 的 95%，瓶颈是 LPDDR5X 带宽——已经顶到天花板，NPU 再强的矩阵算力也帮不上。TTS 主干正是逐帧 decode。
2. **实测反例：NPU decode 未必比 CPU 快。** gemma-4-E2B / v79 实测：prefill NPU 1145 vs CPU 225（NPU 5.1× 快），但 **decode NPU 28.5 vs CPU 42.5（CPU 反而 1.5× 快）**。原文结论：hybrid（NPU prefill + CPU decode）才是最强配置。
3. **长时间散热无数据。** 同实测连续 5 轮 decode：42°C → 87.2°C（未降频但已很热），作者明确写「multi-minute soak has not been run」。TTS 生成长音频正是持续负载，「解药」说法未被验证。
4. **功耗优势要打折看。** 3.8W vs 6.2W 的对比里，NPU 的 tok/s 也更低（12.8 vs 7.4 是另一口径）。若 NPU decode 更慢，省下的功耗会被拉长的时间抵消，总能耗未必占优。
5. **工程成本。** 本项目是独立 fork（`pcloth/Breeze-TTS-2.cpp` + pinned ggml `36da571`），hexagon 后端在 llama.cpp 仓库，需 backport 整套 backend registry / extra-bufs / GGML_BACKEND_API 改动，外加 Hexagon-SDK CE 6.4.0、FastRPC 运行时打包、设备端 HTP 库部署。且它仍 experimental、有 test-backend-ops 失败项。

---

## 五、建议的下一步（若要继续）

本脚本已经完成第 1 步（算子覆盖）。结论足以支持「先不大投入」，但若要推进，按顺序：

1. **判定缺口可规避性**（纯静态，可继续做）：
   - `transpose` 能否在图上用 reshape/stride 消掉（Breeze 已大量用 `cont(transpose(x))`，可能部分已消除）；
   - `elu` / `sin` 能否在 hexagon unary 映射里补两条（改动小）；
   - `conv_transpose_1d` 能否改写成「零插值 + conv_1d + 裁剪」——参考 `docs/21` 里 opencl 的同类思路；若可行，缺口可降到 0。
2. **真机 PoC**（必须，无法用沙箱替代）：用 llama.cpp 官方 hexagon preset 跑一个本项目的 Q4_0 gguf，复用 `breeze_get_timings()` 分段计时，实测 backbone/depth/vocoder 三段 NPU vs CPU 的耗时，以及连续 3–5 分钟生成的温度曲线。
3. **决策门槛**：只有当 (a) 缺口算子可规避到 0 或接近 0，(b) backbone/depth 的 decode 段 NPU 确实更快，(c) 长时生成温度压得住——三条都满足，才值得正式移植。否则维持现状。

---

## 六、产物

- `tools/check_hexagon_op_coverage.sh`：算子覆盖检查脚本（本次新建）。默认从 llama.cpp master 拉 `htp-kparams.cpp`，也支持复用缓存；以后升级 ggml / 切 hexagon 版本时重跑即可看缺口变化。
- 运行方式：`BREEZE_SRC=/path/to/Breeze-TTS-2.cpp/src ./tools/check_hexagon_op_coverage.sh`
- 本次实测基线：llama.cpp master @ 2026-11-16 拉取，Breeze 源码 @ pcloth/Breeze-TTS-2.cpp main。
