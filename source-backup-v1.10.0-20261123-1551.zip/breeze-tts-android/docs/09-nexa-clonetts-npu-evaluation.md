# 补充调研：Nexa SDK / CloneTTS 能否给本项目带来生成加速

> 调研日期：2026-11-15。针对用户提供的两条线索，核实其真实能力边界，并回答
> 「有没有办法用它实现生成加速」。
>
> **结论先说：两者都无法给现有的 Breeze TTS 2 GGUF 加速；但 CloneTTS 证明了
> 「NPU 上跑 TTS 确实能快约 2×」，并给出了一份可复制的配方。真正的加速空间不在
> 换后端，而在换模型架构——Breeze TTS 2 是 2.4 GB 的四阶段自回归模型，而 NPU
> 友好的 ZipVoice 只有 123 M 参数、非自回归、静态图。**

---

## 一、先纠正两条事实

### 1.1 CloneTTS 不是开源 App，是闭源二进制分发

直接查 GitHub API（`api.github.com/repos/sipeter/CloneTTS`，2026-11-15）：

| 项 | 实测值 |
| --- | --- |
| 仓库体积 | **99 KB** |
| 根目录内容 | 只有 `README.md` 和 `docs/` 两个目录 |
| `docs/` 内容 | 两份 Markdown：`Beginner's Guide & FAQ.md`、`Reference Audio Guide.md` |
| `language` | `null`（GitHub 未识别出任何编程语言） |
| `license` | **`null`（无开源许可证）** |
| Releases 资产 | 只有 APK：v0.7.2 = 248.9 MB，v0.7.1 = 299.5 MB，v0.7.0 = 287.5 MB |
| 热度 | 891 stars / 29 forks / 0 open issues |

也就是说，仓库**没有一行可编译源码、没有 Gradle 工程、没有 JNI/C++ 代码、没有 LICENSE**。
README 第 9 节「致谢」列出的是它依赖的开源组件，不是它自己开源。它是
**闭源 APK + 使用文档 + 致谢清单**，法律上也未授予任何使用／修改其代码的权利。

因此用户描述的「专注 TTS 的开源 App……适合直接使用而非二次开发」应修正为：
**可以安装使用，但连"二次开发"的入口都不存在**；能借鉴的只有它公开的技术选型（下一节）。

### 1.2 Nexa SDK 的「GGUF + TTS + NPU」是三条独立能力，交集为空

NexaSDK 的 README 顶部写着「supports ONNX and GGML models … ASR, and TTS …
runs … on NPU, GPU, and CPU」，功能对比表里也有 `Full multimodality support …
TTS`。但把具体条款摊开看，这三者**不能同时成立**：

| 能力 | 官方条款原文口径 | 落地条件 |
| --- | --- | --- |
| 支持 GGUF | "GGUF runs on macOS, Linux, and Windows **on CPU/GPU**"；Android SDK 支持 `GGUF, NEXA` | GGUF 走 `plugin_id=cpu_gpu`，**不上 NPU** |
| 支持 TTS | 老版 CLI/Python 模型表里有 `bark-small`(fp16)、`OuteTTS-0.1-350M`、`OuteTTS-0.2-500M`(q4_K_M)，均为 GGUF | 三个官方适配好的固定模型，走 `nexa run`，仍是 CPU/GPU |
| 跑 Hexagon NPU | `plugin_id="npu"` + `model_path=.../files-1-1.nexa`；模型名形如 `NexaAI/OmniNeural-4B`、`Granite-4.0-h-350M-NPU` | **必须是 `.nexa` 专有格式**，由 Nexa 官方转换/编译 |

补充两条硬约束：

- **Android SDK 的模型类型清单里没有 TTS**。README 的 Android 段落写的是
  `Models: LLM, Multimodal, ASR, OCR, Rerank, Embedding`；CLI 段落同样是
  `LLM, Multimodal, ASR, OCR, Rerank, Object Detection, Image Generation, Embedding`。
  TTS 只出现在框架级的功能对比表和 Python/CLI 的老模型表里。
- **NPU 组件不是 Apache-2.0**。NexaSDK 双许可：CPU/GPU 组件 Apache-2.0；
  NPU 组件「个人使用需从 Nexa AI Model Hub 申请免费 license key，**每个 key 只激活 1 台设备**；
  商用需联系 hello@nexa.ai」。Android NPU 还要求 `minSdk 27` + Snapdragon 8 Gen 4
  （即 8 Elite）以上。

**结论**：Nexa 的 GGUF 路径与 NPU 路径是互斥的两条管线；它的 TTS 是几个官方适配的
小模型，不是通用 GGUF 加载器；Breeze TTS 2 既不是 `.nexa`，也不在其模型清单里。
想让它跑，只能走 Nexa 的 Wishlist / model launching partner 让官方做模型适配，
再引入闭源 NPU 组件与逐设备授权——这已经不是"加速"，而是换整套运行时加商业谈判。

---

## 二、CloneTTS 到底做了什么，为什么能 2×

### 2.1 公开的技术栈（README 第 9 节致谢）

| 组件 | 角色 |
| --- | --- |
| **sherpa-onnx** | 端侧 C++ 推理流水线、Kotlin/Java API |
| **ZipVoice** | 零样本音色克隆声学模型（小米 / k2-fsa，Flow Matching + Zipformer） |
| **ONNX Runtime** | 推理引擎 |
| **Qualcomm AI Engine Direct SDK (QNN/QAIRT)** | Hexagon NPU 后端 |
| NanoHTTPD | 本地 HTTP 服务 |

ZipVoice 的关键性质：**123 M 参数的 Distill 版、非自回归 flow matching、整句并行出帧**，
`num_steps` 只有 2/4/8（README 推荐 2，FAQ 推荐 4，最大 8），论文/项目页称在 CPU
单线程上即可接近实时（RTF≈1）。int8 量化后的模型包约 200 MB。

### 2.2 NPU 模式的实现细节（来自其官方 FAQ Part 3）

| 事实 | 数值 / 行为 |
| --- | --- |
| 支持芯片 | 8 Gen 2 / 8 Gen 3 / **8 Elite** / **8 Elite Gen 5** |
| 加速包 | **额外下载 600–740 MB**，按芯片架构分 **4 个版本**的 `.bin`，App 内在线下载或本地导入，自动校验 hash 与 SoC 匹配 |
| 首次切换 | 约 **10 秒 "Preparing…"**（QNN 图编译 / context binary 加载） |
| 效果 | 约 **2× CPU**、整机温度低约 **10 °C**；**音质与标准模式完全一致（同模型，只换算力）** |
| 线程 | NPU 生效后 CPU 只做文本编码等辅助任务，自动降到 **2 线程**（可手动设 1） |
| 回退 | 三级：不支持→不显示卡片；NPU 初始化失败→重建为纯 CPU；**超长文本段超出 NPU 处理上限→该段单独回退 CPU** |
| 建议 | 参考音频 ≤ 8 秒（更长会更容易触发超长段回退） |

这些细节与 sherpa-onnx 官方 QNN 文档完全对得上：QNN 路径用的不是普通 `.onnx`，
而是**按芯片预编译的 QNN context binary**（官方示例里 SenseVoice int8 的
`libmodel.so` 就是 227 MB），Kotlin 侧配置形如
`provider="qnn"` + `QnnConfig(backendLib="libQnnHtp.so", systemLib="libQnnSystem.so", contextBinary=...)`。
所以才需要按 SoC 分发 4 个包、才有 10 秒准备时间、才会"超长段回退 CPU"——
**NPU 跑的是静态 shape 的预编译图，动态 shape 天然受限。**

### 2.3 为什么这条路能成，而我们的 Vulkan 不能

1.3 版已经论证过：Breeze TTS 2 逐帧自回归（12.5 帧/秒）+ CFG=4 双分支 KV cache，
是 DRAM 带宽瓶颈，Vulkan 上还因 fp16 出杂音。ZipVoice 恰好相反——**一次前向把整句
声学特征算完，是一整块大 GEMM + 固定 shape 子图，能一次性 offload 到 HTP 并常驻**。
sherpa-onnx / react-native-nitro-onnx 的文档也把这条边界写得很直白：
*"HTP only helps when the encoder is offloaded as one large subgraph and stays
resident"*，流式逐帧模型反而常常比 CPU 慢。

**所以 CloneTTS 的 2× 是可信的，但它证明的是「NPU 适合小体量、非自回归、静态图
TTS」，不是「NPU 能给任意 TTS 提速」。**

---

## 三、对本项目：现有 Breeze GGUF 能不能借它们上 NPU

逐条封堵，四条独立理由，任一条都足以否决：

| # | 障碍 | 具体证据 |
| --- | --- | --- |
| 1 | **格式不对** | 我们的模型是 `HoppouAI/Breeze-TTS-2.cpp` 的 Q4_K 2.4 GB / Q6_K 2.9 GB / Q8_0 3.3 GB / F16 5.9 GB。Nexa NPU 只吃 `.nexa`；GenieX/llama.cpp 的 GGML Hexagon 后端**只有 Q4_0 支持 NPU**，Q8_0 / F16 / Q4_K_M / Q5_K_M 明确只能 GPU/CPU；sherpa-onnx QNN 要的是预编译 context binary，根本不加载 GGUF |
| 2 | **算子与计算图不对** | Breeze 是 T5Gemma2 文本编码器 → Qwen3 主干 → RVQ 深度解码器 → 语音解码器/codec 四段串行，含 `conv_transpose_1d`（1920× 上采样）、`get_rows`（RVQ 码本）、`sin/exp/sqr/div`（snake_beta）、带 `-inf` mask 的 `soft_max_ext`。GGML Hexagon / QNN 只覆盖 `ADD/MUL_MAT` 这类常见 LLM 算子，且不向外部暴露通用 ggml graph 的 NPU 执行接口 |
| 3 | **动态 shape 冲突** | 自回归逐帧、变长文本、CFG=4 的两份 KV cache、分块 flush，全是动态 shape；QNN 要预编译静态图，CloneTTS 自己都得为"超长段"留 CPU 回退。1.3 文档第 4.3 节的六个障碍在这里同样成立 |
| 4 | **许可与源码** | CloneTTS 无源码无 LICENSE，抠不出后端；Nexa NPU 组件闭源 + 逐设备 license key + 商用另谈；QNN 运行库受 Qualcomm 条款约束，社区项目普遍不敢随 APK 再分发 |

顺带说清 GenieX（用户提到的对照物）：它的 `llama_cpp` 运行时确实宣称「任意 GGUF
走 Hexagon NPU」，但那是 **llama.cpp 内部针对 LLM 算子实现的 GGML Hexagon backend**，
并受 Q4_0 量化限制；`qairt` 路径更窄，只吃 Qualcomm AI Hub 按芯片预编译的 bundle
（精度、context、KV cache 全部烤死，Android 上连 `nCtx` 都不让改）。Breeze TTS 2
既不是标准 LLM 架构，也不在 AI Hub 上，两条路径都进不去。GenieX 自身虽是 BSD-3-Clause，
但仍受 Qualcomm Terms of Use 与 RAIL 使用限制（个人非商用）。

**一句话：现有 1.3 APK 的 Breeze TTS 2 生成，靠这三家都加速不了。**

---

## 四、真正可行的路：换模型架构，而不是换后端

这是本次调研最有价值的结论。**加速的大头来自模型，NPU 只是再乘一个 2**：

| | Breeze TTS 2（现状） | ZipVoice-Distill（CloneTTS 同类） |
| --- | --- | --- |
| 体量 | Q4_K 2.4 GB（F16 5.9 GB） | 123 M 参数，int8 约 200 MB |
| 生成范式 | 四阶段自回归，12.5 帧/秒逐帧，CFG=4 双分支 | Flow Matching 非自回归，整句并行，2–8 步 |
| 桌面参考速度 | RTX 3060 + Q8_0 约 **1.5× 实时**（52 ms/帧，深度解码器占 34 ms） | 论文/项目页称 CPU 单线程即近 RTF≈1 |
| NPU 适配 | 动态 shape、KV cache、自定义算子 → 不适配 | 静态图、固定 shape 桶、整块大 GEMM → 适配，实测 ~2× |
| 指令/情绪 | **Voice Design（纯文字描述造音色）+ Voice Direction（引导语调/情感/语速）+ 内联 `[笑]`/`(sigh)` + CFG=4 强化遵从** | **只有 text + 参考音频 + 参考文字稿 + num_steps/语速**，没有 instruction 通道，没有语音设计 |
| 权重许可 | BreezeBlue Research and Non-Commercial License | 社区打包说明基于 Emilia 数据集，CC-BY-NC-4.0（同样非商用，需核对具体模型卡） |

注意最后一行的能力差：**换 ZipVoice 会丢掉本项目最核心的"用各种音色遵从表达/情绪指令"
以及 1.1 专门拆分出来的「音色设计」页**。所以它不是"升级"，是"另一种用途"。

### 建议做成双引擎，而不是替换

| 引擎 | 后端 | 用途 | 保留能力 |
| --- | --- | --- | --- |
| **Breeze 导演模式**（现有） | ggml / CPU（1.3 默认） | 音色设计、情绪/表达指令、高保真克隆 | 全部现有功能 |
| **ZipVoice 快速模式**（新增） | sherpa-onnx + ONNX Runtime，可选 QNN NPU | 长文本朗读、纯音色克隆、追求 RTF 与低发热 | 音色库、ASR 转写、历史、播放、导出、UI 全部复用 |

这样用户要在「慢但能导演」和「快但只能照着念」之间自己选，不牺牲任何现有能力。

---

## 五、方案 B 的落地清单（如果要做）

好消息：**工程里已经有 sherpa-onnx 1.13.8 + ONNX Runtime 1.28.2**（1.2 为 SenseVoice
ASR 引入的 `libonnxruntime.so` / `libsherpa-onnx-*.so` 与 `sherpa-onnx-classes.jar`）。
实测 `libonnxruntime.so` 内含 `QNNExecutionProvider` / `QnnHtpShared` 符号，说明 QNN EP
已编入 ORT；但工程**没有打包任何 QNN 后端库、没有 `SHERPA_ONNX_ENABLE_QNN` 构建、
也没有 QNN context binary 模型**，当前实际走 CPU/NNAPI。要补的是下面这些：

1. **拿 QAIRT / QNN SDK**（官方示例用 v2.40.0+），或走 Maven
   `com.qualcomm.qti:onnxruntime-android-qnn:2.6.0` + `com.qualcomm.qti:qnn-runtime:2.50.0`
   （约 210 MB arm64 库，需接受 Qualcomm AI Hub Model License，**不能随意再分发**）。
2. **打包 QNN 运行库**（官方示例体积）：`libQnnHtp.so` 2.4 MB、
   `libQnnHtpPrepare.so` **71 MB**、`libQnnSystem.so` 2.5 MB；再加按 SoC 的一对
   Stub/Skel：**8 Elite = V79**（Skel 9.6 MB + Stub 562 KB）、**8 Elite Gen 5 = V81**
   （Skel 10 MB + Stub 618 KB）。Skel 放 assets，运行时设 `ADSP_LIBRARY_PATH`。
   裁剪后 APK 预计从 41 MB 涨到 **约 120–150 MB**。
3. **重编 sherpa-onnx 带 `QNN_ROOT`**（定义 `SHERPA_ONNX_ENABLE_QNN`），或改用其
   QNN 预编译产物；现有 `libsherpa-onnx-*.so` 需替换。
4. **准备 ZipVoice 的 QNN 模型**：不是普通 ONNX，要按 HTP V79/V81 预编译出
   context binary（CloneTTS 那 600–740 MB 的加速包就是这个）。首次加载约 10 秒图编译，
   需缓存 context binary；按 CloneTTS 的经验做三级回退（无包→CPU、初始化失败→CPU、
   超长段→CPU）。
5. **代码改动点**（沿用现有分层，不动 ggml 侧）：
   - `engine/` 新增 `ZipVoiceEngine.kt`（sherpa-onnx Kotlin `OfflineTts` + `provider` 配置）
   - `vm/AppViewModel.kt` 增加引擎选择，按模式路由 `synthesize()`
   - `ui/SynthesizeScreen.kt` 加「导演模式 / 快速模式」切换；快速模式下隐藏 instruction 与音色设计入口（该模型不支持）
   - `data/ModelRepository.kt` 增加 ZipVoice 模型包下载/校验/按 SoC 选 V79/V81
   - `audio/AudioDecoder.kt`、`HistoryRepository`、`Playback`、导出链路**完全复用**
6. **风险与代价**：QNN 库许可与分发；ZipVoice 权重 CC-BY-NC-4.0 非商用；包体涨 3 倍；
   QNN 首次编译耗时；真机未验证（沙箱无设备）；`provider="qnn"` 绝不自动启用，
   必须做 CPU 基准 A/B，官方明确警告 QNN 可能比 CPU 更慢。

### 更保守的第一步（推荐先做这个）

**先只加 ZipVoice-Distill int8 的 CPU 引擎，完全不碰 QNN。** 用同一套 sherpa-onnx
依赖、约 200 MB 模型、APK 几乎不涨，先在真机上量出 CPU RTF，与 Breeze 的 RTF 对比。
如果 123 M 非自回归已经把速度拉到够用，就没必要背 QNN 的 100 MB 库和许可包袱；
如果还不够，再按上面的清单加 NPU。**换模型本身就是最大的一次提速。**

---

## 六、结论与建议

| 问法 | 回答 |
| --- | --- |
| Nexa SDK 能给现有 App 加速吗？ | **不能**。GGUF 与 NPU 互斥；Android SDK 不支持 TTS；NPU 需 `.nexa` + 官方适配 + 逐设备授权 |
| CloneTTS 能拿来改吗？ | **不能**。仓库无源码无 LICENSE，只有 README + 文档 + 闭源 APK |
| 那 NPU 加速 TTS 是假的吗？ | **不是**。它在 ZipVoice 上实测约 2×、低约 10 °C，可信；但成立前提是「小模型 + 非自回归 + 静态图 + 预编译 context binary」 |
| 我们有没有办法真的提速？ | **有，但要换模型**：新增 ZipVoice 快速引擎做双引擎。先做纯 CPU 版量 RTF，再决定是否上 QNN。代价是丢掉指令/情绪/音色设计能力、包体与许可成本 |

**排序建议**：① 先做 ZipVoice-CPU 双引擎（低风险、复用现有 sherpa-onnx、量出真实 RTF）
→ ② 若 RTF 仍不够且能接受 QNN 许可，再加 V79/V81 NPU 包 → ③ 保留现有 Breeze 导演模式不动。
不推荐的路径：等 Nexa 官方适配 Breeze、或把 Breeze 四阶段整体重导出到 QNN
（1.3 文档第 4.4 节路径 C，工程量与许可风险都极高）。

> 本次只做调研，**未改动 1.3 APK、未重新编译**；`dist/BreezeTTS-1.3-release.apk`
> 仍是当前交付版本。沙箱无 2.4 GB 权重与 Android 真机，以上性能数字均来自
> 项目方公开资料与官方文档，未在本项目真机复现。

---

## 七、主要来源

- [sipeter/CloneTTS README](https://github.com/sipeter/CloneTTS/blob/master/README.md) 与
  [Beginner's Guide & FAQ（NPU 细节）](https://github.com/sipeter/CloneTTS/blob/master/docs/CloneTTS%20Beginner%27s%20Guide%20%26%20FAQ.md)；
  仓库元数据经 GitHub API 核实（2026-11-15）
- [NexaAI/nexa-sdk README](https://github.com/NexaAI/nexa-sdk)（含 Qualcomm 官方 fork 的
  [README 原文](https://github.com/qualcomm/nexa-sdk/blob/1915274c/README.md?plain=1)）；
  [DeepWiki：Supported Models and Hardware Backends](https://deepwiki.com/qualcomm/nexa-sdk/1.2-supported-models-and-hardware-backends)
- [Qualcomm GenieX：Platforms & runtimes](https://geniex.aihub.qualcomm.com/en/get-started/platforms)、
  [On-Device LLM Inference on Android using GenieX](https://qualcomm.github.io/qidk/blogs/geniex_android.html)
- [sherpa-onnx QNN：Build Android examples](https://k2-fsa.github.io/sherpa/onnx/qnn/build-android-demo.html)、
  [QNN 模型与 provider 配置](https://github.com/k2-fsa/sherpa-onnx)
- [ZipVoice 项目页](http://zipvoice.github.io/) / [k2-fsa/ZipVoice](https://github.com/k2-fsa/ZipVoice)
- [BreezeBlue/Breeze-TTS-2 模型卡](https://huggingface.co/BreezeBlue/Breeze-TTS-2/blob/main/README.md)
  （Voice Design / Voice Direction / `--cfg-scale 4`）
- 本项目 [`docs/08-v1.3-vulkan-npu.md`](08-v1.3-vulkan-npu.md)（Vulkan 杂音与 NPU 六障碍）、
  [`docs/02-gguf-backend.md`](02-gguf-backend.md)（GGUF 量化档位与 C API 契约）
