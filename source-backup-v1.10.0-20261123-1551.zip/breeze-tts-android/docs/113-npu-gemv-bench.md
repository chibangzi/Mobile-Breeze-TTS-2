# NPU 判定实验：单层 GEMV 微基准

> 日期：2026-11-22
> 触发：Q4 模型实测「速度没有明显优势」，需要判定 NPU 路线是否还有价值
> 产物：`tools/hexagon-bench/`（可执行文件 + 源码 + 说明）、`dist/hexagon-bench-20261122.zip`

---

## 一、为什么 Q4 不快，以及这为什么重要

把两组数放一起：

| | 权重字节/帧 | 实测深度耗时 | 折算带宽 |
| --- | --- | --- | --- |
| Q8_0 | 5.31 GB | ~96 ms | **55 GB/s** |
| Q4 | 2.65 GB | 只快一点点 | **~28 GB/s** |

Q8 时带宽接近 LPDDR5X 可用上限（65–70 GB/s），Q4 时反而腰斩。如果瓶颈是「读字节」，Q4 应该快一倍。

原因是 ARM repack 内核里 Q8_0 与 Q4 的形态差异：

- Q8_0 的 repack 布局让 int8 直接排好，GEMV 每 128 字节只要 8 条 `vdotq_s32`，零解包；
- Q4 的 4 bit 必须先展开成 int8（`vand` + `vshr` + 拼接 + 乘 scale），每 64 字节要 14–16 条指令。

每字节指令数涨 1.8–2 倍，字节省一半，两者相乘约等于 1 —— 这就是「没有可感优势」的完整解释。

> 推论一：Q3/IQ3/Q2 只会更差，CPU 上的精度路线到此终结。
> 推论二：如果 Q4 想复活，只有换一个「4 bit 解包不占指令发射」的执行单元，即 GPU 或 NPU。

而 GPU 这条被 TFLite 卡住：GPU delegate 不接受 4 bit 权重，进去第一件事就是反量化成 int8/FP16，字节优势当场消失。**于是 NPU 成了 Q4 唯一的现实载体。**

## 二、但这个推论有个未验证的前提

上面说「NPU 能解除指令瓶颈」，隐含假设是 NPU 在**批 = 1 的 GEMV** 上带宽不差。这个假设很可疑：

- NPU 的矩阵引擎为大 batch 设计，n=1 时利用率极低；
- 每次算子下发都有 FastRPC 往返 + DMA 设置；
- llama.cpp 社区在 gemma-4-E2B / v79 上的实测是：prefill NPU 比 CPU 快 5.1 倍，但 **decode NPU 28.5 tok/s vs CPU 42.5，CPU 反而快 1.5 倍**（见 docs/38）。

TTS 的 depth 解码正是 decode 形态。所以「NPU 一定更快」很可能不成立，必须实测。

## 三、实验设计

用 ggml 自己的内核做单层 GEMV，不走 App、不走 QNN：

- 形状：`[1024, 2816]`（depth 的 FFN 半宽）、`[1024, 3072]`（qkv 合并后的宽度）、`[2048, 2048]`（对照方阵）；
- 权重类型：Q8_0、Q4_0、Q4_K；
- 后端：CPU（4 线程，与 App 默认一致）与 Hexagon HTP；
- 每组合预热 5 次、计时 200 次，同时记录平均与最快一次。

**为什么不走 QNN**：QNN 是独立 SDK（约 2–3 GB，需注册），环境里没有；而 ggml-hexagon 是 llama.cpp 已合入的后端，源码在手，且同样支持 Q4_0/Q8_0。用它能把「NPU 在 GEMV 上的带宽」这个变量单独拎出来。

**为什么用最快一次**：HTP 的下发延迟有抖动，平均值会被首次调度的尖峰拉高；`min` 更接近纯计算能力。两个都打印，判读时以平均为主、`min` 佐证。

## 四、判据

| HTP 带宽 | 结论 | 下一步 |
| --- | --- | --- |
| ≥ 70 GB/s | NPU 确实解除了指令瓶颈 | Q4 + NPU 立项，depth 96 → 40 ms |
| 50–70 GB/s | 与 CPU 持平 | 只做 backbone（无 15 遍放大），depth 放弃 |
| < 50 GB/s | NPU 在 GEMV 上无优势 | Q4 与 NPU 一起收摊 |

参考量级：depth 每帧 5.31 GB（Q8），若 HTP 达到 70 GB/s，单帧 76 ms；若 Q4 在 HTP 上也能维持 70 GB/s，则 2.65 GB → 38 ms。

## 五、主机侧验证：现象在 x86 上同样复现

工具编完后先在 x86 上跑了一遍（同样代码、同样 ggml，只是后端换成 x86 CPU），用来确认逻辑正确。结果比预期更有价值：

```
CPU  q8_0  1024 x 2816   0.163 ms/次   18.8 GB/s
CPU  q4_0  1024 x 2816   0.165 ms/次    9.9 GB/s
CPU  q4_K  1024 x 2816   0.159 ms/次   10.2 GB/s
```

**Q4_0 的有效带宽只有 Q8_0 的 53%**，而 ARM 上的实测比值是 28/55 = 51%。两个完全不同的架构、两套不同的 SIMD 内核（x86 AVX2 vs ARM i8mm），比值几乎一致。

这说明「Q4 在 GEMV 上掉带宽」不是 ARM repack 的实现缺陷，而是 **4 bit 权重在批 = 1 时的普遍规律**：字节省一半，解包指令涨近一倍，净收益接近零。

附带一个观察：Q4_K 在 x86 上比 Q4_0 略快（10.2 vs 9.9），但都不到 Q8 的六成。这也解释了为什么之前 Q8→Q4_K 的真机对比「无可感差异」。

## 六、局限（必须说清）

1. **HTP 路径没有在真机上跑过。** 沙箱无骁龙设备，只完成了交叉编译与打包。同一份源码在主机上跑通并复现了 Q4 掉带宽的现象（见第五节），但 HTP 的运行时行为、kernel 质量、会话建立全部未经验证。
2. **unsigned PD 可能被拒。** ggml-hexagon 走 `FASTRPC_CONTROL_UNSIGNED_MODULE`，零售设备多数允许，但部分 ROM 会返回 `0x80000406`。README 里给了排查表。
3. **需要 adb。** FastRPC 访问 CDSP 通常不给普通 App，必须在 `adb shell` 里执行。
4. **ggml-hexagon 仍标 experimental**，Q4_0 在 v79 上的 kernel 质量未经本项目验证；若某类型直接不支持，程序会打印「分配不了」并继续下一个。

## 七、产物

| 路径 | 内容 |
| --- | --- |
| `tools/hexagon-bench/bench_gemv.cpp` | 源码，约 200 行，无外部依赖（除 ggml） |
| `tools/hexagon-bench/out/` | arm64 可执行文件 + 4 个 ggml 库 + 4 份 HTP skel + `run.sh` |
| `tools/hexagon-bench/README.md` | 推送、运行、失败排查 |
| `dist/hexagon-bench-20261122.zip` | 以上打包，5.7 MB |

构建：ggml 0.22.0（`GGML_HEXAGON=ON`）+ Hexagon SDK 6.4.0.2（Tools 19.0.04）+ NDK 27.1，`ANDROID_PLATFORM=android-28`。

## 八、跑完怎么读

把 `sh run.sh` 的完整输出发回即可。判读顺序：

1. 先看 `后端列表` 里有没有 Hexagon，没有就是加载问题，不是性能问题；
2. 看 `Hexagon Arch version`，若显示 v73 而非 v79，说明探测失败，结果只能定性不能定量；
3. 同形状下比 CPU 与 HTP 的 GB/s；
4. 特别注意 **Q4_0 在 HTP 上是否也掉到 28 GB/s** —— 若掉，说明 NPU 也在解包上受限，整条路线判死；若维持 55+，说明解包确实被硬件吸收了，Q4 的价值成立。
