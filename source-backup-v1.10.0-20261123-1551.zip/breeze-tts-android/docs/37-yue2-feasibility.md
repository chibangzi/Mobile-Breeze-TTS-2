# YuE2 音乐生成模型落地 Android App 可行性调研

调研日期：2026-11-17 · 结论：**技术上可行，但不建议现在装进正式版**。

---

## 一、结论先行

| 问题 | 结论 |
|---|---|
| 有没有可用的量化版模型？ | **有，而且不止一家。** GGUF 量化已成熟，最小约 1.9GB，还有专门的移动端 Q4 文件 |
| 能不能在我们的 App 里本地跑？ | **能。** 推理引擎 audio.cpp 与我们现用的 `Breeze-TTS-2.cpp + ggml` 是同一套技术栈，甚至同一个项目已同时支持 BreezeTTS 2 和 YuE2 |
| 现在适合装吗？ | **不建议进正式版。** 三个硬伤：模型体积、手机端推理耗时、权重**禁止商用**（CC BY-NC 4.0） |

一句话：**引擎这关基本是现成的，卡点在模型体积、手机算力和许可证。** 如果你的 App 是面向爱好者/研究用途、能接受几百 MB 到 2GB 的下载和分钟级等待，可以做一个实验性入口；如果要商用或追求流畅体验，先别碰。

---

## 二、YuE2 是什么

YuE2 是 m-a-p（Multimodal Art Projection，HKUST 等机构）在 **2026 年 9 月**发布的开源歌曲生成模型，是 2025 年初 YuE（v1）的继任者。

- **参数量**：约 3.58B（官方口径 3B 档）
- **架构**：单个 28 层 MoT（Mixture-of-Transformers），AR 专家自回归写乐谱和语义 token，NAR 专家用 flow matching 一次性去噪出声学 latent，再由 VAE 解码成 **48kHz 立体声**
- **输入**：风格描述 + 歌词；可先产出**可编辑的 ABC 乐谱**（旋律/和弦/结构），再演奏成带人声与伴奏的完整歌曲
- **亮点**：乐谱可改、可翻唱、可对话式编辑；盲测 best-of-8 下对 Suno v4.5 胜率 57.3%，对 Suno v5 基本打平
- **速度参考**：RTX 4090 上生成 3.6 分钟歌曲约 71 秒（RTF≈0.33）；8GB 显卡用 Q4 量化 RTF≈0.20（221 秒音频约 44 秒）

> ⚠️ 注意版本号混淆：网上「YuE / YuE v1 / YuE2 / ACE-Step」是几代不同产物。YuE v1 是 7B+1B 两阶段；**YuE2 是 3.6B 单模型**；ACE-Step 是同一团队的另一条产品线。社区里有个别页面把 "YuE2" 标成 0.677B，那是把转录用的 SheetSage2 组件当成主模型了，别被误导。

---

## 三、可用的量化版模型（重点）

### 3.1 官方/半官方 GGUF 仓库：`audio-cpp/Yue2-3B-GGUF`

这是最值得用的一家，**audio.cpp 原生权重**，已并入主分支，ModelScope 和 GitCode 都有镜像（国内可直连）。仓库总计约 17.6GB（含试听样例）。

| 文件 | 作用 |
|---|---|
| `yue2-3b-bf16.gguf` | 主模型 BF16 全精度 |
| `yue2-3b-q8_0.gguf` | 主模型 Q8_0 量化 |
| `yue2-3b-q4_0.gguf` | 主模型 Q4_0 量化，**8GB 显存可跑** |
| **`yue2-3b-ios-q4_0.gguf`** | **专门面向移动端（iOS）的 Q4_0 版本** |
| `yue2-vae-f32.gguf` / `yue2-vae-f16.gguf` | VAE 解码器，把 latent 还原成 48kHz 立体声（F16 约 265MB） |
| `sidecars/*.json` + `yue2-qwen.tiktoken` | 模型结构、生成默认参数、Qwen 分词器、VAE 配置 |

**生成必须三件套齐备**：主模型 GGUF + VAE GGUF + `sidecars/` 目录。

地址：
- ModelScope：`modelscope.cn/models/audio-cpp/Yue2-3B-GGUF`
- GitCode 镜像：`gitcode.com/hf_mirrors/audio-cpp/Yue2-3B-GGUF`

### 3.2 社区量化：`jagamypriera/Yue2-3B-GGUF-Quantized`（Hugging Face）

**这家明确写了「for use with audio.cpp and the Radio Android app」** —— 也就是已经有人把 audio.cpp + YuE2 跑在 Android App（Radio）上了，这是最直接的移动端可行性证据。

| 量化档 | 体积 |
|---|---|
| Q2_K | 1.92 GB |
| Q6_K | 3.49 GB |
| F16（VAE） | 265 MB |

共 25 个量化版本可选。地址：`huggingface.co/jagamypriera/Yue2-3B-GGUF-Quantized`

### 3.3 第三方量化：`thepatch/YuE2-3B`（ggufmodels.com 收录）

| 量化档 | 文件体积 | 估算内存占用（8K 上下文） |
|---|---|---|
| Q4_K_M | 2.53 GB | ~4.0 GB |
| Q8_0 | 3.91 GB | ~5.3 GB |
| BF16 | 7.26 GB | ~8.7 GB |

### 3.4 选型建议（手机端）

- **起步**：Q4 主模型（约 2–2.5GB）+ VAE F16（265MB），合计 **约 2.3–2.8GB 下载**
- 这个体积对 App 是很大一坨：需要按需下载、断点续传、外置存储，且低端机装不下
- 平台里已有 `ModelDownloadService` + `ModelCatalog` + `ModelRepository` 这套下载/校验框架，可以直接复用

---

## 四、推理引擎：audio.cpp —— 关键突破口

这是这次调研最重要的发现。

**audio.cpp**（GitHub：`0xShug0/audio.cpp`，约 4.3k stars）是「音频版的 llama.cpp」：纯 C++ 17 + ggml，无 Python 依赖，一个二进制支持 80+ 音频模型家族。

- **它官方支持 BreezeTTS 2** —— 也就是我们 App 现在用的内核。换句话说，我们已经在用它的「近亲」甚至同一套代码
- 同时支持 **YuE2、Stable Audio、ACE-Step、HeartMuLa** 等音乐生成模型
- **后端**：CPU（默认，NEON 优化）、CUDA、ROCm、Metal（Apple Silicon）、**Vulkan（跨平台，含 Android 可用）**、可选 RKNN NPU
- **嵌入方式**：提供 **C API**、HTTP server（`/health`、`/v1/models`、`/v1/recipes`）、内嵌 WebUI；可作为库 link 进自己的程序
- **构建**：CMake，`-DENGINE_ENABLE_VULKAN=ON` 等开关；预编译包覆盖 Windows/Ubuntu/macOS
- 版本很活跃（v0.9.x，2026-11 仍在更新），YuE2 能力约在 0.8.x 后进入主分支，0.8.1 起支持 LoRA

**对我们的意义**：不需要从零写推理。理论上可以把现有 `libbreeze_gguf.so` 换成/升级成 audio.cpp 的 so，通过一个统一的 C API 同时撑起 TTS 和音乐生成。Android 端交叉编译路径清晰，`jniLibs/arm64-v8a` 的现成结构可以直接套。

---

## 五、可行性逐项评估

| 维度 | 评估 | 说明 |
|---|---|---|
| **引擎对接** | ✅ 低风险 | audio.cpp 与我们同源，C API + JNI 桥接模式现成（现有 `BreezeEngine` 就是这套） |
| **模型获取** | ✅ 低风险 | 多家 GGUF，国内 ModelScope 镜像可直连，已有下载框架可复用 |
| **模型体积** | ⚠️ 高成本 | 2.3–2.8GB，远超当前 TTS 模型；需按需下载 + 提示用户存储 |
| **手机算力** | ❌ 高风险 | 官方数据全是 PC/4090/8GB 显卡。**手机 CPU 没有实测数据**。3B 模型逐 token AR + 32 步 flow matching 解码，在骁龙上大概率是「一首歌几分钟到十几分钟」，且 4GB 内存占用对手机很吃紧 |
| **音频链路** | ⚠️ 需改造 | YuE2 输出 48kHz **立体声**；我们现有管线是 24kHz 单声道（`SAMPLE_RATE = 24_000`），播放器、WAV 导出、波形组件都要扩 |
| **许可证** | ❌ 硬障碍（商用） | 权重 **CC BY-NC 4.0，禁止商用**。代码 Apache-2.0，但模型权重非商用。个人/创作者可用并售卖生成的歌，但**把它集成进 App 分发**属于另一回事，商用需单独授权 |

> 许可证补充：我们 App 现有的 Breeze 权重本身也是「Research and Non-Commercial License」（About 页已写明）。所以从「产品整体非商用定位」看，加一个非商用音乐模型并不比现状更糟；但只要未来要商用，这就是必须清理的债。

---

## 六、如果要做，建议的路径

1. **先做 PoC，不进主线**：单独分支，用 audio.cpp 官方预编译的 Android/Vulkan so（或交叉编译），JNI 层照抄现有 `BreezeEngine` 结构
2. **最小验证集**：Q4 主模型 + VAE F16 + sidecars，先在一台 12GB 内存的旗舰机上跑通「风格 + 歌词 → 30 秒音频」
3. **实测 RTF**：拿到真机数据再决定。若 RTF > 5（即 1 分钟音频要 5 分钟以上），体验上就只适合「后台生成 + 完成通知」
4. **UI 定位**：做成独立「音乐」标签页，而不是塞进现有朗读流程。输入风格描述 + 歌词，可选 cot 模式（off/full/melody）
5. **音频链路扩展**：采样率从固定 24k 改为跟随文件；导出 WAV 支持 48k 立体声；波形组件适配双声道
6. **许可证确认**：明确 App 分发定位；若商用，先联系 m-a-p 申请权重授权

---

## 七、信息来源与可信度

**一手来源（已直接核对）**
- ModelScope `audio-cpp/Yue2-3B-GGUF` 模型卡：文件清单、体积、许可证
- Hugging Face `jagamypriera/Yue2-3B-GGUF-Quantized` 模型卡：量化档体积、"Radio Android app" 表述
- `deepwiki.com/multimodal-art-projection/YuE`：模型目录与权重解析机制
- 本仓库 CMakeLists.txt / BreezeEngine.kt：确认现有引擎为 `Breeze-TTS-2.cpp + ggml`、24kHz 单声道

**二手来源（聚合/媒体，数字仅供参考）**
- songcreator.pro、neurohive.io、siliconnoon.com：发布信息、参数量、盲测数据、RTF
- vibecontent.net、CSDN、tycp.xyz：audio.cpp 能力矩阵、后端列表、构建开关
- ggufmodels.com：Q4_K_M/Q8_0/BF16 体积与内存估算

**未验证项**
- `github.com/audio-cpp/audio-cpp` 路径 404，正确仓库为 `0xShug0/audio.cpp`（来自二手来源指向，未逐字核对 README）
- **手机端没有任何官方性能数据**，所有速度结论均是从 PC 数据外推，务必以真机实测为准
