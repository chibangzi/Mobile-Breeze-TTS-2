# 22. 骁龙 8 Elite Gen 5 的能力盘点：三个"特别之处"，只有一个能用

> 起因：用户问「我的 8e5 的 GPU 和 NPU 有没有什么特别之处能在 Breeze TTS 2 上加速」。
> 结论先说：**有，而且被漏掉的那个不在 GPU 也不在 NPU，在 CPU**——Oryon Gen 3 首次加入的
> SME 矩阵单元，而本项目当前构建的 `armv8.6-a+dotprod+i8mm+fp16` 根本不会生成这类指令。
> 这条路的确定性比 GPU/NPU 两条都高，因为它不依赖驱动、不依赖 QNN 许可、不需要换模型格式。

---

## 一、先把规格钉死

骁龙 8 Elite Gen 5（SM8850，2025-09，TSMC N3P）：

| 部件 | 规格 | 对 Breeze 的意义 |
| --- | --- | --- |
| CPU | 2× Oryon Gen 3 Prime 4.6 GHz + 6× Performance 3.6 GHz，**首次硬件矩阵加速（SME）**，FlexCache 动态缓存池 | ⭐ 被漏掉的加速点 |
| GPU | Adreno 840，三切片，1.2 GHz，1536 shader，FP32 约 3.69 / **FP16 约 7.37 TFLOPS**，OpenCL 3.0 FP，Vulkan 1.3，**18 MB Adreno HPM** | 只对声码器有意义 |
| NPU | Hexagon，AI 性能 +37%，12 标量 + 8 向量 + 1 张量加速器，INT2/INT4/INT8/INT16/**FP8**/FP16，Micro Tile Inferencing | 架构不匹配，见 §四 |
| 内存 | LPDDR5X 10600 MT/s，64-bit，**84.8 GB/s** | ⚠️ **与上代 8 Elite 完全相同** |

最后一行是全文最重要的数字。8 Elite → 8 Elite Gen 5，GPU 算力 +23%（官方口径）、
NPU +37%、CPU 单核 +20%，**唯独带宽一个字节都没涨**。

而 Breeze 最耗时的两段（主干逐帧 CFG 双分支 2317 ms、RVQ 深度解码 6472 ms，合计占 47%）
恰恰是 batch=1、算术强度极低的 GEMV——这类负载的天花板就是带宽，不是算力。
**芯片换代对这两段几乎不产生任何帮助**，这不是推测，是 LPDDR 带宽除以权重字节数的硬约束。

---

## 二、被漏掉的那个：Oryon Gen 3 的 SME

### 2.1 事实

高通在 8 Elite Gen 5 的官网特性里写的是「Qualcomm Oryon CPU with **first ever hardware
matrix acceleration**」——这是 ARMv9.2 的 SME（Scalable Matrix Extension），
一颗独立于 NEON 的矩阵单元，用 ZA tile 寄存器做外积（MOPA），不是把 NEON 加宽。

Arm 与社区已经验证过 ggml 在这件事上的现状（[Arm 学习路径](https://learn.arm.com/learning-paths/mobile-graphics-and-gaming/performance_llama_cpp_sme2/kleidiai_integration/)、
[coldpath 的二进制扫描](https://github.com/JonathanSolvesProblems/coldpath/)）：

> 「The ggml stack ships zero SME on every OS... SME reaches ggml only through KleidiAI,
> and `GGML_CPU_KLEIDIAI` defaults to **OFF**... ggml's runtime dispatcher still loads the
> highest variant a CPU supports, so on an SME-capable device (**Dimensity 9500, Snapdragon 8
> Elite Gen 5**) it loads the armv9.2 backend and gets a library with **no SME in it**,
> leaving the matrix-tile unit unused.」

同一次扫描里，ONNX Runtime 的 aarch64 wheel 有 469 条 SME 指令、其中 208 条是 MOPA 外积，
llama.cpp 官方 arm64 包是 0 条——**同一个 KleidiAI，两个项目默认值相反**。

### 2.2 本项目的实际状态

`tools/build_breeze_android.sh:38`：

```bash
ARM_ARCH="${ARM_ARCH:-armv8.6-a+dotprod+i8mm+fp16}"
```

- 目标是 **armv8.6-a**，只有 dotprod + i8mm + fp16。**没有 sve2，没有 sme**。
- CMake 参数里**没有** `-DGGML_CPU_KLEIDIAI=ON`（`GGML_NATIVE=OFF`，`GGML_LLAMAFILE=OFF`）。
- 结论：这颗芯片的矩阵单元在跑 Breeze 时**一直是闲的**。

### 2.3 能拿到多少（待 bench 确认）

KleidiAI 的 SME2 microkernel 只对特定类型组合生效（LHS F32 × RHS ∈ {Q4_0, Q8_0, F16}），
**Q4_K 不在列**——这点很关键：

| 模型 | 能否走 KleidiAI SME | 说明 |
| --- | --- | --- |
| `q8_0` | ✅ | 用户平时用的就是 q8，RHS=Q8_0 在支持表内 |
| `q4_k`（Q4_K_M） | ❌ | 需换成 Q4_0 才能吃 SME，或等 KleidiAI 补 Q4_K |
| codec / 声码器（F32 权重） | ⚠️ 部分 | RHS=F32 不支持；只能靠 `-march` 让编译器对 F32 代码做 SVE2 自动向量化 |

按 Arm 公布的 Q8_0 SME2 相对 NEON 的差距，以及「prefill compute-bound / decode
memory-bound」的既有规律，预期：

- **预填充 1829 ms** → 1.6–2.2×，省 **600–900 ms**（SME 最擅长的场景：一次大 GEMM）
- **深度解码 6472 ms** → 1.1–1.3×，省 **500–1300 ms**（GEMV 仍是带宽瓶颈，别期待更多）
- **声码器 8116 ms** → 只有 SVE2 自动向量化的收益，估计 5–15%

合计：18.9 s → **约 16 s，RTF 4.7**。单靠这一项不够，但它和「conv_transpose 改写成 gemm」
是叠加的、互不冲突的、且都不碰音质数值路径。

### 2.4 代价与坑

1. **二进制兼容**：`armv9.2-a+sme2` 的 so 在 armv8.6 设备上会 SIGILL。必须走 ggml 的
   多变体机制（`GGML_BACKEND_DL=ON` + 分别编 `armv8.6` / `armv9.2` 两份 libggml-cpu，
   运行时按 `HWCAP2_SME` 选择），或者干脆分两个 APK。
2. **KleidiAI 要引依赖**：`GGML_CPU_KLEIDIAI=ON` 会拉 kleidiai 子模块，交叉编译需要
   确认 NDK 工具链能过（Arm 的文档只覆盖桌面与 Android NDK r27+）。
3. **首次加载变慢**：KleidiAI 在模型加载时做一次 RHS repack（Q8_0 → qsi8d32p 布局），
   q8 模型约 4 GB 权重需要多花几秒，可接受但要提示。
4. **必须 A/B**：1.10 的教训——三项一起上，音质一变就归不了因。这项只改 CPU 指令选择、
   不改任何数值路径，理论上输出应当**逐位相同**（同一套 Q8 反量化顺序，只是并行方式不同）。
   实际上不会逐位相同（累加顺序变了），所以判据用 **SNR ≥ 80 dB** 而不是逐位比较。

---

## 三、GPU：确实有增量，但增量不在我们要用的地方

| 特性 | 真实情况 | 对 Breeze |
| --- | --- | --- |
| FP16 7.37 TFLOPS | 比上代 6.7 提升约 9% | 声码器有份，但声码器不是算力不够，是 kernel 太碎 |
| **18 MB Adreno HPM** | 官方定义是「可配置的**图形**工作空间，存渲染目标、深度/颜色缓冲、前序阶段的纹理」 | ❌ 不是通用可寻址显存，OpenCL 后端拿不到。llama.cpp 也没有任何代码路径去申请它 |
| OpenCL 3.0 FP | 与上代一致 | 无增量 |
| 三切片架构 | 提高并发与调度粒度 | 对单 kernel 延迟无帮助 |

也就是说：**HPM 听起来最像"专用显存"，实际是给渲染管线用的**，我们这种
「一次性把权重读进来算完就走」的 compute 负载用不上。真正能给 compute 用的片上内存，
是 CPU 的 FlexCache 和 NPU 扩容后的共享内存，不是 HPM。

> 顺带纠正一个容易混淆的点：**Adreno 的 Matrix Cores 是下一代（第六代骁龙 8，2026-09）
> 才有的**，8 Elite Gen 5 没有。别把两代特性混在一起做规划。

---

## 四、NPU：Gen 5 加了 INT2/FP8，但对我们的结论一个字都不用改

Gen 5 的 NPU 相对上代多了 INT2、FP8、Micro Tile Inferencing、Hexagon Direct Link，
峰值算力按官方口径 +37%。但 [`docs/08`](08-v1.3-vulkan-npu.md) §4.3 列的六个障碍
**没有一条被这次升级解决**：

1. 算子覆盖（`conv_transpose_1d` / `roll` / `sin` / `get_rms` 全要回退 CPU）
2. 量化格式（GGUF 的 Q4_K/Q8_0 块布局 ≠ QNN 的 QDQ，得整套重导出 + PTQ 校准）
3. 动态 shape（自回归逐帧 + CFG 双分支 KV cache，context binary 要枚举 shape）
4. 四段串行流水（任一环回退就打断整条）
5. batch=1 的 GEMV（NPU 优势在大 GEMM）
6. QNN 专有库的许可与分发

INT2/FP8 解决的是"算得更快"，而这六条挡的是"根本喂不进去"。§4.5 的结论依然成立：
NPU 加速的前提是「小模型 + 非自回归 + 预编译静态图」，Breeze 三条全不满足；
要拿 NPU 的 2×，得先换模型（ZipVoice 那条路）。

---

## 五、修正后的推进顺序

原来我建议先做 GPU 声码器 bench。看完 SoC 规格后，顺序要改：

| 序 | 动作 | 预期收益 | 风险 | 是否动音质 |
| --- | --- | --- | --- | --- |
| **1** | **CPU：`conv_transpose_1d` → 零插值 + `conv_1d`** | 声码器内该段 4–7×（主机实测 413→69 ms） | 极低，纯代码 | 否（同一算术，仅顺序不同） |
| **2** | **CPU：开 `GGML_CPU_KLEIDIAI` + armv9.2 变体** | prefill 1.6–2.2×，decode 1.1–1.3× | 中（需多变体打包） | 否（SNR 80 dB 判据） |
| 3 | GPU：声码器 OpenCL（S0 bench 先验） | 8.1 s → 1.5–2.5 s | 高（驱动 + 3 个算子 + 无 sched） | 低（F32 路径） |
| 4 | GPU：预填充 | 1.8 s → 0.5 s | 中 | 否 |
| — | NPU | 0 | 极高（许可/重导出） | — |
| — | GenieX | 0 | 不可行（unknown arch） | — |

**为什么把 CPU 提到 GPU 前面**：1 和 2 加起来预期把 RTF 从 5.37 压到 3.6–4.0，
和 GPU 路线的天花板（3.5–3.9）几乎相同，但**没有驱动风险、没有许可问题、不需要
为 3 个缺失算子写 kernel、也不用引入 backend sched**。而 GPU 那条即使全成功，
也只是把 3.9 变成 3.5。

**顺序错了的代价**：先做 GPU 却收益不达预期时，会分不清是"驱动不行"还是"这条负载本来
就不适合 GPU"。先把确定的两项做完，把 RTF 打到 4 左右，再上 GPU 才有干净的对照基线——
这正是 1.10 那次三合一失败给出的教训。

---

## 六、验证边界

本文所有性能数字都是**静态推断 + 主机侧微基准**，没有一次真机测量：

- SME2 的加速比来自 Arm 公布数据与 KleidiAI 的通用规律，我没能在 Adreno 840 + Oryon Gen 3
  的真机上跑过；
- 「带宽 84.8 GB/s 与上代相同」来自第三方规格库（NanoReview / hmc-tech）与高通 5300 MHz
  LPDDR5X 的公开口径；
- 「HPM 对 OpenCL 不可用」是依据官方功能描述（图形工作空间）做的判断，未拿到驱动文档级证据。

**真机 5 分钟即可证伪/证实 §2**：`adb shell cat /proc/cpuinfo | grep -i -E "sme|sve"`、
以及用 `GGML_CPU_KLEIDIAI=ON` 编一个 armv9.2 的 `llama-bench` 跑同一个 q8 模型，
对比 tok/s。如果 SME 没被内核上报，§2 整节作废。
