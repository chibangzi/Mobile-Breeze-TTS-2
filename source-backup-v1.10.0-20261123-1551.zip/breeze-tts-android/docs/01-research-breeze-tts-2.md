# Breeze TTS 2 调研笔记（截至 2026-11）

> 本文所有结构参数、字段名、token id 均来自 `huggingface.co/BreezeBlue/Breeze-TTS-2` 的
> `config.json` / `tokenizer_config.json` 与 `github.com/breezeblue-ai/breeze-tts` 源码，
> 非二手推断。文中标注「实测」的结论在 `tools/verify_tokenizer.py` 中可复现。

## 1. 基本信息

| 项目 | 值 |
| --- | --- |
| 仓库 | `github.com/breezeblue-ai/breeze-tts`（推理代码，Apache-2.0） |
| 权重 | `huggingface.co/BreezeBlue/Breeze-TTS-2`（BF16，约 3.47B 参数） |
| 架构名 | `BreezeForConditionalGeneration` |
| 语言 | 中 / 英 |
| 采样率 | 24 kHz 单声道 |
| 帧率 | 12.5 Hz（1 帧 = 80 ms = 1920 采样点） |
| 音色能力 | Voice Clone / Voice Design / Voice Direction / 内联语气事件 |
| 许可 | 代码 Apache-2.0；**权重与派生模型仅限研究与非商用** |

官方指标（H100，warm fast path）：TTFA < 40 ms，RTF 0.32，eager 推理显存约 7.7 GiB。
Artificial Analysis TTS 榜 Elo 1215，开源权重第一。

## 2. 三件套架构

Breeze 不是常见的「LLM + 声码器」两段式，而是**四段式**：

```
文本 ──> T5Gemma2 文本编码器(26L, d=1152) ──> Linear(1152→2048)
                                              │
参考音频 ──> Mimi 编码器(16 码本, 12.5Hz) ──> 码本嵌入求和 ──┤
                                              ▼
                                   Qwen3 backbone (28L, d=2048, 16Q/8KV)
                                              │ 每帧 1 个 token（2051 类）
                                              ▼
                                   深度解码器 (12L, d=1024, 16 码本)
                                              │ 每帧补出 15 个 token
                                              ▼
                              Qwen3-TTS 语音解码器 (16 码本 → 24kHz 波形)
```

关键参数（`config.json`）：

| 字段 | 值 | 含义 |
| --- | --- | --- |
| `num_hidden_layers` / `hidden_size` | 28 / 2048 | backbone（Qwen3 结构，`rope_theta=5e5`，llama3 rope scaling factor 32） |
| `num_attention_heads` / `num_key_value_heads` | 16 / 8 | GQA |
| `vocab_size` | 2051 | 每帧首码本的取值空间 |
| `backbone_eos_token_id` | 2051 | 首码本 head 的额外 EOS 类（logits 维 2052），源码 `breeze.py:922` |
| `audio_token_id` / `audio_eos_token_id` | 262144 / 262145 | 文本序列里的音频占位符 / 参考音频结束符 |
| `audio_num_codebooks` | 16 | RVQ 层数 |
| `text_vocab_size` | 262158 | 文本词表（Gemma 风格 BPE + byte fallback） |
| `text_encoder_config` | 26L / 1152 / inter 6912 / 4 heads×256 | T5Gemma2 text encoder，**只用了 encoder** |
| `depth_decoder_config` | 12L / 1024 / 8 heads / kv 2 / inter 8192 | 帧内 RVQ 自回归 |
| `codec_config` | Mimi encoder（32 量化器，取前 16） | 参考音频 → 码本 |
| `audio_tokenizer` | `Qwen3TTSTokenizerV2Model`，8L，upsample 8·5·4·3·2·2=1920 | 码本 → 波形 |

> 注意 `audio_embed_size = 2048 = backbone hidden`，因此主干隐藏态**不需要**投影即可直接作为
> 深度解码器的第 0 位输入（`backbone_hidden_state_projector = None`）。

## 3. 提示词构造（推理代码 `breeze_infer/templates.py`）

四个模板，全部以说话人前缀 `[S0]` 起头（默认 `speaker="S0"`）：

| 模板 | 输入 | 序列 |
| --- | --- | --- |
| `tts_plain` | text | `[S0] + text` |
| `tts_instruction` | text + instruction | `[S0]<ins_bos>{ins}<ins_eos>{text}` |
| `ref_clone_tata` | text + ref_audio + ref_text | `[S0]{ref_text}` → `<|AUDIO|>×N<|audio_eos|>` → `[S0]{text}` |
| `ref_edit_tata` | 上述 + instruction | `[S0]{ref_text}` → 音频 → `[S0]<ins_bos>{ins}<ins_eos>{text}` |

要点：

1. **每一段文本单独 encode 再拼接**，音频段按帧数展开成 N 个 `<|AUDIO|>`，后接一个
   `<|audio_eos|>`。文本段与音频段在最终序列中交替。
2. 最终 `tokenizer(final_text, add_special_tokens=False)` —— **没有 BOS**。
3. 文本段与音频段的切分（`text_ids_mask` / `text_ids_len`）要一起送到模型，因为文本位置走
   T5Gemma2，音频位置走码本嵌入。
4. `<|AUDIO|>` 位置的嵌入 = 该帧 16 个码本嵌入**求和**；
   `<|audio_eos|>` 位置 = 码本 0（`codebook_eos_token_id=0`）的嵌入。
5. 参考音频最后 1 帧可丢弃（`drop_last_frame`），用于避免编码器尾部噪声。

### 特殊 token id（实测，`tools/verify_tokenizer.py` 校验）

| token | id | 说明 |
| --- | --- | --- |
| `<bos>` | 2 | 归一化时**不**加 |
| `<|AUDIO|>` | 262144 | 单 token |
| `<|audio_eos|>` | 262145 | 单 token |
| `[S0]`…`[S9]` | 262146…262155 | 单 token |
| `<ins_bos>` | 262156 | 单 token |
| `<ins_eos>` | 262157 | 单 token |

### 分词器特性（决定端上实现方式）

`tokenizer.json`：`normalizer = Replace(" "→"▁")`，`pre_tokenizer = Split("▁", MergedWithPrevious)`
（实际效果是 `▁` 前缀到**后**一个词），`byte_fallback = true`，decoder 再换回空格。

因此端上分词算法为：

1. 先按 added tokens 做最长匹配切分（`[S0]`、`<ins_bos>` 等**必须**整体识别，否则会被拆成多 token）；
2. 空格替换为 `U+2581`；
3. 按 `▁?[^▁]+|▁+` 切块；
4. 每块内部逐字符做 BPE 合并（按 merge rank 取最小）；
5. 词表缺失的符号回退为 `<0xXX>` 字节 token。

该算法与官方 `tokenizers` 库在 12 条中英混排样例上 **12/12 完全一致**（含 emoji、数字、
标点、多行、首尾空格）。C++ 实现见 `app/app/src/main/cpp/breeze_tokenizer.cpp`。

## 4. 生成流程（每帧）

```
prefill:  embeds[1,S,2048] -> backbone -> logits(last)
loop frame:
    c0 = sample(logits[0:2048], eos=2051)
    if c0 == 2051: break
    h  = backbone 最后一位 hidden_states          # 2048
    seq = [PAD, c0]                              # 深度解码器输入
    for k in 1..15:
        logits_k = depth(seq_padded_to_16, h)[k-1]   # 用第 k-1 个 codebook head
        c_k = sample(logits_k)
        seq.append(c_k)
    codes = [c0..c15]                            # 1 帧
    pcm   = speech_decoder(codes)                # 1920 采样
    feed  = sum(codec_embed[c_k][k]) for k       # 2048 维，喂回 backbone 生成下一帧
```

- 深度解码器是 `input_ids` + `backbone_last_hidden_state` 联合输入；第 0 位嵌入被主干隐状态
  **覆盖**，第 k 位（k≥1）用「第 k 个码本的第 c_k 个嵌入」，输出头按位置取
  `codebooks_head.weight[k-1]`（源码 `breeze.py:604-625`）。
- 官方实现每步 `use_cache=False` 重算整段（序列 ≤ 16），端上因此可以导出**固定长度 16**
  的静态图，GPU 上更友好，详见 `docs/03-architecture.md` 的取舍分析。
- 采样：`temperature=0.9`、`do_sample=true`；CFG 默认 `cfg_scale=1.0`（不带负分支）。

## 5. 能力边界

- **Voice Clone**：需要参考音频 + **逐字准确**的文本稿；参考音频必须干净、少噪声。
- **Voice Design**：无参考音频，用自然语言描述音色（指令语言需与目标文本语言一致）。
- **Voice Direction**：参考音频定音色 + 指令控情绪/语速/语气。
- **内联事件**：英文用圆括号 `(laugh)`/`(sigh)`/`(cough)`/`(clears throat)`，
  中文用方括号 `[笑]`/`[叹气]`/`[咳嗽]`/`[清嗓子]`。
- 只支持中英；指令遵循强度靠 prompt，`cfg_scale>1` 更强但需双份 KV（端上默认关闭，见架构文档）。

## 6. 许可（重要）

> Source code is licensed under Apache 2.0. Breeze TTS 2 model weights, derivative models,
> and self-hosted outputs are for research and non-commercial use only.

**量化后的 `.mnn` 权重属于派生模型，同样受 BreezeBlue Research and Non-Commercial License 约束**：
不得商用、不得用于未授权的音色克隆/冒充/欺诈。App 内已内置该提示（`NOTICE.md` 与首启弹窗）。
需要商用必须向 BreezeBlue 取得书面授权。
