# 114 · NPU 判定基准（APK 版）

> **当前版本 1.1**（含大张量与一层形态两组，见下文「三组用例」）。
> 第一轮实测的结论与方法修正记录在 `docs/115-npu-bench-round1.md`。

## 为什么改成 APK

上一版是个命令行程序，得先装 adb、开 USB 调试、接数据线。这一步的摩擦比实验本身还大，
而且真正要回答的问题只有一个：**同一层矩阵乘，跑在 Hexagon 上比 CPU 快多少。**

所以把它做成一个独立 App：装上、点两下、出数。不需要电脑，不需要 root，不需要 adb。

## 安装

1. 把 `dist/BreezeNpuBench-1.0.apk` 传到手机（微信/QQ 传文件、网盘、数据线都行）。
2. 点开安装。系统会提示「未知来源」，允许即可。它和 Breeze 是不同包名（`ai.breeze.npubench`），
   可以并存，不会覆盖你的正式版。
3. 桌面出现「NPU 基准」图标。

只支持 arm64（8 Elite 是 arm64-v8a），minSdk 33。

## 怎么跑

打开后先点 **① 只测 CPU**，约 40 秒。这一步的作用是确认程序能起来、并拿到 CPU 的基线。

看到 9 行结果（3 个形状 × 3 种量化）之后，再点 **② 只测 NPU**。

「③ 全部」是两个连起来跑，一般不用。

跑的时候屏幕别关（App 没加常亮，长时间无操作会息屏）。全跑完约 2–4 分钟，
NPU 那组如果卡住超过 2 分钟没输出，基本是 FastRPC 会话建立不上，可以直接杀掉。

结果会自动存一份到 `Android/data/ai.breeze.npubench/files/gemv-bench.txt`，
点「分享结果」可以直接发出来。

## 它到底在测什么

和 App 里深度解码的真实形态一致：**批 = 1 的 GEMV**，读一遍权重、每个元素做一次乘加。

### 1.1 起有三组用例

| 组 | 形状 | 用途 |
| --- | --- | --- |
| 小张量 | 1024×2816 / 1024×3072 / 2048×2048 | 对照。**这组测不出带宽**——3 MB 的权重被 0.15 ms 的固定开销盖住，只能横向比两个后端 |
| 大张量 | 1024×28160（30 MB） | **唯一的真带宽判据**。固定开销占比降到 1% |
| 一层形态 | 一次 launch 里 7 个 matmul，7 × 1024×4096 | 与真实深度同构，ms/层 可直接对 App 的 0.53 ms/层 |

小张量跑 Q8_0 / Q4_0 / Q4_K，200 次计时；大张量与一层跑 Q8_0 / Q4_0，100 次计时。
都输出平均 ms、平均 GB/s，以及最快一次的值。

**只看一个数：GB/s。** 形状不同、实现不同，ms 不能横向比，GB/s 可以。

## 结果怎么读

把 CPU 组和 NPU 组同形状、同量化的 GB/s 摆在一起：

**看大张量那一组，不要看小张量。** 小张量的数字全是固定开销，第一轮就是栽在这里。

| 大张量 · NPU 的 Q8_0 带宽 | 结论 |
| --- | --- |
| ≥ 80 GB/s | 真的超过 CPU 的 77（扣开销后的估计），NPU 路线成立，往下做 |
| 60–80 | 与 CPU 持平。带宽上没有优势，只能靠「减少 launch 次数」取胜 |
| < 60 | 反而更慢，收手；Q4 + NPU 一并放弃 |

**同时看一层形态那一行**：HTP 的 ms/层 要明显低于 CPU 的 0.53 ms 才算有用。
大张量高、一层形态不低，说明优势全被 launch 开销吃掉了，实际用不上。

再看大张量的 Q4_0：若 HTP 上它仍只有 Q8 的六成，说明 Hexagon 的 4 bit 解包同样受指令限制，
「Q4 提高密度」这条路在 NPU 上也走不通。

## 可能的失败，以及每种失败说明什么

App 已经做了两件能做的事：manifest 里 `<uses-native-library name="libcdsprpc.so" required="false">`
（Android 12 起访问 vendor 库的官方声明方式），以及启动时按绝对路径预加载一次驱动。
剩下的取决于系统策略，失败时日志会写清楚卡在哪一层。

| 日志里的表现 | 含义 |
| --- | --- |
| `白名单里没有 FastRPC / QNN 库` | 系统没把 `libcdsprpc.so` 列为公开库，App 进程加载不了驱动。这是**系统策略**，没有绕法 |
| `驱动 libcdsprpc.so 失败：... not accessible for namespace` | 同上，linker 层被拦 |
| `/dev/fastrpc-cdsp 不可访问` | 驱动库有了，但 SELinux 不放行设备节点 |
| `初始化抛异常：failed to enable unsigned PD` | 能连上 DSP，但 ROM 禁止 unsigned PD。少数机型如此 |
| `初始化抛异常：failed to open session` | skel 没找到或架构不匹配（本包带 v73/v75/v79/v81 四份） |
| 一直停在「NPU · ...」没有下文 | 会话建不上，卡在 FastRPC 等待 |

前三种都说明「普通 App 碰不到 Hexagon」，那就只剩 adb shell 这条路（`dist/hexagon-bench-20261122.zip`，
用法见 `tools/hexagon-bench/README.md`）。**这本身也是明确结论**：NPU 进不了正式 App，
即便 benchmark 好看也没法用，路线直接否掉，不用再花两周。

## 打包了什么

```
libhvxbench.so          JNI 入口 + 基准逻辑（本仓 tools/hexagon-bench-app/app/src/main/cpp）
libggml.so              调度与图
libggml-base.so         基础算子
libggml-cpu.so          CPU 后端（NEON / i8mm / dotprod / repack）
libggml-hexagon.so      Hexagon 后端（FastRPC + dspqueue）
libggml-htp-v73/75/79/81.so   四份 DSP 端 skel，运行时按 SoC 架构挑
libc++_shared.so        C++ 运行时
```

ggml 从源码编（NDK r27，arm64-v8a，Release）。App 体积 5.7 MB。

## 与命令行版的关系

命令行版 `dist/hexagon-bench-20261122.zip` 仍然保留，两者跑的是**同一份测量逻辑**
（`bench_gemv.cpp` 与 `bench_jni.cpp` 的 bench 函数逐行对应）。
命令行版的优势是能拿到完整 stderr 与 `dmesg`，排查 FastRPC 问题时信息更全；
APK 版的优势是不用电脑。先跑 APK，卡住了再考虑上 adb。

## 源码位置

```
tools/hexagon-bench-app/          独立 Gradle 工程（Java + 手编 .so）
  app/src/main/cpp/bench_jni.cpp  基准逻辑 + JNI
  app/src/main/java/.../MainActivity.java
  app/src/main/jniLibs/arm64-v8a/ 预编库
tools/hexagon-bench/              命令行版（同逻辑）
```

改完重编的顺序：先 clang 重编 `libhvxbench.so`，再 `gradle :app:assembleRelease`，
然后 zipalign + apksigner。命令在 `tools/hexagon-bench-app/build.sh`。
