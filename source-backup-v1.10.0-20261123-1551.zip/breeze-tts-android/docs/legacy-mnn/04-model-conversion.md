# 模型转换：Breeze TTS 2 → MNN（12GB / 骁龙 8 Elite 档位）

## 0. 环境

- Linux x86_64（一台有 GPU 的机器更快，但导出只需 CPU 也能跑，只是慢）
- Python 3.10+
- `torch==2.9.1`、`transformers==4.57.3`、`qwen-tts==0.1.1`（与官方 `requirements.txt` 一致）
- [MNN](https://github.com/alibaba/MNN) 源码（要里面的 `MNNConvert` 与 `transformers/llm/export/utils`）
- 磁盘 ≥ 40 GB（原始权重 7 GB + ONNX 中间产物）

```bash
git clone https://github.com/breezeblue-ai/breeze-tts
git clone https://github.com/alibaba/MNN
cd MNN && mkdir build && cd build && cmake .. -DMNN_BUILD_CONVERTER=ON && make -j
export PATH=$PWD:$PATH
export PYTHONPATH=$(dirname $PWD)/transformers/llm/export:$PYTHONPATH
```

## 1. 一条命令跑完

```bash
cd tools
pip install -r requirements.txt

M=/data/models/Breeze-TTS-2      # huggingface-cli download BreezeBlue/Breeze-TTS-2 --local-dir $M
C=/data/repos/breeze-tts

python export_tokenizer.py       --model $M --out out/tokenizer.bin
python export_modules.py         --model $M --code $C --out onnx/          # 4 个辅助模块
python export_backbone.py        --model $M --code $C --out onnx/          # 主干（inputs_embeds）
python export_codec_embedding.py --model $M --code $C --out out/codec_embedding.bin
python onnx_to_mnn.py            --onnx onnx/ --out mnn/ --profile standard
python make_package.py           --mnn mnn/ --tokenizer out/tokenizer.bin \
                                 --codes out/codec_embedding.bin \
                                 --hf-tokenizer $M/tokenizer.json --out pkg/ --profile standard
python verify_tokenizer.py       --model $M --bin out/tokenizer.bin       # 必须 13/13
python publish_package.py        --pkg pkg/ --repo <你的账号>/breeze-tts-2-mnn-int4
hf upload <你的账号>/breeze-tts-2-mnn-int4 pkg/ --repo-type model
```

## 2. 五个模块分别导的是什么

| 脚本 | 产物 | 关键点 |
| --- | --- | --- |
| `export_modules.py` | `text_encoder.onnx` | T5Gemma2 **只导 encoder** + `text_encoder_proj`（1152→2048）。必须 `attn_implementation="eager"`，否则 SDPA 导出成一坨 fused op，MNN 不认 |
| 同上 | `depth_decoder.onnx` | 固定 `input_ids[1,16]`；输出裁成 `[1,15,2051]`，第 k 个位置用 `codebooks_head.weight[k-1]`。**位置 0 的预测本来就被丢弃**，所以不必导 |
| 同上 | `speech_decoder.onnx` | 16 码本 → 24 kHz，帧数动态。upsample 总量 8·5·4·3·2·2 = 1920 |
| 同上 | `codec_encoder.onnx` | 参考音频 → 16 码本，采样点动态。只在克隆时用 |
| `export_backbone.py` | `backbone.onnx` | 最容易翻车的一步，见下 |

### 2.1 主干为什么必须 `inputs_embeds` 入

Breeze 的文本向量来自 T5Gemma2，不是查表；如果按普通 LLM 导出（`input_ids` 入、图内查表），
端上就没法把文本向量喂进去。MNN 自己的 Qwen3-TTS Talker 就是按 `inputs_embeds` 入导出的
（`transformers/llm/export/utils/talker.py:59`、`:277-290`），所以照抄它的 `onnx_export` 调用。

导出后 `Llm::forward(VARP input_embeds)` 直接可用，KV cache 由 MNN 运行时通过
`KVCACHE_INFO` 原地维护，不需要我们一帧一帧拼 `past_key_values`。

### 2.2 常见坑

| 现象 | 原因 / 处理 |
| --- | --- |
| ONNX 里出现 `MultiHeadAttention` | 导出时没关 SDPA。`attn_implementation="eager"` + `opset 17` |
| `depth_decoder` 输出 16 个位置，端上取错 | 契约是 `[1,15,2051]`，第 `k-1` 项才是 `c_k` |
| 转 MNN 报 `Gather` 不支持 | 主干里 `embed_tokens` 没被裁掉；确认走的是 `inputs_embeds` 分支 |
| 端上 fp16 出 NaN | 深度解码器必须 fp32。MNN Talker 的注释里明确写了这个坑（`omni.cpp:2985`） |
| 中文读出英文口音 | 文本段没有单独编码，跨段注意力污染；必须逐段 encode 再 scatter |

## 3. 量化档位

| 模块 | standard (推荐) | hq | 理由 |
| --- | --- | --- | --- |
| backbone | INT4 | INT8 | 12.5 次/秒，纯带宽瓶颈 |
| depth_decoder | INT4 | INT8 | 200 次/秒，全流程最大带宽黑洞 |
| text_encoder | INT8 | INT8 | 每句一次，省这点没意义 |
| speech_decoder | INT8 | INT8 | 音质直接受影响 |
| codec_encoder | INT8 | INT8 | 跑得少 |

体积参考：standard ≈ **1.6 GB**，hq ≈ **3.1 GB**。12 GB 机型两档都能装，hq 需要留足后台空间。

## 4. 质量闸门（上传前必做）

```bash
# 1) 分词：必须 13/13
python verify_tokenizer.py --model $M --bin out/tokenizer.bin

# 2) 逐模块 ONNX vs PyTorch 数值比对（cosine ≥ 0.999）
python check_parity.py --model $M --code $C --onnx onnx/ --tokens 128

# 3) 听感回归：用官方 infer.py 和端上同一段文本/音色，A/B 对比
python $C/infer.py $M --text "今天天气不错，我们出去走走吧。" --output ref.wav
# 把生成的 wav 放进手机 /sdcard/Download 用 App 内的「对比播放」听
```

`check_parity.py` 会打印每个模块的最大绝对误差；主干只要 top-1 码本一致率 > 98% 就算通过
（自回归会把小误差放大，别用 MSE 判断）。
