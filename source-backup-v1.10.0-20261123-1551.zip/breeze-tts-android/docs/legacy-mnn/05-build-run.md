# 构建与使用

## 1. 硬件基线

| 项目 | 要求 |
| --- | --- |
| 内存 | **12 GB 起**（App 峰值约 4.5 GB：权重 1.6 GB + KV + 中间张量 + 系统缓存） |
| SoC | **骁龙 8 Elite**（Adreno 830，LPDDR5X ~76 GB/s）；8 Gen 3 也能跑，RTF 更差 |
| 系统 | Android 13 (API 33) 及以上 |
| 存储 | 模型包 1.7 GB（standard）/ 3.2 GB（hq），另留 500 MB 波形缓存 |
| 其它 | 首次运行需联网下载模型；之后完全离线 |

不承诺低端机可用：int4 主干 + 200 次/秒的深度解码器对内存带宽的要求是硬门槛。

## 2. 构建

工程已经在本仓库内配好可直接编译的环境（NDK 27.1 / AGP 8.7.3 / Gradle 8.9 / CMake 3.22.1），
但 **MNN 的 `.so` 不进 git**（约 7 MB、每次升级都要重编）。首次构建先跑一次脚本：

```bash
# 0) 编译 MNN 的 arm64 运行时（只做一次，产物落在 app/app/src/main/jniLibs/arm64-v8a/）
./tools/build_mnn_android.sh
#    NDK 可用环境变量指定：NDK=/path/to/android-ndk ./tools/build_mnn_android.sh
#    脚本会：拉 MNN 源码 → cmake(OpenCL/LLM/ARM82) → 收集 4 个 .so → 拷头文件 → strip

# 1) 打包
cd app
./gradlew :app:assembleDebug      # app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:assembleRelease    # 未签名，需 apksigner
```

签名（release 必须）：

```bash
BT=$ANDROID_HOME/build-tools/35.0.0
$BT/zipalign -p -f 4 app-release-unsigned.apk aligned.apk
$BT/apksigner sign --ks signing/breeze-test.jks --ks-pass pass:breezetest \
    --out BreezeTTS-release.apk aligned.apk
```

`signing/breeze-test.jks` 是仓库自带的**测试签名**（口令 `breezetest`），只用于自己装机器；
对外分发请换成你自己的 keystore。

### 依赖与环境（实际使用的版本）

| 组件 | 版本 |
| --- | --- |
| JDK | 17+（实测 Zulu 20） |
| Gradle | 8.9 |
| AGP / Kotlin | 8.7.3 / 2.0.21 |
| compileSdk / targetSdk / minSdk | 35 / 35 / 33 |
| NDK | 27.1.12297006 |
| Compose BOM | 2024.09.00 |

MNN 编译选项（`build_mnn_android.sh` 里固化）：

```
-DMNN_OPENCL=ON -DMNN_ARM82=ON -DMNN_BUILD_LLM=ON -DMNN_BUILD_SHARED_LIBS=ON
-DMNN_SUPPORT_TRANSFORMER_FUSE=ON -DMNN_SEP_BUILD=ON -DMNN_KLEIDIAI=OFF
```

产出 `libMNN.so` / `libMNN_Express.so` / `libMNN_CL.so` / `libllm.so`，
strip 后合计约 7 MB。`libMNN_CL.so` 必须一起打包 —— OpenCL 后端是运行时 dlopen 的。


## 3. 首次运行

```
启动 → 模型页（空状态）
        ├─ [一键下载]  ← 默认仓库 your-name/breeze-tts-2-mnn-int4（standard 档）
        │     · 先拉 breeze.json，按清单逐文件下载，支持断点续传
        │     · 每个文件校验 sha256，全部通过才「安装」
        │     · 进度、速度、剩余时间实时显示；可暂停/继续/取消
        ├─ [换仓库]  ← 填任意 HF repo id，或选 hf-mirror 镜像
        └─ [从文件导入] ← 选本地 zip（离线场景，先传到手机）
        ↓
      加载引擎（显示「预热中」约 3-8 s）
        ↓
      合成页可用了
```

### 下载实现要点

- 默认走 `https://huggingface.co/{repo}/resolve/main/{file}`；镜像开关把域名换成
  `https://hf-mirror.com`。镜像默认开，拉清单失败会自动回退官方源。
- 直接 GET + `Range: bytes=N-` 续传（服务端不支持 Range 时从头覆盖写），`.part` 落盘后再原子改名。
- 清单里带 sha256 的文件逐个校验，校验失败删除重下。
- 前台服务（`dataSync`）跑下载，通知栏显示总进度；锁屏/切后台不断。
- 空间预检：`breeze.json.totalBytes × 1.1`，不足直接拦下并提示。
- **离线路径**：`make_package.py` 产出的 zip 直接拷到手机，模型页「从本地 ZIP 导入」，
  解压到暂存目录 → 按清单校验 → 原子改名安装，不会留下半成品。

## 4. 合成页

| 控件 | 说明 |
| --- | --- |
| 文本 | 支持内联事件：中文 `[笑] [叹气] [咳嗽] [清嗓子]`，英文 `(laugh) (sigh)` |
| 音色 | 三选一：**克隆音色**（选已有）/ **设计音色**（描述生成）/ **不定制**（模型默认音色） |
| 表达指令 | 预置短语一键填入，也可自由输入；留空则走 `tts_plain`（指令为空时模型行为更稳） |
| 参数 | 语速提示（写进指令）、温度、topP、seed |
| 动作 | 生成（流式播放）/ 停止 / 导出 WAV（`Music/BreezeTTS/`） |

整段送入模型一次生成，音频按 `chunkFrames`（默认 25 帧 = 2 秒）分块解码并立刻写入
`AudioTrack` 播放，所以首包延迟约等于「首块 2 秒音频的生成时间」，不必等整段跑完。
进度条按「已生成帧 / 预计帧」推进（12.5 帧 = 1 秒音频），预计帧数由文本长度估算。

## 5. 音色页

- **克隆**：录 5-15 秒（或从文件导入 wav/m4a），填**准确文本稿** → `ref_clone_tata`。
  必须填文本稿，模型靠它对齐；文本稿错了音色会漂。
- **设计**：只填描述（如「一位温柔自信的年轻女性，声音清晰，语气亲切」），发音时走
  `tts_instruction`，不需要参考音频。
- **定向**：克隆音色 + 指令，走 `ref_edit_tata`（推荐用法：固定音色，换情绪）。
- 音色保存为 `voices/<id>.json` + `<id>.codes`（参考音频编码后的 16×T 码本，约 20 KB/秒），
  下次合成直接复用，不必重新编码。

## 6. 已知限制

1. **CFG 关闭**：`cfg_scale=1`。开 CFG 需要两份 KV，12 GB 机型会 OOM。官方默认也是 1.0。
2. **非实时**：预计 RTF 0.8–1.6（8 Elite，int4）。10 秒语音约 8–16 秒生成完。
3. **长文本**：单次建议 ≤ 300 字；超长会被切句，句间停顿由 App 控制。
4. **音色克隆的伦理与法律**：只允许克隆你有权使用的声音。App 首次使用克隆功能时强制确认。
5. **许可**：权重非商用。`NOTICE.md` 与首启弹窗都写明。

## 7. 排障

| 现象 | 排查 |
| --- | --- |
| 模型页一直「校验失败」 | 仓库里 `breeze.json` 的 sha256 与实际文件不一致（重新 `make_package.py`） |
| 加载即崩 | 看 logcat `BreezeEngine`；多为 `backbone.mnn` 不是 `inputs_embeds` 入 |
| 出声但全是噪声 | `codec_embedding.bin` 的码本顺序反了，或 `speech_decoder` 输入没转置成 `[1,16,T]` |
| 音色不像 | 参考音频有背景音 / 文本稿不准 / 音频短于 3 秒 |
| 中文夹英文读错 | 指令语言与文本语言不一致；中文文本配中文指令 |
| 生成到一半 OOM | 换 standard 档；关闭其它后台；`maxFrames` 上限调小 |
