# App 架构设计

## 1. 分层

```
┌──────────────────────────── Compose UI ────────────────────────────┐
│ 合成页(文本/指令/音色/参数)  音色页(克隆/设计/管理)  模型页(导入/校验) │
└───────────────▲──────────────────────────────▲─────────────────────┘
                │ StateFlow                    │
┌───────────────┴──────────────────────────────┴─────────────────────┐
│ ViewModel: SynthesizeViewModel / VoiceViewModel                     │
│  - 组装 SynthesisRequest（模板选择、参数钳制、音色引用）             │
└───────────────▲────────────────────────────────────────────────────┘
                │ suspend / callback
┌───────────────┴────────────────────────────────────────────────────┐
│ BreezeEngine (Kotlin 单例)                                          │
│  - 模型包校验、native 加载、请求队列（单线程串行）                   │
│  - 回调：onChunk(ShortArray) / onProgress(frame) / onDone / onError  │
└───────────────▲────────────────────────────────────────────────────┘
                │ JNI
┌───────────────┴────────────────────────────────────────────────────┐
│ breeze_engine.cpp  （MNN Express + Llm）                            │
│  ├─ BreezeTokenizer   tokenizer.bin，Gemma 风格 BPE                  │
│  ├─ PromptBuilder     4 套模板，产出 ids + 段落切分 + 音频码本        │
│  ├─ Llm*              backbone（KV cache、int4、OpenCL/CPU）         │
│  ├─ Module×4          text_encoder / depth_decoder / speech_decoder  │
│  │                    / codec_encoder                                │
│  └─ CodecStreamDecoder 分块解码 + 重叠淡入淡出                       │
└────────────────────────────────────────────────────────────────────┘
```

## 2. 模型包布局

```
<filesDir>/models/breeze-tts-2-int4/
├── config.json            # MNN LLM 配置（backbone），含 backend_type / precision / thread_num
├── breeze.json            # 本 App 的元信息（版本、码本数、帧率、模块文件名、量化位宽）
├── backbone.mnn           # 主干（llm 格式，输入 inputs_embeds）
├── backbone.mnn.weight
├── text_encoder.mnn       # T5Gemma2 + proj
├── text_encoder.mnn.weight
├── depth_decoder.mnn      # 12L，固定长度 16
├── depth_decoder.mnn.weight
├── speech_decoder.mnn     # 16 码本 -> 24kHz
├── speech_decoder.mnn.weight
├── codec_encoder.mnn      # 24kHz -> 16 码本（克隆用）
├── codec_encoder.mnn.weight
├── codec_embedding.bin    # int8 [16,2051,2048] + per-row scale
├── tokenizer.bin          # 压缩后的 BPE（见 §5）
└── voices/                # 预置音色（可选）
    └── <id>.json + <id>.codes
```

## 3. 六个模块的输入输出契约

导出脚本（`tools/export_modules.py`）与 C++ 侧必须严格一致，否则加载即失败。

| 模块 | 输入 | 输出 | 形状说明 |
| --- | --- | --- | --- |
| `text_encoder` | `input_ids` int32、`attention_mask` int32 | `text_embeds` f32 | `[1,S]` → `[1,S,2048]`；S 动态，含 proj |
| `backbone` | `inputs_embeds` f32、`attention_mask`、`position_ids` | `logits`、`hidden_states` | `[1,S,2048]` → `[1,S,2052]` / `[1,S,2048]`；KV cache 由 MNN 内部管理 |
| `depth_decoder` | `input_ids` int32、`backbone_hidden` f32 | `logits` f32 | `[1,16]`、`[1,2048]` → `[1,15,2051]`；**固定 16** |
| `speech_decoder` | `codes` int32 | `waveform` f32 | `[1,16,T]` → `[1,1,T*1920]` |
| `codec_encoder` | `waveform` f32 | `codes` int32 | `[1,1,N]` → `[1,16,N/1920]` |
| `codec_embedding.bin` | — | — | int8 `[16,2051,2048]` + scale `[16*2051]` |

### 为什么深度解码器固定长度 16

官方实现每步 `use_cache=False` 重算整段（长度 ≤16），因为序列太短，KV cache 的收益不够抵消
启动开销。端上把这个特性变成优势：导出**静态形状** `[1,16]`，GPU 上无需动态 shape 编译，
每次前向 16 个位置并行；第 k 步只需要 `logits[k-1]`（输出已裁掉位置 0），多余的尾部位置被因果掩码屏蔽，不影响结果。

代价是多算了一些位置（16 步共 136 个位置 vs 理论 16 个），但深度解码器只有 0.33B，
在 int4 下每次前向读 ~170 MB 权重，**总读取量与是否算满 16 个位置无关**（权重主导），
所以静态满长度几乎不额外花钱。

## 4. 主循环（C++ 侧 `BreezeEngine::synthesize`）

```
1. plan  = tokenizer.buildPrompt(request)         // ids / 段落 / 音频码本
2. embeds = zeros[1,S,2048]
3. for each text segment:                          // 段落独立编码，避免跨段注意力污染
       e = text_encoder(segment_ids, mask)          // [1,s,2048]
       embeds[seg] = e
4. for each audio segment:                         // 只在克隆/定向时出现
       embeds[audio_pos] = sum_k(codec_embed[k][code_k])
       embeds[audio_eos_pos] = codec_embed[0][0]
5. llm->reset(); logits = llm->forward(embeds); hidden = llm->getOutputs()[hidden_states]
6. for frame in 0..maxFrames:
       c0 = sample(logits[0:2048], eos=2051, temp, topP, topK)
       if c0 == 2051: break
       seq[0] = 2050 (pad); seq[1] = c0
       for k in 1..15:
           lg = depth(seq padded to 16, hidden)[k-1]
           seq[k+1] = sample(lg, temp=0.9)
       decoder.push(codes)                        // 分块解码，凑够 25 帧就吐一次 PCM
       embeds = sum_k(codec_embed[k][codes[k]])    // [1,1,2048]
       logits, hidden = llm->forward(embeds)
7. decoder.flush()
```

采样用确定性 RNG（`seed` 参数），保证同参数可复现。温度/`topP`/`topK` 可在 UI 调。

## 5. `tokenizer.bin` 自定义格式

端上不解析 32 MB 的 `tokenizer.json`（慢且需要 JSON 库）。导出脚本把它压成二进制：

```
"BZTK2\0"                8B magic
u32 vocab_size
u32 merge_count
u32 added_count
u32 byte_token_id[256]           // "<0xXX>" 的 id，缺失填 0xFFFFFFFF
added:  {u32 id, u32 len, bytes} × added_count
vocab:  {u32 len, bytes} × vocab_size
merges: {u32 left, u32 right, u32 merged, u32 rank} × merge_count
```

C++ 侧构建 `unordered_map<uint64_t, pair<uint32_t,uint32_t>>`（key = `left<<32|right`），
按 rank 贪心合并；added tokens 用长度降序的前缀匹配表。

## 6. 线程与内存

| 关注点 | 方案 |
| --- | --- |
| 推理线程 | 单线程串行（MNN Express 会话非线程安全），`BreezeEngine` 内部持锁 |
| 加载时机 | 首次合成时懒加载（1.6 GB 权重，冷启动 3–8 s），加载进度回调到 UI |
| 释放 | `onTrimMemory(TRIM_MEMORY_RUNNING_LOW)` / 退到后台 5 min 后 `release()` |
| 播放 | `AudioTrack` STREAM 模式，24 kHz / 16 bit / mono，缓冲 200 ms |
| 录音 | `AudioRecord` 48 kHz 采集 → 线性重采样到 24 kHz → WAV |
| 前端进度 | 每帧回调一次（12.5 Hz），够画进度条与波形 |

## 7. 降 RTF 的三条工程手段

1. **音色前缀缓存**：同一音色的「参考文本 + 参考音频码本」的 prefill 结果（KV + 文本嵌入）
   可以缓存，第二次合成同一音色直接跳过 prefill。端上缓存 4 个音色，每个 ~几十 MB。
2. **句级切分 + 流水线**：长文本按标点切成 ≤40 字的句子，串行生成但解码与播放并行，
   首包延迟从「整段」降到「一句」。
3. **深度解码器 int4 + CPU 定标**：这是最大瓶颈（占 ~70% 带宽）。按 MNN Talker 的实测结论，
   小 seq 场景钉 CPU 反而比 OpenCL 快；主干与声码器仍走 GPU。

## 8. 明确的边界（当前实现未覆盖）

- **CFG（`cfg_scale > 1`）默认关闭**：需要 cond/uncond 两份 KV，显存翻倍，手机不可行；
  官方 CLI 默认也是 1.0。指令强度靠 prompt 与音色本身保证。
- **`--fast-*` CUDA Graph** 是 H100 专属优化，端上无对应实现。
- **流式首包 <40 ms** 是 H100 指标；端上首包 = 一句的生成时间（约 2–5 s）。
- 模型包需要用户在 PC/服务器上用 `tools/` 转换后导入，App 不内置 7 GB 权重（也规避分发风险）。
