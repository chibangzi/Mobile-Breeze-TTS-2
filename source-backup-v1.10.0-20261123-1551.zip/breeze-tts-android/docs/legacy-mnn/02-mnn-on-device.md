# MNN 端上推理：MNN Chat 是怎么做语音的

## 1. 先把一个常见误解纠正：GGUF ≠ MNN

MNN Chat 下载的模型是 **MNN 自己的格式**（`*.mnn` + `weight` 外置权重 + `config.json`），
不是 `GGUF`。GGUF 是 llama.cpp 生态的容器格式，两者的量化布局、算子实现、KV cache 管理
完全不通用，**不能把 Breeze 的 GGUF 直接丢给 MNN**。

因此本项目走 MNN 的官方路线：`PyTorch → ONNX → MNN`（`MNNConvert` / `llmexport`），
量化直接在 MNN 侧做 weight-only INT4/INT8。这样得到的体积与 GGUF Q4 同量级，但能吃满
MNN 的 OpenCL / Vulkan / QNN 后端。

## 2. MNN Chat 的后端选择

| 后端 | MNN 枚举 | 说明 |
| --- | --- | --- |
| CPU | `MNN_FORWARD_CPU` | 兜底，ARM82/NEON + fp16，i8mm 机型可用 int8 GEMM |
| OpenCL | `MNN_FORWARD_OPENCL` | 高通/ARM Mali 通用；`numThread` 需 `|64`、`|512` 走 buffer 模式 |
| Vulkan | `MNN_FORWARD_VULKAN` | MNN 3.5 起支持 LLM 全流程，覆盖面最广的移动 GPU |
| QNN | `MNN_FORWARD_QNN` | 骁龙 HTP/NPU，需要额外 QNN SDK 与离线编译 |

MNN Chat 的实践要点（源码 `apps/Android/MnnLlmChat/app/src/main/cpp/llm_session.cpp`）：

- 用户可在设置里切 CPU / OpenCL，并做「性能评测」看 prefill / decode 速度；
- 失败会自动回退（GPU 创建失败 → CPU），并对 GPU 做过热/黑名单处理；
- LLM 的 KV cache 通过 `Interpreter::KVCACHE_INFO` 挂在 runtime manager 上，
  由算子原地读写，**不走每步拷贝**；
- 量化模型在加载时按 `config.json` 里的 `backend_type` / `precision` / `thread_num` 决定调度。

## 3. MNN 已经内置了一条 TTS 流水线

这是本项目能落地的关键：MNN 3.5 的 `Llm` 体系里有一个 `Talker` 子类
（`transformers/llm/engine/src/omni.hpp`），专门跑「自回归码本 + 声码器」类 TTS，
并且**原生支持 Qwen3-TTS**：

```cpp
// omni.hpp:79-162
class Talker : public Llm {
    bool generateQwen3TTS(const std::string& prompt, int maxFrames, const std::string& refAudio);
    std::shared_ptr<Module> mQwen3PromptEmbedder;      // 文本/码本 -> 主干输入嵌入
    std::shared_ptr<Module> mQwen3AudioCodePredictor;  // 帧内 RVQ（深度解码器）
    std::shared_ptr<Module> mQwen3CodecEmbedder;       // 码本嵌入
    std::shared_ptr<Module> mQwen3SpeechDecoder;       // 码本 -> 波形
    std::shared_ptr<Module> mQwen3SpeakerEncoder;      // 参考音频 -> 说话人嵌入
};
```

模块签名（`omni.cpp:2962-3010`）：

| 模块 | 输入 | 输出 |
| --- | --- | --- |
| talker | `inputs_embeds, attention_mask, position_ids` | `logits, hidden_states` |
| prompt embedder | `codec_embeds, text_raw_embeds, tts_raw_embeds` | `prompt_inputs_embeds, ...` |
| audio_code_predictor | `inputs_embeds, attention_mask, position_ids` | `logits` |
| codec_embedder | `codec_embeds, text_hidden` | `inputs_embeds` |
| speech_decoder | `codes` | `waveform` |
| speaker_encoder | `mels` | `speaker_embedding` |

**Breeze TTS 2 的语音解码器就是 `Qwen3TTSTokenizerV2Model`（12.5 Hz / 16 码本 / 24 kHz /
upsample 1920）**，与 MNN 已支持的 Qwen3-TTS 声码器同构。也就是说 MNN 里「码本 → 波形」这一
段已经写好并且被验证过，我们只需要按同样的**输入输出契约**导出 Breeze 的权重即可。

`Talker` 里还有两个非常有价值的工程细节，直接照抄：

1. **深度解码器必须 fp32**：`cpBackendConfig.precision = Precision_High`。注释写明该子模型
   fp16 下 RMSNorm/attention 中间值溢出直接 NaN。
2. **深度解码器在小 seq 下钉在 CPU 更快**：注释给出的实测是同一台 OpenCL 设备上
   「50.5s vs 11.8s（10s 音频）」，因为 15 次 seq=1 的提交/同步开销远超 63M 参数模型本身的计算。

MNN Chat 里可下载的 `supertonic-tts-mnn` 是另一种形态（duration predictor + vector estimator
+ vocoder 的**非自回归**四模块方案，CPU 上 RTF≈0.07），可以参考它的模型包组织方式，但架构与本
项目无关。

## 4. 为什么不用 llama.cpp / ONNX Runtime

| 方案 | 结论 |
| --- | --- |
| llama.cpp | 只有 GGUF + 单一 LLM 图，装不下「文本编码器 + 主干 + 深度解码器 + 声码器」四段异构流水线；也没有移动 GPU 的成熟后端 |
| ONNX Runtime Mobile | 四段图都能跑，但 3B 主干在手机上缺 int4 weight-only 与 KV cache 原地更新，实测内存/速度都不达标 |
| **MNN** | 一套 API 同时管 LLM（KV cache、int4、OpenCL/Vulkan）和自定义 `Module`（编码器、声码器），MNN Chat 已经证明在真机上可跑 3B 级模型 |

## 5. 端上性能预算（按 12GB / 骁龙 8 Elite 推算，非实测）

基线：Adreno 830，LPDDR5X ~76.8 GB/s，8 GB 级带宽是 8 Gen 3 的 1.25 倍左右。

每生成 1 秒音频需要：12.5 次主干前向 + 12.5×16 次深度解码器前向。

| 模块 | 参数量 | INT4 体积 | 每秒读取量 | 备注 |
| --- | --- | --- | --- | --- |
| backbone 28L | ~1.53B | 0.77 GB | 9.6 GB | 12.5 次/秒 |
| text encoder 26L | ~1.0B | 0.50 GB | 仅 prefill | 每句一次；嵌入表占大头 |
| depth decoder 12L | ~0.33B | 0.17 GB | 33 GB | 200 次/秒，**最大瓶颈** |
| speech decoder | ~0.2B | 0.10 GB | 1.25 GB | 12.5 次/秒 |
| codec encoder | ~0.05B | 0.03 GB | 仅克隆时 | 每句一次 |
| **合计常驻** | ~3.1B | **~1.7 GB** | ~44 GB/s | 未计 KV cache |

44 GB/s 相对 76.8 GB/s 的峰值留了约 40% 余量，考虑实测有效带宽通常只有峰值的 60–70%，
**RTF 估计 0.8–1.6**（10 秒语音约 8–16 秒生成完）。INT8 档体积翻倍、带宽需求同比例上升，
RTF 大约再差 30–40%。

结论：12 GB 机型内存充裕（峰值约 4.5 GB），瓶颈在带宽而不是容量，所以默认档把
backbone 与深度解码器压到 INT4，把精度预算留给文本编码器与声码器。
