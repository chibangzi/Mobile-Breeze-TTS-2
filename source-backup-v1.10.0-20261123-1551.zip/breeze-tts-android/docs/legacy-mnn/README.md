# 旧 MNN 路线（已归档，仅供回溯）

这一目录里的文档与 `tools/legacy-mnn/` 里的脚本，属于 App 的**第一版架构**：
`PyTorch → ONNX → MNN`，需要在 PC / GPU 上把 7 GB 的 Breeze TTS 2 原始权重
自行导出、量化成六个 `.mnn` 模块，再由 App 按 `breeze.json` 清单下载。

**现版本已改为 GGUF 原生后端，不再需要任何模型转换**：导入一个 `.gguf`
文件即可推理。当前架构见 [`../02-gguf-backend.md`](../02-gguf-backend.md)。

归档内容：

| 文件 | 内容 |
| --- | --- |
| `02-mnn-on-device.md` | MNN Chat 的后端 / 量化 / TTS 流水线调研，以及 GGUF 与 MNN 格式不兼容的分析 |
| `03-architecture.md` | 六个 MNN 模块的输入输出契约与生成主循环 |
| `04-model-conversion.md` | ONNX 导出与量化全流程 |
| `05-build-run.md` | 旧版构建、下载与使用说明 |
| `tools/legacy-mnn/*.py` | 分词器导出 / 子模块导出 / 量化 / 打包 / 发布 / 一致性校验脚本 |
| `tools/legacy-mnn/build_mnn_android.sh` | MNN arm64 运行库交叉编译脚本 |

保留它们的原因：其中关于 **Breeze TTS 2 模型结构、四套 prompt 模板、特殊 token id**
的调研结论（见 `../01-research-breeze-tts-2.md`）仍然有效；自研 BPE 分词器与官方
`tokenizers` 的 13/13 一致性验证也是可复用的工程记录。

`app/app/src/main/cpp/breeze_tokenizer.*` 是这套自研 BPE 的 C++ 实现，现仍留在
源码目录中但**不参与编译**（新后端的 tokenizer 直接来自 GGUF）。
