#include "breeze/codec.h"
#include "breeze/common.h"

#include <cfloat>
#include <cmath>
#include <string>

namespace breeze {

using namespace codec_detail;

// GPU 图的固定帧数，必须与 Android 侧 VocoderGpu.FRAMES 一致。
// 对不上不会算错：Kotlin 那边帧数越界会抛异常，native 收到就回落 CPU。
static constexpr int kGpuFrames = 128;

static ggml_tensor * transpose_cont(ggml_context * ctx, ggml_tensor * x) {
    return ggml_cont(ctx, ggml_transpose(ctx, x));
}

std::vector<float> MimiCodec::decode_latent(const std::vector<int> & codes, int T, int n_cb) {
    if (n_cb <= 0) n_cb = m->cfg.num_codebooks;
    const int C = m->cfg.voc.latent_dim;

    Graph g(32768);
    ggml_tensor * x = vocoder_latent(g.ctx, *m, g, codes, n_cb, T);
    g.compute(m->backend, x);
    const std::vector<float> raw = tensor_to_f32(x);   // ggml 布局：raw[t + c*T]

    // 必须转成行主序再交出去。
    //
    // ggml 的 ne0 是**变化最快**的那一维，vocoder_latent 返回的 ne0 是 T，
    // 所以内存里时间是连续的（每帧的 1024 个通道相隔 T 个 float）。而 TFLite
    // 的输入是 [1,T,1,C]，最后一维连续 —— 恰好相反。
    //
    // 不转置也能跑完：声码器照样吐 24 kHz、能量正常的波形，只是全是噪声，
    // 能听出音高轮廓但一个字也听不清。自检发现不了，因为它 CPU/GPU 两边喂
    // 的是同一份人工构造的数据，布局错得一致。1.9.87 就是这么发出去的。
    std::vector<float> out((size_t) T * (size_t) C);
    for (int c = 0; c < C; c++) {
        const float * src = raw.data() + (size_t) c * (size_t) T;
        for (int t = 0; t < T; t++) out[(size_t) t * (size_t) C + c] = src[t];
    }
    return out;
}

std::vector<float> MimiCodec::decode(const std::vector<int> & codes, int T, int n_cb) {
    trace("voc:decode T=%d", T);

    if (n_cb <= 0) n_cb = m->cfg.num_codebooks;

    // GPU 路径：只跑到 transformer 输出，后半段交给 external。任何失败都回落
    // 到 CPU 全链路 —— 声码器只占整链路四分之一，不值得为它让整次合成失败。
    if (external && T > 0) {
        try {
            std::vector<float> lat = decode_latent(codes, T, n_cb);
            const int C = m->cfg.voc.latent_dim;
            const int spf = m->cfg.samples_per_frame;
            const size_t want = (size_t) T * (size_t) spf;
            if (lat.size() == (size_t) T * (size_t) C) {
                // 只把最后 kGpuFrames 帧交给 GPU。
                //
                // T 是 88（transformer 滑窗上下文）+ chunk，而卷积这部分实测只需要
                // 8 帧上下文就与全上下文逐位一致（2 帧差 11.9%、4 帧 0.59%、
                // 6 帧 0.087%、8 帧 0.000%）。所以 T 大于图的长度时，前面那些帧
                // 对最终的 chunk 帧毫无影响，白算。
                //
                // 这里截取尾部、把结果写到 out 的对应位置；开头那段留零，
                // 调用方（deliver）只取最后 chunk 帧，不会读到。
                const int n_frames = T < kGpuFrames ? T : kGpuFrames;
                const int off = T - n_frames;
                std::vector<float> out(want, 0.0f);
                const int n = external(lat.data() + (size_t) off * C, n_frames,
                                       out.data() + (size_t) off * spf,
                                       (int) (want - (size_t) off * spf));
                if (n == n_frames * spf) return out;
                trace("voc:external returned %d, want %d, falling back", n, n_frames * spf);
            }
            trace("voc:external returned nothing, falling back");
        } catch (const std::exception & e) {
            trace("voc:external threw %s, falling back", e.what());
        }
    }

    Graph g(32768);
    ggml_tensor * x = vocoder_decode(g.ctx, *m, g, codes, n_cb, T);
    ggml_tensor * audio = ggml_cont(g.ctx, ggml_reshape_1d(g.ctx, x, x->ne[0]));
    g.compute(m->backend, audio);
    return tensor_to_f32(audio);
}

static int nearest(const std::vector<float> & book, const float * v, int dim, int n) {
    int best = 0;
    float best_d = FLT_MAX;
    for (int c = 0; c < n; c++) {
        const float * b = &book[(size_t) c * dim];
        float d = 0.0f;
        for (int k = 0; k < dim; k++) {
            float diff = v[k] - b[k];
            d += diff * diff;
        }
        if (d < best_d) { best_d = d; best = c; }
    }
    return best;
}

static std::vector<float> read_book(BreezeModel & m, const std::string & name) {
    return tensor_to_f32(m.w(name));
}

std::vector<int> MimiCodec::encode(const std::vector<float> & audio, int & n_frames) {
    const int nc = m->cfg.num_codebooks;
    const int n_sem = m->cfg.codec.num_semantic;
    const int n_ac = nc - n_sem;
    const int dim = m->cfg.codec.codebook_dim;
    const int book = m->cfg.codec_codebook_size;

    Graph g(16384);
    ggml_tensor * x = g.input_f32(audio, (int) audio.size(), 1); // [L, 1]
    x = seanet_encoder(g.ctx, *m, x);                            // [T, hidden]
    x = transpose_cont(g.ctx, x);                                // [hidden, T]
    x = mimi_transformer(g.ctx, *m, g, x, "codec.enct", (int) x->ne[1]);
    x = transpose_cont(g.ctx, x);                                // [T, hidden]
    x = conv1d_causal(g.ctx, m->w("codec.downsample.conv.weight"), nullptr, x, 2, 1); // [T2, hidden]
    ggml_tensor * emb = transpose_cont(g.ctx, x);                // [hidden, T2]
    ggml_tensor * rs = linear(g.ctx, m->w("codec.sq.in_proj.weight"), emb); // [dim, T2]
    ggml_tensor * ra = linear(g.ctx, m->w("codec.aq.in_proj.weight"), emb); // [dim, T2]
    ggml_set_output(rs);
    g.write(rs);
    g.compute(m->backend, ra);

    std::vector<float> rs_h = tensor_to_f32(rs);
    std::vector<float> ra_h = tensor_to_f32(ra);
    const int T = (int) ra->ne[1];
    n_frames = T;

    std::vector<float> sbook = read_book(*m, "codec.sq.0.embed");
    std::vector<std::vector<float>> abook(n_ac);
    for (int i = 0; i < n_ac; i++) abook[i] = read_book(*m, "codec.aq." + std::to_string(i) + ".embed");

    std::vector<int> codes((size_t) T * nc);
    std::vector<float> res(dim);
    for (int f = 0; f < T; f++) {
        codes[(size_t) f * nc + 0] = nearest(sbook, &rs_h[(size_t) f * dim], dim, book);
        for (int k = 0; k < dim; k++) res[k] = ra_h[(size_t) f * dim + k];
        for (int i = 0; i < n_ac; i++) {
            int c = nearest(abook[i], res.data(), dim, book);
            codes[(size_t) f * nc + (n_sem + i)] = c;
            const float * b = &abook[i][(size_t) c * dim];
            for (int k = 0; k < dim; k++) res[k] -= b[k];
        }
    }
    return codes;
}

}
