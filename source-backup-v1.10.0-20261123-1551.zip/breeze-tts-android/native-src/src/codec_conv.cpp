#include "breeze/codec.h"

#include <cstdlib>
#include <string>
#include <vector>

namespace breeze {
namespace codec_detail {

ggml_tensor * conv1d_causal(ggml_context * ctx, ggml_tensor * w, ggml_tensor * b,
                            ggml_tensor * x, int stride, int dilation) {
    const int K = (int) w->ne[0];
    int pad = (K - 1) * dilation - (stride - 1);
    if (pad < 0) pad = 0;
    if (!ggml_is_contiguous(x)) x = ggml_cont(ctx, x);
    const int64_t n_out = (x->ne[0] + pad - (int64_t) dilation * (K - 1) - 1) / stride + 1;
    ggml_tensor * y = ggml_conv_1d(ctx, w, x, stride, pad, dilation);
    if (y->ne[0] != n_out) {
        y = ggml_cont(ctx, ggml_view_2d(ctx, y, n_out, y->ne[1], y->nb[1], 0));
    }
    if (b) y = ggml_add(ctx, y, ggml_reshape_2d(ctx, b, 1, b->ne[0]));
    return y;
}

// 转置卷积的等价改写（1.9.5）。
//
// 上游用的 ggml_conv_transpose_1d 是**标量**实现：每个输出点单独循环，
// 不吃 NEON / i8mm，主机实测同一形状 413 ms，而等价的 GEMM 写法只要 69 ms（6×）。
// 声码器 6 层转置卷积（stride 2,2,8,5,4,3）占了整段 8.1 s 的大头，全卡在这里。
//
// 数学等价关系：对 stride = s、kernel = K、输入 x[L, Cin]，
//     out[i*s + r] = sum_j  w[r + j*s] · x[i - j]        r ∈ [0, s)
// 也就是「按相位拆成 s 条独立的因果卷积」——每条都是一个普通 GEMM，
// 计算量与原实现完全相同（不引入零插值，避免算力被放大 s 倍），
// 最后把 s 条结果按 r 交错拼回 [L*s, Cout]。
//
// 与标量实现的差异只有累加顺序，F32 下误差在 1e-6 量级（见 tools/convtr_check）。
static bool convtr1d_use_gemm() {
    static const bool on = [] {
        const char * e = getenv("BREEZE_CONVTR_SCALAR");
        return !(e && e[0] == '1');
    }();
    return on;
}

static ggml_tensor * convtr1d_causal_gemm(ggml_context * ctx, ggml_tensor * w, ggml_tensor * b,
                                          ggml_tensor * x, int stride) {
    const int64_t K = w->ne[0];
    const int64_t Cout = w->ne[1];
    const int64_t Cin = w->ne[2];
    const int64_t L = x->ne[0];
    const int s = stride;
    GGML_ASSERT(s >= 1 && s <= 16);

    if (!ggml_is_contiguous(x)) x = ggml_cont(ctx, x);
    // x: [L, Cin] → xT: [Cin, L]，让收缩维落在 ne0，才能直接用 mul_mat
    ggml_tensor * xT = ggml_cont(ctx, ggml_transpose(ctx, x));

    // 每个相位最多 Kr 个抽头；前面补 Kr-1 帧零，因果对齐（对应 conv_transpose 的左填充）
    const int64_t Kr = (K + s - 1) / s;
    if (Kr > 1) xT = ggml_pad_ext(ctx, xT, 0, 0, Kr - 1, 0, 0, 0, 0, 0);

    // w: [K, Cout, Cin] → [Cin, Cout, K]（一次转置拷贝，之后每个抽头都是连续视图）
    ggml_tensor * wt = ggml_cont(ctx, ggml_permute(ctx, w, 2, 1, 0, 3));

    ggml_tensor * acc = nullptr;
    for (int r = 0; r < s; r++) {
        ggml_tensor * phase = nullptr;
        for (int64_t j = 0; j < Kr; j++) {
            const int64_t m = (int64_t) r + j * s;
            if (m >= K) break;
            // x[i - j] 的整段：xp 里偏移 (Kr-1-j) 帧起的 L 列
            ggml_tensor * seg = ggml_view_2d(ctx, xT, Cin, L, xT->nb[1],
                                             (size_t) (Kr - 1 - j) * xT->nb[1]);
            ggml_tensor * wj = ggml_view_2d(ctx, wt, Cin, Cout, wt->nb[1],
                                            (size_t) m * wt->nb[2]);
            ggml_tensor * t = ggml_mul_mat(ctx, wj, seg);   // [Cout, L]
            phase = phase ? ggml_add(ctx, phase, t) : t;
        }
        if (!phase) continue;                                // 该相位没有抽头（K < r）
        acc = acc ? ggml_concat(ctx, acc, phase, 1) : phase;  // 沿时间维堆叠：[Cout, s*L]
    }
    if (!acc) acc = ggml_cont(ctx, ggml_view_2d(ctx, xT, Cout, L, xT->nb[1], 0));

    // [Cout, s*L]（r 慢、i 快）→ [L*s, Cout]（i 慢、r 快）
    const int64_t n_phase = (acc->ne[1] + L - 1) / L;
    ggml_tensor * y = ggml_cont(ctx, ggml_transpose(ctx, acc));   // [s*L, Cout]
    if (n_phase > 1) {
        y = ggml_reshape_3d(ctx, y, L, n_phase, Cout);
        y = ggml_cont(ctx, ggml_permute(ctx, y, 1, 0, 2, 3));
    }
    y = ggml_reshape_2d(ctx, y, L * s, Cout);
    if (b) y = ggml_add(ctx, y, ggml_reshape_2d(ctx, b, 1, b->ne[0]));
    return y;
}

ggml_tensor * convtr1d_causal(ggml_context * ctx, ggml_tensor * w, ggml_tensor * b,
                              ggml_tensor * x, int stride) {
    if (convtr1d_use_gemm()) return convtr1d_causal_gemm(ctx, w, b, x, stride);

    ggml_tensor * y = ggml_conv_transpose_1d(ctx, w, x, stride, 0, 1);
    const int keep = (int) x->ne[0] * stride;
    y = ggml_cont(ctx, ggml_view_2d(ctx, y, keep, y->ne[1], y->nb[1], 0));
    if (b) y = ggml_add(ctx, y, ggml_reshape_2d(ctx, b, 1, b->ne[0]));
    return y;
}

ggml_tensor * resnet_block(ggml_context * ctx, BreezeModel & m, const std::string & p, ggml_tensor * x) {
    ggml_tensor * h = ggml_elu(ctx, x);
    h = conv1d_causal(ctx, m.w(p + ".block.1.conv.weight"), m.w(p + ".block.1.conv.bias"), h, 1, 1);
    h = ggml_elu(ctx, h);
    h = conv1d_causal(ctx, m.w(p + ".block.3.conv.weight"), m.w(p + ".block.3.conv.bias"), h, 1, 1);
    return ggml_add(ctx, x, h);
}

// depthwise conv as shift and multiply, ggml conv ops have no group support
// x is [L, C], w is [C, K]
ggml_tensor * depthwise1d_causal(ggml_context * ctx, ggml_tensor * w, ggml_tensor * b,
                                 ggml_tensor * x, int K) {
    const int64_t L = x->ne[0];
    const int64_t C = x->ne[1];
    ggml_tensor * xp = ggml_pad_ext(ctx, x, 0, K - 1, 0, 0, 0, 0, 0, 0);
    xp = ggml_roll(ctx, xp, K - 1, 0, 0, 0);
    ggml_tensor * acc = nullptr;
    for (int k = 0; k < K; k++) {
        ggml_tensor * seg = ggml_cont(ctx, ggml_view_2d(ctx, xp, L, C, xp->nb[1], (size_t) k * xp->nb[0]));
        ggml_tensor * wk = ggml_cont(ctx, ggml_transpose(ctx,
            ggml_view_2d(ctx, w, C, 1, w->nb[1], (size_t) k * w->nb[1])));
        ggml_tensor * t = ggml_mul(ctx, seg, wk);
        acc = acc ? ggml_add(ctx, acc, t) : t;
    }
    if (b) acc = ggml_add(ctx, acc, ggml_reshape_2d(ctx, b, 1, b->ne[0]));
    return acc;
}

ggml_tensor * seanet_encoder(ggml_context * ctx, BreezeModel & m, ggml_tensor * x) {
    const std::vector<int> & up = m.cfg.codec.upsampling_ratios;
    auto conv = [&](int i, ggml_tensor * in, int s) {
        const std::string p = "codec.enc." + std::to_string(i);
        return conv1d_causal(ctx, m.w(p + ".conv.weight"), m.w(p + ".conv.bias"), in, s, 1);
    };
    const int conv_idx[4] = { 3, 6, 9, 12 };
    const int res_idx[4] = { 1, 4, 7, 10 };
    const int ratios[4] = { up[3], up[2], up[1], up[0] };
    ggml_tensor * h = conv(0, x, 1);
    for (int s = 0; s < 4; s++) {
        h = resnet_block(ctx, m, "codec.enc." + std::to_string(res_idx[s]), h);
        h = ggml_elu(ctx, h);
        h = conv(conv_idx[s], h, ratios[s]);
    }
    h = ggml_elu(ctx, h);
    return conv(14, h, 1);
}

}
}
