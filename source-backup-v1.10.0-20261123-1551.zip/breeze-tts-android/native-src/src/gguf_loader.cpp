#include "breeze/gguf_loader.h"

#include "ggml-alloc.h"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <stdexcept>

#ifndef _WIN32
#include <sys/mman.h>
#endif

namespace breeze {

// ---------------------------------------------------------------------------
// 1.9.100 THP 偏好：只影响之后的分配。诊断页切换后会重载模型，让新页在
// fault 时就落成大页；直接对已加载区 madvise 只作为「不重载」时的尽力而为。
// ---------------------------------------------------------------------------
static std::atomic<bool> g_thp{false};

void set_thp_pref(bool on) { g_thp.store(on, std::memory_order_relaxed); }
bool thp_pref() { return g_thp.load(std::memory_order_relaxed); }

static int advise_one(ggml_backend_buffer_t b, bool on) {
    if (!b) return 0;
    // 只处理 CPU 权重区：GPU buffer 的 base 在 Vulkan/OpenCL 那边，不能 madvise。
    if (ggml_backend_buffer_get_type(b) != ggml_backend_cpu_buffer_type()) return 0;
    void * base = ggml_backend_buffer_get_base(b);
    const size_t size = ggml_backend_buffer_get_size(b);
    if (!base || size == 0) return 0;
#ifdef MADV_HUGEPAGE
    const int advice = on ? MADV_HUGEPAGE : MADV_NOHUGEPAGE;
    return ::madvise(base, size, advice) == 0 ? 1 : 0;
#else
    (void) on;
    return 0;
#endif
}

int apply_thp(GGUFModel & m, bool on) {
    int ok = 0;
    // buffer 常常只是 buffers.front() 的别名，重复 madvise 无害，但计数会翻倍，
    // 所以这里按指针去重，返回「真正处理了几个不同的区间」。
    ggml_backend_buffer_t seen[16];
    int nseen = 0;
    auto visit = [&](ggml_backend_buffer_t b) {
        if (!b) return;
        for (int i = 0; i < nseen; i++) if (seen[i] == b) return;
        if (nseen < 16) seen[nseen++] = b;
        if (advise_one(b, on)) ok++;
    };
    for (ggml_backend_buffer_t b : m.buffers) visit(b);
    visit(m.buffer);
    visit(m.buffer_repack);
    return ok;
}

std::string thp_sys_mode() {
#ifdef __linux__
    FILE * f = std::fopen("/sys/kernel/mm/transparent_hugepage/enabled", "r");
    if (!f) return "unknown";
    char buf[256] = {0};
    const size_t n = std::fread(buf, 1, sizeof(buf) - 1, f);
    std::fclose(f);
    if (n == 0) return "unknown";
    std::string s(buf);
    // 格式：always [madvise] never —— 方括号里是当前生效项
    const size_t l = s.find('[');
    const size_t r = s.find(']');
    if (l != std::string::npos && r != std::string::npos && r > l) return s.substr(l + 1, r - l - 1);
    for (const char * k : {"always", "madvise", "never"})
        if (s.find(k) != std::string::npos) return k;
    return "unknown";
#else
    return "unknown";
#endif
}

#ifdef _WIN32
#define breeze_fseek _fseeki64
#else
#define breeze_fseek fseeko
#endif

// A weight may only live in the repacked buffer when nothing ever views or row-indexes it.
// The repack layout interleaves 8 (or 4) rows so the ARM i8mm kernels can do 4x8 int8 dots,
// which means `nb[1]` no longer describes a whole row: `ggml_view_2d` slices by rows and
// `ggml_get_rows` (embeddings, per-codebook tables) read rows directly. Both would land on
// the wrong bytes. Everything else is a plain `mul_mat` operand and is safe to repack.
//
// Row count is the second trap, and it is what broke Q4_K: ggml's repack kernels interleave
// whole groups of 8 (K-quants) or 4 (Q4_0/Q8_0) rows, so a weight whose `ne[1]` is not a
// multiple of that has no kernel at all. `ggml_repack_get_optimal_repack_type()` then returns
// null, and the repack buffer's `set_tensor` calls a *virtual* `repack()` through that null
// pointer — a SIGSEGV while loading, not an exception. The backbone head is exactly such a
// tensor: it is 2048 -> 2052, and 2052 % 8 == 4. Q8_0 only needs groups of 4 rows so it
// loaded fine, while Q4_K/Q6_K crashed the moment the loader reached the head.
static int repack_row_multiple(ggml_type type) {
    switch (type) {
        case GGML_TYPE_Q4_K:
        case GGML_TYPE_Q5_K:
        case GGML_TYPE_Q6_K: return 8;
        case GGML_TYPE_Q4_0:
        case GGML_TYPE_Q8_0:
        case GGML_TYPE_IQ4_NL: return 4;
        // Q2_K/Q3_K have no NEON implementation in this ggml: repacking them would hand
        // back a null trait and crash on the same line.
        default: return 0;
    }
}

static bool repack_candidate(const std::string & name, const ggml_tensor * t) {
    if (!ggml_is_quantized(t->type)) return false;
    if (t->ne[0] <= 0 || t->ne[1] <= 0) return false;
    // only 2-D weights reach the repacked matmul path; anything else would just eat memory
    if (ggml_n_dims(t) != 2) return false;
    const int rows = repack_row_multiple(t->type);
    if (rows == 0 || t->ne[1] % rows != 0) return false;
    if (name.size() < 7 || name.compare(name.size() - 7, 7, ".weight") != 0) return false;
    static const char * const exact[] = {
        "bb.lm_head.weight",
        "dd.in_proj.weight",
        "te.proj.weight",
    };
    for (const char * e : exact)
        if (name == e) return true;
    // 1.9.104：文本编码器也要复排。它是 26 层 × 7 个 matmul，prompt 阶段占 734 ms
    // （6 线程实测），却因为前缀不匹配一直走普通 Q8_0 布局 —— 也就是 batch=100 的
    // GEMM 被当成逐行 dot 在算，只有峰值的 1.4%（主干 prefill 是 12%）。
    return name.rfind("bb.blk.", 0) == 0 || name.rfind("dd.blk.", 0) == 0 ||
           name.rfind("te.blk.", 0) == 0;
}

static ggml_backend_buffer_type_t repack_buffer_type(ggml_backend_t backend) {
    ggml_backend_dev_t dev = ggml_backend_get_device(backend);
    if (!dev) return nullptr;
    ggml_backend_reg_t reg = ggml_backend_dev_backend_reg(dev);
    if (!reg) return nullptr;
    // not a public symbol: the backend exposes it through the registry, like llama.cpp does
    auto fct = (ggml_backend_dev_get_extra_bufts_t)
        ggml_backend_reg_get_proc_address(reg, "ggml_backend_dev_get_extra_bufts");
    if (!fct) return nullptr;
    ggml_backend_buffer_type_t * bufts = fct(dev);
    if (!bufts) return nullptr;
    for (int i = 0; bufts[i]; i++) {
        const char * n = ggml_backend_buft_name(bufts[i]);
        if (n && std::strstr(n, "REPACK")) return bufts[i];
    }
    return nullptr;
}

// give the buffer back and unbind the tensors, so they can be allocated somewhere else
static void release_group(ggml_backend_buffer_t buf, const std::vector<ggml_tensor *> & group) {
    if (buf) ggml_backend_buffer_free(buf);
    for (ggml_tensor * t : group) {
        t->buffer = nullptr;
        t->data = nullptr;
        t->extra = nullptr;
    }
}

// allocate one buffer for a group of tensors, honouring the buffer type's own alloc size
static ggml_backend_buffer_t alloc_group(ggml_context * ctx, ggml_backend_buffer_type_t buft,
                                         const std::vector<ggml_tensor *> & group) {
    if (group.empty()) return nullptr;
    const size_t align = std::max<size_t>(ggml_backend_buft_get_alignment(buft), 64);
    size_t size = 0;
    for (ggml_tensor * t : group) {
        size_t one = ggml_backend_buft_get_alloc_size(buft, t);
        if (one == 0) one = ggml_nbytes(t);
        size += (one + align - 1) / align * align;
    }
    ggml_backend_buffer_t buf = ggml_backend_buft_alloc_buffer(buft, size);
    if (!buf) return nullptr;
    ggml_tallocr tal = ggml_tallocr_new(buf);
    for (ggml_tensor * t : group) {
        if (ggml_tallocr_alloc(&tal, t) != GGML_STATUS_SUCCESS) {
            // tensors allocated so far are already bound to this buffer: unbind before freeing,
            // otherwise the plain pass asserts on a non-null tensor->buffer
            release_group(buf, group);
            return nullptr;
        }
    }
    return buf;
}

// 1.9.48：按 buffer type 的单次分配上限切块。Vulkan 的 suballocation_block_size 默认
// 1 GB，2.4 GB 的 Q4_K 整模型一次要下来必然被驱动拒绝；切成三块就能过。
// 任何一块失败就整组回滚到 CPU —— 半 GPU 半 CPU 每层都要拷激活，比纯 CPU 更慢。
static bool alloc_chunked(ggml_context * ctx, ggml_backend_buffer_type_t buft,
                          const std::vector<ggml_tensor *> & group,
                          std::vector<ggml_backend_buffer_t> & out) {
    if (group.empty()) return true;
    const size_t align = std::max<size_t>(ggml_backend_buft_get_alignment(buft), 64);
    size_t cap = ggml_backend_buft_get_max_size(buft);
    if (cap == 0) cap = SIZE_MAX;

    size_t idx = 0;
    while (idx < group.size()) {
        size_t size = 0, end = idx;
        while (end < group.size()) {
            size_t one = ggml_backend_buft_get_alloc_size(buft, group[end]);
            if (one == 0) one = ggml_nbytes(group[end]);
            const size_t padded = (one + align - 1) / align * align;
            if (size + padded > cap && end > idx) break;
            size += padded;
            end++;
        }
        ggml_backend_buffer_t buf = ggml_backend_buft_alloc_buffer(buft, size);
        if (!buf) {
            for (ggml_backend_buffer_t b : out) ggml_backend_buffer_free(b);
            out.clear();
            for (ggml_tensor * t : group) { t->buffer = nullptr; t->data = nullptr; t->extra = nullptr; }
            return false;
        }
        ggml_tallocr tal = ggml_tallocr_new(buf);
        for (size_t i = idx; i < end; i++) {
            if (ggml_tallocr_alloc(&tal, group[i]) != GGML_STATUS_SUCCESS) {
                ggml_backend_buffer_free(buf);
                for (ggml_backend_buffer_t b : out) ggml_backend_buffer_free(b);
                out.clear();
                for (ggml_tensor * t : group) { t->buffer = nullptr; t->data = nullptr; t->extra = nullptr; }
                return false;
            }
        }
        out.push_back(buf);
        idx = end;
    }
    return true;
}

// Interleaved rows read wrong if anything about the layout is off, and the failure mode is
// noise rather than an exception. Dot the first row of a freshly repacked weight against the
// bytes straight from the file: same numbers or the buffer type is not usable here.
static bool repack_matches_disk(Backend & be, ggml_tensor * w, const uint8_t * raw) {
    const int64_t n_in = w->ne[0];
    const ggml_type_traits * tt = ggml_get_type_traits(w->type);
    if (n_in <= 0 || n_in > 16384 || !tt || !tt->to_float) return true;

    std::vector<float> ref((size_t) n_in);
    tt->to_float(raw, ref.data(), n_in);
    double expect = 0.0;
    for (float v : ref) expect += v;

    Graph g(64);
    std::vector<float> ones((size_t) n_in, 1.0f);
    ggml_tensor * x = g.input_f32(ones, n_in);
    ggml_tensor * y = ggml_mul_mat(g.ctx, w, x);
    g.compute(be, y);
    const std::vector<float> got = tensor_to_f32(y);
    if (got.empty() || !std::isfinite(got[0])) return false;

    const double tol = 0.02 * std::fabs(expect) + 0.5;
    return std::fabs(got[0] - expect) <= tol;
}

bool GGUFModel::load(const std::string & path, Backend & be, bool allow_repack) {
    gguf_init_params gp{ /*no_alloc=*/true, /*ctx=*/&meta };
    gguf = gguf_init_from_file(path.c_str(), gp);
    if (!gguf) return false;

    const int64_t n_tensors = gguf_get_n_tensors(gguf);
    std::vector<ggml_tensor *> repackable, plain;
    if (n_tensors > 0) {
        repackable.reserve((size_t) n_tensors);
        plain.reserve((size_t) n_tensors);
        for (ggml_tensor * t = ggml_get_first_tensor(meta); t; t = ggml_get_next_tensor(meta, t)) {
            if (repack_candidate(t->name, t)) repackable.push_back(t);
            else plain.push_back(t);
        }
    }

    // try the repack layout first; anything that goes wrong falls back to plain memory so a
    // backend without repack support still loads, just slower
    // GPU 模式下 repack 没有意义：Vulkan 用自己的量化 shader 直接读 K-quant，
    // 而且 repack 布局会让 sched 判断 tensor 归属时多一层麻烦。
    ggml_backend_buffer_type_t rp = (allow_repack && !be.gpu) ? repack_buffer_type(be.backend) : nullptr;

    // Even after the row-count filter a tensor can come back without a repack kernel: a CPU
    // lacking i8mm/dotprod has no K-quant interleave at all. `tensor->extra` is what set_tensor
    // calls through, so drop any such tensor *before* a single byte is written into the buffer.
    while (rp && !repackable.empty()) {
        buffer_repack = alloc_group(meta, rp, repackable);
        if (!buffer_repack) break;
        std::vector<ggml_tensor *> unsupported;
        for (ggml_tensor * t : repackable)
            if (!t->extra) unsupported.push_back(t);
        if (unsupported.empty()) break;
        release_group(buffer_repack, repackable);
        buffer_repack = nullptr;
        std::fprintf(stderr, "breeze: %zu weight(s) have no repack kernel, keeping them plain\n",
                     unsupported.size());
        for (ggml_tensor * t : unsupported) {
            plain.push_back(t);
            repackable.erase(std::remove(repackable.begin(), repackable.end(), t), repackable.end());
        }
    }

    if (buffer_repack) {
        repack_tensors = (int) repackable.size();
        for (ggml_tensor * t : repackable) repack_bytes += ggml_nbytes(t);
    } else {
        // failed: put those tensors back with the plain ones
        for (ggml_tensor * t : repackable) plain.push_back(t);
        repack_tensors = 0;
        repack_bytes = 0;
    }

    if (be.gpu) {
        if (!alloc_chunked(meta, ggml_backend_get_default_buffer_type(be.gpu), plain, buffers)) {
            std::fprintf(stderr, "breeze: vulkan buffer allocation failed, falling back to CPU\n");
            be.gpuBytes = 0;
            buffers.clear();
        } else {
            for (ggml_tensor * t : plain) be.gpuBytes += ggml_nbytes(t);
            buffer = buffers.empty() ? nullptr : buffers.front();
        }
    }
    if (buffers.empty()) {
        buffer = alloc_group(meta, ggml_backend_get_default_buffer_type(be.backend), plain);
        if (!buffer) return false;
        for (ggml_tensor * t : plain) be.cpuBytes += ggml_nbytes(t);
    }

    // 1.9.100：在写入任何张量之前打标，这样 fread 后第一次 fault 就会落成大页。
    // 放在分配之后、fread 之前，是 THP 唯一确定生效的时机。
    if (thp_pref()) apply_thp(*this, true);

    FILE * f = fopen(path.c_str(), "rb");
    if (!f) return false;

    const size_t data_off = gguf_get_data_offset(gguf);
    const int64_t n = gguf_get_n_tensors(gguf);
    int verify = buffer_repack ? 1 : 0;   // 1 = still unchecked, 0 = done
    bool verified = true;
    std::vector<uint8_t> buf;
    for (int64_t i = 0; i < n; i++) {
        const char * name = gguf_get_tensor_name(gguf, i);
        ggml_tensor * t = ggml_get_tensor(meta, name);
        const size_t off = data_off + gguf_get_tensor_offset(gguf, i);
        const size_t sz = ggml_nbytes(t);
        buf.resize(sz);
        if (breeze_fseek(f, (long long) off, SEEK_SET) != 0) { fclose(f); return false; }
        if (fread(buf.data(), 1, sz, f) != sz) { fclose(f); return false; }
        // for a repacked tensor ggml_backend_tensor_set runs the row interleave for us
        ggml_backend_tensor_set(t, buf.data(), 0, sz);
        tensors[name] = t;
        if (verify == 1 && repack_candidate(t->name, t)) {
            verify = 0;
            verified = repack_matches_disk(be, t, buf.data());
        }
    }
    fclose(f);

    if (!verified) {
        // the layout came out wrong: reload everything in plain memory rather than emit noise
        free();
        return load(path, be, false);
    }
    return true;
}

void GGUFModel::free() {
    // buffers 非空时 buffer 只是 buffers.front() 的别名，别重复释放
    if (!buffers.empty()) {
        for (ggml_backend_buffer_t b : buffers) ggml_backend_buffer_free(b);
        buffers.clear();
        buffer = nullptr;
    }
    if (buffer) ggml_backend_buffer_free(buffer);
    if (buffer_repack) ggml_backend_buffer_free(buffer_repack);
    if (meta) ggml_free(meta);
    if (gguf) gguf_free(gguf);
    buffer = nullptr;
    buffer_repack = nullptr;
    repack_bytes = 0;
    repack_tensors = 0;
    meta = nullptr;
    gguf = nullptr;
}

ggml_tensor * GGUFModel::find(const std::string & name) const {
    auto it = tensors.find(name);
    return it == tensors.end() ? nullptr : it->second;
}

ggml_tensor * GGUFModel::get(const std::string & name) const {
    ggml_tensor * t = find(name);
    if (!t) throw std::runtime_error("missing tensor: " + name);
    return t;
}

bool GGUFModel::has(const std::string & name) const {
    return tensors.count(name) > 0;
}

int GGUFModel::kv_u32(const char * key, int def) const {
    const int64_t id = gguf_find_key(gguf, key);
    if (id < 0) return def;
    switch (gguf_get_kv_type(gguf, id)) {
        case GGUF_TYPE_UINT32: return (int) gguf_get_val_u32(gguf, id);
        case GGUF_TYPE_INT32:  return (int) gguf_get_val_i32(gguf, id);
        case GGUF_TYPE_UINT64: return (int) gguf_get_val_u64(gguf, id);
        case GGUF_TYPE_INT64:  return (int) gguf_get_val_i64(gguf, id);
        default: return def;
    }
}

float GGUFModel::kv_f32(const char * key, float def) const {
    const int64_t id = gguf_find_key(gguf, key);
    if (id < 0) return def;
    const gguf_type t = gguf_get_kv_type(gguf, id);
    if (t == GGUF_TYPE_FLOAT32) return gguf_get_val_f32(gguf, id);
    if (t == GGUF_TYPE_FLOAT64) return (float) gguf_get_val_f64(gguf, id);
    return def;
}

bool GGUFModel::kv_bool(const char * key, bool def) const {
    const int64_t id = gguf_find_key(gguf, key);
    if (id < 0) return def;
    if (gguf_get_kv_type(gguf, id) == GGUF_TYPE_BOOL) return gguf_get_val_bool(gguf, id);
    return def;
}

std::string GGUFModel::kv_str(const char * key, const std::string & def) const {
    const int64_t id = gguf_find_key(gguf, key);
    if (id < 0 || gguf_get_kv_type(gguf, id) != GGUF_TYPE_STRING) return def;
    return gguf_get_val_str(gguf, id);
}

std::vector<int> GGUFModel::kv_i32_array(const char * key) const {
    std::vector<int> out;
    const int64_t id = gguf_find_key(gguf, key);
    if (id < 0 || gguf_get_kv_type(gguf, id) != GGUF_TYPE_ARRAY) return out;
    const size_t n = gguf_get_arr_n(gguf, id);
    const void * data = gguf_get_arr_data(gguf, id);
    const gguf_type at = gguf_get_arr_type(gguf, id);
    out.resize(n);
    for (size_t i = 0; i < n; i++) {
        if (at == GGUF_TYPE_INT32) out[i] = ((const int32_t *) data)[i];
        else if (at == GGUF_TYPE_UINT32) out[i] = (int) ((const uint32_t *) data)[i];
    }
    return out;
}

std::vector<std::string> GGUFModel::kv_str_array(const char * key) const {
    std::vector<std::string> out;
    const int64_t id = gguf_find_key(gguf, key);
    if (id < 0 || gguf_get_kv_type(gguf, id) != GGUF_TYPE_ARRAY) return out;
    const size_t n = gguf_get_arr_n(gguf, id);
    out.reserve(n);
    for (size_t i = 0; i < n; i++) out.emplace_back(gguf_get_arr_str(gguf, id, i));
    return out;
}

}
