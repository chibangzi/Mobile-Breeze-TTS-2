#include "breeze/model.h"

namespace breeze {

bool BreezeModel::load(const std::string & path, bool prefer_gpu) {
    backend.init(prefer_gpu);
    if (!gg.load(path, backend)) return false;
    // 权重一个字节都没放上 GPU（分配被驱动拒绝）时，把 GPU 后端也放掉：
    // 留着它只会让每个图都走一遍 sched 的切分与拷贝，比纯 CPU 更慢。
    if (backend.gpu && backend.gpuBytes == 0) {
        ggml_backend_free(backend.gpu);
        backend.gpu = nullptr;
        backend.is_gpu = false;
    }
    cfg = parse_config(gg);
    if (!tok.load(gg)) return false;
    return true;
}

void BreezeModel::free() {
    gg.free();
    backend.free();
}

}
