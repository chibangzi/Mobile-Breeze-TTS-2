#include "breeze/breeze.h"
#include "breeze/audio.h"
#include "breeze/generation.h"
#include "ggml-cpu.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <exception>
#include <string>
#include <vector>

using namespace breeze;

struct breeze_context {
    BreezeModel model;
    MimiCodec codec;
    GenTimings timings;   // filled by the last breeze_generate call
    // 1.9.105：参考前缀的 KV 快照。同一音色连续合成时省掉六到八成的 prefill。
    PrefixCache prefix;
};

static std::string g_error;

// 码本落盘：int16、帧优先（每帧 n_codebooks 个）。Kotlin 侧原样存成 <id>.codes，
// 下次把它当 ref_codes 传回来即可跳过一次 codec encode。
static bool write_codes_file(const char * path, const std::vector<int> & codes) {
    FILE * f = std::fopen(path, "wb");
    if (!f) return false;
    std::vector<int16_t> buf(codes.size());
    for (size_t i = 0; i < codes.size(); i++) buf[i] = (int16_t) codes[i];
    const size_t n = std::fwrite(buf.data(), sizeof(int16_t), buf.size(), f);
    std::fclose(f);
    return n == buf.size();
}

static GenRequest to_req(const breeze_request * r) {
    GenRequest g;
    g.text = r->text ? r->text : "";
    g.instruction = r->instruction ? r->instruction : "Speak clearly and naturally.";
    g.ref_text = r->ref_text ? r->ref_text : "";
    if (r->ref_audio && r->ref_audio_len > 0)
        g.ref_audio.assign(r->ref_audio, r->ref_audio + r->ref_audio_len);
    g.cfg_scale = r->cfg_scale > 0 ? r->cfg_scale : 1.0f;
    g.seed = r->seed;
    g.max_new_tokens = r->max_new_tokens;
    if (r->split_chars != 0) g.split_chars = r->split_chars < 0 ? 0 : r->split_chars;
    g.temperature = r->temperature;
    g.top_k = r->top_k;
    g.top_p = r->top_p;
    g.repetition_penalty = r->repetition_penalty;
    if (r->chunk_first > 0) g.chunk_first = r->chunk_first;
    if (r->chunk_max > 0) g.chunk_max = r->chunk_max;
    if (g.chunk_max < g.chunk_first) g.chunk_max = g.chunk_first;
    if (r->pace != 0) g.pace = r->pace > 0;
    // 0 keeps the engine default, a negative value turns the guard off
    if (r->pad_stop != 0) g.pad_stop = r->pad_stop < 0 ? 0 : r->pad_stop;
    if (r->cfg_decay_frames > 0) g.cfg_decay_frames = r->cfg_decay_frames;
    if (r->depth_cfg_off > 0) g.depth_cfg_off = true;
    if (r->voc_threads > 0) g.voc_threads = r->voc_threads;
    if (r->gen_threads > 0) g.gen_threads = r->gen_threads;
    // 1.9.69 诊断页对照实验：默认 0，正式合成路径完全不受影响。
    if (r->depth_mode > 0) g.depth_mode = r->depth_mode;
    // 1.9.106 码本截断实验：0 = 全部，正式合成恒 0。
    if (r->num_codebooks > 0) g.codebooks = r->num_codebooks;
    return g;
}

breeze_context * breeze_init(const char * gguf_path, int use_gpu) {
    breeze_context * c = new breeze_context();
    try {
        if (!c->model.load(gguf_path, use_gpu != 0)) {
            g_error = "failed to load model";
            delete c;
            return nullptr;
        }
    } catch (const std::exception & e) {
        g_error = e.what();
        delete c;
        return nullptr;
    }
    c->codec.init(c->model);
    return c;
}

// Reports the compute backend actually selected by BreezeModel::load.
// "Vulkan0" (or similar) means GPU acceleration is live; "CPU" means the
// Vulkan device was unavailable and ggml fell back to the CPU backend.
const char * breeze_backend_name(breeze_context * ctx) {
    if (!ctx) return "none";
    // append how much of the model landed in the repacked layout: it is the difference
    // between running the i8mm matmul kernels and the plain ones on arm64
    static thread_local std::string s;
    s = ctx->model.backend.name();
    const int n = ctx->model.gg.repack_tensors;
    if (n > 0) {
        char b[80];
        std::snprintf(b, sizeof b, " · i8mm %d块/%dMB", n, (int) (ctx->model.gg.repack_bytes >> 20));
        s += b;
    }
    return s.c_str();
}

int breeze_backend_is_gpu(breeze_context * ctx) {
    return (ctx && ctx->model.backend.is_gpu) ? 1 : 0;
}

void breeze_free(breeze_context * ctx) {
    if (ctx) {
        // 前缀快照的 KV 挂在 backend buffer 上，必须先于 model 释放。
        ctx->prefix.state.free();
        ctx->model.free();
        delete ctx;
    }
}

// ggml's CPU backend defaults to 4 threads, which leaves half of an 8-core
// flagship idle.  Let the host pick a sane value (6-8 on Snapdragon 8 Elite).
void breeze_set_threads(breeze_context * ctx, int n_threads) {
    if (!ctx || n_threads <= 0) return;
    if (ctx->model.backend.is_gpu) return;  // GPU backends manage their own queues
    if (!ctx->model.backend.backend) return;
    ggml_backend_cpu_set_n_threads(ctx->model.backend.backend, n_threads);
}

// ---------------------------------------------------------------------------
// 1.9.100 透明大页。开关本身是全局的（下一次 load 也会读），这里顺带对
// 已经加载的模型做一次尽力而为的 madvise —— 但真正可复现的效果要重载。
// ---------------------------------------------------------------------------
int breeze_set_thp(breeze_context * ctx, int on) {
    set_thp_pref(on != 0);
    if (!ctx) return 0;
    return apply_thp(ctx->model.gg, on != 0);
}

long long breeze_thp_bytes(breeze_context *) {
    // 自己的 smaps 不受 SELinux 限制；几千行 VMA，一次几十毫秒，只在诊断页调用。
    FILE * f = std::fopen("/proc/self/smaps", "r");
    if (!f) return -1;
    long long kb = 0;
    char line[512];
    while (std::fgets(line, sizeof(line), f)) {
        if (std::strncmp(line, "AnonHugePages:", 14) != 0) continue;
        long long v = 0;
        if (std::sscanf(line + 14, "%lld", &v) == 1) kb += v;
    }
    std::fclose(f);
    return kb * 1024;
}

const char * breeze_thp_mode(void) {
    static std::string s;
    s = thp_sys_mode();
    return s.c_str();
}

// Warm up BOTH inference paths. The app defaults to cfg_scale=4 for voice
// design / instruction following (matching the PC reference), which allocates
// a second (unconditioned) KV cache and a 2-branch depth decoder. Touching
// only the cfg=1 path would leave the first real design request paying for
// those allocations, so we run one short throwaway generation with cfg>1 too.
// This also forces all mmap'd weights into page cache and pre-builds the ggml
// graphs / scratch buffers / (on Vulkan) compute pipelines.
int breeze_warmup(breeze_context * ctx) {
    if (!ctx) return 1;
    try {
        GenRequest req;
        req.text = "Warming up.";
        req.max_new_tokens = 8;
        req.pace = false;
        req.chunk_first = 4;
        req.chunk_max = 8;

        req.cfg_scale = 1.0f;
        generate(ctx->model, ctx->codec, req, [](const float *, int) { return true; });

        req.cfg_scale = 4.0f;   // exercise cond/uncond branches + 2-deep depth runner
        generate(ctx->model, ctx->codec, req, [](const float *, int) { return true; });

        const int nc = ctx->model.cfg.num_codebooks;
        // Cover the real decode shapes so the first live flush does not pay for
        // scratch allocation: chunk_max + 88 context is the steady state, and the
        // tail flush after eos uses whatever is left over.
        for (int T : { 1, 2, 8, 16, 32, 64, 104, 160, 184 }) {
            std::vector<int> codes((size_t) T * nc, 0);
            ctx->codec.decode(codes, T);
        }
        return 0;
    } catch (const std::exception & e) {
        g_error = e.what();
        return 1;
    }
}

int breeze_sample_rate(breeze_context * ctx) {
    return ctx ? ctx->model.cfg.sample_rate : 0;
}

int breeze_generate(breeze_context * ctx, const breeze_request * req, breeze_audio_cb cb, void * user) {
    if (!ctx || !req) return 1;
    try {
        GenRequest g = to_req(req);

        // 已编码的参考码本优先于参考音频：省掉 codec encode，也是「锁定的设计音色」
        // 能复现同一个人的原因 —— 音色不再由采样决定，而是从这段码本出发。
        if (req->ref_codes && req->ref_frames > 0) {
            const int nc = ctx->model.cfg.num_codebooks;
            const size_t want = (size_t) req->ref_frames * (size_t) nc;
            g.ref_codes.assign(req->ref_codes, req->ref_codes + want);
            g.ref_frames = req->ref_frames;
            if (g.ref_text.empty()) g.ref_text = req->ref_text ? req->ref_text : "";
        }

        GenAnchor anchor;
        GenAnchor * anchor_out = (req->codes_out && req->codes_out[0]) ? &anchor : nullptr;

        ctx->timings = GenTimings();
        generate(ctx->model, ctx->codec, g, [&](const float * s, int n) {
            return cb ? cb(s, n, user) == 0 : true;
        }, &ctx->timings, anchor_out, &ctx->prefix);

        if (anchor_out && anchor.frames > 0 && !anchor.codes.empty())
            write_codes_file(req->codes_out, anchor.codes);
    } catch (const std::exception & e) {
        g_error = e.what();
        return 1;
    }
    return 0;
}

// Per stage wall clock of the last generation, for the host's stats panel.
void breeze_set_vocoder(breeze_context * ctx, breeze_vocoder_fn fn, void * user) {
    if (!ctx) return;
    if (!fn) {
        ctx->codec.external = nullptr;
        return;
    }
    // 只捕获函数指针和 user，不捕获 ctx —— 避免与 MimiCodec 形成环
    ctx->codec.external = [fn, user](const float * latent, int frames, float * out, int cap) {
        return fn(latent, frames, out, cap, user);
    };
}

int breeze_vocoder_check(breeze_context * ctx, int frames, float * out) {
    if (!ctx || !out || !ctx->codec.external || frames <= 0) return -1;
    const int nc = ctx->model.cfg.num_codebooks;
    const int book = ctx->model.cfg.codec_codebook_size > 0 ? ctx->model.cfg.codec_codebook_size : 2048;

    // 固定种子：每次自检的输入必须相同，误差才可比。索引打散在整个码本上，
    // 避免全 0 codes 退化成常数信号 —— 那种输入下什么实现都"对得上"。
    std::vector<int> codes((size_t) frames * nc);
    uint32_t st = 1234u;
    for (auto & c : codes) {
        st = st * 1664525u + 1013904223u;
        c = (int) ((st >> 8) % (uint32_t) book);
    }

    // 包一层，记下回调到底有没有被调用。没有就是回落 CPU 了，这时 GPU 结果
    // 等于 CPU 结果，误差 0%，不区分就会误判成"完美"。
    int called = 0;
    const auto orig = ctx->codec.external;
    ctx->codec.external = [&called, orig](const float * la, int f, float * o, int cap) {
        called++;
        return orig(la, f, o, cap);
    };

    const auto t0 = std::chrono::steady_clock::now();
    std::vector<float> gpu = ctx->codec.decode(codes, frames);
    out[3] = (float) std::chrono::duration<double, std::milli>(
                 std::chrono::steady_clock::now() - t0).count();

    ctx->codec.external = orig;
    if (!called) return -3;

    // 摘掉 external 跑一遍纯 CPU 全链路作为基准
    ctx->codec.external = nullptr;
    std::vector<float> cpu = ctx->codec.decode(codes, frames);
    ctx->codec.external = orig;

    if (gpu.empty() || gpu.size() != cpu.size()) return -2;

    double se = 0.0, sb = 0.0;
    size_t sat_g = 0, sat_c = 0;
    for (size_t i = 0; i < cpu.size(); i++) {
        const double d = (double) gpu[i] - (double) cpu[i];
        se += d * d;
        sb += (double) cpu[i] * (double) cpu[i];
        if (std::fabs(gpu[i]) >= 0.998f) sat_g++;
        if (std::fabs(cpu[i]) >= 0.998f) sat_c++;
    }
    const double n = (double) cpu.size();
    out[0] = (float) (std::sqrt(se / n) / (std::sqrt(sb / n) + 1e-12));
    out[1] = (float) sat_g / (float) n;
    out[2] = (float) sat_c / (float) n;
    return 0;
}

int breeze_get_timings(breeze_context * ctx, breeze_timings * out) {
    if (!ctx || !out) return 1;
    // 先清零：调用方（JNI）用自己的头文件编译，结构体可能比本库多字段，
    // 不清零会把栈上残留值当成数据读出去。
    std::memset(out, 0, sizeof(*out));
    const GenTimings & t = ctx->timings;
    out->prompt_ms = t.prompt;
    out->prefill_ms = t.prefill;
    out->backbone_ms = t.backbone;
    out->depth_ms = t.depth;
    out->vocoder_ms = t.vocoder;
    out->first_audio_ms = t.first_audio;
    out->tail_ms = t.tail;
    out->frames = t.frames;
    out->flushes = t.flushes;
    out->steps = t.steps;
    out->stopped_early = t.stopped_early;
    out->prefill_tokens = t.prefill_tokens;
    out->prefill_reused = t.prefill_reused;
    out->depth_fused_frames = t.depth_fused;
    out->depth_step_frames = t.depth_steps;
    return 0;
}

// Spoken length of a text in codec frames (12.5 per second), so the host can size
// both the token budget and the streaming pre-buffer without its own guess.
int breeze_estimate_frames(breeze_context * ctx, const char * text) {
    if (!ctx || !text) return 0;
    const double sec = estimate_seconds(text);
    const double fps = ctx->model.cfg.sample_rate / (double) std::max(1, ctx->model.cfg.samples_per_frame);
    return (int) (sec * fps + 0.5);
}

int breeze_generate_wav(breeze_context * ctx, const breeze_request * req, const char * out_path) {
    try {
        GenRequest g = to_req(req);
        g.pace = false;
        std::vector<float> audio;
        generate(ctx->model, ctx->codec, g, [&](const float * s, int n) {
            audio.insert(audio.end(), s, s + n);
            return true;
        });
        if (!write_wav(out_path, audio, ctx->model.cfg.sample_rate)) {
            g_error = "failed to write wav";
            return 1;
        }
    } catch (const std::exception & e) {
        g_error = e.what();
        return 1;
    }
    return 0;
}

// 1.9.54：音色转换。源音频先过 Mimi 编码器拿语义 + 声学码本，转换只保留第 0 个
// 语义码本（词与时长都在这里），其余 15 个按参考音色重算，最后整段解码成 wav。
int breeze_convert(breeze_context * ctx, const char * src_wav, const char * ref_wav,
                   const char * ref_text, const char * src_text, const char * out_wav,
                   float temperature, int top_k, int keep_acoustic, int seed,
                   breeze_convert_progress_cb cb, void * user) {
    if (!ctx || !src_wav || !ref_wav || !out_wav) return 1;
    try {
        const int sr = ctx->model.cfg.sample_rate;

        std::vector<float> src;
        if (!read_wav(src_wav, sr, src) || src.empty()) {
            g_error = "failed to read source wav";
            return 2;
        }
        // 上限 120 秒：转换是逐帧重算声学码本，1 秒音频约 12.5 帧、每帧两次主干 +
        // 15 次深度，比普通合成还重。再长就变成「点了没反应，几分钟后才出声」，
        // 这里直接截断并在上层提示，避免用户以为卡死。
        const size_t max_samples = (size_t) (120.0 * sr);
        if (src.size() > max_samples) src.resize(max_samples);

        int T = 0;
        std::vector<int> codes = ctx->codec.encode(src, T);
        if (T <= 0 || codes.empty()) {
            g_error = "codec produced no frames";
            return 3;
        }

        std::vector<float> ref;
        if (!read_wav(ref_wav, sr, ref) || ref.empty()) {
            g_error = "failed to read reference wav";
            return 4;
        }

        ConvertOptions opt;
        opt.src_text = src_text ? src_text : "";
        opt.temperature = temperature > 0.f ? temperature : 0.3f;
        opt.top_k = top_k > 0 ? top_k : 1;
        opt.keep_acoustic = keep_acoustic > 0 ? keep_acoustic : 0;
        opt.seed = seed;

        std::vector<float> audio = convert_voice(
            ctx->model, ctx->codec, codes, T, ref, ref_text ? ref_text : "", opt,
            [&](int phase, int done, int total) {
                return cb ? cb(phase, done, total, user) == 0 : true;
            });

        if (audio.empty()) {
            g_error = "cancelled";
            return 6;
        }
        if (!write_wav(out_wav, audio, sr)) {
            g_error = "failed to write wav";
            return 5;
        }
        return 0;
    } catch (const std::exception & e) {
        g_error = e.what();
        return 1;
    }
}

const char * breeze_last_error(void) {
    return g_error.c_str();
}

// ---------------------------------------------------------------------------
// 1.9.48 Vulkan 只读探测
//
// 1.3 的溃败方式有三个，这里逐个避开：
//   1. 探测跑在独立进程（Java 侧 :vkprobe），驱动 SIGSEGV 只死子进程；
//   2. 不碰主推理路径、不落盘任何「已开启」标记，崩了重启仍是纯 CPU；
//   3. 先问 supports_op 再跑图 —— Vulkan 至今没有 SIN（声码器 snake 激活要用），
//      整图硬塞会 GGML_ABORT，这里把它变成一行可读的报告。
// ---------------------------------------------------------------------------
namespace {

struct Report {
    char * buf;
    int cap;
    int len = 0;
    void add(const char * fmt, ...) {
        if (len >= cap - 1) return;
        va_list ap;
        va_start(ap, fmt);
        const int n = std::vsnprintf(buf + len, (size_t) (cap - len), fmt, ap);
        va_end(ap);
        if (n > 0) len += n;
        if (len > cap - 1) len = cap - 1;
    }
};

}  // namespace

BREEZE_API int breeze_vk_probe(char * out, int cap) {
    if (!out || cap < 256) return -1;
    out[0] = 0;
    Report r{ out, cap };

    const size_t ndev = ggml_backend_dev_count();
    r.add("ggml 设备 %zu 个\n", ndev);
    ggml_backend_dev_t gpu_dev = nullptr;
    for (size_t i = 0; i < ndev; i++) {
        ggml_backend_dev_t d = ggml_backend_dev_get(i);
        ggml_backend_dev_props p{};
        ggml_backend_dev_get_props(d, &p);
        const char * type = p.type == GGML_BACKEND_DEVICE_TYPE_GPU ? "GPU"
                         : p.type == GGML_BACKEND_DEVICE_TYPE_IGPU ? "IGPU"
                         : p.type == GGML_BACKEND_DEVICE_TYPE_CPU ? "CPU" : "其他";
        r.add("  [%zu] %s · %s · 显存 %.1f/%.1f GB\n", i, ggml_backend_dev_name(d), type,
              p.memory_free / 1073741824.0, p.memory_total / 1073741824.0);
        if (!gpu_dev && (p.type == GGML_BACKEND_DEVICE_TYPE_GPU || p.type == GGML_BACKEND_DEVICE_TYPE_IGPU))
            gpu_dev = d;
    }
    if (!gpu_dev) {
        r.add("结论：没有 GPU 后端（编译未开 BREEZE_VULKAN，或驱动未暴露设备）\n");
        return -1;
    }

    ggml_backend_t be = ggml_backend_dev_init(gpu_dev, nullptr);
    if (!be) {
        r.add("结论：设备存在但 ggml_backend_dev_init 失败\n");
        return -1;
    }

    // 一张覆盖 Breeze 四阶段的图：量化权重 GEMV、RMSNorm、softmax、码本查表、
    // 以及声码器 snake 激活要用的 sin。
    const size_t mem = ggml_tensor_overhead() * 64 + ggml_graph_overhead_custom(512, false) + (1u << 20);
    ggml_context * ctx = ggml_init(ggml_init_params{ mem, nullptr, true });
    if (!ctx) {
        r.add("结论：ggml 上下文分配失败\n");
        ggml_backend_free(be);
        return -1;
    }
    ggml_tensor * w   = ggml_new_tensor_2d(ctx, GGML_TYPE_F16, 1024, 1024);
    ggml_tensor * x   = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, 1024, 1);
    ggml_tensor * idx = ggml_new_tensor_2d(ctx, GGML_TYPE_I32, 1, 1);
    ggml_tensor * y   = ggml_mul_mat(ctx, w, x);
    ggml_tensor * n   = ggml_rms_norm(ctx, y, 1e-6f);
    ggml_tensor * sm  = ggml_soft_max(ctx, n);
    ggml_tensor * gr  = ggml_get_rows(ctx, w, idx);
    ggml_tensor * sn  = ggml_sin(ctx, sm);

    struct OpCase { const char * name; ggml_tensor * t; };
    const OpCase cases[] = {
        { "MUL_MAT", y }, { "RMS_NORM", n }, { "SOFT_MAX", sm },
        { "GET_ROWS", gr }, { "SIN", sn },
    };
    int missing = 0;
    r.add("算子支持：");
    for (const auto & c : cases) {
        const bool has = ggml_backend_supports_op(be, c.t);
        if (!has) missing++;
        r.add("%s=%s ", c.name, has ? "有" : "无");
    }
    r.add("\n");

    ggml_cgraph * gf = ggml_new_graph_custom(ctx, 512, false);
    ggml_build_forward_expand(gf, sn);
    ggml_build_forward_expand(gf, gr);

    ggml_gallocr_t alloc = ggml_gallocr_new(ggml_backend_get_default_buffer_type(be));
    if (!ggml_gallocr_alloc_graph(alloc, gf)) {
        r.add("结论：最小图分配失败（显存不足）\n");
        ggml_gallocr_free(alloc);
        ggml_free(ctx);
        ggml_backend_free(be);
        return -1;
    }

    std::vector<uint16_t> h16((size_t) 1024 * 1024);
    std::vector<float> hf((size_t) 1024 * 1024, 0.01f);
    ggml_fp32_to_fp16_row(hf.data(), h16.data(), (int64_t) h16.size());
    ggml_backend_tensor_set(w, h16.data(), 0, h16.size() * sizeof(uint16_t));
    std::vector<float> xv(1024, 1.0f);
    ggml_backend_tensor_set(x, xv.data(), 0, xv.size() * sizeof(float));
    int32_t one = 0;
    ggml_backend_tensor_set(idx, &one, 0, sizeof(one));

    bool ok = true;
    double ms = 0;
    // 第一次 dispatch 要编译 pipeline，单独热身不计时
    if (ggml_backend_graph_compute(be, gf) != GGML_STATUS_SUCCESS) {
        ok = false;
    } else {
        std::vector<float> val((size_t) ggml_nelements(sn));
        ggml_backend_tensor_get(sn, val.data(), 0, val.size() * sizeof(float));
        for (float v : val) if (!std::isfinite(v)) { ok = false; break; }
    }
    if (ok) {
        const int reps = 10;
        const auto t0 = std::chrono::steady_clock::now();
        for (int i = 0; i < reps; i++) {
            if (ggml_backend_graph_compute(be, gf) != GGML_STATUS_SUCCESS) { ok = false; break; }
        }
        ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() / reps;
        r.add("最小图：%s · f16 1024² GEMV+norm+softmax+sin %.2f ms/次\n", ok ? "跑通且数值有效" : "失败", ms);
    } else {
        r.add("最小图：执行失败或出 NaN\n");
    }

    ggml_gallocr_free(alloc);
    ggml_free(ctx);
    ggml_backend_free(be);

    if (!ok) {
        r.add("结论：Vulkan 图执行不可用，不要开启后端\n");
        return -1;
    }
    if (missing) {
        r.add("结论：Vulkan 可用，但有 %d 个算子缺失 —— 整图必须走 sched，缺的自动落回 CPU\n", missing);
    } else {
        r.add("结论：Vulkan 可用，关键算子齐全\n");
    }
    return 0;
}

// 1.9.51：崩溃定位。实现放在 common.cpp，这里只做 C 入口。
BREEZE_API void breeze_set_trace_file(const char * path) {
    breeze::trace_set_file(path);
}
