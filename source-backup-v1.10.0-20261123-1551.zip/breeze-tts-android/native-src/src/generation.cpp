#include "breeze/generation.h"
#include "breeze/common.h"
#include "breeze/sampling.h"
#include "breeze/text_encoder.h"
#include "ggml-cpu.h"

#include <algorithm>
#include <chrono>
#include <memory>
#include <random>

namespace breeze {

// ---------------------------------------------------------------------------
// 一块待解码的音频。
//
// 声码器每次都要带上左侧 ctx 帧的上下文一起重算（sliding_window 250 + 16），
// 解完再把前缀丢掉 —— 块越小，重复计算越多，所以 flush 里的 chunk 会逐步放大。
// ---------------------------------------------------------------------------
struct VocBlock {
    std::vector<int> codes;
    int T = 0;         // 参与解码的总帧数（含左侧上下文）
    int start = 0;     // 本块第一帧的绝对帧号
    int count = 0;     // 本块新增帧数
    int ctx_start = 0; // 参与解码的第一帧绝对帧号
};

struct Seg {
    bool is_text;
    std::vector<int> tokens;
    std::vector<int> codes; // frame-major, for audio segments
    int n_frames = 0;
    bool eos = false;
};

static Seg text_seg(BreezeModel & m, const std::string & s) {
    Seg seg;
    seg.is_text = true;
    seg.tokens = m.tok.encode(s, true);
    return seg;
}

static std::vector<Seg> build_segments(BreezeModel & m, const GenRequest & r, const std::string & text,
                                       bool has_ref, const std::string & ref_text,
                                       const std::vector<int> & ref_codes, int ref_T, bool cond) {
    std::vector<Seg> segs;
    const std::string spk = "[S0]";
    if (has_ref) {
        segs.push_back(text_seg(m, spk + ref_text));
        Seg a;
        a.is_text = false;
        a.codes = ref_codes;
        a.n_frames = ref_T;
        a.eos = true;
        segs.push_back(a);
    }
    std::string tail = cond ? spk + "<ins_bos>" + r.instruction + "<ins_eos>" + text : spk + text;
    segs.push_back(text_seg(m, tail));
    return segs;
}

static std::vector<float> assemble(BreezeModel & m, const std::vector<Seg> & segs, int & total) {
    const int H = m.cfg.hidden_size;
    std::vector<float> out;
    total = 0;
    for (const Seg & s : segs) {
        if (s.is_text) {
            std::vector<float> e = text_encoder_forward(m, s.tokens);
            out.insert(out.end(), e.begin(), e.end());
            total += (int) s.tokens.size();
        } else {
            std::vector<float> e = audio_embed_forward(m, s.codes, s.n_frames);
            out.insert(out.end(), e.begin(), e.end());
            total += s.n_frames;
            std::vector<int> eos_frame(m.cfg.num_codebooks, m.cfg.codebook_eos_token_id);
            std::vector<float> ee = audio_embed_forward(m, eos_frame, 1);
            out.insert(out.end(), ee.begin(), ee.end());
            total += 1;
        }
    }
    (void) H;
    return out;
}

// 1.9.105：前缀 = 除最后一段（目标文本）以外的全部。参考文本 + 参考音频 + 一个 EOS 帧。
static int prefix_tokens(const std::vector<Seg> & segs) {
    if (segs.size() < 2) return 0;
    int n = 0;
    for (size_t i = 0; i + 1 < segs.size(); i++)
        n += segs[i].is_text ? (int) segs[i].tokens.size() : segs[i].n_frames + 1;
    return n;
}

static uint64_t prefix_key(const std::vector<int> & codes, const std::string & text, int n) {
    uint64_t h = 1469598103934665603ull;
    auto mix = [&](uint64_t v) { h ^= v; h *= 1099511628211ull; };
    mix((uint64_t) n);
    mix((uint64_t) codes.size());
    for (int c : codes) mix((uint64_t) (uint32_t) c);
    for (unsigned char ch : text) mix((uint64_t) ch);
    return h;
}

static std::vector<float> combine_logits(const std::vector<float> & cond, const std::vector<float> & unc,
                                         bool use_cfg, float scale) {
    if (!use_cfg) return cond;
    std::vector<float> out(cond.size());
    for (size_t i = 0; i < out.size(); i++) out[i] = unc[i] + scale * (cond[i] - unc[i]);
    return out;
}

// what a finished piece leaves behind so the next one can keep the same voice
struct ChunkRef {
    std::vector<int> codes;
    int n_frames = 0;
    std::string text;
};

static bool generate_chunk(BreezeModel & m, MimiCodec & codec, const GenRequest & req,
                           const std::string & text, const ChunkRef & ref, uint32_t seed,
                           const AudioCallback & cb, GenTimings & tm,
                           std::chrono::steady_clock::time_point t_start, PlayClock & clock,
                           ChunkRef & out, PrefixCache * pc = nullptr) {
    const auto clock_now = [] { return std::chrono::steady_clock::now(); };
    const auto since = [](std::chrono::steady_clock::time_point t) {
        return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t).count();
    };

    std::mt19937 rng(seed);
    const int nc = m.cfg.num_codebooks;
    const int spf = m.cfg.samples_per_frame;
    const bool has_ref = !ref.codes.empty() && !ref.text.empty();
    const bool use_cfg = req.cfg_scale != 1.0f;

    const std::vector<int> & ref_codes = ref.codes;
    const int ref_T = ref.n_frames;

    auto t0 = clock_now();
    trace("gen:prompt");
    int total_c = 0, total_u = 0;
    const std::vector<Seg> segs_c = build_segments(m, req, text, has_ref, ref.text, ref_codes, ref_T, true);
    std::vector<float> emb_c = assemble(m, segs_c, total_c);
    std::vector<float> emb_u;
    if (use_cfg) emb_u = assemble(m, build_segments(m, req, text, has_ref, ref.text, ref_codes, ref_T, false), total_u);
    tm.prompt += since(t0);

    // 1.9.105：前缀只取决于音色，同一份参考连续合成时整段 KV 可以复用。
    const int pre = prefix_tokens(segs_c);
    const int H = m.cfg.hidden_size;
    const uint64_t pkey = prefix_key(ref_codes, ref.text, pre);
    const bool hit = pc && pre > 0 && total_c > pre && pc->valid && pc->key == pkey && pc->len == pre;

    const int max_new = req.max_new_tokens > 0 ? req.max_new_tokens : m.cfg.max_new_tokens;

    BackboneState st_c, st_u;
    st_c.init(m, total_c + max_new + 8);
    if (use_cfg) st_u.init(m, total_u + max_new + 8);

    t0 = clock_now();
    StepOut o_c, o_u;
    if (hit) {
        trace("gen:prefill-hit pre=%d of %d", pre, total_c);
        st_c.kv.copy_prefix_from(pc->state.kv, pre);
        st_c.pos = pre;
        o_c = backbone_run(m, st_c, std::vector<float>(emb_c.begin() + (size_t) pre * H, emb_c.end()),
                           total_c - pre);
        if (use_cfg) {
            const int pre_u = pre < total_u ? pre : 0;
            st_u.kv.copy_prefix_from(pc->state.kv, pre_u);
            st_u.pos = pre_u;
            o_u = backbone_run(m, st_u, std::vector<float>(emb_u.begin() + (size_t) pre_u * H, emb_u.end()),
                               total_u - pre_u);
        }
    } else {
        trace("gen:prefill-cond n=%d", total_c);
        o_c = backbone_run(m, st_c, emb_c, total_c);
        if (use_cfg) {
            trace("gen:prefill-uncond n=%d", total_u);
            o_u = backbone_run(m, st_u, emb_u, total_u);
        }
    }
    tm.prefill += since(t0);
    // 1.9.103：CFG 两个分支都真的算了一遍，所以 token 数也要算两份，
    // 否则 tok/s 会被高估一倍。
    tm.prefill_tokens += (hit ? total_c - pre : total_c) + (use_cfg ? (hit ? total_u - pre : total_u) : 0);
    if (hit) tm.prefill_reused = pre * (use_cfg ? 2 : 1);

    // 前缀算完立刻留一份，下一次同音色直接拷。用 st_c：两个分支的前缀输入逐位相同。
    if (pc && pre > 0 && !hit && total_c > pre) {
        pc->state.init(m, pre + 4);
        pc->state.kv.copy_prefix_from(st_c.kv, pre);
        pc->state.pos = pre;
        pc->key = pkey;
        pc->len = pre;
        pc->valid = true;
        trace("gen:prefill-saved pre=%d", pre);
    }

    trace("gen:depth-init nb=%d", use_cfg ? 2 : 1);
    DepthRunner depth;
    depth.init(m, use_cfg ? 2 : 1);
    // 1.9.69 诊断页对照实验：1 = 强制逐码本，0 = 默认单图。
    depth.mode = req.depth_mode;
    // 1.9.106 码本截断实验：0 = 全部码本，正式合成恒 0。
    depth.n_cb = req.codebooks;

    SampleParams bp;
    bp.temperature = req.temperature > 0.0f ? req.temperature : m.cfg.temperature;
    bp.top_k = req.top_k > 0 ? req.top_k : m.cfg.top_k;
    bp.top_p = req.top_p > 0.0f ? req.top_p : m.cfg.top_p;
    bp.repetition_penalty = req.repetition_penalty > 0.0f ? req.repetition_penalty : m.cfg.repetition_penalty;
    std::vector<int> suppress;
    for (int t = m.cfg.codec_codebook_size; t < m.cfg.audio_vocab_size; t++) suppress.push_back(t);

    std::vector<int> hist;
    std::vector<float> comb = combine_logits(o_c.logits, o_u.logits, use_cfg, req.cfg_scale);
    int cb0 = sample_token(comb, bp, rng, &hist, &suppress);

    std::vector<int> frames;
    int emitted = 0;
    bool stopped = false;
    int pad_run = 0;
    int step = 0;
    // when the last chunk went out, so the silent tail can be measured and reported
    std::chrono::steady_clock::time_point last_audio = clock_now();
    // the first flush is small so audio starts early, then it grows to keep the vocoder efficient
    const int chunk_max = std::max(1, req.chunk_max);
    int chunk = std::min(std::max(1, req.chunk_first), chunk_max);
    const int pad_stop = req.pad_stop;
    // the transformer window plus the slack the vocoder convolutions reach back over
    const int ctx = m.cfg.voc.sliding_window + 16;
    const double frame_audio_ms = 1000.0 * spf / m.cfg.sample_rate;
    const auto ema = [](double & avg, double v) { avg = avg > 0 ? avg * 0.7 + v * 0.3 : v; };
    // a flush has to start while the listener still has enough left to cover decoding it
    const auto due_early = [&](int pending) {
        if (!req.pace || !clock.started || clock.voc_ms <= 0) return false;
        const int span = emitted + pending - (emitted > ctx ? emitted - ctx : 0);
        // generating and decoding it has to take well under what it plays, or small flushes spiral
        if (pending * clock.frame_ms + 1.2 * clock.voc_ms * span >= pending * frame_audio_ms) return false;
        const double left = std::chrono::duration<double, std::milli>(clock.runs_out - clock_now()).count();
        return left < 1.25 * (clock.frame_ms + clock.voc_ms * (span + 1)) + 100.0;
    };
    // 1.9.43：声码器与主干对线程数的敏感性不同。实测 8 线程下声码器每帧比
    // 6 线程慢三倍多（docs/49），flush 期间临时切到独立线程数，返回后恢复。
    struct ThreadSwap {
        ggml_backend_t b = nullptr;
        int restore = 0;
        bool active = false;
        ThreadSwap(ggml_backend_t backend, int use, int back) : b(backend), restore(back) {
            if (b && use > 0 && back > 0 && use != back) {
                ggml_backend_cpu_set_n_threads(b, use);
                active = true;
            }
        }
        // 只有真的切过才恢复：忘了这个判断的话，默认路径每次 flush 都会
        // 用同一个值重设线程数，而 ggml 会连带重建线程池，正是 docs/47 里
        // 「分阶段线程切换反而更慢」的成因。
        ~ThreadSwap() {
            if (active) ggml_backend_cpu_set_n_threads(b, restore);
        }
    };
    // 一条音频块真正被回调出去：统计、播放时钟、进度都在这里推进。
    auto deliver = [&](const VocBlock & j, const std::vector<float> & audio, double vtime) {
        const int sub_T = j.start + j.count - j.ctx_start;
        tm.vocoder += vtime;
        ema(clock.voc_ms, vtime / sub_T);
        tm.flushes++;
        const int skip = (j.start - j.ctx_start) * spf;
        const size_t need = (size_t) skip + (size_t) j.count * spf;
        if (audio.size() < need) return false; // 解码失败：这块没出来
        if (!tm.first_audio) {
            tm.first_vocoder = vtime;
            tm.first_frames = sub_T;
            tm.first_audio = since(t_start);
        }
        if (!cb(audio.data() + skip, j.count * spf)) return false;
        last_audio = clock_now();
        const auto now = clock_now();
        if (!clock.started || clock.runs_out < now) clock.runs_out = now;
        clock.runs_out += std::chrono::microseconds((long long) (j.count * frame_audio_ms * 1000.0));
        clock.started = true;
        emitted = j.start + j.count;
        return true;
    };

    auto flush = [&](bool final_flush) {
        // 声码器与主干对线程数的敏感性不同（实测 8 线程下声码器每帧快三成，主干反而慢），
        // flush 期间临时切到声码器线程数，返回后恢复。
        std::unique_ptr<ThreadSwap> swap =
            std::make_unique<ThreadSwap>(m.backend.backend, req.voc_threads, req.gen_threads);
        const int have = (int) frames.size() / nc;
        while (have > emitted) {
            const bool full = final_flush || have - emitted >= chunk;
            const bool early = !full && due_early(have - emitted);
            if (!full && !early) break;
            VocBlock j;
            j.start = emitted;
            j.count = full && !final_flush ? chunk : have - emitted;
            j.ctx_start = j.start > ctx ? j.start - ctx : 0;
            j.T = j.start + j.count - j.ctx_start;
            j.codes.assign(frames.begin() + (size_t) j.ctx_start * nc,
                           frames.begin() + (size_t) (j.start + j.count) * nc);
            // an early flush means the buffer is thin, so the chunk holds its size until it recovers
            if (!early) chunk = std::min(chunk + chunk / 2 + 1, chunk_max);

            const auto tv = clock_now();
            std::vector<float> audio = codec.decode(j.codes, j.T);
            if (!deliver(j, audio, since(tv))) return false;
        }
        return true;
    };

    for (step = 0; step < max_new; step++) {
        // A stop request must be seen between frames too. While the model idles on pad
        // frames no audio chunk is produced, so the flush callback never runs and the
        // caller would wait for the whole token budget before getting control back.
        if (!cb(nullptr, 0)) { stopped = true; break; }
        if (cb0 == m.cfg.backbone_eos_token_id) break;
        // 1.9.43 后段降 CFG：前 cfg_decay_frames 帧按原强度走双分支，之后切到
        // cond 单分支。step 单调递增，切过去就不必再切回来。
        const bool cfg_now = use_cfg && (req.cfg_decay_frames <= 0 || step < req.cfg_decay_frames);
        // 深度解码是否也吃 CFG：主干两分支只算一次 logits，代价很小；深度要在
        // 15 个码本上各跑一遍双分支，实测占每帧 45%。关掉它主干照样受引导。
        const bool depth_cfg = cfg_now && !req.depth_cfg_off;
        std::vector<std::vector<float>> hiddens = { o_c.hidden };
        if (depth_cfg) hiddens.push_back(o_u.hidden);
        auto td = clock_now();
        trace("f%d:depth nb=%d", step, cfg_now ? 2 : 1);
        std::vector<int> depth_codes = depth.run(m, hiddens, cb0, depth_cfg ? req.cfg_scale : 1.0f, rng);
        const double depth_ms = since(td);
        tm.depth += depth_ms;
        // 1.9.106：截断实验时深度只返回前 N-1 个码本，其余位置用上一帧同位置的
        // 码本顶上（首帧没有上一帧，补 0）。不能补 pad —— 全 pad 的帧会被整帧丢弃，
        // 那等于帧率也被砍了，实验就量不出「只省算力」的净值。
        const int need_cb = nc - 1;
        for (int j = (int) depth_codes.size(); j < need_cb; j++) {
            int v = 0;
            if (!frames.empty()) v = frames[frames.size() - (size_t) (need_cb - j)];
            depth_codes.push_back(v);
        }
        std::vector<int> frame = { cb0 };
        frame.insert(frame.end(), depth_codes.begin(), depth_codes.end());

        bool pad = true;
        for (int c : frame) if (c != m.cfg.codebook_pad_token_id) { pad = false; break; }
        if (!pad) {
            pad_run = 0;
            frames.insert(frames.end(), frame.begin(), frame.end());
            tm.frames++;
            trace("f%d:voc flush", step);
            if (!flush(false)) { stopped = true; break; }
        } else if (pad_stop > 0 && !frames.empty() && ++pad_run >= pad_stop) {
            // Empty frames are dropped from the output, so a stretch of them is pure
            // compute with zero audio: the ui sits on the last chunk for seconds. Once
            // speech has started, a run this long means the model is idling rather than
            // about to say something, so end the piece here.
            tm.stopped_early = 1;
            break;
        }
        hist.push_back(cb0);

        auto tb = clock_now();
        trace("f%d:aembed", step);
        std::vector<float> ae = audio_embed_forward(m, frame, 1);
        trace("f%d:backbone cfg=%d", step, cfg_now ? 1 : 0);
        if (cfg_now) {
            auto pair = backbone_run_cfg(m, st_c, st_u, ae);
            o_c = std::move(pair[0]);
            o_u = std::move(pair[1]);
        } else {
            // 后段单分支：只推进 cond 的 KV cache，uncond 那条就此冻结。
            o_c = backbone_run(m, st_c, ae, 1);
        }
        const double backbone_ms = since(tb);
        tm.backbone += backbone_ms;
        ema(clock.frame_ms, depth_ms + backbone_ms);
        comb = combine_logits(o_c.logits, o_u.logits, cfg_now, cfg_now ? req.cfg_scale : 1.0f);
        cb0 = sample_token(comb, bp, rng, &hist, &suppress);
        trace("f%d:ok frames=%d", step, tm.frames);
    }
    if (!stopped && !flush(true)) stopped = true;
    tm.steps += step;
    // only the longest silent stretch matters: for split text every piece has one
    tm.tail = std::max(tm.tail, std::chrono::duration<double, std::milli>(clock_now() - last_audio).count());

    // 1.9.71：把实际走过的深度路径记下来，诊断页据此判断 A/B 是否真的分成了两臂。
    tm.depth_fused = depth.fused_calls;
    tm.depth_steps = depth.step_calls;

    trace("gen:free");
    st_c.free();
    if (use_cfg) st_u.free();
    depth.free();

    out.codes = std::move(frames);
    out.n_frames = (int) out.codes.size() / nc;
    out.text = text;
    trace("gen:end frames=%d", out.n_frames);
    return !stopped;
}

void GenSession::begin(BreezeModel & m, MimiCodec & codec, const GenRequest & req, GenTimings * tm) {
    m_model = &m;
    m_codec = &codec;
    m_req = req;
    m_piece = 0;
    m_start = std::chrono::steady_clock::now();
    m_clock = PlayClock();
    m_codes.clear();
    m_frames = 0;
    m_text.clear();

    if (!req.ref_codes.empty() && req.ref_frames > 0 && !req.ref_text.empty()) {
        m_codes = req.ref_codes;
        m_frames = req.ref_frames;
        m_text = req.ref_text;
    } else if (!req.ref_audio.empty() && !req.ref_text.empty()) {
        const auto t0 = std::chrono::steady_clock::now();
        m_codes = codec.encode(req.ref_audio, m_frames);
        m_text = req.ref_text;
        if (tm) tm->encode_ref =
            std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    }
}

bool GenSession::speak(const std::string & text, const AudioCallback & cb, GenTimings * tm) {
    if (!m_model || !m_codec) return false;
    GenTimings sink;
    GenTimings & t = tm ? *tm : sink;

    ChunkRef anchor;
    anchor.codes = m_codes;
    anchor.n_frames = m_frames;
    anchor.text = m_text;

    ChunkRef made;
    const bool ok = generate_chunk(*m_model, *m_codec, m_req, text, anchor,
                                   (uint32_t) m_req.seed + m_piece, cb, t, m_start, m_clock, made,
                                   m_pcache);
    m_piece++;
    // the opening piece stands in as the reference when there was no clip to clone
    if (ok && m_codes.empty() && made.n_frames > 0) {
        m_codes = std::move(made.codes);
        m_frames = made.n_frames;
        m_text = made.text;
    }
    return ok;
}

// long text is generated piece by piece, each one carrying the same reference so the voice does
// not change at the seams
void generate(BreezeModel & m, MimiCodec & codec, const GenRequest & req, const AudioCallback & cb,
              GenTimings * timings, GenAnchor * anchor, PrefixCache * prefix) {
    GenTimings sink;
    GenTimings & tm = timings ? *timings : sink;

    GenSession s;
    s.set_prefix_cache(prefix);
    s.begin(m, codec, req, &tm);

    // a half minute of reference makes the model skip whole sentences of whatever comes next, so
    // when the first piece has to double as the reference it stays near the usual clip length
    const int anchor_chars = 200;
    const std::vector<std::string> parts =
        split_text(req.text, req.split_chars, s.needs_anchor() ? anchor_chars : 0);

    for (const std::string & part : parts)
        if (!s.speak(part, cb, &tm)) break;

    // hand back whatever served as the reference. exiting early on a cancel still leaves a
    // usable anchor when the first piece already landed, which is the common case for a
    // one-sentence audition sample.
    if (anchor && s.frames() > 0) {
        anchor->codes = s.codes();
        anchor->text = s.text();
        anchor->frames = s.frames();
    }
}

void warm_up(BreezeModel & m, MimiCodec & codec, const GenRequest & base) {
    GenRequest req = base;
    req.text = "Warming up.";
    req.instruction = GenRequest().instruction;
    req.max_new_tokens = 24;
    req.pace = false;
    const AudioCallback drop = [](const float *, int) { return true; };
    generate(m, codec, req, drop);
    req.cfg_scale = 2.0f;
    req.max_new_tokens = 8;
    generate(m, codec, req, drop);
    // vulkan picks matmul pipelines by size class, so touch the spread of chunk lengths a stream uses
    const int nc = m.cfg.num_codebooks;
    for (int T : { 1, 2, 4, 8, 16, 32, 64, m.cfg.voc.sliding_window + 16 + std::max(1, base.chunk_max) }) {
        std::vector<int> codes((size_t) T * nc, 0);
        codec.decode(codes, T);
    }
}

// keeps the source's semantic codes and rebuilds the acoustic ones in the reference voice. the words
// and their timing survive, the pitch contour does not, it gets replaced by the reference's own
// the backbone goes degenerate with nothing to read, and forcing codes against that state comes out
// mumbled. what the filler says does not matter, only that there is roughly a clip's worth of it
static std::string filler_text(double secs) {
    static const char * lines[] = {
        "This is a recording of ordinary speech made in a quiet room. ",
        "The words themselves do not matter very much at all here. ",
        "It simply carries on for a little while longer than that. ",
        "Nothing in particular is being described at this point. ",
    };
    const size_t want = (size_t) (secs * 17.0) + 16;
    std::string s;
    for (int i = 0; s.size() < want; i++) s += lines[i % 4];
    return s;
}

std::vector<float> convert_voice(BreezeModel & m, MimiCodec & codec, const std::vector<int> & src_codes,
                                 int src_T, const std::vector<float> & ref_audio,
                                 const std::string & ref_text, const ConvertOptions & opt,
                                 const ConvertProgress & progress) {
    const int nc = m.cfg.num_codebooks;
    const bool use_cfg = opt.cfg_scale != 1.0f;
    std::mt19937 rng((uint32_t) opt.seed);

    SampleParams sp;
    sp.temperature = opt.temperature;
    sp.top_k = opt.top_k;

    int ref_T = 0;
    std::vector<int> ref_codes;
    if (!opt.ref_codes.empty() && opt.ref_frames > 0) {
        ref_codes = opt.ref_codes;
        ref_T = opt.ref_frames;
    } else {
        ref_codes = codec.encode(ref_audio, ref_T);
    }

    const std::string text =
        opt.src_text.empty()
            ? filler_text(src_T * (double) m.cfg.samples_per_frame / m.cfg.sample_rate)
            : opt.src_text;
    GenRequest req;
    int total_c = 0, total_u = 0;
    std::vector<float> emb_c =
        assemble(m, build_segments(m, req, text, true, ref_text, ref_codes, ref_T, false), total_c);
    // the negative branch drops the reference, so guidance pushes toward the target voice
    std::vector<float> emb_u;
    if (use_cfg) emb_u = assemble(m, build_segments(m, req, text, false, "", {}, 0, false), total_u);

    BackboneState st_c, st_u;
    st_c.init(m, total_c + src_T + 8);
    if (use_cfg) st_u.init(m, total_u + src_T + 8);
    StepOut o_c = backbone_run(m, st_c, emb_c, total_c);
    StepOut o_u;
    if (use_cfg) o_u = backbone_run(m, st_u, emb_u, total_u);

    DepthRunner depth;
    depth.init(m, use_cfg ? 2 : 1);

    std::vector<int> out((size_t) src_T * nc);
    const int keep = opt.keep_acoustic < nc - 1 ? opt.keep_acoustic : nc - 1;
    for (int t = 0; t < src_T; t++) {
        const int cb0 = src_codes[(size_t) t * nc];
        std::vector<std::vector<float>> hiddens = { o_c.hidden };
        if (use_cfg) hiddens.push_back(o_u.hidden);
        std::vector<int> rest =
            depth.run(m, hiddens, cb0, opt.cfg_scale, rng, &sp,
                      keep > 0 ? &src_codes[(size_t) t * nc + 1] : nullptr, keep);
        out[(size_t) t * nc] = cb0;
        for (int c = 1; c < nc; c++) out[(size_t) t * nc + c] = rest[c - 1];

        const int * from = opt.feed_source ? &src_codes[(size_t) t * nc] : &out[(size_t) t * nc];
        std::vector<int> frame(from, from + nc);
        std::vector<float> ae = audio_embed_forward(m, frame, 1);
        if (use_cfg) {
            auto pair = backbone_run_cfg(m, st_c, st_u, ae);
            o_c = std::move(pair[0]);
            o_u = std::move(pair[1]);
        } else {
            o_c = backbone_run(m, st_c, ae, 1);
        }
        if (t % 25 == 0) { printf("\rconverting %d/%d frames", t, src_T); fflush(stdout); }
        // 1.9.54：UI 进度。返回 false 表示用户取消 —— 半成品音频没有意义，
        // 直接释放状态并退回空结果，由 C API 报「已取消」。
        if (progress && !progress(0, t + 1, src_T)) {
            printf("\rconversion cancelled at %d/%d\n", t + 1, src_T);
            st_c.free();
            if (use_cfg) st_u.free();
            depth.free();
            return {};
        }
    }
    printf("\rconverted %d frames        \n", src_T);

    st_c.free();
    if (use_cfg) st_u.free();
    depth.free();

    // the vocoder upsamples 1920x, so decoding a long clip in one graph asks for gigabytes at once.
    // walk it in windows with enough left context for the convolutions to reach back over
    const int spf = m.cfg.samples_per_frame;
    const int ctx = m.cfg.voc.sliding_window + 16;
    const int step = 40;
    const int n_win = (src_T + step - 1) / step;
    std::vector<float> audio;
    audio.reserve((size_t) src_T * spf);
    // 1.9.57：声码器阶段也要报进度，并且要能被取消 —— 这段占全程 30~40%，
    // 早期只在帧循环里查取消，用户在这一段点「停止」要等它全部跑完才生效。
    if (progress && !progress(1, 0, n_win)) return {};
    for (int start = 0, wi = 0; start < src_T; start += step, wi++) {
        const int count = std::min(step, src_T - start);
        const int cs = start > ctx ? start - ctx : 0;
        std::vector<int> sub(out.begin() + (size_t) cs * nc, out.begin() + (size_t) (start + count) * nc);
        std::vector<float> part = codec.decode(sub, start + count - cs);
        const size_t skip = (size_t) (start - cs) * spf;
        const size_t want = (size_t) count * spf;
        if (part.size() < skip + want) break;
        audio.insert(audio.end(), part.begin() + skip, part.begin() + skip + want);
        if (progress && !progress(1, wi + 1, n_win)) {
            printf("\rconversion cancelled at vocoder window %d/%d\n", wi + 1, n_win);
            return {};
        }
    }
    return audio;
}

}
