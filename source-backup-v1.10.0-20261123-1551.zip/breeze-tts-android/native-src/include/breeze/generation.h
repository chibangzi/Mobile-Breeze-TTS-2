#pragma once

#include "breeze/backbone.h"
#include "breeze/codec.h"
#include "breeze/depth_decoder.h"
#include "breeze/model.h"

#include <chrono>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace breeze {

struct GenRequest {
    std::string text;
    std::string instruction = "Speak clearly and naturally.";
    std::string ref_text;
    std::vector<float> ref_audio; // mono 24 kHz, empty for voice design
    // already encoded reference. takes priority over ref_audio so a repeated voice skips the codec,
    // which is most of the wait before the first audio comes out
    std::vector<int> ref_codes;
    int ref_frames = 0;
    float cfg_scale = 1.0f;
    int seed = 42;
    // sampling. zero on any of these keeps whatever the gguf was built with
    float temperature = 0.0f;
    int top_k = 0;
    float top_p = 0.0f;
    float repetition_penalty = 0.0f;
    int max_new_tokens = 0; // 0 uses the model default
    // frames per streamed chunk, ramping from first to max. set both the same for a fixed size
    int chunk_first = 4;
    int chunk_max = 25;
    // the model loses track of the text past about a minute of audio, 0 keeps it in one pass
    int split_chars = 600;
    // send a short chunk early when the listener is about to run dry, pointless when writing a file
    bool pace = true;
    // stop once this many consecutive empty (all-pad) frames arrive after real speech.
    // the model occasionally idles on pad tokens instead of sampling eos: each of those
    // frames costs a full backbone + depth step and produces no audio at all, which is
    // exactly the long silent tail people see after the last spoken word. 0 disables.
    int pad_stop = 16;
    // 1.9.43: 前 N 帧按 cfg_scale 走 cond/uncond 双分支，之后降到 1.0 只跑 cond。
    // 音色在前若干帧已经定型，尾段继续放大引导几乎不改变听感，却要多付一倍算力。
    // 0 = 全程双分支（原路径）。
    int cfg_decay_frames = 0;
    // 1.9.91：深度解码是否也走 CFG 双分支。CFG 在 15 个码本上各做一次，实测占
    // 每帧 45% 的深度耗时（205.8 → 112.2 ms），而它只改变码本的采样分布、
    // 不影响主干。关掉后主干仍受 CFG 引导，只是码本不再被二次放大。
    bool depth_cfg_off = false;
    // 1.9.43: 声码器 flush 期间临时使用的线程数，0 = 不切换。gen_threads 是恢复值。
    int voc_threads = 0;
    int gen_threads = 0;
    /**
     * 1.9.69 对照实验（性能诊断页用，正式合成都传 0）：
     *
     * depth_mode = 1 强制深度解码走逐码本 replay，用来量出「单图」到底省了多少。
     */
    int depth_mode = 0;
    /**
     * 1.9.106 码本截断实验（诊断页用，正式合成传 0）：
     *
     * 0 = 全部码本；N = 只解前 N 个码本，其余位置用「上一帧同位置码本」补齐
     * （首帧补 0）。深度解码必须把 333 M 权重读 15 遍，这是整帧 65% 的来源，
     * 唯一能减的就是遍数。
     */
    int codebooks = 0;
};

// when the listener's audio runs out, assuming playback starts the moment a chunk lands
struct PlayClock {
    bool started = false;
    std::chrono::steady_clock::time_point runs_out;
    double frame_ms = 0; // backbone plus depth per frame
    double voc_ms = 0;   // vocoder per decoded frame, context included
};

// break text on sentence boundaries into pieces worth roughly budget characters, cjk counted heavier.
// first_budget sizes the opening piece only, 0 to treat it like the rest
std::vector<std::string> split_text(const std::string & text, int budget, int first_budget = 0);

// rough spoken length in seconds, only good enough to drive a progress bar
double estimate_seconds(const std::string & text);

// how faithfully the acoustic codes are resynthesised. codec language models are known to go
// unstable on random sampling, so conversion leans much harder on the likeliest codes than tts does
struct ConvertOptions {
    std::string src_text;   // transcript of the source, empty generates filler
    float temperature = 0.3f;
    int top_k = 1;
    float cfg_scale = 1.0f;
    // acoustic codebooks taken straight from the source instead of being regenerated. pitch lives in
    // the low ones, so this trades voice identity back for the source's melody and intonation
    int keep_acoustic = 0;
    bool feed_source = false;
    int seed = 42;
    // already encoded reference, used instead of the ref_audio argument when set
    std::vector<int> ref_codes;
    int ref_frames = 0;
};

// 1.9.57：转换分两个阶段回报进度，返回 false 表示调用方要求中止
// （用户点了取消），convert_voice 会丢掉半成品并返回空音频。
//
//   phase 0 = 逐帧重说，done/total 是帧号（每帧两次主干 + 15 次深度，占大头前半）
//   phase 1 = 声码器合成，done/total 是窗口号（每窗 40 帧波形，是末尾那段长耗时）
//
// 分成两段是因为声码器在逐帧循环之后单独跑，占总时长 30~40%；早期版本只在
// 帧循环里回报，于是进度停在 99% 却还要等半分钟，看起来像卡死。
using ConvertProgress = std::function<bool(int phase, int done, int total)>;

// respeak already encoded audio in the reference voice. words and frame timing come from the source,
// pitch and timbre from the reference, so intonation is not carried over.
std::vector<float> convert_voice(BreezeModel & m, MimiCodec & codec, const std::vector<int> & src_codes,
                                 int src_T, const std::vector<float> & ref_audio,
                                 const std::string & ref_text, const ConvertOptions & opt = {},
                                 const ConvertProgress & progress = {});

// called with each decoded audio chunk; return false to stop generation early
using AudioCallback = std::function<bool(const float * samples, int n)>;

// per stage wall clock milliseconds, optionally filled by generate
struct GenTimings {
    double encode_ref = 0, prompt = 0, prefill = 0, backbone = 0, depth = 0, vocoder = 0;
    double first_audio = 0, first_vocoder = 0;
    // from the last audio chunk to the end of generate: the silent tail the ui shows as a stall
    double tail = 0;
    int frames = 0, flushes = 0, first_frames = 0;
    // 1.9.71：这次到底走了哪条深度解码路径。深度解码的判定条件是
    // 「top_p >= 1 且 top_k <= 256」才进单图，光看请求参数猜不出来，
    // 只能让 native 自己数——否则 A/B 实验很可能两臂跑的都是同一条路径，
    // 量出来的几个百分点全是热漂移。
    int depth_fused = 0, depth_steps = 0;
    // model steps actually run (one per codebook-0 token) and whether the pad guard fired
    int steps = 0, stopped_early = 0;
    // 1.9.103：prefill 真正跑过的 token 数（双分支各算一遍，所以 CFG 开着时是 prompt 的两倍）。
    // 有了它才能算 prefill 的 tok/s —— 在此之前 prefill 只有毫秒数，
    // 判断不了「1.5 s 是 GEMM 慢还是文本编码器慢」。
    int prefill_tokens = 0;
    // 1.9.105：其中直接命中前缀 KV 的数量（CFG 双分支时算两份）。
    int prefill_reused = 0;
};

// codes captured from a finished generation. used to pin a designed voice: the first
// piece of a session already doubles as the reference for the rest of that session,
// so keeping it is enough to make the same timbre come back on the next call.
struct GenAnchor {
    std::vector<int> codes; // [frames * num_codebooks], frame-major
    std::string text;       // transcript of the piece those codes came from
    int frames = 0;
};

// 1.9.105：参考前缀（参考文本 + 参考音频）的 KV 快照。
// 这一段只取决于音色，和目标文本无关，但每个请求都要在主干上重算一遍，
// 实测占 prefill 的六到八成。同一音色连续合成（阅读器就是）时可以直接复用。
// 只存 cond 分支的一份：两个 CFG 分支的前缀输入完全相同，KV 逐位一致。
struct PrefixCache {
    bool valid = false;
    uint64_t key = 0;
    int len = 0;
    BackboneState state;
};

void generate(BreezeModel & m, MimiCodec & codec, const GenRequest & req, const AudioCallback & cb,
              GenTimings * timings = nullptr, GenAnchor * anchor = nullptr,
              PrefixCache * prefix = nullptr);

// runs a throwaway generation so the first real request doesnt pay for pipeline setup
void warm_up(BreezeModel & m, MimiCodec & codec, const GenRequest & base);

// text that arrives a bit at a time, the reference and play clock carry over between pieces
class GenSession {
public:
    void begin(BreezeModel & m, MimiCodec & codec, const GenRequest & req, GenTimings * tm = nullptr);

    // speaks one piece. false means the callback asked to stop
    bool speak(const std::string & text, const AudioCallback & cb, GenTimings * tm = nullptr);

    void set_instruction(const std::string & s) { m_req.instruction = s; }
    // 1.9.105：跨请求的前缀 KV 缓存。传 null 就是原来的行为。
    void set_prefix_cache(PrefixCache * p) { m_pcache = p; }

    // with no clip to clone the first piece becomes the reference, so it wants to stay short
    bool needs_anchor() const { return m_codes.empty(); }

    // the reference in force: either the clip passed in, or the first piece spoken
    const std::vector<int> & codes() const { return m_codes; }
    const std::string & text() const { return m_text; }
    int frames() const { return m_frames; }

private:
    BreezeModel * m_model = nullptr;
    MimiCodec * m_codec = nullptr;
    GenRequest m_req;
    std::vector<int> m_codes;
    std::string m_text;
    int m_frames = 0;
    uint32_t m_piece = 0;
    PrefixCache * m_pcache = nullptr;
    std::chrono::steady_clock::time_point m_start;
    PlayClock m_clock;
};

}
