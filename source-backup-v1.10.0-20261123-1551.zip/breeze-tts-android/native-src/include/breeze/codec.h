#pragma once

#include "breeze/model.h"

#include <functional>
#include <string>
#include <vector>

namespace breeze {

struct MimiCodec {
    BreezeModel * m = nullptr;
    void init(BreezeModel & model) { m = &model; }

    /**
     * 非空时 decode() 只跑到 transformer 输出（即 dpre+dtf 之后），把
     * [frames, latent_dim] 的行主序 latent 交出去，由外部（手机 GPU）算出 PCM。
     * 返回写入 out 的采样数；<=0 表示失败，decode() 会回落到 CPU 全链路。
     *
     * 切在这里是因为声码器后半段占整条链路约四分之一，而它全是卷积、没有
     * 动态长度，正好适合 GPU；前面的注意力有 softmax 和滑窗，留在 CPU 更稳。
     */
    std::function<int(const float * latent, int frames, float * out, int cap)> external;

    // codes frame-major [f * n_cb + cb]; n_cb 0 means the full set. fewer codebooks drops detail,
    // 1 leaves only the semantic stage
    std::vector<float> decode(const std::vector<int> & codes, int n_frames, int n_cb = 0);
    // 只跑 quantizer → dpre → dtf，返回 [n_frames, latent_dim] 行主序
    std::vector<float> decode_latent(const std::vector<int> & codes, int n_frames, int n_cb = 0);
    // audio waveform in, returns codes frame-major, sets n_frames
    std::vector<int> encode(const std::vector<float> & audio, int & n_frames);
};

namespace codec_detail {

ggml_tensor * conv1d_causal(ggml_context * ctx, ggml_tensor * w, ggml_tensor * b,
                            ggml_tensor * x, int stride, int dilation);
ggml_tensor * convtr1d_causal(ggml_context * ctx, ggml_tensor * w, ggml_tensor * b,
                              ggml_tensor * x, int stride);
ggml_tensor * depthwise1d_causal(ggml_context * ctx, ggml_tensor * w, ggml_tensor * b,
                                 ggml_tensor * x, int kernel);
ggml_tensor * resnet_block(ggml_context * ctx, BreezeModel & m, const std::string & prefix, ggml_tensor * x);
ggml_tensor * seanet_encoder(ggml_context * ctx, BreezeModel & m, ggml_tensor * x);
ggml_tensor * mimi_transformer(ggml_context * ctx, BreezeModel & m, Graph & g, ggml_tensor * x,
                               const std::string & prefix, int seq_len);
ggml_tensor * vocoder_transformer(ggml_context * ctx, BreezeModel & m, Graph & g, ggml_tensor * x, int seq_len);
ggml_tensor * vocoder_decode(ggml_context * ctx, BreezeModel & m, Graph & g,
                             const std::vector<int> & codes, int n_codebooks, int seq_len);
// quantizer → dpre → dtf，输出 [seq_len, latent_dim]（转置后，时间在前）
ggml_tensor * vocoder_latent(ggml_context * ctx, BreezeModel & m, Graph & g,
                             const std::vector<int> & codes, int n_codebooks, int seq_len);
// 从 dup 开始的后半段：输入 [T, latent_dim]
ggml_tensor * vocoder_tail(ggml_context * ctx, BreezeModel & m, ggml_tensor * h);

}

}
