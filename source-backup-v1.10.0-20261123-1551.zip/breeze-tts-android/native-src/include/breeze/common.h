#pragma once

#include "ggml.h"
#include "ggml-backend.h"
#include "ggml-cpp.h"

#include <cstdint>
#include <string>
#include <utility>
#include <vector>

namespace breeze {

// one compute backend (any GPU ggml was built with, else CPU) shared by all graphs.
//
// 1.9.48 起改成「CPU + 可选 GPU」两个后端共存：
//   · backend 始终是 CPU，兼容所有既有调用（KC cache、纯 CPU 图）
//   · gpu 非空时，每个 Graph 自建一个 ggml_backend_sched，把能上 GPU 的算子分过去，
//     不支持的算子（Vulkan 缺 SIN，声码器的 snake 激活就是它）自动回落到 CPU。
// 这样即使 Vulkan 缺算子也不会 GGML_ABORT —— 1.3 的整段噪声/闪退都出在「整图硬塞
// 一个后端」上，sched 的 op_offload 是官方给的解法。
struct Backend {
    ggml_backend_t backend = nullptr;   // CPU，恒存在
    ggml_backend_t gpu = nullptr;       // Vulkan，可能为空
    ggml_gallocr_t alloc = nullptr;     // 仅纯 CPU 路径使用
    bool is_gpu = false;
    size_t gpuBytes = 0;                // 实际落在 GPU 上的权重字节数
    size_t cpuBytes = 0;

    void init(bool prefer_gpu);
    void free();
    const char * name() const;
};

// persistent per-layer key/value cache living in its own backend buffer
// several CFG branches can share one cache, interleaved as slot = pos * n_branch + branch
struct KVCache {
    ggml_context * ctx = nullptr;
    ggml_backend_buffer_t buffer = nullptr;
    std::vector<ggml_tensor *> k, v;
    int head_dim = 0, n_kv_head = 0, max_seq = 0, len = 0, n_branch = 1;

    void init(Backend & be, int n_layer, int head_dim, int n_kv_head, int max_seq, int n_branch = 1);
    // 1.9.105：把另一个 cache 的前 n 个位置拷进来（前缀 KV 复用）。
    // 走 host 中转，逐层 1.6 MB，比一次 d2d 大拷贝更容易在 CPU 后端上保证正确。
    void copy_prefix_from(const KVCache & src, int n);
    void reset() { len = 0; }
    void free();
};

// inputs are uploaded after allocation; prepared graphs own their scratch buffers
struct Graph {
    ggml_context * ctx = nullptr;
    ggml_cgraph * gf = nullptr;
    ggml_gallocr_t alloc = nullptr;
    // 1.9.48：GPU 参与时改用 sched 分配，纯 CPU 路径仍走 gallocr（行为逐位不变）
    ggml_backend_sched_t sched = nullptr;
    // 1.9.52：sched 的哈希表容量。默认 2048 装不下深度图（5794 节点），插入时 GGML_ABORT。
    size_t sched_cap = 0;
    std::vector<std::pair<ggml_tensor *, std::vector<uint8_t>>> pending;
    std::vector<ggml_tensor *> extra_roots;

    explicit Graph(size_t n_nodes = GGML_DEFAULT_GRAPH_SIZE);
    ~Graph();
    Graph(const Graph &) = delete;
    Graph & operator=(const Graph &) = delete;

    ggml_tensor * input_i32(const std::vector<int32_t> & data, int ne0, int ne1 = 1);
    ggml_tensor * input_f32(const std::vector<float> & data, int ne0, int ne1 = 1, int ne2 = 1);
    void write(ggml_tensor * node) { extra_roots.push_back(node); }

    void compute(Backend & be, ggml_tensor * out);
    void prepare(Backend & be, ggml_tensor * out);
    void replay(Backend & be);
};

// store cur [head_dim, n_kv_head, n] into cache at position pos; returns view over [0, pos+n)
ggml_tensor * cache_append(ggml_context * ctx, Graph & g, ggml_tensor * cache, ggml_tensor * cur, int pos);

ggml_tensor * rms_norm(ggml_context * ctx, ggml_tensor * x, ggml_tensor * w, float eps);
ggml_tensor * layer_norm(ggml_context * ctx, ggml_tensor * x, ggml_tensor * w, ggml_tensor * b, float eps);
ggml_tensor * linear(ggml_context * ctx, ggml_tensor * w, ggml_tensor * x);
ggml_tensor * swiglu_ffn(ggml_context * ctx, ggml_tensor * x, ggml_tensor * gate,
                         ggml_tensor * up, ggml_tensor * down);

// q,k,v laid out as [head_dim, n_head, n_tokens]; returns [head_dim*n_head, n_q]
ggml_tensor * attention(ggml_context * ctx, ggml_tensor * q, ggml_tensor * k, ggml_tensor * v,
                        ggml_tensor * mask, float scale, int n_head, int n_kv_head);

std::vector<float> build_causal_mask(int n_q, int n_kv, int q_offset, int sliding_window);

// causal within a branch, blind across branches, for interleaved multi branch caches
std::vector<float> build_branch_causal_mask(int n_q, int n_kv, int q_offset, int n_branch);

// encoder style mask: everything visible, optionally limited to a window on both sides
std::vector<float> build_bidirectional_mask(int n_q, int n_kv, int sliding_window);

std::vector<float> tensor_to_f32(ggml_tensor * t);

// ---------------------------------------------------------------------------
// 1.9.51 崩溃定位：把「当前正在执行什么」覆盖写到文件里。
//
// Vulkan 驱动崩溃是 SIGSEGV/SIGABRT，C++ 的 try/catch 与 Kotlin 的 catch 都拦不住，
// 进程直接消失，事后拿不到任何栈。唯一能确定崩溃点的办法是「崩之前把位置落盘」：
// 每进一个阶段先 fsync 一条，进程被杀后文件里剩下的就是崩溃点。
//
// 成本：每次覆盖写一个几字节的文件，约 0.05 ms；只在设了路径时生效，
// 路径为空时 trace() 立即返回，纯 CPU 路径不受影响。
void trace_set_file(const char * path);
void trace(const char * fmt, ...);

}
