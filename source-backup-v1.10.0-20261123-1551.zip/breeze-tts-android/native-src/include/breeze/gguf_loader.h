#pragma once

#include "breeze/common.h"
#include "ggml.h"
#include "gguf.h"

#include <string>
#include <unordered_map>
#include <vector>

namespace breeze {

// loads a GGUF file, uploads all tensor data to the backend and exposes typed KV access
struct GGUFModel {
    gguf_context * gguf = nullptr;
    ggml_context * meta = nullptr;
    ggml_backend_buffer_t buffer = nullptr;
    // 1.9.48：GPU 上的权重按 buffer type 的上限（Vulkan 默认 1 GB/块）拆成多块，
    // 免得一次 2.4 GB 分配被驱动拒掉。空表示全部落在 CPU 的那一个 buffer 里。
    std::vector<ggml_backend_buffer_t> buffers;
    // second buffer holding the matmul weights in the CPU repack layout (i8mm friendly).
    // separate from `buffer` because tensors that get viewed or row-indexed must keep
    // their plain layout, and a repacked tensor's rows are interleaved.
    ggml_backend_buffer_t buffer_repack = nullptr;
    size_t repack_bytes = 0;
    int repack_tensors = 0;
    std::unordered_map<std::string, ggml_tensor *> tensors;

    // allow_repack: try the CPU repack buffer first (i8mm friendly row interleave)
    bool load(const std::string & path, Backend & be, bool allow_repack = true);
    void free();

    ggml_tensor * get(const std::string & name) const;
    ggml_tensor * find(const std::string & name) const;
    bool has(const std::string & name) const;

    int   kv_u32(const char * key, int def = 0) const;
    float kv_f32(const char * key, float def = 0.0f) const;
    bool  kv_bool(const char * key, bool def = false) const;
    std::string kv_str(const char * key, const std::string & def = "") const;
    std::vector<int> kv_i32_array(const char * key) const;
    std::vector<std::string> kv_str_array(const char * key) const;
};

// ---------------------------------------------------------------------------
// 1.9.100 调度实验：透明大页（THP）
//
// 权重是 fread 进匿名内存的，2.4 GB ≈ 60 万个 4 KB 页，逐帧扫描 5 GB 时
// TLB 根本覆盖不了。MADV_HUGEPAGE 让内核按 2 MB 页映射，同样的工作集只需
// 1200 个 TLB 项，是否真能换来提速由诊断页 A/B 实测。
//
// 注意：madvise 只对「之后 fault 进来的页」确定生效，已经映射过的 4 KB 页
// 要靠 khugepaged 后台折叠，时间不可控。所以开关在分配前设好、再重载模型，
// 才是可复现的比较方式。
// ---------------------------------------------------------------------------
void set_thp_pref(bool on);
bool thp_pref();
/** 对已加载的 CPU 权重区应用 / 撤销大页建议，返回成功处理的 buffer 数。 */
int apply_thp(GGUFModel & m, bool on);
/** /sys/kernel/mm/transparent_hugepage/enabled 的模式：always / madvise / never。 */
std::string thp_sys_mode();

}
