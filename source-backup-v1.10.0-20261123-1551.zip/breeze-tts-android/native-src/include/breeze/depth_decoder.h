#pragma once

#include "breeze/model.h"
#include "breeze/sampling.h"

#include <memory>
#include <random>
#include <vector>

namespace breeze {

struct DepthStep {
    Graph graph{2048};
    ggml_tensor * audio = nullptr;
    ggml_tensor * hidden = nullptr;
    ggml_tensor * logits = nullptr;
};

// every codebook step and its sampling in one graph, so a frame is a single submit and readback
struct DepthFused {
    Graph graph{16384};
    ggml_tensor * cb0 = nullptr;
    ggml_tensor * hidden = nullptr;
    ggml_tensor * noise = nullptr;
    ggml_tensor * cfg = nullptr;
    ggml_tensor * inv_temp = nullptr;
    ggml_tensor * codes = nullptr;
    int top_k = 0;
    // 1.9.106：这张图里展开了几个码本步（默认 num_codebooks-1）。
    // 截断实验时要少建几步，否则「跳过」只是不读结果，时间一分不少。
    int n_steps = 0;
};

// autoregressive residual decoder: predicts codebooks 1..num_codebooks-1 for one frame
struct DepthRunner {
    KVCache kv; // CFG branches share one cache, interleaved per position
    int n_branch = 1;
    std::vector<float> freq_factors;
    std::vector<std::unique_ptr<DepthStep>> steps;
    std::unique_ptr<DepthFused> fused;
    // 1.9.43：单分支（cfg=1）版本的同一张图，给「后段降 CFG」用。
    // hiddens 只给 1 个时走这张图，省掉 uncond 那一半 transformer。
    std::unique_ptr<DepthFused> fused_one;

    /**
     * 1.9.69 对照实验：0 = 默认（条件满足时走 fused 单图），1 = 强制逐码本 replay。
     *
     * 单图这条路径从 1.9.43 起就是默认，所以「把深度展开成一张图」不是待做项，
     * 而是既有实现。这里把两条路径都保留成可选，只为了在性能诊断页里用同一句
     * 文本、同一组参数实测出它到底值多少毫秒，而不是靠推断。
     *
     * 注意逐码本路径不支持 top_p 过滤之外的分支补齐方式完全等价（见 run()），
     * 所以两者采样结果一致，差异只在调度次数。
     */
    int mode = 0;

    /**
     * 1.9.106 码本截断实验：0 = 全部码本（默认），N = 只解前 N 个码本。
     *
     * 深度解码是整帧的大头（实测 97.7 ms/帧，占 65%），而它必须把同一份
     * 333 M 权重读 15 遍——这份字节量是结构决定的，绕不开。唯一能减的就是遍数。
     * 诊断页用它测「少解几个码本」能换回多少时间，以及音质掉到什么程度。
     * 正式合成恒 0。
     */
    int n_cb = 0;

    // 1.9.71：实际走了哪条路径的计数器。判定条件（top_p / top_k / 分支数）在
    // run() 里，外部只能靠它来判断 A/B 是不是真的跑在两个路径上。
    int fused_calls = 0;
    int step_calls = 0;

    ~DepthRunner() { free(); }
    void init(BreezeModel & m, int n_branches);
    void free();

    // cond hidden first; force replaces the first n_force residual codebooks
    std::vector<int> run(BreezeModel & m, const std::vector<std::vector<float>> & hiddens,
                         int cb0, float cfg_scale, std::mt19937 & rng,
                         const SampleParams * sp = nullptr,
                         const int * force = nullptr, int n_force = 0);

private:
    // 图由调用方显式传入：1.9.43 曾经按 nb 去挑 fused / fused_one，而 cfg=1.0 时
    // n_branch 本身就是 1，于是 nb==1==n_branch 走了 *fused、却解引用到还没建的
    // fused_one —— 锁定/克隆音色（cfg 自动 1.0）必崩。见 docs/53。
    std::vector<int> run_fused(BreezeModel & m, const std::vector<std::vector<float>> & hiddens,
                               int cb0, float cfg_scale, std::mt19937 & rng, const SampleParams & sp,
                               int nb, DepthFused * fp);
};

}
