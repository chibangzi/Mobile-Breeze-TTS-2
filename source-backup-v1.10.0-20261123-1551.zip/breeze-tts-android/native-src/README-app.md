# native-src —— libbreeze_gguf.so 的源码

这是 `Breeze-TTS-2.cpp`（上游 `pcloth/Breeze-TTS-2.cpp` @ main）+ 固定的 ggml
commit `36da5713` 的工作副本，已经打过本仓库的两个补丁：

1. `tools/patches/breeze-vendor.patch` —— 改名 `breeze_gguf`、去掉 CLI、
   补 `breeze_set_threads` / `breeze_warmup` / `breeze_backend_name` /
   `breeze_get_timings` / `breeze_estimate_frames`、分块与尾帧保护、
   CPU repack 布局等；
2. `tools/patches/native-1.9.43.patch` —— 后段降 CFG、声码器独立线程、
   深度解码器动态分支数、`breeze_convert()` 音色转换与 trace 打点。

`third_party/ggml` 没有放进来（约 100 MB，且是上游原样代码）：
执行 `tools/build_breeze_android.sh` 时脚本会按上面那个 commit 自动下载。

产物：`libbreeze_gguf.so` + `libggml.so` / `libggml-base.so` / `libggml-cpu.so`，
纯 CPU（`BREEZE_VULKAN=OFF`，1.9.55 起不再产出 `libggml-vulkan.so`）。
