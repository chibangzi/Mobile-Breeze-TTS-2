plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "ai.breeze.tts"
    compileSdk = 35
    // 固定 NDK 版本，避免不同机器上 AGP 默认版本不一致
    ndkVersion = "27.1.12297006"

    defaultConfig {
        applicationId = "ai.breeze.tts"
        minSdk = 33          // 12GB / 8 Elite 基线，不迁就低端机
        targetSdk = 35
        versionCode = 124
        versionName = "1.10.0"

        ndk {
            // 只出 arm64（12GB / 骁龙 8 Elite 基线）
            abiFilters += listOf("arm64-v8a")
        }
        externalNativeBuild {
            cmake {
                // 不使用 -ffast-math：音频链路的 NaN/Inf 防护依赖 std::isfinite，
                // fast-math 会让编译器假定不存在非有限值而把该判断优化掉。
                cppFlags += listOf("-std=c++17", "-O3")
                arguments += listOf("-DANDROID_STL=c++_shared")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        // LiteRT 2.3.2 的 Kotlin 元数据是 2.4.0，比本工程的 2.0.21 新。
        // 只跳过版本校验（不用它的新语法就不会出问题），不动整条工具链。
        freeCompilerArgs += "-Xskip-metadata-version-check"
    }
    packaging {
        jniLibs {
            // 1.7 GB 权重不打包，.so 用压缩安装可省下载体积
            useLegacyPackaging = true
        }
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
    androidResources {
        // 自检探测图 300 KB，不压缩才能直接 mmap 给 LiteRT
        noCompress += "tflite"
    }

    lint {
        // LiteRT 2.3.2 用 Kotlin 2.4 编译，AGP 自带的 lint 分析器在
        // NonNullableMutableLiveData 检测器上会抛 IncompatibleClassChangeError。
        // 这与工程代码无关，关掉 release 的 lint 即可，不影响编译与安装。
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    // GGUF 运行时（libbreeze_gguf.so + libggml*.so）以预编译 .so 放在
    // src/main/jniLibs/arm64-v8a/，由 CMake IMPORTED target 链接，不需要 aar 依赖。

    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // 端上离线 ASR：sherpa-onnx + SenseVoice（比 Vosk small-cn 高一个量级）。
    // AAR 已拆成 classes.jar + arm64 .so，避免把 4 种架构的 so 全打进包里。
    implementation(files("libs/sherpa-onnx-classes.jar"))

    // GPU 加速可行性测试（LiteRT）。运行时库 + Kotlin API + GPU 加速器 so。
    implementation("com.google.ai.edge.litert:litert:2.3.2")
    implementation("com.google.ai.edge.litert:litert-api:2.3.2")
    implementation("com.google.ai.edge.litert:litert-gpu:2.3.2")
}
