//
//  breeze_jni.cpp
//  Kotlin <-> C++ 的薄桥接层。刻意不做 JSON 解析：参数逐个传，少一层出错点。
//
#include <jni.h>
#include <android/log.h>

#include <memory>
#include <string>

#include "breeze_engine.h"
#include "breeze/breeze.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "breeze-jni", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "breeze-jni", __VA_ARGS__)

namespace {

JavaVM* gVm = nullptr;

struct Bridge {
    breeze::Engine engine;
    jobject obj = nullptr;
    jmethodID emitChunk = nullptr;
    jmethodID emitProgress = nullptr;
    jmethodID emitDone = nullptr;
    jmethodID emitError = nullptr;
    jmethodID emitStats = nullptr;
    jmethodID emitConvertProgress = nullptr;
};

std::string toStd(JNIEnv* env, jstring s) {
    if (!s) return {};
    const char* p = env->GetStringUTFChars(s, nullptr);
    std::string out(p ? p : "");
    if (p) env->ReleaseStringUTFChars(s, p);
    return out;
}

class Env {
public:
    JNIEnv* env = nullptr;
    bool attached = false;

    Env() {
        if (gVm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
            gVm->AttachCurrentThread(&env, nullptr);
            attached = true;
        }
    }
    ~Env() {
        if (attached) gVm->DetachCurrentThread();
    }
};

/**
 * 从 Java 反射里读出某个方法的 JNI 描述符（形如 "(DD...I)V"）。
 *
 * 为什么不在 C++ 里手写这个字符串：v1.9.69 给 emitStats 加过一个参数，
 * 但 GetMethodID 里仍是旧的 "(DDDDDDDIIIIII)V"，返回 null 又被 ExceptionClear 吃掉，
 * 于是 onTimings 全程不回调 → 诊断页拿不到任何分阶段计时 → 每一行都只显示「失败」，
 * 而且没有任何一条错误日志。手写签名与 Kotlin 参数表之间没有编译器检查，这类错误
 * 只会以「静默无数据」的形式出现，非常难查。改成运行时从参数类型生成，就再也不会错位。
 */
std::string classDescriptor(JNIEnv* env, jclass c, jmethodID clsGetName) {
    auto s = static_cast<jstring>(env->CallObjectMethod(c, clsGetName));
    if (!s) return "V";
    const char* p = env->GetStringUTFChars(s, nullptr);
    std::string n = p ? p : "";
    env->ReleaseStringUTFChars(s, p);
    env->DeleteLocalRef(s);
    if (n == "int") return "I";
    if (n == "long") return "J";
    if (n == "double") return "D";
    if (n == "float") return "F";
    if (n == "boolean") return "Z";
    if (n == "byte") return "B";
    if (n == "char") return "C";
    if (n == "short") return "S";
    if (n == "void") return "V";
    // 数组的类名本身就是描述符（"[I" / "[Ljava.lang.String;"），只需把 . 换成 /
    std::string d = (n[0] == '[') ? n : ("L" + n + ";");
    for (auto& ch : d) if (ch == '.') ch = '/';
    return d;
}

std::string methodDescriptor(JNIEnv* env, jobject thiz, const char* name) {
    jclass cls = env->GetObjectClass(thiz);
    jclass classCls = env->FindClass("java/lang/Class");
    jclass methodCls = env->FindClass("java/lang/reflect/Method");
    if (!classCls || !methodCls) return {};
    jmethodID getDeclared = env->GetMethodID(classCls, "getDeclaredMethods",
                                             "()[Ljava/lang/reflect/Method;");
    jmethodID clsGetName = env->GetMethodID(classCls, "getName", "()Ljava/lang/String;");
    jmethodID getName = env->GetMethodID(methodCls, "getName", "()Ljava/lang/String;");
    jmethodID getParams = env->GetMethodID(methodCls, "getParameterTypes", "()[Ljava/lang/Class;");
    jmethodID getRet = env->GetMethodID(methodCls, "getReturnType", "()Ljava/lang/Class;");
    if (!getDeclared || !clsGetName || !getName || !getParams || !getRet) return {};

    auto methods = static_cast<jobjectArray>(env->CallObjectMethod(cls, getDeclared));
    if (!methods) return {};
    std::string result;
    const jsize n = env->GetArrayLength(methods);
    for (jsize i = 0; i < n && result.empty(); ++i) {
        jobject m = env->GetObjectArrayElement(methods, i);
        auto ns = static_cast<jstring>(env->CallObjectMethod(m, getName));
        std::string mn;
        if (ns) {
            const char* np = env->GetStringUTFChars(ns, nullptr);
            if (np) mn = np;
            if (np) env->ReleaseStringUTFChars(ns, np);
            env->DeleteLocalRef(ns);
        }
        if (mn == name) {
            auto params = static_cast<jobjectArray>(env->CallObjectMethod(m, getParams));
            std::string sig = "(";
            if (params) {
                const jsize pn = env->GetArrayLength(params);
                for (jsize j = 0; j < pn; ++j) {
                    auto pc = static_cast<jclass>(env->GetObjectArrayElement(params, j));
                    sig += classDescriptor(env, pc, clsGetName);
                    env->DeleteLocalRef(pc);
                }
                env->DeleteLocalRef(params);
            }
            sig += ")";
            auto rc = static_cast<jclass>(env->CallObjectMethod(m, getRet));
            sig += classDescriptor(env, rc, clsGetName);
            if (rc) env->DeleteLocalRef(rc);
            result = sig;
        }
        env->DeleteLocalRef(m);
    }
    env->DeleteLocalRef(methods);
    return result;
}

void emitError(Bridge* b, const char* msg) {
    Env e;
    jstring s = e.env->NewStringUTF(msg ? msg : "unknown");
    e.env->CallVoidMethod(b->obj, b->emitError, s);
    e.env->DeleteLocalRef(s);
}

}  // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    gVm = vm;
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jlong JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeCreate(JNIEnv* env, jobject thiz, jstring dir,
                                                    jint threads) {
    auto* b = new Bridge();
    b->obj = env->NewGlobalRef(thiz);
    jclass cls = env->GetObjectClass(thiz);
    b->emitChunk = env->GetMethodID(cls, "emitChunk", "([SI)V");
    b->emitProgress = env->GetMethodID(cls, "emitProgress", "(II)V");
    b->emitDone = env->GetMethodID(cls, "emitDone", "(JIJ)V");
    b->emitError = env->GetMethodID(cls, "emitError", "(Ljava/lang/String;)V");
    // emitStats 的参数表随版本变化（1.9.72 刚删掉一个），签名在运行时从
    // Kotlin 的方法参数类型生成，不再手写——见 methodDescriptor() 的注释。
    const std::string statsSig = methodDescriptor(env, thiz, "emitStats");
    if (statsSig.empty()) {
        env->ExceptionClear();
        b->emitStats = env->GetMethodID(cls, "emitStats", "(DDDDDDDIIIIIIII)V");
    } else {
        b->emitStats = env->GetMethodID(cls, "emitStats", statsSig.c_str());
    }
    b->emitConvertProgress = env->GetMethodID(cls, "emitConvertProgress", "(III)V");
    if (!b->emitConvertProgress) env->ExceptionClear();
    if (!b->emitStats) {
        env->ExceptionClear();
        // 埋点缺失只影响统计面板，不能把启动搞挂；但必须留痕，否则又是「静默失败」。
        LOGE("emitStats 未找到（签名=%s），分阶段计时将全部丢失", statsSig.c_str());
    } else {
        LOGI("emitStats 已绑定：%s", statsSig.c_str());
    }
    env->DeleteLocalRef(cls);

    b->engine.onAudio = [b](const int16_t* pcm, size_t n, int sr) {
        Env e;
        jshortArray arr = e.env->NewShortArray(static_cast<jsize>(n));
        e.env->SetShortArrayRegion(arr, 0, static_cast<jsize>(n), reinterpret_cast<const jshort*>(pcm));
        e.env->CallVoidMethod(b->obj, b->emitChunk, arr, sr);
        e.env->DeleteLocalRef(arr);
    };
    b->engine.onProgress = [b](int frame, int maxFrames) {
        Env e;
        e.env->CallVoidMethod(b->obj, b->emitProgress, frame, maxFrames);
    };
    b->engine.onDone = [b](int64_t prefillMs, int frames, int64_t audioMs) {
        Env e;
        e.env->CallVoidMethod(b->obj, b->emitDone, static_cast<jlong>(prefillMs), frames,
                              static_cast<jlong>(audioMs));
    };
    b->engine.onError = [b](const std::string& msg) { emitError(b, msg.c_str()); };
    b->engine.onConvertProgress = [b](int phase, int done, int total) {
        if (!b->emitConvertProgress) return;
        Env e;
        e.env->CallVoidMethod(b->obj, b->emitConvertProgress, phase, done, total);
    };
    b->engine.onTimings = [b](const breeze::StageTimings& t) {
        if (!b->emitStats) return;
        Env e;
        e.env->CallVoidMethod(b->obj, b->emitStats, static_cast<jdouble>(t.promptMs),
                              static_cast<jdouble>(t.prefillMs), static_cast<jdouble>(t.backboneMs),
                              static_cast<jdouble>(t.depthMs), static_cast<jdouble>(t.vocoderMs),
                              static_cast<jdouble>(t.firstAudioMs), static_cast<jdouble>(t.tailMs),
                              static_cast<jint>(t.frames), static_cast<jint>(t.flushes),
                              static_cast<jint>(t.steps), static_cast<jint>(t.stoppedEarly),
                              static_cast<jint>(t.prefillTokens), static_cast<jint>(t.prefillReused),
                              static_cast<jint>(t.depthFusedFrames),
                              static_cast<jint>(t.depthStepFrames));
    };

    const std::string modelDir = toStd(env, dir);
    if (!b->engine.load(modelDir, threads)) {
        // 详细错误已由 engine 通过 onError 上报（含 breeze_last_error），这里不重复发
        delete b;
        return 0;
    }
    return reinterpret_cast<jlong>(b);
}

extern "C" JNIEXPORT void JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeDestroy(JNIEnv* env, jobject, jlong h) {
    auto* b = reinterpret_cast<Bridge*>(h);
    if (!b) return;
    b->engine.release();
    if (b->obj) env->DeleteGlobalRef(b->obj);
    delete b;
}

extern "C" JNIEXPORT jint JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeSynthesize(
    JNIEnv* env, jobject, jlong h, jstring text, jstring instruction, jstring refWav,
    jstring refText,     jstring codesPath, jstring codesOut, jstring designPrompt,
    jstring voiceKind, jint seed, jfloat temperature, jfloat topP, jint maxFrames,
    jint chunkFirst, jfloat cfgScale, jboolean reusePrefixEmb,
    jint cfgDecayFrames, jint vocThreads, jint depthMode, jint chunkMaxFrames, jint depthCfgOff,
    jint numCodebooks) {
    auto* b = reinterpret_cast<Bridge*>(h);
    if (!b) return -1;

    breeze::Request req;
    req.text = toStd(env, text);
    req.instruction = toStd(env, instruction);
    req.refWav = toStd(env, refWav);
    req.refText = toStd(env, refText);
    req.codesPath = toStd(env, codesPath);
    req.codesOut = toStd(env, codesOut);
    req.designPrompt = toStd(env, designPrompt);
    req.voiceKind = toStd(env, voiceKind);
    req.seed = seed;
    req.temperature = temperature;
    req.topP = topP;
    req.maxFrames = maxFrames;
    req.chunkFirst = chunkFirst;
    req.cfgScale = cfgScale;
    req.reusePrefixEmb = reusePrefixEmb == JNI_TRUE;
    req.cfgDecayFrames = cfgDecayFrames > 0 ? cfgDecayFrames : 0;
    req.vocThreads = vocThreads > 0 ? vocThreads : 0;
    // 1.9.69 性能诊断页的对照实验开关；正式合成一律传 0。
    req.depthMode = depthMode > 0 ? depthMode : 0;
    req.chunkMax = chunkMaxFrames > 0 ? chunkMaxFrames : 0;
    // 1.9.91 深度解码不吃 CFG（默认关，保持原行为）
    req.depthCfgOff = depthCfgOff > 0;
    // 1.9.106 码本截断实验（默认 0 = 全部码本）
    req.codebooks = numCodebooks > 0 ? numCodebooks : 0;

    return b->engine.synthesize(req);
}

/** 1.9.54 音色转换：阻塞执行，结果直接写进 outWav；进度走 emitConvertProgress。 */
extern "C" JNIEXPORT jint JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeConvert(
    JNIEnv* env, jobject, jlong h, jstring srcWav, jstring refWav, jstring refText,
    jstring srcText, jstring outWav, jfloat temperature, jint topK, jint keepAcoustic,
    jint seed) {
    auto* b = reinterpret_cast<Bridge*>(h);
    if (!b) return -1;

    breeze::ConvertRequest req;
    req.srcWav = toStd(env, srcWav);
    req.refWav = toStd(env, refWav);
    req.refText = toStd(env, refText);
    req.srcText = toStd(env, srcText);
    req.outWav = toStd(env, outWav);
    req.temperature = temperature;
    req.topK = topK > 0 ? topK : 1;
    req.keepAcoustic = keepAcoustic > 0 ? keepAcoustic : 0;
    req.seed = seed;

    return b->engine.convert(req);
}

extern "C" JNIEXPORT void JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeCancel(JNIEnv*, jobject, jlong h) {
    auto* b = reinterpret_cast<Bridge*>(h);
    if (b) b->engine.cancel();
}

extern "C" JNIEXPORT jint JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeWarmup(JNIEnv*, jobject, jlong h) {
    auto* b = reinterpret_cast<Bridge*>(h);
    return b ? b->engine.warmup() : -1;
}

extern "C" JNIEXPORT void JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeSetThreads(JNIEnv*, jobject, jlong h, jint n) {
    auto* b = reinterpret_cast<Bridge*>(h);
    if (b) b->engine.setThreads(n);
}

/** 实际生效的计算后端（1.9.55 起恒为 "CPU"）。 */

extern "C" JNIEXPORT jstring JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeBackendName(JNIEnv* env, jobject, jlong h) {
    auto* b = reinterpret_cast<Bridge*>(h);
    const std::string name = b ? b->engine.backendName() : std::string("none");
    return env->NewStringUTF(name.c_str());
}

/**
 * 1.9.51 崩溃定位：把「当前执行到哪」覆盖写到 path。进程被信号杀掉后，
 * 文件里剩下的内容就是崩溃点。路径为空表示关闭（纯 CPU 路径零开销）。
 */
extern "C" JNIEXPORT void JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeSetTrace(JNIEnv* env, jobject, jstring path) {
    if (!path) {
        breeze_set_trace_file(nullptr);
        return;
    }
    const char* p = env->GetStringUTFChars(path, nullptr);
    breeze_set_trace_file(p);
    env->ReleaseStringUTFChars(path, p);
}

/** 这台机器上 libggml 探测到的 CPU 指令集特性（纯查询，不需要权重就绪）。 */
/** 1.9.43 核心绑定：把合成线程钉在最快的 n 个核上。返回实际绑定核数，0 = 未绑定。 */
extern "C" JNIEXPORT jint JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeSetCorePin(JNIEnv*, jobject, jlong h, jboolean on, jint n) {
    auto* b = reinterpret_cast<Bridge*>(h);
    return b ? b->engine.setCorePin(on == JNI_TRUE, n) : 0;
}

/** 当前绑定的核号列表，例如 "7,6,5,4,3,2"；空串表示没有绑定。 */
extern "C" JNIEXPORT jstring JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativePinnedCpus(JNIEnv* env, jobject, jlong h) {
    auto* b = reinterpret_cast<Bridge*>(h);
    return env->NewStringUTF(b ? b->engine.pinnedCpus().c_str() : "");
}

/** 1.9.100 THP：设置偏好并对当前权重区 madvise。返回处理的 CPU buffer 数。 */
extern "C" JNIEXPORT jint JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeSetThp(JNIEnv*, jobject, jlong h, jboolean on) {
    auto* b = reinterpret_cast<Bridge*>(h);
    return b ? b->engine.setThp(on == JNI_TRUE) : 0;
}

/** 当前进程 AnonHugePages 字节数；-1 = 读不到。 */
extern "C" JNIEXPORT jlong JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeThpBytes(JNIEnv*, jobject, jlong h) {
    auto* b = reinterpret_cast<Bridge*>(h);
    return b ? static_cast<jlong>(b->engine.thpBytes()) : -1;
}

extern "C" JNIEXPORT jstring JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeThpMode(JNIEnv* env, jobject) {
    return env->NewStringUTF(breeze_thp_mode());
}

extern "C" JNIEXPORT jstring JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeCpuFeatures(JNIEnv* env, jobject, jlong h) {
    auto* b = reinterpret_cast<Bridge*>(h);
    const std::string s = b ? b->engine.cpuFeatures() : std::string("未加载");
    return env->NewStringUTF(s.c_str());
}

/** 分阶段线程：prefill 用满线程，decode 降到 decodeThreads。 */
extern "C" JNIEXPORT void JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeSetPhaseThreads(JNIEnv*, jobject, jlong h,
                                                            jboolean on, jint decodeThreads) {
    auto* b = reinterpret_cast<Bridge*>(h);
    if (b) b->engine.setPhaseThreads(on == JNI_TRUE, decodeThreads);
}

/** 按文本估算的口语长度（codec 帧），0 表示未知。 */
extern "C" JNIEXPORT jint JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeEstimateFrames(JNIEnv* env, jobject, jlong h,
                                                            jstring text) {
    auto* b = reinterpret_cast<Bridge*>(h);
    if (!b) return 0;
    return b->engine.estimateFrames(toStd(env, text));
}

// ---------------------------------------------------------------------------
// 1.9.87 声码器外置：把 dup 之后的卷积交给手机 GPU。
//
// 回调发生在合成线程上，该线程由 native 创建，没有 JNIEnv，所以每次都要
// AttachCurrentThread / Detach。把 Kotlin 的返回值再拷回 out，多一次 245 KB
// 的拷贝 —— 相比 GPU 上几十毫秒的推理可以忽略。
// ---------------------------------------------------------------------------

namespace {

struct VocBridge {
    JavaVM* vm = nullptr;
    jobject obj = nullptr;   // Kotlin 回调对象的全局引用
    jmethodID run = nullptr; // float[] run(float[] latent, int frames)
    int latentDim = 1024;
};

VocBridge gVoc;

int vocBridge(const float* latent, int frames, float* out, int cap, void*) {
    if (!gVoc.obj || !gVoc.run || frames <= 0) return 0;
    JNIEnv* env = nullptr;
    bool detach = false;
    if (gVoc.vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (gVoc.vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return 0;
        detach = true;
    }
    int n = 0;
    const int total = frames * gVoc.latentDim;
    jfloatArray arr = env->NewFloatArray(total);
    if (arr) {
        env->SetFloatArrayRegion(arr, 0, total, latent);
        auto res = static_cast<jfloatArray>(env->CallObjectMethod(gVoc.obj, gVoc.run, arr, frames));
        if (env->ExceptionCheck()) {
            env->ExceptionDescribe();
            env->ExceptionClear();
        } else if (res) {
            const jsize len = env->GetArrayLength(res);
            if (len > 0 && len <= cap) {
                env->GetFloatArrayRegion(res, 0, len, out);
                n = len;
            }
            env->DeleteLocalRef(res);
        }
        env->DeleteLocalRef(arr);
    }
    if (detach) gVoc.vm->DetachCurrentThread();
    return n;
}

}  // namespace

/** 设置/解除声码器 GPU 回调。cb 为 null 时恢复纯 CPU。 */
extern "C" JNIEXPORT void JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeSetVocoder(JNIEnv* env, jobject, jlong h,
                                                        jobject cb, jint latentDim) {
    auto* b = reinterpret_cast<Bridge*>(h);
    if (!b) return;
    if (gVoc.obj) {
        env->DeleteGlobalRef(gVoc.obj);
        gVoc.obj = nullptr;
    }
    gVoc.run = nullptr;
    if (!cb) {
        b->engine.setVocoder(nullptr, nullptr);
        return;
    }
    if (!gVoc.vm) env->GetJavaVM(&gVoc.vm);
    gVoc.latentDim = latentDim > 0 ? latentDim : 1024;
    jclass c = env->GetObjectClass(cb);
    gVoc.run = env->GetMethodID(c, "run", "([FI)[F");
    env->DeleteLocalRef(c);
    if (!gVoc.run) {
        LOGE("vocoder callback has no run([FI)[F");
        return;
    }
    gVoc.obj = env->NewGlobalRef(cb);
    b->engine.setVocoder(vocBridge, nullptr);
    LOGI("vocoder delegate attached (latentDim=%d)", gVoc.latentDim);
}

/**
 * 端到端校验。返回 5 个 float：[返回码, 相对误差, GPU饱和占比, CPU饱和占比, GPU毫秒]。
 *
 * 只在设置页自检里调。它跑的是真实链路（native 解码 → 回调 → GPU），
 * 能抓住自检图抓不到的那类错：交给 GPU 的 latent 布局不对时，那张图照样
 * 显示 0.01% 误差，因为两边喂的是同一块内存。
 */
extern "C" JNIEXPORT jfloatArray JNICALL
Java_ai_breeze_tts_engine_BreezeEngine_nativeVocoderCheck(JNIEnv* env, jobject, jlong h,
                                                          jint frames) {
    auto* b = reinterpret_cast<Bridge*>(h);
    if (!b) return nullptr;
    float out[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
    const int rc = b->engine.vocoderCheck(frames, out);
    jfloatArray arr = env->NewFloatArray(5);
    if (!arr) return nullptr;
    const float v[5] = { (float) rc, out[0], out[1], out[2], out[3] };
    env->SetFloatArrayRegion(arr, 0, 5, v);
    return arr;
}
