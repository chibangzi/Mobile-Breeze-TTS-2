//
//  breeze_engine.h
//  Breeze TTS 2 端上推理（GGUF 原生后端）：
//  单一 .gguf 文件由 libbreeze_gguf.so（Breeze-TTS-2.cpp / ggml）加载，
//  内部自带 tokenizer、文本编码器、主干、深度解码器、声码器与 codec。
//  JNI 接口保持不变，便于 Kotlin 层复用。
//
#pragma once

#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

#include "breeze/breeze.h"

namespace breeze {

struct Request {
    std::string text;
    std::string instruction;
    std::string refWav;      // 参考音频（wav），仅克隆
    std::string refText;     // 参考音频逐字稿
    std::string codesPath;   // 预编码码本（int16[T,16]），命中则跳过 codec encode
    std::string codesOut;    // 非空时把本次生成首段的码本写到这里（锁定设计音色用）
    std::string designPrompt;
    std::string voiceKind;   // "clone" | "design" | ""
    int seed = 42;
    float temperature = 0.9f;
    float topP = 0.9f;
    /** CFG 引导强度。PC 端做音色设计用 4.0；1.0 等于关闭指令引导。 */
    float cfgScale = 4.0f;
    int maxFrames = 900;
    /**
     * 首块 flush 的目标帧数（12.5 帧/秒）。0 = 引擎默认 16。
     *
     * 声码器每次 flush 都要把 72 帧滑动窗口上下文重算一遍（算 88 帧只多出
     * 本次新增的那几帧），所以块越小、重复计算越多。短句按估算长度给一个
     * 「一次 flush 到底」的值，可以把声码器的工作量压到最低（见 docs/44）。
     */
    int chunkFirst = 0;
    /**
     * 1.9.72：后续块的上限（0 = 与 chunkFirst 相同，即 1.9.71 之前的行为）。
     *
     * 声码器每解一块都要重算最多 266 帧上下文（sliding_window 250 + 16）。首块小
     * 是为了让第一声早点出来，但后续块没必要跟着小：162 帧分成 81+81 要解 243 帧，
     * 一块解完只需 162 帧。上限放大只影响「攒够多少才解」，不影响首包延迟。
     */
    int chunkMax = 0;
    /** 1.9.11 实验优化：复用参考前缀的文本编码，默认关闭。 */
    bool reusePrefixEmb = false;
    /** 1.9.43 后段降 CFG：前 N 帧双分支，之后单分支。0 = 关闭。 */
    int cfgDecayFrames = 0;
    /** 1.9.43 声码器独立线程数，0 = 跟随主线程数。 */
    int vocThreads = 0;
    /** 1.9.69 诊断页对照实验：1 = 深度强制逐码本；正式合成恒 0。 */
    int depthMode = 0;
    /**
     * 1.9.91 深度解码不吃 CFG。默认 false（保持原行为）。
     * 打开后每帧深度耗时约降 45%，主干仍走双分支受 CFG 引导。
     */
    bool depthCfgOff = false;
    /** 1.9.106 码本截断实验：0 = 全部码本（正式合成恒 0），N = 只解前 N 个。 */
    int codebooks = 0;
};

/**
 * 1.9.54 音色转换：把源音频里说的话用目标音色重说一遍。
 *
 * 与本 Request 的区别是「输入是音频而不是文本」：词、时长、节奏、重音都来自
 * 源音频，只有音高与音色按目标重新生成。目标音色必须带参考音频（克隆音色，
 * 或录过试听样本的设计音色）。
 */
struct ConvertRequest {
    std::string srcWav;    // 源音频（24 kHz 单声道 16-bit WAV，上层已归一）
    std::string refWav;    // 目标音色的参考音频
    std::string refText;   // 参考音频的逐字稿
    std::string srcText;   // 源音频的逐字稿；可空，空时模型自动生成等长填充
    std::string outWav;    // 结果写入路径
    /** 深度采样温度：0.3 接近贪心，最忠实于目标音色；调高会更自然但源音色会漏回来。 */
    float temperature = 0.3f;
    int topK = 1;
    /** 保留源音频前 N 个声学码本（0–15）：给唱歌素材保留旋律，普通说话会抖，默认 0。 */
    int keepAcoustic = 0;
    int seed = 42;
};

/** 上一次合成的分阶段耗时（毫秒），用于界面展示与性能分析。 */
struct StageTimings {
    double promptMs = 0;      // 文本编码 + prompt 组装
    double prefillMs = 0;     // 主干 prefill
    double backboneMs = 0;    // 逐帧主干（含 CFG 双分支）
    double depthMs = 0;       // 逐帧深度解码（15 个声学码本）
    double vocoderMs = 0;     // 声码器（含 88 帧上下文）
    double firstAudioMs = 0;  // 请求开始 → 首块音频
    double tailMs = 0;        // 最后一块音频 → 返回（这段是「无输出的空转」）
    int frames = 0;
    int flushes = 0;
    int steps = 0;
    int stoppedEarly = 0;     // 1 = 尾帧保护提前收尾
    int prefillTokens = 0;    // prompt token 数
    int prefillReused = 0;    // 其中直接复用参考前缀的数量
    /** 1.9.71 深度解码实际路径的帧数：fused = 单图，step = 逐码本。 */
    int depthFusedFrames = 0;
    int depthStepFrames = 0;
};

class Engine {
public:
    using AudioCb = std::function<void(const int16_t*, size_t, int sampleRate)>;
    using ProgressCb = std::function<void(int frame, int maxFrames)>;
    /** 1.9.57 转换进度：(phase, done, total)，phase 0=逐帧重说 / 1=声码器合成。 */
    using ConvertProgressCb = std::function<void(int phase, int done, int total)>;
    using DoneCb = std::function<void(int64_t prefillMs, int frames, int64_t audioMs)>;
    using ErrorCb = std::function<void(const std::string&)>;
    using TimingsCb = std::function<void(const StageTimings&)>;

    Engine();
    ~Engine();

    /** 加载 GGUF。纯 CPU 后端（1.9.55 起 Vulkan 路径已整体移除）。 */
    bool load(const std::string& modelDir, int threads);
    /** 后台预热：提前把权重页与 ggml 图/暂存缓冲准备好。返回 0 成功。 */
    int warmup();
    /** 运行时调整 ggml CPU 线程数，不需要重新加载权重。 */
    void setThreads(int n);
    /**
     * 分阶段线程：prompt prefill 是计算密集、用满线程；逐帧 decode 是
     * 内存带宽密集，线程过多只会让 ggml barrier 空转、触发降频。开启后在首个音频
     * 块回调时把线程数降到 decodeThreads（2–4）。
     */
    void setPhaseThreads(bool on, int decodeThreads);

    /**
     * 1.9.87：把声码器后半段（dup/dhead/dblk/dfin）交给外部算。
     *
     * fn 在合成线程上被调用，传入 [frames,1024] 的 latent，要求把 PCM 写进 out。
     * 返回写入的采样数，<=0 表示失败 —— 该块自动回落到 CPU 全链路，合成不中断。
     * fn=null 解除，恢复成原来的纯 CPU 路径。
     */
    void setVocoder(breeze_vocoder_fn fn, void * user);
    /**
     * 端到端校验：固定 codes 跑一次 GPU 半链路、一次 CPU 全链路，比两者。
     *
     * out 需要 4 个 float：相对误差、GPU 饱和占比、CPU 饱和占比、GPU 耗时(ms)。
     * 返回 0 成功；-1 未接 GPU；-2 长度不符；-3 回调没被调用（回落 CPU 了）。
     * 只给设置页自检用，合成路径不走这里。
     */
    int vocoderCheck(int frames, float * out);
    /**
     * 1.9.43 核心绑定：把合成线程钉在频率最高的几个核上，避免调度器把工作线程
     * 迁移到降频核、或者把第 7/8 个线程塞进同一簇。throttle=false 时解除。
     * 返回实际绑定的核数（0 表示失败，已静默回退）。
     */
    int setCorePin(bool on, int n);
    /** 当前绑定的核列表，形如 "6,7,4,5"；未绑定返回空串。 */
    std::string pinnedCpus() const;
    /**
     * 1.9.100 调度实验：透明大页。只影响之后的分配，诊断页切换后会重载模型。
     * 返回本次实际 madvise 成功的 CPU buffer 数；0 = 无可用区或内核不支持。
     */
    int setThp(bool on);
    /** 当前进程 AnonHugePages 总量（字节），-1 = 读不到。用它验证大页是否真的生效。 */
    long long thpBytes();
    /** 内核 THP 模式：always / madvise / never / unknown。 */
    std::string thpMode();
    /** 实际生效的后端名称（1.4 起恒为 "CPU"），未加载返回 "none"。 */
    std::string backendName() const;
    /**
     * libggml 在这台机器上探测到的 CPU 指令集特性（NEON / DOTPROD / SME2 …）。
     * 纯查询，不依赖权重，用于判断「重编内核能不能吃到矩阵单元」。
     */
    std::string cpuFeatures() const;
    void release();

    /** 阻塞执行；返回 0 成功。音频通过 onAudio 流式吐出。 */
    int synthesize(const Request& req);
    /**
     * 1.9.54 音色转换，阻塞执行。返回 0 成功；6 已取消；其余为错误码。
     * 音频一次性写进 req.outWav（不是流式），进度通过 onConvertProgress 回报。
     */
    int convert(const ConvertRequest& req);
    void cancel();

    /** 按文本估算的口语长度（codec 帧，12.5 帧/秒），用于 maxFrames 与预缓冲。 */
    int estimateFrames(const std::string& text);

    AudioCb onAudio;
    ProgressCb onProgress;
    DoneCb onDone;
    ErrorCb onError;
    TimingsCb onTimings;
    /** 1.9.57 转换进度：(phase, done, total)，phase 0=逐帧重说 / 1=声码器合成。 */
    ConvertProgressCb onConvertProgress;

private:
    struct Impl;
    std::unique_ptr<Impl> mImpl;
};

}  // namespace breeze
