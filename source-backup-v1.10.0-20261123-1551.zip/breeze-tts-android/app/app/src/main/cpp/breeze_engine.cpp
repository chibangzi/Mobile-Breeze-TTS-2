//
//  breeze_engine.cpp
//  GGUF 原生后端。分词 / T5Gemma2 文本编码器 / Qwen3 主干 / 深度解码器 /
//  声码器 / Mimi codec 全部由 libbreeze_gguf.so（Breeze-TTS-2.cpp + ggml）完成。
//
//  本层只做四件事：定位 GGUF、把 Request 映射到 C API、解码参考 WAV、
//  把 float 音频流转成 PCM16 并上报进度 / 取消。
//
#include "breeze_engine.h"
#include "breeze/breeze.h"

#include <android/log.h>

// 原生侧关键路径日志：JNI 层只能看到返回码，真正的原因（生成失败 / 图分配失败 /
// 声码器解码异常）只有这里知道。tag 与 Kotlin 侧分开，便于 logcat 过滤。
#define EBLOG(...) __android_log_print(ANDROID_LOG_INFO, "breeze-eng", __VA_ARGS__)
#define EBLOGE(...) __android_log_print(ANDROID_LOG_ERROR, "breeze-eng", __VA_ARGS__)

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <dlfcn.h>
#include <sched.h>
#include <sys/types.h>
#include <unistd.h>
#include <functional>
#include <mutex>
#include <string>
#include <sys/stat.h>
#include <vector>

namespace breeze {
namespace {

constexpr int kDefaultSampleRate = 24000;
constexpr double kFramesPerSecond = 12.5;  // Breeze 声码器 12.5 Hz 帧率
constexpr int kNumCodebooks = 16;          // 码本文件 int16[T*16] 的列数

inline uint16_t rd16(const uint8_t* p) {
    return static_cast<uint16_t>(p[0] | (static_cast<uint16_t>(p[1]) << 8));
}
inline uint32_t rd32(const uint8_t* p) {
    return static_cast<uint32_t>(p[0]) | (static_cast<uint32_t>(p[1]) << 8) |
           (static_cast<uint32_t>(p[2]) << 16) | (static_cast<uint32_t>(p[3]) << 24);
}

std::string trimmed(const std::string& s) {
    size_t b = 0, e = s.size();
    auto isSpace = [](unsigned char c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r'; };
    while (b < e && isSpace(static_cast<unsigned char>(s[b]))) ++b;
    while (e > b && isSpace(static_cast<unsigned char>(s[e - 1]))) --e;
    return s.substr(b, e - b);
}

bool asciiOnly(const std::string& s) {
    for (unsigned char c : s) if (c >= 0x80) return false;
    return true;
}

bool endsWithPunct(const std::string& s) {
    static const char* const tails[] = {"。", "，", "、", "；", "！", "？", "…", ".", ",", ";", "!", "?"};
    for (const char* t : tails) {
        const size_t n = std::strlen(t);
        if (s.size() >= n && s.compare(s.size() - n, n, t) == 0) return true;
    }
    return false;
}

/**
 * 把「音色描述」与「表达指令」合并成一条 instruction。
 *
 * 上游 C API 只有**一个** instruction 槽位，它在 cond 分支里被拼成
 * `[S0]<ins_bos>…<ins_eos>文本`，再靠 CFG 放大与无指令分支的差异。也就是说
 * 描述和表达天然抢同一个位置——旧代码是 `instruction 非空就丢掉 designPrompt`，
 * 于是设计音色的身份（年龄 / 性别 / 音色）被情绪句整体覆盖：小孩音色一旦
 * 填了「用温柔的语气」，模型就只剩「温柔的语气」可依据，退回成年中性声。
 *
 * 这里改成合并，并且**身份在前、表达在后**：
 *   - 身份决定基频与共振峰，必须先落地，否则后面再怎么写都只是修饰；
 *   - 表达放句末，语速 / 语气这类可覆盖的属性自然以最后一次描述为准，
 *     正好符合「音色不变、只改表达」的预期。
 * 追加连接词（「说话时」等）会引入训练分布里没有的句式，因此只补句号。
 */
std::string mergeInstruction(const std::string& design, const std::string& delivery) {
    std::string a = trimmed(design);
    std::string b = trimmed(delivery);
    if (a.empty()) return b;
    if (b.empty()) return a;
    if (a == b) return a;
    // 用户可能在情绪框里顺手写了一遍身份描述，去重后再拼，避免同一句被强调两次
    if (b.find(a) != std::string::npos) return b;
    if (a.find(b) != std::string::npos) return a;
    // 描述本身就是「一个年迈的老头苍老的声音」这种名词短语时，用逗号接更自然：
    // 「…的声音，语气兴奋雀跃」读起来是一句完整描述，而句号会把表达切成两段独立描述，
    // 模型更容易把后一段当成新音色的说明。已有句末标点就不动它。
    if (!endsWithPunct(a)) a += asciiOnly(a) ? ", " : "，";
    return a + b;
}

/** 读取 16-bit PCM WAV → 24 kHz 单声道 float[-1,1]；非 24 kHz 做线性重采样。 */
bool readWavF32(const std::string& path, std::vector<float>& out) {
    out.clear();
    FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    bool ok = false;
    do {
        uint8_t h[12];
        if (std::fread(h, 1, 12, f) != 12) break;
        if (std::memcmp(h, "RIFF", 4) != 0 || std::memcmp(h + 8, "WAVE", 4) != 0) break;

        int channels = 0, rate = 0, bits = 0;
        std::vector<int16_t> pcm;
        uint8_t ch[8];
        while (std::fread(ch, 1, 8, f) == 8) {
            const uint32_t sz = rd32(ch + 4);
            if (std::memcmp(ch, "fmt ", 4) == 0) {
                uint8_t b[16] = {0};
                const uint32_t n = std::min<uint32_t>(sz, 16);
                if (std::fread(b, 1, n, f) != n) break;
                if (n >= 16) {
                    channels = rd16(b + 2);
                    rate = static_cast<int>(rd32(b + 4));
                    bits = rd16(b + 14);
                }
                for (uint32_t i = n; i < sz; ++i) std::fgetc(f);
            } else if (std::memcmp(ch, "data", 4) == 0) {
                const size_t bytes = static_cast<size_t>(sz) & ~size_t(1);
                pcm.resize(bytes / 2);
                const size_t got = std::fread(pcm.data(), 1, bytes, f);
                pcm.resize(got / 2);
                break;
            } else {
                std::fseek(f, static_cast<long>(sz), SEEK_CUR);
            }
        }
        if (channels <= 0 || rate <= 0 || bits != 16 || pcm.empty()) break;

        const size_t frames = pcm.size() / static_cast<size_t>(channels);
        std::vector<float> mono;
        mono.reserve(frames);
        for (size_t i = 0; i < frames; ++i) {
            float v = 0.f;
            for (int c = 0; c < channels; ++c) v += pcm[i * channels + c] / 32768.f;
            mono.push_back(v / channels);
        }
        if (rate == kDefaultSampleRate) {
            out = std::move(mono);
        } else {
            const double step = static_cast<double>(rate) / kDefaultSampleRate;
            const size_t n = static_cast<size_t>(mono.size() / step);
            out.reserve(n);
            for (size_t i = 0; i < n; ++i) {
                const double pos = i * step;
                const size_t a = static_cast<size_t>(pos);
                const float frac = static_cast<float>(pos - a);
                const float b0 = mono[a];
                const float b1 = (a + 1 < mono.size()) ? mono[a + 1] : b0;
                out.push_back(b0 + (b1 - b0) * frac);
            }
        }
        ok = !out.empty();
    } while (false);
    std::fclose(f);
    return ok;
}

/** 支持传 GGUF 文件路径，或包含若干 .gguf 的目录（取体积最大者＝精度最高的档）。 */
std::string findGguf(const std::string& pathOrDir) {
    struct stat st {};
    if (::stat(pathOrDir.c_str(), &st) == 0 && S_ISREG(st.st_mode)) return pathOrDir;

    DIR* d = ::opendir(pathOrDir.c_str());
    if (!d) return {};
    std::string best;
    off_t bestSize = -1;
    while (dirent* e = ::readdir(d)) {
        const std::string name(e->d_name);
        if (name.size() < 6 || name.compare(name.size() - 5, 5, ".gguf") != 0) continue;
        const std::string full = pathOrDir + "/" + name;
        if (::stat(full.c_str(), &st) == 0 && S_ISREG(st.st_mode) && st.st_size > bestSize) {
            best = full;
            bestSize = st.st_size;
        }
    }
    ::closedir(d);
    return best;
}

// ---------------------------------------------------------------------------
// 1.9.43 核心绑定
//
// 骁龙 8 Elite Gen 5（SM8850）是 2x4.74GHz Prime + 6x3.62GHz Performance 的
// 全大核架构，没有小核。八线程跑满时两个 Prime 核先做完自己的份额，然后
// 每个 ggml barrier 都要等 6 个 3.62GHz 的核 —— 多出来的两个线程不产生吞吐，
// 只多耗电、多抢内存带宽（实测主干 39 → 65 ms/帧，docs/49）。
//
// 这里按 cpufreq 的 cpuinfo_max_freq 把核排序，只把合成线程钉在最快的 N 个上，
// 同时避免调度器在合成中途把线程迁到别的核、丢掉 L1/L2 里的权重块。
// 读不到 cpufreq 时静默回退（不绑 = 原来行为），不会因为权限问题挡住合成。
// ---------------------------------------------------------------------------
struct CpuCore {
    int id = 0;
    long maxKhz = 0;
};

static std::vector<CpuCore> readCpuTopology() {
    std::vector<CpuCore> out;
    for (int i = 0; i < 32; i++) {
        char dir[96];
        std::snprintf(dir, sizeof(dir), "/sys/devices/system/cpu/cpu%d", i);
        struct stat st {};
        if (::stat(dir, &st) != 0) break;
        char path[160];
        std::snprintf(path, sizeof(path),
                      "/sys/devices/system/cpu/cpu%d/cpufreq/cpuinfo_max_freq", i);
        long khz = 0;
        if (FILE* f = std::fopen(path, "r")) {
            if (std::fscanf(f, "%ld", &khz) != 1) khz = 0;
            std::fclose(f);
        }
        CpuCore c;
        c.id = i;
        c.maxKhz = khz;
        out.push_back(c);
    }
    return out;
}

static int applyAffinity(const std::vector<int>& cpus) {
    if (cpus.empty()) return 0;
    cpu_set_t set;
    CPU_ZERO(&set);
    for (int c : cpus) {
        if (c >= 0 && c < CPU_SETSIZE) CPU_SET(c, &set);
    }
    int ok = 0;
    if (::sched_setaffinity(0, sizeof(set), &set) == 0) ok++;
    // ggml 的线程池线程在 set_threads 之后才存在，这里把已经在跑的也一起挪过去。
    if (DIR* d = ::opendir("/proc/self/task")) {
        while (dirent* e = ::readdir(d)) {
            const char* n = e->d_name;
            if (!n || n[0] < '0' || n[0] > '9') continue;
            const pid_t tid = static_cast<pid_t>(std::atoi(n));
            if (tid > 0 && ::sched_setaffinity(tid, sizeof(set), &set) == 0) ok++;
        }
        ::closedir(d);
    }
    return ok;
}

}  // namespace

struct Engine::Impl {
    breeze_context* ctx = nullptr;
    std::atomic<bool> cancelled{false};
    std::mutex mu;  // breeze_context 不可重入，串行化 synthesize / load / release
    int sampleRate = kDefaultSampleRate;

    // ---- 分阶段线程 ----
    bool phaseThreads = true;
    int prefillThreads = 6;
    int decodeThreads = 3;

    // ---- 输出健全性 ----
    int nonFiniteBlocks = 0;

    // ---- 1.9.43 核心绑定 ----
    bool corePin = false;
    std::string pinnedList;
};

Engine::Engine() : mImpl(std::make_unique<Impl>()) {}
Engine::~Engine() { release(); }

bool Engine::load(const std::string& modelDir, int threads) {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    if (mImpl->ctx) {
        breeze_free(mImpl->ctx);
        mImpl->ctx = nullptr;
    }
    const std::string path = findGguf(modelDir);
    if (path.empty()) {
        if (onError) onError("未找到 .gguf 模型文件，请先在「模型」页导入 GGUF");
        return false;
    }

    // 纯 CPU：breeze_init 的第二个参数是历史上 GPU 的开关，这里恒传 0。
    mImpl->ctx = breeze_init(path.c_str(), 0);
    if (!mImpl->ctx) {
        const char* e = breeze_last_error();
        if (onError) onError(std::string("GGUF 加载失败：") + (e ? e : "未知错误"));
        return false;
    }

    // ggml CPU 默认只有 4 线程；8 核旗舰机上按用户设置放大到 6-8 线程。
    mImpl->prefillThreads = threads > 0 ? threads : 6;
    mImpl->decodeThreads = std::clamp(mImpl->prefillThreads / 2, 2, 4);
    breeze_set_threads(mImpl->ctx, mImpl->prefillThreads);
    const int sr = breeze_sample_rate(mImpl->ctx);
    if (sr > 0) mImpl->sampleRate = sr;
    return true;
}

int Engine::warmup() {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    if (!mImpl->ctx) return -1;
    return breeze_warmup(mImpl->ctx);
}

void Engine::setThreads(int n) {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    if (n <= 0) return;
    mImpl->prefillThreads = n;
    mImpl->decodeThreads = std::clamp(n / 2, 2, 4);
    if (mImpl->ctx) breeze_set_threads(mImpl->ctx, n);
}

void Engine::setPhaseThreads(bool on, int decodeThreads) {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    mImpl->phaseThreads = on;
    if (decodeThreads > 0) mImpl->decodeThreads = std::clamp(decodeThreads, 1, 8);
}

void Engine::setVocoder(breeze_vocoder_fn fn, void * user) {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    if (!mImpl->ctx) return;
    breeze_set_vocoder(mImpl->ctx, fn, user);
}

int Engine::vocoderCheck(int frames, float * out) {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    if (!mImpl->ctx) return -1;
    return breeze_vocoder_check(mImpl->ctx, frames, out);
}

int Engine::setCorePin(bool on, int n) {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    auto cores = readCpuTopology();
    if (cores.empty()) {
        mImpl->corePin = false;
        mImpl->pinnedList.clear();
        return 0;
    }
    if (!on) {
        std::vector<int> all;
        all.reserve(cores.size());
        for (const auto& c : cores) all.push_back(c.id);
        applyAffinity(all);
        mImpl->corePin = false;
        mImpl->pinnedList.clear();
        return 0;
    }
    int want = n > 0 ? n : mImpl->prefillThreads;
    want = std::min<int>(want, static_cast<int>(cores.size()));
    // 频率高的排前面。读不到频率的核（maxKhz=0）排后面，不会被优先选中。
    std::stable_sort(cores.begin(), cores.end(),
                     [](const CpuCore& a, const CpuCore& b) { return a.maxKhz > b.maxKhz; });
    cores.resize(static_cast<size_t>(want));
    std::vector<int> ids;
    ids.reserve(cores.size());
    for (const auto& c : cores) ids.push_back(c.id);
    const bool ok = applyAffinity(ids) > 0;
    mImpl->corePin = ok;
    mImpl->pinnedList.clear();
    if (ok) {
        for (size_t i = 0; i < ids.size(); i++) {
            if (i) mImpl->pinnedList += ",";
            mImpl->pinnedList += std::to_string(ids[i]);
        }
    }
    return ok ? want : 0;
}

std::string Engine::pinnedCpus() const {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    return mImpl->pinnedList;
}

// ---------------------------------------------------------------------------
// 1.9.100 调度实验：透明大页
//
// 只在诊断页用。开关是全局偏好，set 之后必须重载模型才会对权重区重新分配；
// 对已加载区 madvise 只是尽力而为，内核不会把已 fault 的 4 KB 页就地合并。
// ---------------------------------------------------------------------------
int Engine::setThp(bool on) {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    if (!mImpl->ctx) return 0;
    return breeze_set_thp(mImpl->ctx, on ? 1 : 0);
}

long long Engine::thpBytes() {
    // 只读 /proc/self/smaps，不碰 ctx；传空指针即可，避免与 release 抢锁。
    return breeze_thp_bytes(nullptr);
}

std::string Engine::thpMode() {
    const char * m = breeze_thp_mode();
    return m ? m : "unknown";
}

std::string Engine::backendName() const {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    const char* n = breeze_backend_name(mImpl->ctx);
    return n ? n : "none";
}

// ggml 的特性探测函数由 libggml 导出，但不属于 breeze 的 C API。
// 用 dlsym 在运行时按名查找：拿不到就当作未知，绝不能因为缺符号把启动搞挂
// （换一版 libggml 时这些名字随时可能变）。
static int cpuProbe(const char* sym) {
    using Fn = int (*)();
    auto fn = reinterpret_cast<Fn>(::dlsym(RTLD_DEFAULT, sym));
    return fn ? fn() : -1;
}

std::string Engine::cpuFeatures() const {
    struct Item {
        const char* sym;
        const char* label;
    };
    // 顺序即展示顺序：越靠后越「新」，也越说明这台机器有没有加速余量。
    static const Item kItems[] = {
        {"ggml_cpu_has_neon", "NEON"},
        {"ggml_cpu_has_dotprod", "DOTPROD"},
        {"ggml_cpu_has_sve", "SVE"},
        {"ggml_cpu_has_sme", "SME"},
        {"ggml_cpu_has_sme2", "SME2"},
        {"ggml_cpu_has_fp16_va", "FP16"},
        {"ggml_cpu_has_matmul_int8", "MMINT8"},
    };
    std::string out;
    for (const auto& it : kItems) {
        if (cpuProbe(it.sym) != 1) continue;
        if (!out.empty()) out += " · ";
        out += it.label;
    }
    if (out.empty()) return "未探测到";
    // repack 是编译期能力，没有运行时探测符号：本包实测导出了
    // ggml_backend_cpu_repack_buffer_type，所以直接用符号存在性判断。
    if (::dlsym(RTLD_DEFAULT, "_Z35ggml_backend_cpu_repack_buffer_typev") != nullptr) {
        out += " · REPACK";
    }
    return out;
}

void Engine::release() {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    if (mImpl->ctx) {
        breeze_free(mImpl->ctx);
        mImpl->ctx = nullptr;
    }
}

int Engine::synthesize(const Request& req) {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    if (!mImpl->ctx) {
        if (onError) onError("引擎尚未加载 GGUF 模型");
        return -1;
    }
    mImpl->cancelled.store(false, std::memory_order_relaxed);

    // 已编码的参考码本。设计音色「锁定」后就有：音色由这份码本决定，
    // 不再受采样随机性影响（见 docs/18）。克隆音色首次合成后也会回填。
    std::vector<int16_t> refCodes;
    int refFrames = 0;
    if (!req.codesPath.empty()) {
        if (std::FILE* f = std::fopen(req.codesPath.c_str(), "rb")) {
            std::fseek(f, 0, SEEK_END);
            const long sz = std::ftell(f);
            std::fseek(f, 0, SEEK_SET);
            // 文件长度必须能被「一帧 16 个 int16」整除，否则是半截文件，宁可重算
            if (sz > 0 && sz % (2 * kNumCodebooks) == 0) {
                const size_t n = static_cast<size_t>(sz) / 2;
                refCodes.resize(n);
                if (std::fread(refCodes.data(), 2, n, f) != n) {
                    refCodes.clear();
                } else {
                    refFrames = static_cast<int>(n / kNumCodebooks);
                }
            }
            std::fclose(f);
        }
    }
    // 码本 + 文本稿齐全才算「锁定」，否则退回描述驱动
    const bool locked = refFrames > 0 && !req.refText.empty();

    // 设计音色与表达指令共用同一个 instruction 通道（上游只有一个槽位），
    // 必须以「音色描述在前、表达指令在后」合并，不能二选一：
    // 二选一会让情绪句把身份描述整体挤掉，小孩音色退化成成年中性声（见 docs/14）。
    // 克隆音色没有 designPrompt，走的仍是原来的单条指令，行为不变。
    // 锁定之后就不同了：音色来自码本，描述再塞进 instruction 只会和情绪抢位置，
    // 所以这里只透传用户填的情绪。
    // instruction 内容必须与 PC 端一致（同样一句中文），不要在这里改写或翻译。
    std::string instr = locked ? req.instruction
                               : mergeInstruction(req.designPrompt, req.instruction);

    breeze_request r{};
    r.text = req.text.c_str();
    r.instruction = instr.empty() ? nullptr : instr.c_str();
    // CFG 是「指令遵从度」的开关：上游 build_segments 只在 cond 分支把
    // <ins_bos>…</ins_eos> 指令拼进 prompt，combine_logits = unc + cfg*(cond-unc)。
    // cfg=1 会彻底关掉 uncond 分支（use_cfg=false），描述被稀释成模型默认先验，
    // 于是「一个年迈的老头苍老的声音」会退化成偏年轻的中性音色。
    // PC 端用的是 4，这里按用户设置透传（默认 4.0），与 PC 对齐。
    // 纯克隆且没有任何指令时关掉 CFG：既避免对中性默认指令做无意义放大，
    // 也省掉第二份 KV cache 与 2 分支深度解码，明显更快、音色更保真。
    r.cfg_scale = instr.empty() ? 1.0f : (req.cfgScale > 0.f ? req.cfgScale : 4.0f);
    r.seed = req.seed;
    r.max_new_tokens = req.maxFrames > 0 ? req.maxFrames : 0;
    r.temperature = req.temperature;
    r.top_p = req.topP;
    // 流式分块的粒度直接决定声码器的有效算力。声码器每次 flush 都要重算
    // ctx = codec.sliding_window(72) + 本次新增帧 的卷积上下文，只为了吐出新帧：
    //   chunk=25 → 实际算 113 帧产出 25 帧，浪费 4.5 倍
    //   chunk=64 → 实际算 152 帧产出 64 帧，浪费 2.4 倍
    //
    // 1.9.38 起改成「短句一次 flush 到底」，长句才分块。
    //   - 旧版固定 chunk_first=16 的理由是「早点听到第一声」，但合成过程是 muted 的
    //     （不建 AudioTrack），首块再小也换不来任何可听收益，只剩重复计算；
    //   - 2.4 秒（30 帧）的短句在旧参数下 16+14 分两次 flush，实算 104+102=206 帧，
    //     一次到底只需 88+30=118 帧，声码器工作量降到 57%。
    //
    // 1.9.41 修正：chunk_first 是**上限**而不是固定工作量。1.9.38–1.9.40 里由上层
    // 按「估算帧数 ×1.2」给定，一旦真实长度比估算多一帧（模型采样带随机性，同一句
    // 会产出 38 或 43 帧），就会多出一次只含几帧的碎片 flush：
    //   - 声码器要再算一遍 88 帧滑动窗口上下文（实测 5030 ms vs 一次到底的 1810 ms）；
    //   - 引擎在首块吐出时切换线程数，切换本身要重建线程池/重排权重，尾段
    //     逐帧成本从 98 涨到 130 ms/帧。
    // 所以这里不再"贴着估算值卡"，统一按 96 帧（7.7 秒）切；超长文本由上层
    // 给出**等分**块长，保证句尾不会出现几帧的碎片块。
    const int chunkFrames = req.chunkFirst > 0 ? req.chunkFirst : 96;
    r.chunk_first = chunkFrames;
    // 1.9.72：首块与上限拆开。首块小是为了让第一声早点出来，之后每块都跟着小
    // 就只是白白重算上下文——上层可以单独给一个更大的上限（0 = 与首块相同，
    // 保持 1.9.71 之前的行为）。
    r.chunk_max = req.chunkMax > 0 ? std::max(req.chunkMax, chunkFrames) : chunkFrames;
    // pace=0：只发满块，不再因为「播放即将断粮」提前切碎。
    // 合成过程不播放（StreamingPlayer 的 muted 模式不建 AudioTrack），
    // 引擎按「生成慢于实时」推测出的断粮并不存在，提前小块只会成倍放大
    // 上面那笔重复计算。进度由 onProgress 的逐帧回调驱动，不依赖分块节奏。
    r.pace = 0;
    // 尾部保护：模型有时不吐 eos 而是一直吐全 pad 的空帧。这些帧会被丢弃，
    // 但每帧都要跑一遍主干 + 深度解码，于是「最后一个字念完之后界面卡住几十秒、
    // 却再也出不来新音频」。连续 16 帧（1.28 秒）空帧就收尾。
    r.pad_stop = 16;
    // split_chars 保持 0 → 用默认 600 字符切段（约 2.5 分钟音频，避免长文本丢跟踪）
    // 1.9.11 实验优化：默认 0，关闭时走原路径（逐位等价）。
    r.reuse_prefix_emb = req.reusePrefixEmb ? 1 : 0;
    // 1.9.43 后段降 CFG：0 表示全程双分支（原路径）。
    r.cfg_decay_frames = req.cfgDecayFrames > 0 ? req.cfgDecayFrames : 0;
    // 1.9.43 声码器独立线程：0 = 全程沿用当前线程数。
    r.voc_threads = req.vocThreads > 0 ? req.vocThreads : 0;
    // 1.9.69 诊断页对照实验开关：默认 0，正式合成不设。
    r.depth_mode = req.depthMode > 0 ? req.depthMode : 0;
    r.depth_cfg_off = req.depthCfgOff ? 1 : 0;
    // 1.9.106 码本截断实验：0 = 全部码本，正式合成恒 0。
    r.num_codebooks = req.codebooks > 0 ? req.codebooks : 0;
    r.gen_threads = mImpl->prefillThreads;

    if (!req.codesOut.empty()) r.codes_out = req.codesOut.c_str();

    std::vector<float> refAudio;
    if (locked) {
        // 码本比参考音频优先：省掉一次 codec encode，也让音色跨请求完全一致
        r.ref_codes = refCodes.data();
        r.ref_frames = refFrames;
        r.ref_text = req.refText.c_str();
    } else if (!req.refWav.empty()) {
        if (!readWavF32(req.refWav, refAudio)) {
            if (onError) onError("参考音频读取失败：需要 16-bit PCM WAV（24 kHz 单声道）");
            return -2;
        }
        if (req.refText.empty()) {
            if (onError) onError("克隆音色必须填写参考音频的逐字文本稿");
            return -3;
        }
        r.ref_audio = refAudio.data();
        r.ref_audio_len = static_cast<int>(refAudio.size());
        r.ref_text = req.refText.c_str();
    }

    // prefill 阶段用满线程（大 GEMM，计算密集），首块音频吐出时切到 decode 线程数。
    mImpl->nonFiniteBlocks = 0;
    if (mImpl->phaseThreads)
        breeze_set_threads(mImpl->ctx, mImpl->prefillThreads);

    struct State {
        Engine* engine;
        std::atomic<bool>* cancelled;
        int64_t totalSamples = 0;
        int maxFrames = 0;
        int sampleRate = kDefaultSampleRate;
        int* nonFiniteBlocks = nullptr;
        std::function<void()> onFirstAudio;
        bool firstAudioDone = false;
    } st;
    st.engine = this;
    st.cancelled = &mImpl->cancelled;
    st.maxFrames = req.maxFrames;
    st.sampleRate = mImpl->sampleRate;
    st.nonFiniteBlocks = &mImpl->nonFiniteBlocks;
    st.onFirstAudio = [this]() {
        if (mImpl->phaseThreads && mImpl->ctx)
            breeze_set_threads(mImpl->ctx, mImpl->decodeThreads);
    };

    // 无捕获 lambda，作为 C 函数指针传给 breeze_generate
    auto cb = [](const float* samples, int n, void* user) -> int {
        auto* s = static_cast<State*>(user);
        if (s->cancelled->load(std::memory_order_relaxed)) return 1;
        if (n > 0 && samples) {
            std::vector<int16_t> pcm(static_cast<size_t>(n));
            for (int i = 0; i < n; ++i) {
                const float v = samples[i];
                // 任何非有限样本都直接丢弃该块并中止生成，
                // 绝不把噪声当语音交给播放器和 WAV 导出。
                if (!std::isfinite(v)) {
                    if (s->nonFiniteBlocks) (*s->nonFiniteBlocks)++;
                    return 1;
                }
                const float c = v < -1.f ? -1.f : (v > 1.f ? 1.f : v);
                pcm[i] = static_cast<int16_t>(std::lround(c * 32767.f));
            }
            if (!s->firstAudioDone) {
                s->firstAudioDone = true;
                if (s->onFirstAudio) s->onFirstAudio();
            }
            if (s->engine->onAudio) s->engine->onAudio(pcm.data(), pcm.size(), s->sampleRate);
            s->totalSamples += n;
            if (s->engine->onProgress) {
                const int frames =
                    static_cast<int>(s->totalSamples * kFramesPerSecond / s->sampleRate);
                s->engine->onProgress(frames, s->maxFrames);
            }
        }
        return 0;
    };

    const int rc = breeze_generate(mImpl->ctx, &r, cb, &st);
    EBLOG("generate rc=%d depth=%d chunk=%d/%d max=%d cfg=%.2f samples=%lld",
          rc, r.depth_mode, r.chunk_first, r.chunk_max, r.max_new_tokens, r.cfg_scale,
          static_cast<long long>(st.totalSamples));
    if (rc != 0) {
        const char* e = breeze_last_error();
        EBLOGE("generate 失败 rc=%d err=%s", rc, e ? e : "(null)");
    }

    // 分阶段耗时：界面用它展示「时间花在哪」，也是判断还有多少优化空间的唯一依据。
    breeze_timings bt{};
    if (onTimings && breeze_get_timings(mImpl->ctx, &bt) == 0) {
        StageTimings t;
        t.promptMs = bt.prompt_ms;
        t.prefillMs = bt.prefill_ms;
        t.backboneMs = bt.backbone_ms;
        t.depthMs = bt.depth_ms;
        t.vocoderMs = bt.vocoder_ms;
        t.firstAudioMs = bt.first_audio_ms;
        t.tailMs = bt.tail_ms;
        t.frames = bt.frames;
        t.flushes = bt.flushes;
        t.steps = bt.steps;
        t.stoppedEarly = bt.stopped_early;
        t.prefillTokens = bt.prefill_tokens;
        t.prefillReused = bt.prefill_reused;
        t.depthFusedFrames = bt.depth_fused_frames;
        t.depthStepFrames = bt.depth_step_frames;
        EBLOG("timings frames=%d flushes=%d depth=%.0f voc=%.0f backbone=%.0f "
              "depthPath=fused%d/step%d",
              t.frames, t.flushes, t.depthMs, t.vocoderMs, t.backboneMs,
              t.depthFusedFrames, t.depthStepFrames);
        onTimings(t);
    }

    if (mImpl->nonFiniteBlocks > 0) {
        if (onError) onError(
            "检测到非有限音频样本（NaN/Inf），已中止生成并丢弃该段，避免把噪声写入 WAV。");
        return -5;
    }
    if (mImpl->cancelled.load(std::memory_order_relaxed)) return -9;  // 用户取消，不报完成
    if (rc != 0) {
        const char* e = breeze_last_error();
        if (onError) onError(std::string("合成失败：") + (e ? e : "未知错误"));
        return -4;
    }

    const int frames =
        static_cast<int>(st.totalSamples * kFramesPerSecond / mImpl->sampleRate);
    const int64_t audioMs = st.totalSamples * 1000LL / mImpl->sampleRate;
    if (onDone) onDone(0, frames, audioMs);
    return 0;
}

void Engine::cancel() { mImpl->cancelled.store(true, std::memory_order_relaxed); }

/**
 * 1.9.54 音色转换。
 *
 * 与 synthesize 共用同一把锁与 cancelled 标志：同一时刻只能跑一个任务，
 * 转换中点取消会让进度回调返回 1，native 丢掉半成品并返回 6。
 */
int Engine::convert(const ConvertRequest& req) {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    if (!mImpl->ctx) {
        if (onError) onError("引擎尚未加载 GGUF 模型");
        return -1;
    }
    if (req.srcWav.empty() || req.outWav.empty() || req.refWav.empty() || req.refText.empty()) {
        if (onError) onError("音色转换缺少必要参数（源音频 / 目标音色 / 参考文本稿）");
        return -2;
    }
    mImpl->cancelled.store(false, std::memory_order_relaxed);
    // 转换的逐帧主干是大 GEMM 与小 GEMV 交替，用满线程比 decode 线程更合适。
    if (mImpl->phaseThreads) breeze_set_threads(mImpl->ctx, mImpl->prefillThreads);

    // 无捕获 lambda：转成 C 函数指针，每完成一帧 / 一个声码器窗口回一次进度，
    // 顺便检查取消（声码器那段也能立刻停下，不用等整段跑完）。
    auto cb = [](int phase, int done, int total, void* user) -> int {
        auto* e = static_cast<Engine*>(user);
        if (e->mImpl->cancelled.load(std::memory_order_relaxed)) return 1;
        if (e->onConvertProgress) e->onConvertProgress(phase, done, total);
        return 0;
    };

    const int rc = breeze_convert(
        mImpl->ctx, req.srcWav.c_str(), req.refWav.c_str(), req.refText.c_str(),
        req.srcText.empty() ? nullptr : req.srcText.c_str(), req.outWav.c_str(),
        req.temperature, req.topK, req.keepAcoustic, req.seed, cb, this);

    if (rc == 6) return -9;  // 用户取消
    if (rc != 0) {
        const char* e = breeze_last_error();
        if (onError) onError(std::string("音色转换失败：") + (e ? e : "未知错误"));
        return -4;
    }
    return 0;
}

int Engine::estimateFrames(const std::string& text) {
    std::lock_guard<std::mutex> lk(mImpl->mu);
    if (!mImpl->ctx || text.empty()) return 0;
    return breeze_estimate_frames(mImpl->ctx, text.c_str());
}

}  // namespace breeze
