#include "breeze_tokenizer.h"

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <fstream>

namespace breeze {

namespace {
constexpr const char* kSpace = "\xE2\x96\x81";  // ▁ U+2581
constexpr size_t kSpaceLen = 3;

inline int utf8Len(unsigned char c) {
    if (c < 0x80) return 1;
    if ((c & 0xE0) == 0xC0) return 2;
    if ((c & 0xF0) == 0xE0) return 3;
    if ((c & 0xF8) == 0xF0) return 4;
    return 1;
}
}  // namespace

bool BreezeTokenizer::load(const std::string& binPath) {
    std::ifstream in(binPath, std::ios::binary);
    if (!in) {
        printf("[breeze] 打不开 %s\n", binPath.c_str());
        return false;
    }
    std::string blob((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    if (blob.size() < 8 || memcmp(blob.data(), "BZTK2\0\0\0", 8) != 0) {
        printf("[breeze] tokenizer.bin magic 不符\n");
        return false;
    }
    const uint8_t* p = reinterpret_cast<const uint8_t*>(blob.data());
    size_t off = 8;
    auto rdU32 = [&]() -> uint32_t {
        uint32_t v;
        memcpy(&v, p + off, 4);
        off += 4;
        return v;
    };
    auto rdStr = [&]() -> std::string {
        uint32_t n = rdU32();
        std::string s(reinterpret_cast<const char*>(p + off), n);
        off += n;
        return s;
    };

    const uint32_t vocabSize = rdU32();
    const uint32_t mergeCount = rdU32();
    const uint32_t addedCount = rdU32();
    for (int i = 0; i < 256; ++i) mByteId[i] = rdU32();

    mAdded.clear();
    mAdded.reserve(addedCount);
    for (uint32_t i = 0; i < addedCount; ++i) {
        uint32_t id = rdU32();
        mAdded.emplace_back(static_cast<int>(id), rdStr());
    }
    std::stable_sort(mAdded.begin(), mAdded.end(),
                     [](const auto& a, const auto& b) { return a.second.size() > b.second.size(); });

    mIdToTok.assign(vocabSize, std::string());
    mTokToId.clear();
    for (uint32_t i = 0; i < vocabSize; ++i) {
        mIdToTok[i] = rdStr();
        if (!mIdToTok[i].empty()) mTokToId[mIdToTok[i]] = static_cast<int>(i);
    }

    mMerges.clear();
    mMerges.reserve(mergeCount);
    for (uint32_t i = 0; i < mergeCount; ++i) {
        uint32_t l = rdU32(), r = rdU32(), m = rdU32(), rank = rdU32();
        mMerges[(static_cast<uint64_t>(l) << 32) | r] = {rank, m};
    }

    auto pick = [&](const char* t, int fallback) {
        auto it = mTokToId.find(t);
        return it == mTokToId.end() ? fallback : it->second;
    };
    mAudioToken = pick("<|AUDIO|>", mAudioToken);
    mAudioEos = pick("<|audio_eos|>", mAudioEos);
    mSpeaker = pick("[S0]", mSpeaker);
    printf("[breeze] tokenizer ok: vocab=%u merges=%u added=%u audio=%d\n",
           vocabSize, mergeCount, addedCount, mAudioToken);
    return true;
}

int BreezeTokenizer::idOf(const std::string& token) const {
    auto it = mTokToId.find(token);
    return it == mTokToId.end() ? -1 : it->second;
}

std::vector<std::string> BreezeTokenizer::bpePiece(const std::string& piece) const {
    std::vector<std::string> syms;
    for (size_t i = 0; i < piece.size();) {
        int n = utf8Len(static_cast<unsigned char>(piece[i]));
        n = std::min<int>(n, static_cast<int>(piece.size() - i));
        syms.push_back(piece.substr(i, n));
        i += n;
    }
    while (syms.size() > 1) {
        uint32_t bestRank = UINT32_MAX;
        int bestIdx = -1;
        uint32_t bestMerged = 0;
        for (size_t i = 0; i + 1 < syms.size(); ++i) {
            auto a = mTokToId.find(syms[i]);
            auto b = mTokToId.find(syms[i + 1]);
            if (a == mTokToId.end() || b == mTokToId.end()) continue;
            const uint64_t key = (static_cast<uint64_t>(a->second) << 32) | static_cast<uint32_t>(b->second);
            auto it = mMerges.find(key);
            if (it != mMerges.end() && it->second.first < bestRank) {
                bestRank = it->second.first;
                bestIdx = static_cast<int>(i);
                bestMerged = it->second.second;
            }
        }
        if (bestIdx < 0) break;
        syms[bestIdx] = mIdToTok[bestMerged];
        syms.erase(syms.begin() + bestIdx + 1);
    }
    return syms;
}

std::vector<int> BreezeTokenizer::encodePlain(const std::string& text) const {
    std::string s;
    s.reserve(text.size() + 16);
    for (char c : text) {
        if (c == ' ') s += kSpace;
        else s += c;
    }

    std::vector<int> out;
    size_t i = 0;
    while (i < s.size()) {
        const size_t start = i;
        if (s.compare(i, kSpaceLen, kSpace) == 0) i += kSpaceLen;
        const size_t bodyStart = i;
        while (i < s.size() && s.compare(i, kSpaceLen, kSpace) != 0) {
            i += utf8Len(static_cast<unsigned char>(s[i]));
        }
        if (i == bodyStart) {  // 纯 ▁ 串
            while (i < s.size() && s.compare(i, kSpaceLen, kSpace) == 0) i += kSpaceLen;
        }
        if (i <= start) break;  // 防御：绝不原地打转

        const std::string piece = s.substr(start, i - start);
        for (const auto& sym : bpePiece(piece)) {
            auto it = mTokToId.find(sym);
            if (it != mTokToId.end()) {
                out.push_back(it->second);
                continue;
            }
            for (unsigned char b : sym) {  // 字节回退
                const uint32_t id = mByteId[b];
                out.push_back(id == 0xFFFFFFFFu ? 3 : static_cast<int>(id));
            }
        }
    }
    return out;
}

std::vector<int> BreezeTokenizer::encode(const std::string& text) const {
    std::vector<int> out;
    size_t pos = 0;
    while (pos < text.size()) {
        int hitId = -1;
        size_t hitLen = 0;
        for (const auto& kv : mAdded) {
            if (kv.second.empty() || kv.second[0] != text[pos]) continue;
            if (text.compare(pos, kv.second.size(), kv.second) == 0) {
                hitId = kv.first;
                hitLen = kv.second.size();
                break;
            }
        }
        if (hitId >= 0) {
            out.push_back(hitId);
            pos += hitLen;
            continue;
        }
        size_t next = text.size();
        for (const auto& kv : mAdded) {
            if (kv.second.empty()) continue;
            size_t f = text.find(kv.second, pos + 1);
            if (f != std::string::npos && f < next) next = f;
        }
        auto part = encodePlain(text.substr(pos, next - pos));
        out.insert(out.end(), part.begin(), part.end());
        pos = next;
    }
    return out;
}

PromptPlan BreezeTokenizer::buildPrompt(const std::string& text,
                                        const std::string& instruction,
                                        const std::string& refText,
                                        int refFrames,
                                        bool hasRef) const {
    PromptPlan plan;
    const bool hasIns = !instruction.empty();
    const std::string spk = "[S0]";

    auto pushSegment = [&](const std::string& s) {
        auto ids = encode(s);
        plan.textSegs.emplace_back(static_cast<int>(plan.ids.size()), static_cast<int>(ids.size()));
        plan.ids.insert(plan.ids.end(), ids.begin(), ids.end());
        plan.isText.insert(plan.isText.end(), ids.size(), 1);
    };

    if (hasRef && refFrames > 0) {
        // 段 1：参考文本
        pushSegment(spk + refText);
        // 段 2：N 帧音频占位 + eos
        const int start = static_cast<int>(plan.ids.size());
        for (int i = 0; i < refFrames; ++i) {
            plan.ids.push_back(mAudioToken);
            plan.isText.push_back(0);
        }
        plan.ids.push_back(mAudioEos);
        plan.isText.push_back(0);
        plan.audioStarts.push_back(start);
        plan.audioFrames = refFrames;
    }

    // 段 3（或唯一的段）：目标文本，指令包在 <ins_bos>/<ins_eos> 里
    std::string target = spk;
    if (hasIns) target += "<ins_bos>" + instruction + "<ins_eos>";
    target += text;
    pushSegment(target);

    return plan;
}

}  // namespace breeze
