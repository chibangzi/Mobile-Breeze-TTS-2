#ifndef BREEZE_H
#define BREEZE_H

#include <stddef.h>
#include <stdint.h>

#if defined(_WIN32)
#ifdef BREEZE_BUILD_SHARED
#define BREEZE_API __declspec(dllexport)
#else
#define BREEZE_API
#endif
#else
#define BREEZE_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct breeze_context breeze_context;

// return 0 to continue, non-zero to stop generation
typedef int (*breeze_audio_cb)(const float * samples, int n_samples, void * user);

typedef struct {
    const char * text;
    const char * instruction;   // null for a neutral default
    const char * ref_text;      // null when not cloning
    const float * ref_audio;    // mono 24 kHz samples, null for voice design
    int ref_audio_len;
    float cfg_scale;
    int seed;
    int max_new_tokens;         // 0 uses the model default
    int split_chars;            // 0 uses the default, negative keeps long text in a single pass
    // sampling. zero on any of these keeps whatever the gguf was built with
    float temperature;
    int top_k;
    float top_p;
    float repetition_penalty;
    // Frames per streamed chunk (12.5 frames per second). 0 keeps the engine
    // default (4 / 25). The vocoder always re-decodes ~88 frames of context per
    // flush, so a larger chunk_max amortises that fixed cost a lot: 25 frames
    // wastes about 4.5x the vocoder work, 64 frames about 2.4x. chunk_first
    // stays small so the first audio comes out early.
    int chunk_first;
    int chunk_max;
    // 1 (default when the field is left 0 by an older caller is engine
    // default) flushes a short chunk when playback is about to run dry.
    // 0 disables early flushing and only emits full chunks.
    int pace;
    // Stop after this many consecutive empty (all-pad) frames once real speech has
    // been produced: the model sometimes idles on pad tokens instead of sampling
    // eos, and every one of those frames costs a full backbone + depth step while
    // emitting no audio, which shows up as a long silent tail. 0 = engine default
    // (16), negative disables the guard.
    int pad_stop;
    // 已编码的参考码本，int16[ref_frames * n_codebooks]，帧优先（第 0 帧的 16 个码本在前）。
    // 优先级高于 ref_audio —— 给了它就不再跑 codec encode。设计音色的「锁定」就是
    // 把试听样本的码本存下来，之后每次合成都从这里出发，音色因此完全可复现。
    const int16_t * ref_codes;
    int ref_frames;
    // 非空时，把本次生成首段的码本写成 int16[frames * n_codebooks]。
    // 两处用得上：给设计音色录试听样本；给克隆音色缓存参考音频的编码结果。
    const char * codes_out;
    // 1.9.11：复用参考前缀 embedding 的占位字段。运行时不读，仅用于与 JNI 侧
    // 的结构体布局对齐（多一个 int 就能让后面所有字段偏移 4 字节）。
    int reuse_prefix_emb;
    // 1.9.43 后段降 CFG：前 N 帧按 cfg_scale 走双分支，之后降到 1.0 只跑 cond。
    // 0（默认）= 全程双分支。见 docs/50。
    int cfg_decay_frames;
    // 1.9.43 声码器独立线程：flush 期间临时用 voc_threads，结束恢复 gen_threads。
    // 任一为 0 则全程沿用当前线程数。
    int voc_threads;
    int gen_threads;
    // 1.9.69 性能诊断页的对照实验开关，正式合成一律传 0：
    //   depth_mode = 1 强制深度解码逐码本 replay（用来量「单图」省了多少）
    int depth_mode;
    // 1.9.91 深度解码 CFG：1 = 只走 cond 单分支（每帧深度耗时约降 45%，
    // 码本分布随之改变）。0 = 维持原行为，老调用方零初始化即兼容。
    int depth_cfg_off;
    // 1.9.106 诊断页的码本截断实验：0 = 全部码本（正式合成恒 0），
    // N = 只解前 N 个码本，其余用上一帧同位置补齐。
    int num_codebooks;
} breeze_request;

// Per stage wall clock (ms) of the last breeze_generate call.
typedef struct {
    double prompt_ms;       // text encoder + prompt assembly
    double prefill_ms;      // backbone prefill of the prompt
    double backbone_ms;     // per-frame backbone steps (both cfg branches)
    double depth_ms;        // per-frame depth decoder (acoustic codebooks)
    double vocoder_ms;      // codec.decode calls, context included
    double first_audio_ms;  // request start -> first audio chunk
    double tail_ms;         // last audio chunk -> return (the silent tail)
    int frames;             // audio frames emitted (12.5 per second)
    int flushes;            // vocoder calls
    int steps;              // backbone steps run
    int stopped_early;      // 1 when the pad guard ended the piece
    // 1.9.48：补齐与 JNI 侧一致的两个尾部字段。此前 app 侧头文件多这两个 int、
    // 而库只写到 stopped_early，导致 JNI 读到的是栈上残留值（诊断里偶发乱数）。
    // 目前 generation 不单独统计，固定填 0，保证确定性。
    int prefill_tokens;
    int prefill_reused;
    // 1.9.71：深度解码实际走的路径计数（帧数）。fused + steps == frames。
    // 判定条件在 native 内部（top_p/top_k/分支数），宿主侧看不到，只能由 native 数。
    int depth_fused_frames;
    int depth_step_frames;
} breeze_timings;

BREEZE_API breeze_context * breeze_init(const char * gguf_path, int use_gpu);
BREEZE_API void breeze_free(breeze_context * ctx);
BREEZE_API int breeze_sample_rate(breeze_context * ctx);

// Name of the compute backend actually in use ("CPU", "Vulkan0", ...).
// Returns "none" when ctx is null. The pointer stays valid for the ctx lifetime.
BREEZE_API const char * breeze_backend_name(breeze_context * ctx);
// 1 when the selected backend is a GPU (Vulkan), 0 for CPU fallback.
BREEZE_API int breeze_backend_is_gpu(breeze_context * ctx);

// Override the ggml CPU thread count (default is 4). Ignored on GPU backends.
// Call right after breeze_init, before the first generate.
BREEZE_API void breeze_set_threads(breeze_context * ctx, int n_threads);

// ---------------------------------------------------------------------------
// 1.9.100 调度实验：透明大页
//
// 2.4 GB 权重按 4 KB 分页是 60 万个页，逐帧扫 5 GB 时 TLB 覆盖不了；
// MADV_HUGEPAGE 让内核按 2 MB 映射，同样工作集只需约 1200 个 TLB 项。
//
// 只影响「之后」的分配：已映射的 4 KB 页要靠 khugepaged 后台折叠，时间不可控。
// 所以要可复现地比较，必须 set(on) → 重载模型 → 再测。
// 返回本次实际 madvise 成功的 CPU buffer 数（0 = 没有可处理区或内核不支持）。
BREEZE_API int breeze_set_thp(breeze_context * ctx, int on);
// 当前进程 AnonHugePages 总量（字节），用来验证大页到底有没有生效；读不到返回 -1。
BREEZE_API long long breeze_thp_bytes(breeze_context * ctx);
// 内核 THP 模式："always" / "madvise" / "never" / "unknown"。
BREEZE_API const char * breeze_thp_mode(void);

// Run a short throwaway generation so the first real request does not pay for
// weight paging and ggml graph/scratch allocation. Returns 0 on success.
BREEZE_API int breeze_warmup(breeze_context * ctx);

// streams audio chunks to the callback; returns 0 on success
BREEZE_API int breeze_generate(breeze_context * ctx, const breeze_request * req,
                               breeze_audio_cb cb, void * user);

// convenience: generate and write a 16-bit PCM WAV; returns 0 on success
BREEZE_API int breeze_generate_wav(breeze_context * ctx, const breeze_request * req,
                                   const char * out_path);

// Stage timings of the last breeze_generate call. Returns 0 on success.
BREEZE_API int breeze_get_timings(breeze_context * ctx, breeze_timings * out);

// Spoken length of a text in codec frames (12.5 frames per second), 0 when unknown.
BREEZE_API int breeze_estimate_frames(breeze_context * ctx, const char * text);

// Stage timings of the last breeze_generate call. Returns 0 on success.
BREEZE_API int breeze_get_timings(breeze_context * ctx, breeze_timings * out);

// Spoken length of a text in codec frames (12.5 frames per second), 0 when unknown.
BREEZE_API int breeze_estimate_frames(breeze_context * ctx, const char * text);

// 1.9.48 Vulkan 只读探测：不加载模型、不改全局状态。枚举 ggml 看到的 GPU 设备，
// 对 Breeze 实际用到的几个算子逐个问 supports_op，再跑一张最小图确认能出数。
// 成功返回 0，报告写入 out（总长不超过 cap）；-1 表示没有可用的 GPU 后端。
// 注意：本函数会创建 Vulkan device，部分驱动在这一步直接 SIGSEGV ——
// 调用方必须放在独立进程里，崩了只死探测进程（docs/27 的教训）。
BREEZE_API int breeze_vk_probe(char * out, int cap);

// 1.9.51 崩溃定位：把「当前正在执行什么」覆盖写到 path（绝对路径，UTF-8）。
// 传 null 关闭。进程被 SIGSEGV/SIGABRT 杀掉后，文件里剩下的内容就是崩溃点。
// 每次写入约 0.05 ms，只在 Vulkan 路径上开启，纯 CPU 不调用即零开销。
BREEZE_API void breeze_set_trace_file(const char * path);

// ---------------------------------------------------------------------------
// 1.9.87 声码器外置（手机 GPU）
//
// 设置后，合成时声码器只跑 quantizer → dpre → dtf，把 [frames, 1024] 的 latent
// 交给 fn，由外部（LiteRT GPU）算出 PCM。fn 返回写入 out 的采样数，<=0 表示失败，
// 该块自动回落到 CPU 全链路。
//
// 注意：fn 在合成线程上被调用（不是创建 ctx 的线程），实现方需要自己 attach JNI。
// 传 fn=null 解除。每次合成前设置，合成结束即可保持 —— 它不持有额外资源。
// ---------------------------------------------------------------------------
typedef int (*breeze_vocoder_fn)(const float * latent, int frames, float * out, int cap, void * user);

BREEZE_API void breeze_set_vocoder(breeze_context * ctx, breeze_vocoder_fn fn, void * user);

// 端到端校验：固定 codes，跑一次「GPU 半链路」和一次「CPU 全链路」，比两者。
//
// 为什么需要它：设置页那张自检图（CPU 后端 vs GPU 后端、同一份人工 latent）
// 只能证明 delegate 没有引入误差，证明不了**交给 GPU 的 latent 本身是对的**——
// 两边喂的是同一块内存，布局错得一致，误差照样 0.01%。1.9.87 就是这么把
// 一份列主序的 latent 喂进 channels-last 的图，输出全噪声却"自检通过"。
//
// out 需要 4 个 float：相对误差、GPU 饱和占比、CPU 饱和占比、GPU 耗时(ms)。
// 返回 0 成功；-1 未接 GPU；-2 长度不符；-3 回调根本没被调用（说明回落到 CPU 了）。
BREEZE_API int breeze_vocoder_check(breeze_context * ctx, int frames, float * out);

// ---------------------------------------------------------------------------
// 1.9.54 音色转换（音频 → 音频）
//
// 把 src_wav 里「说的话」用 ref_wav 的音色重说一遍：词、时长、节奏、重音来自源音频
// （语义码本原样复制），音高与音色按参考重新生成（15 个声学码本重算）。
//
// 这不是上游模型的官方能力，而是 codec「语义 / 声学」分离带来的副产品（README 标注
// experimental）：音高是重新唱的，可能整段移调；源文本可留空，但会退化成自动填充句，
// 对齐精度下降。
//
// 进度回调按帧回报（约 12.5 帧/秒音频）；回调返回非 0 表示取消，函数返回 6。
// 返回值：0 成功 / 1 内部错误 / 2 源音频读取失败 / 3 源音频编码失败
//        / 4 参考音频读取失败 / 5 结果写入失败 / 6 已取消
// ---------------------------------------------------------------------------
// phase 0 = 逐帧重说（done/total 为帧号），phase 1 = 声码器合成（done/total 为窗口号）。
// 返回非 0 表示调用方要求中止。1.9.57 起带 phase：声码器段占全程 30~40%，
// 不单独回报的话进度会停在 99% 很久。
typedef int (*breeze_convert_progress_cb)(int phase, int done, int total, void * user);

BREEZE_API int breeze_convert(breeze_context * ctx, const char * src_wav, const char * ref_wav,
                              const char * ref_text, const char * src_text, const char * out_wav,
                              float temperature, int top_k, int keep_acoustic, int seed,
                              breeze_convert_progress_cb cb, void * user);

BREEZE_API const char * breeze_last_error(void);

#ifdef __cplusplus
}
#endif

#endif
