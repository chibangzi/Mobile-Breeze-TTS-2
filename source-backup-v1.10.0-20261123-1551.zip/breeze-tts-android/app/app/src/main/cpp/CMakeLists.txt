cmake_minimum_required(VERSION 3.22.1)
project(breeze LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_FLAGS_RELEASE "${CMAKE_CXX_FLAGS_RELEASE} -O3 -fvisibility=hidden")

# ---------------------------------------------------------------------------
# GGUF 运行时：Breeze-TTS-2.cpp + ggml，由 tools/build_breeze_android.sh
# 交叉编译产出，预置在 app/src/main/jniLibs/<abi>/：
#   libbreeze_gguf.so  libggml.so  libggml-base.so  libggml-cpu.so
#
# 分词 / 文本编码 / 主干 / 深度解码器 / 声码器 全部在该运行时内完成，
# 本工程只编 JNI 桥接层。breeze_tokenizer.* 是旧 MNN 路线的残留参考实现，
# 不再参与编译（新后端的 tokenizer 直接来自 GGUF）。
# ---------------------------------------------------------------------------
set(GGUF_LIB_DIR ${CMAKE_CURRENT_SOURCE_DIR}/../jniLibs/${ANDROID_ABI})

if(NOT EXISTS ${GGUF_LIB_DIR}/libbreeze_gguf.so)
    message(FATAL_ERROR
        "缺少 GGUF 运行时：${GGUF_LIB_DIR}/libbreeze_gguf.so\n"
        "请先执行 tools/build_breeze_android.sh 从 Breeze-TTS-2.cpp 源码交叉编译。")
endif()

add_library(breeze_gguf SHARED IMPORTED)
set_target_properties(breeze_gguf PROPERTIES
        IMPORTED_LOCATION ${GGUF_LIB_DIR}/libbreeze_gguf.so)

# 纯 CPU。1.9.55 起连 Vulkan 运行时（libggml-vulkan.so，35 MB）也不再打包，
# 只依赖 libbreeze_gguf.so（其内部自带 CPU 后端的 ggml）。
add_library(breeze SHARED
        breeze_jni.cpp
        breeze_engine.cpp)

target_include_directories(breeze PRIVATE
        ${CMAKE_CURRENT_SOURCE_DIR}/include)

find_library(log-lib log)

target_link_libraries(breeze PRIVATE
        breeze_gguf
        ${log-lib})

# 只出 arm64（12GB / 骁龙 8 Elite 基线）
set_target_properties(breeze PROPERTIES
        ANDROID_ARM_NEON TRUE
        CXX_VISIBILITY_PRESET hidden)
