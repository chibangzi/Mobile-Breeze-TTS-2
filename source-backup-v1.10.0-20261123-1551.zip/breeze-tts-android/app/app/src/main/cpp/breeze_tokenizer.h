//
//  breeze_tokenizer.h
//  Breeze TTS 2 端上分词：Gemma 风格 BPE + byte fallback + added tokens。
//
//  与 tools/verify_tokenizer.py 的参考实现逐行对应，二者在 13 条中英混排样例上
//  与官方 tokenizers 库完全一致（见 docs/01-research-breeze-tts-2.md §3）。
//
#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace breeze {

struct PromptPlan {
    std::vector<int> ids;         // 完整序列（含 <|AUDIO|> 占位）
    std::vector<uint8_t> isText;  // 每个位置是否走文本编码器
    // 文本段：{起始下标, 长度}，按出现顺序
    std::vector<std::pair<int, int>> textSegs;
    // 音频段在序列中的起点（对应 N 个 <|AUDIO|> + 1 个 <|audio_eos|>）
    std::vector<int> audioStarts;
    int audioFrames = 0;
};

class BreezeTokenizer {
public:
    bool load(const std::string& binPath);

    std::vector<int> encode(const std::string& text) const;

    /**
     * 四种模板：
     *   无参考 + 无指令 : [S0]{text}
     *   无参考 + 有指令 : [S0]<ins_bos>{ins}<ins_eos>{text}
     *   有参考 + 无指令 : [S0]{refText} <|AUDIO|>×N <|audio_eos|> [S0]{text}
     *   有参考 + 有指令 : [S0]{refText} <|AUDIO|>×N <|audio_eos|> [S0]<ins_bos>{ins}<ins_eos>{text}
     *
     * 注意：每段文本单独编码（与官方 templates.py 一致），不能整段拼完再编码，
     * 否则 BPE 会跨段合并，导致和训练分布不一致。
     */
    PromptPlan buildPrompt(const std::string& text,
                           const std::string& instruction,
                           const std::string& refText,
                           int refFrames,
                           bool hasRef) const;

    int idOf(const std::string& token) const;
    int audioTokenId() const { return mAudioToken; }
    int audioEosTokenId() const { return mAudioEos; }
    int speakerId() const { return mSpeaker; }
    int padCodebookId() const { return 2050; }
    int backboneEosId() const { return 2051; }

private:
    std::vector<int> encodePlain(const std::string& text) const;
    std::vector<std::string> bpePiece(const std::string& piece) const;

    std::vector<std::string> mIdToTok;
    std::unordered_map<std::string, int> mTokToId;
    // key = (left << 32) | right -> {rank, mergedId}
    std::unordered_map<uint64_t, std::pair<uint32_t, uint32_t>> mMerges;
    std::vector<std::pair<int, std::string>> mAdded;  // 按长度降序
    uint32_t mByteId[256]{};

    int mAudioToken = 262144;
    int mAudioEos = 262145;
    int mSpeaker = 262146;
};

}  // namespace breeze
