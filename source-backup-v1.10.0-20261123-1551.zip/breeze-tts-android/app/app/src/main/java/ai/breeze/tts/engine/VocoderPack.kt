package ai.breeze.tts.engine

import ai.breeze.tts.i18n.tr

import android.content.Context
import android.net.Uri
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.zip.ZipFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 声码器 GPU 加速包（147 MB 的 LiteRT 图）的独立安装管理。
 *
 * ## 为什么从 APK 里拆出来
 *
 * 这张图一直以 `assets/vocoder_gpu.tflite` 的形式打在包里，而且 `noCompress`
 * 让它在 APK 里原样存 147 MB —— 安装包 216 MB，其中七成是只有少数人会用到的
 * 一条实验路径。1.9.92 起改成**可选安装**：
 *
 * - APK 里只留一张 300 KB 的探测图（判断设备 GPU 能不能用）；
 * - 加速包单独发一个 zip，用户在设置页自己导入，想用再装；
 * - 不装就完全走 CPU 声码器，功能不受任何影响。
 *
 * ## 加速包格式
 *
 * ```
 * breeze-vocoder-gpu-fp32-t128.zip
 *   ├── vocoder_gpu.tflite      147 MB，TFL3 flatbuffer
 *   └── manifest.json           体积 / sha256 / 帧长，用于校验
 * ```
 *
 * 也接受**裸 .tflite**（直接选中文件即可），只是没有 sha256 可对。
 *
 * ## 安装过程为什么这么绕
 *
 * SAF 给的只是一个流，而 zip 需要随机访问才能只解出其中一个条目，所以先整份
 * 复制到私有目录再开 [ZipFile]；打开之后**立刻删掉临时 zip**（Linux 上已打开
 * 的 fd 仍然可读），这样峰值占用只有 147 MB 而不是 284 MB。解压目标先写
 * `.part`，校验通过才改名，任何一步失败都不会留下半成品被下次启动当成已安装。
 */
object VocoderPack {

    private const val TAG = "VocoderPack"

    /** 私有目录名；和模型目录 `models/` 平级，删起来互不影响 */
    const val DIR = "vocoder"
    const val MODEL = "vocoder_gpu.tflite"
    const val MANIFEST = "manifest.json"

    /** 包内模型大小。manifest 缺失时用它做下限判断 */
    const val EXPECT_BYTES = 147_004_904L

    /** 小于这个值的一定不是那张图（也挡掉 HTML 错误页 / 空文件） */
    private const val MIN_BYTES = 100L shl 20

    /** zip 本地文件头 `PK\x03\x04` */
    private val ZIP_MAGIC = byteArrayOf(0x50, 0x4B, 0x03, 0x04)

    fun dir(ctx: Context): File = File(ctx.filesDir, DIR)

    fun modelFile(ctx: Context): File = File(dir(ctx), MODEL)

    fun isInstalled(ctx: Context): Boolean = isInstalled(modelFile(ctx))

    fun isInstalled(f: File): Boolean = f.isFile && f.length() >= MIN_BYTES

    fun bytes(ctx: Context): Long = modelFile(ctx).let { if (it.isFile) it.length() else 0L }

    /** 卸载加速包。正在使用的模型由调用方先 release。 */
    fun remove(ctx: Context) {
        dir(ctx).deleteRecursively()
        Log.i(TAG, "vocoder pack removed")
    }

    /** 解析出的 manifest；字段缺失时给默认值，不让一条坏 json 挡住安装。 */
    data class Manifest(
        val format: String = "",
        val version: Int = 0,
        val bytes: Long = 0,
        val sha256: String = "",
    ) {
        val isVocoderPack: Boolean get() = format == "breeze-vocoder-pack"
    }

    /**
     * 导入。`onProgress(done, total)` 的 total <= 0 表示总量未知（复制阶段），
     * 界面此时只显示已读字节数。
     *
     * 返回安装后的模型文件。任何失败都抛异常，`.part` 会被清掉。
     */
    suspend fun install(
        ctx: Context,
        uri: Uri,
        onProgress: (Long, Long) -> Unit = { _, _ -> },
    ): File = withContext(Dispatchers.IO) {
        val dir = dir(ctx).apply { mkdirs() }
        val tmp = File(dir, "import.tmp").apply { delete() }
        val part = File(dir, "$MODEL.part").apply { delete() }

        try {
            // 1) 先把 SAF 的流整份落到私有目录：zip 需要随机访问
            var copied = 0L
            ctx.contentResolver.openInputStream(uri)?.use { ins ->
                FileOutputStream(tmp).use { fos ->
                    val buf = ByteArray(1 shl 20)
                    while (true) {
                        val n = ins.read(buf)
                        if (n <= 0) break
                        fos.write(buf, 0, n)
                        copied += n
                        onProgress(copied, -1L)
                    }
                }
            } ?: throw IOException(tr("打不开所选文件"))

            if (copied < MIN_BYTES) {
                throw IOException(tr("文件只有 ${copied / 1_000_000} MB，不是声码器加速包", "The file is only ${copied / 1_000_000} MB — not a vocoder acceleration pack"))
            }

            // 2) zip 还是裸 tflite
            val head = ByteArray(4).also { h ->
                tmp.inputStream().use { it.read(h) }
            }
            val manifest: Manifest
            val modelBytes: Long
            if (head.contentEquals(ZIP_MAGIC)) {
                manifest = readManifest(tmp)
                ZipFile(tmp).use { zf ->
                    val entry = zf.getEntry(MODEL)
                        ?: zf.entries().asSequence().firstOrNull {
                            !it.isDirectory && it.name.endsWith(".tflite", ignoreCase = true)
                        }
                        ?: throw IOException(tr("压缩包里没有 .tflite 模型"))
                    modelBytes = entry.size
                    // 打开 fd 后立刻删掉临时 zip：Linux 上句柄仍然有效，
                    // 峰值存储从 284 MB 降到 147 MB。
                    tmp.delete()
                    var done = 0L
                    zf.getInputStream(entry).use { ins ->
                        FileOutputStream(part).use { fos ->
                            val buf = ByteArray(1 shl 20)
                            while (true) {
                                val n = ins.read(buf)
                                if (n <= 0) break
                                fos.write(buf, 0, n)
                                done += n
                                onProgress(done, entry.size)
                            }
                        }
                    }
                }
            } else {
                // 裸 tflite：临时文件本身就是模型，直接改名
                manifest = Manifest()
                modelBytes = copied
                if (!tmp.renameTo(part)) {
                    tmp.copyTo(part, overwrite = true)
                    tmp.delete()
                }
                onProgress(modelBytes, modelBytes)
            }

            // 3) 校验：大小、TFL3 文件头、sha256
            if (part.length() < MIN_BYTES) {
                throw IOException(tr("解出来的模型只有 ${part.length() / 1_000_000} MB，不完整", "The extracted model is only ${part.length() / 1_000_000} MB — incomplete"))
            }
            checkTflite(part)
            if (manifest.sha256.isNotBlank()) {
                onProgress(0, 0)  // 让界面切到「校验中」
                val actual = sha256(part)
                if (!actual.equals(manifest.sha256, ignoreCase = true)) {
                    throw IOException(tr("校验失败：sha256 不匹配（文件可能损坏）"))
                }
            }

            // 4) 原子落位
            val out = modelFile(ctx)
            out.delete()
            if (!part.renameTo(out)) {
                part.copyTo(out, overwrite = true)
                part.delete()
            }
            Log.i(TAG, "installed ${out.length()} bytes (manifest=$modelBytes)")
            out
        } catch (t: Throwable) {
            part.delete()
            throw t
        } finally {
            tmp.delete()
        }
    }

    private fun readManifest(zip: File): Manifest {
        return runCatching {
            ZipFile(zip).use { zf ->
                val e = zf.getEntry(MANIFEST) ?: return@use Manifest()
                val text = zf.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
                val o = org.json.JSONObject(text)
                Manifest(
                    format = o.optString("format"),
                    version = o.optInt("version"),
                    bytes = o.optLong("bytes"),
                    sha256 = o.optString("sha256"),
                )
            }
        }.getOrDefault(Manifest())
    }

    /**
     * TFLite flatbuffer 的第 4–8 字节固定是 `TFL3`（前 4 字节是 root table 偏移）。
     * 这个检查比「文件够大」可靠得多：能挡住把 zip/gguf 改名成 .tflite 的情况。
     */
    private fun checkTflite(f: File) {
        val buf = ByteArray(8)
        f.inputStream().use { if (it.read(buf) != 8) throw IOException(tr("文件头读取失败")) }
        val magic = String(buf, 4, 4, Charsets.US_ASCII)
        if (magic != "TFL3") {
            throw IOException(tr("不是 TFLite 模型（文件头为 $magic），请选择声码器加速包 zip", "Not a TFLite model (header is $magic) — choose the vocoder pack zip"))
        }
    }

    fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(1 shl 20)
            while (true) {
                val n = ins.read(buf)
                if (n <= 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
