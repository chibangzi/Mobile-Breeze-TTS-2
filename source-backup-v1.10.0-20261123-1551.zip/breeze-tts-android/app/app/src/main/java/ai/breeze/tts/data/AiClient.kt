package ai.breeze.tts.data

import ai.breeze.tts.i18n.tr

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * 最小 OpenAI 兼容客户端：只打 `/chat/completions`，非流式。
 *
 * 为什么不用第三方库：整个项目零网络依赖（下载走原生 HttpURLConnection），
 * 为了一个 POST 引 OkHttp + 协程适配不值当。这里手写的部分只有
 * 「拼 JSON / 发请求 / 取 choices[0].message.content」三件事。
 *
 * baseUrl 归一化规则见 [endpointCandidates]：用户填 `https://api.deepseek.com`、
 * `.../v1`、甚至完整 `.../v1/chat/completions` 都能用。
 *
 * 1.9.13 起针对「同一个接口在别的 App 能通、在这里 503」做了三项兼容：
 *  1. 显式发送浏览器风格 User-Agent —— 大量中转站前面挂着 Cloudflare，
 *     其 Bot Fight Mode 会直接阻断 `Dalvik/2.x` 这类默认 UA，返回 403/503。
 *  2. 固定 Content-Length（不走 chunked）—— 部分网关的 WAF 不解析分块请求体。
 *  3. 502/503/504/529 自动重试 + 端点变体回退 —— 中转站返回的
 *     `Service temporarily unavailable` 多数是「该分组暂无可用渠道 / 上游限流」，
 *     重试通常就能过；路径拼错则靠端点回退兜住。
 */
object AiClient {

    /** 一次对话消息：role = system / user / assistant */
    data class Msg(val role: String, val content: String)

    /**
     * 网关判定为「临时故障」的状态码，重试有意义。
     * 503 Service temporarily unavailable / 502 Bad gateway / 504 Gateway timeout /
     * 529（部分中转站用来表示上游过载）。
     */
    private val RETRYABLE = setOf(502, 503, 504, 529)

    /** 这些状态下换一个端点路径可能就好了（路径不对时网关常回 404/405/503 而非标准 404） */
    private val MAYBE_WRONG_PATH = setOf(404, 405, 501, 502, 503, 504)

    /**
     * 伪装成常见 HTTP 客户端。Android 的 HttpURLConnection 默认 UA 是
     * `Dalvik/2.1.0 (Linux; U; Android xx)`，Cloudflare 的机器人防护与部分
     * 中转站的白名单都会把它当异常流量处理 —— 这是「别的 App 能连、这里连不上」
     * 最常见的原因之一（别的 App 大多用 OkHttp）。
     */
    private const val USER_AGENT = "okhttp/4.12.0"

    suspend fun chat(
        provider: AiProvider,
        system: String,
        user: String,
        temperature: Double = 0.9,
        maxTokens: Int = 2048,
        readTimeoutMs: Int = 120_000,
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cands = endpointCandidates(provider.baseUrl)
            require(cands.isNotEmpty()) { tr("接口地址为空，请先在设置里填写 Base URL") }
            require(provider.apiKey.isNotBlank()) { tr("API Key 为空") }
            require(provider.model.isNotBlank()) { tr("模型名为空") }

            val body = JSONObject().apply {
                put("model", provider.model.trim())
                put(
                    "messages", JSONArray().apply {
                        put(JSONObject().put("role", "system").put("content", system))
                        put(JSONObject().put("role", "user").put("content", user))
                    },
                )
                put("temperature", temperature)
                put("max_tokens", maxTokens)
                put("stream", false)
            }.toString()

            val text = requestWithFallback(cands, provider.apiKey, body, readTimeoutMs)
            val obj = JSONObject(text)
            val choices = obj.optJSONArray("choices")
                ?: error(friendlyError(text))
            if (choices.length() == 0) error(tr("接口返回了空的 choices"))
            val msg = choices.getJSONObject(0).optJSONObject("message")
                ?: error(tr("接口返回缺少 message 字段"))
            val content = msg.optString("content", "").trim()
            if (content.isEmpty()) {
                val reasoning = msg.optString("reasoning_content", "")
                error(
                    if (reasoning.isNotBlank())
                        tr("模型只返回了思考过程，没有正文（可能是推理模型，换一个非推理模型试试）")
                    else tr("接口返回了空内容")
                )
            }
            content
        }
    }

    /**
     * 连通性测试。**先 `/models` 再 `/chat/completions`**，两段分开验证。
     *
     * 为什么不像以前那样直接打 chat：绝大多数 App（包括常见的生图 App）的「测试连接」
     * 只打 `/models`，它只证明「地址对、Key 有效」，并不能证明这个 Key 能调对话模型。
     * 用户把同一套配置搬过来时，很容易得到「那边成功、这边 503」，
     * 而真实原因是这家中转站根本没有对话渠道，或者填进来的是个生图模型名。
     * 分层之后每种情况都能给出确定的结论。
     */
    suspend fun probe(provider: AiProvider): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cands = endpointCandidates(provider.baseUrl)
            require(cands.isNotEmpty()) { tr("连接失败：接口地址为空，请先在设置里填写 Base URL") }
            require(provider.apiKey.isNotBlank()) { tr("连接失败：API Key 为空") }
            require(provider.model.isNotBlank()) { tr("连接失败：模型名为空") }

            val (failAttempt, models) = fetchModels(cands, provider.apiKey)
            if (models == null) throw IOException(modelsFailureText(failAttempt))

            val chat = chat(
                provider = provider,
                system = tr("你是连通性测试助手，只回复两个字：可用。"),
                user = "ping",
                temperature = 0.3,
                maxTokens = 32,
                readTimeoutMs = 30_000,
            )
            chat.fold(
                onSuccess = { reply ->
                    tr("连接成功：地址与密钥正常，模型 ${provider.model} 可正常对话", "Connected: address and key are fine, model ${provider.model} answers normally") +
                        tr("（回复：${reply.take(20)}）。该接口共 ${models.size} 个模型。", " (reply: ${reply.take(20)}). This endpoint lists ${models.size} models.")
                },
                onFailure = { throw IOException(chatFailureText(provider.model, models, it)) },
            )
        }
    }

    /** 拉取可用模型列表（GET /models）。用于设置页的「从列表选择」。 */
    suspend fun listModels(provider: AiProvider): Result<List<String>> = withContext(Dispatchers.IO) {
        runCatching {
            val cands = endpointCandidates(provider.baseUrl)
            require(cands.isNotEmpty()) { tr("接口地址为空，请先填写 Base URL") }
            require(provider.apiKey.isNotBlank()) { tr("API Key 为空") }
            val (failAttempt, models) = fetchModels(cands, provider.apiKey)
            models ?: throw IOException(modelsFailureText(failAttempt))
        }
    }

    /** 名字像对话/文本模型。用来在「只有生图模型」时给用户一个明确结论。 */
    fun looksChatable(modelId: String): Boolean {
        val l = modelId.lowercase()
        return NON_CHAT_MARKERS.none { l.contains(it) }
    }

    private val NON_CHAT_MARKERS = listOf(
        "image", "dall-e", "dalle", "stable-diffusion", "sd3", "flux", "midjourney",
        "embed", "bge", "gte", "rerank", "moderation", "whisper", "tts", "audio",
        "speech", "sora", "veo", "kling", "video", "upscale", "ocr",
    )

    private fun modelsFailureText(a: Attempt?): String {
        if (a == null) return tr("连接失败：请求没有发出去，请检查 Base URL 是否合法")
        val tip = tr("\n请求地址：${a.url}", "\nRequest URL: ${a.url}")
        return when {
            a.code == 401 || a.code == 403 ->
                tr("连接失败：密钥被拒绝（/models 返回 ${a.code}）。请确认 Key 完整复制、没有多余空格、未过期。$tip", "Connection failed: the key was rejected (/models returned ${a.code}). Check the key is copied in full, has no stray spaces and hasn't expired.$tip")
            a.code == 404 || a.code == 405 ->
                tr("连接失败：这个地址下没有 OpenAI 兼容接口（/models 返回 ${a.code}），Base URL 少了或多了一段路径。$tip", "Connection failed: no OpenAI-compatible API at this address (/models returned ${a.code}) — the Base URL is missing a path segment or has one too many.$tip")
            a.code in RETRYABLE ->
                tr("连接失败：服务端临时不可用（/models 返回 ${a.code}），过一会儿重试即可。$tip", "Connection failed: the server is temporarily unavailable (/models returned ${a.code}); retry in a moment.$tip")
            else ->
                tr("连接失败：HTTP ${a.code}：${shorten(extractMessage(a.body).ifBlank { a.body })} $tip", "Connection failed: HTTP ${a.code}: ${shorten(extractMessage(a.body).ifBlank { a.body })} $tip")
        }
    }

    /**
     * chat 失败但 `/models` 成功时，把「模型名不对」和「渠道没上游」区分开。
     * 这两种情况用户要做的事完全相反，不能糊成一句「503」。
     */
    private fun chatFailureText(model: String, models: List<String>, e: Throwable): String {
        val head = buildString {
            append(tr("地址与密钥都正常（/models 返回 ${models.size} 个模型），但对话请求失败：\n", "Address and key are fine (/models returned ${models.size} models), but the chat request failed:\n"))
            append(e.message ?: tr("未知错误"))
        }
        if (models.isEmpty()) {
            return tr("$head\n\n该接口没有返回模型列表，无法据此判断。请核对模型名是否拼写正确。", "$head\n\nThis endpoint returned no model list, so it can't be checked that way. Make sure the model name is spelled correctly.")
        }
        val inList = models.any { it.equals(model.trim(), ignoreCase = true) }
        val chatables = models.filter { looksChatable(it) }
        return when {
            !inList -> buildString {
                append(head)
                append(tr("\n\n模型名「$model」不在该接口的模型列表里。", "\n\nThe model name \"$model\" is not in this endpoint's list."))
                if (chatables.isNotEmpty()) {
                    append(tr("\n该接口的对话模型有："))
                    append(chatables.take(8).joinToString("、"))
                    append(tr("\n请把模型名改成上面其中一个。"))
                } else {
                    append(tr("\n而且这个接口的模型全部是生图/向量类的，没有能写文字的对话模型：\n"))
                    append(models.take(12).joinToString("、"))
                    append(tr("\n\n它无法用于扩写，请换一个提供对话模型的服务商（DeepSeek、通义千问、智谱等）。"))
                }
            }
            chatables.isEmpty() -> buildString {
                append(head)
                append(tr("\n\n这个接口的模型全部是生图/向量类的，没有能写文字的对话模型：\n"))
                append(models.take(12).joinToString("、"))
                append(tr("\n\n它无法用于扩写，请换一个提供对话模型的服务商（DeepSeek、通义千问、智谱等）。"))
            }
            else -> buildString {
                append(head)
                append(tr("\n\n模型名没问题，是这个渠道当前没有可用上游（中转站常见）。"))
                append(tr("稍后重试，或改用该接口的其他对话模型："))
                append(chatables.filterNot { it.equals(model.trim(), true) }.take(6).joinToString("、"))
                    .takeIf { it.isNotBlank() }?.let { append("\n").append(it) }
            }
        }
    }

    /** 依次尝试候选端点拉模型列表；返回 (最后一次失败, 模型列表或 null)。 */
    private suspend fun fetchModels(
        candidates: List<String>,
        apiKey: String,
    ): Pair<Attempt?, List<String>?> {
        var meaningful: Attempt? = null
        for (c in candidates) {
            val a = runCatching { get(modelsUrlOf(c), apiKey, 20_000) }.getOrNull() ?: continue
            if (a.code in 200..299) {
                val ids = runCatching {
                    val o = JSONObject(a.body)
                    val arr = o.optJSONArray("data") ?: o.optJSONArray("models")
                    (0 until (arr?.length() ?: 0)).mapNotNull { i ->
                        arr!!.optJSONObject(i)?.optString("id")?.takeIf { it.isNotBlank() }
                    }
                }.getOrDefault(emptyList())
                return a to ids.distinct()
            }
            // 404/405 说明这个路径不对，不如下一个；其它状态码更能说明真实原因
            if (meaningful == null || meaningful.code in setOf(404, 405, 501)) meaningful = a
        }
        return meaningful to null
    }

    private fun modelsUrlOf(chatEndpoint: String): String =
        chatEndpoint.removeSuffix("/chat/completions") + "/models"

    /**
     * 旧接口保留：语义等价于「跑一次 chat」。设置页已改用 [probe]。
     */
    suspend fun test(provider: AiProvider): Result<String> = withContext(Dispatchers.IO) {
        chat(
            provider = provider,
            system = tr("你是连通性测试助手，只回复两个字：可用。"),
            user = "ping",
            temperature = 0.3,
            maxTokens = 32,
            readTimeoutMs = 30_000,
        ).map { it.take(60) }
    }

    /**
     * 把用户填的 Base URL 归一化成完整的 chat/completions 地址。
     *  - 已经以 `/chat/completions` 结尾 → 原样使用
     *  - 以版本段结尾（/v1、/v4、/compatible-mode/v1…）→ 追加 `/chat/completions`
     *  - 其余（只有域名或端口）→ 追加 `/v1/chat/completions`
     */
    fun endpointOf(baseUrl: String): String = endpointCandidates(baseUrl).firstOrNull().orEmpty()

    /**
     * 返回按优先级排列的候选端点。第一个是「按规则推算的最可能地址」，
     * 后面的只在前面返回 404/405/5xx 时才尝试 —— 用来兜住 `.../api`、
     * 只写域名、以及网关把未知路由返回成 503 的情况。
     */
    fun endpointCandidates(baseUrl: String): List<String> {
        val b = baseUrl.trim().trimEnd('/')
        if (b.isEmpty()) return emptyList()
        if (b.endsWith("/chat/completions")) return listOf(b)

        val last = b.substringAfterLast('/')
        val versioned = Regex("^v\\d+([a-zA-Z0-9._-]*)?$").matches(last)

        val primary = if (versioned) "$b/chat/completions" else "$b/v1/chat/completions"

        val alt = LinkedHashSet<String>()
        alt += primary
        // 变体一：去掉末尾版本段直接拼（`.../api/v1` 这类其实网关只认 `.../api/chat/completions`）
        if (versioned) alt += "${b.substringBeforeLast('/')}/chat/completions"
        // 变体二：base 已含自定义路径（如 `.../api`、`.../openai`），补 /chat/completions
        if (!versioned) alt += "$b/chat/completions"
        return alt.toList()
    }

    // ---------------------------------------------------------------- 传输层

    private class Attempt(val url: String, val code: Int, val body: String)

    /**
     * 依次尝试候选端点；对「临时故障」在同一地址上重试一次。
     * 401/403/400/429 直接失败 —— 换路径重试没有意义，还会浪费用户时间。
     *
     * 抛错时挑「最像真实原因」的那次失败：首选端点回的 5xx 比兜底端点回的
     * 404 更能说明问题，不能因为兜底尝试失败把真实原因盖掉。
     */
    private suspend fun requestWithFallback(
        candidates: List<String>,
        apiKey: String,
        body: String,
        readTimeoutMs: Int,
    ): String {
        val failures = mutableListOf<Attempt>()
        candidates.forEachIndexed { index, url ->
            var a = post(url, apiKey, body, readTimeoutMs)
            if (a.code in 200..299) return a.body
            failures += a

            if (a.code in RETRYABLE) {
                delay(if (index == 0) 700L else 400L)
                a = post(url, apiKey, body, readTimeoutMs)
                if (a.code in 200..299) return a.body
                failures += a
            }

            // 鉴权/参数类错误换路径也没用，立刻把结论抛出去
            if (a.code !in MAYBE_WRONG_PATH) throw IOException(formatError(a))
        }
        val best = failures.firstOrNull { it.code !in setOf(404, 405, 501) } ?: failures.first()
        throw IOException(formatError(best))
    }

    private fun post(
        url: String,
        apiKey: String,
        body: String,
        readTimeoutMs: Int,
    ): Attempt {
        val payload = body.toByteArray(StandardCharsets.UTF_8)
        val conn = open(url, apiKey, readTimeoutMs).apply {
            requestMethod = "POST"
            doOutput = true
            // 固定长度：不让 HttpURLConnection 用 chunked，部分 WAF 不解析分块请求体
            setFixedLengthStreamingMode(payload.size)
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        try {
            conn.outputStream.use { it.write(payload) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.let {
                BufferedReader(InputStreamReader(it, StandardCharsets.UTF_8)).use { r -> r.readText() }
            }.orEmpty()
            return Attempt(url, code, text)
        } finally {
            conn.disconnect()
        }
    }

    private fun get(url: String, apiKey: String, readTimeoutMs: Int): Attempt {
        val conn = open(url, apiKey, readTimeoutMs).apply {
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.let {
                BufferedReader(InputStreamReader(it, StandardCharsets.UTF_8)).use { r -> r.readText() }
            }.orEmpty()
            return Attempt(url, code, text)
        } finally {
            conn.disconnect()
        }
    }

    private fun open(url: String, apiKey: String, readTimeoutMs: Int): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = readTimeoutMs
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
            // 不让系统自动加 gzip：个别网关的 gzip 分块与我们的读取方式冲突
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
        }

    // ---------------------------------------------------------------- 文本

    /** 把服务端返回的 error.message 抽出来，比整段 JSON 好读。 */
    private fun friendlyError(raw: String): String {
        val m = extractMessage(raw)
        return if (m.isNotBlank()) tr("接口报错：${shorten(m)}", "Endpoint error: ${shorten(m)}") else tr("接口返回无法解析：${shorten(raw)}", "Unparsable response: ${shorten(raw)}")
    }

    /**
     * one-api / new-api 一系的错误体是 `{"error":{"message":..,"type":"api_error","param":"","code":null}}`，
     * 只取 message 会让「Service temporarily unavailable」这类笼统文案失去上下文，
     * 所以 type 也一并带上。
     */
    private fun extractMessage(raw: String): String = runCatching {
        val o = JSONObject(raw)
        val e = o.optJSONObject("error")
        val msg = e?.optString("message", "").orEmpty().ifBlank { o.optString("message", "") }
        val type = e?.optString("type", "").orEmpty()
        when {
            msg.isBlank() -> ""
            type.isBlank() || type == "api_error" -> msg
            else -> "$msg（$type）"
        }
    }.getOrDefault("")

    private fun formatError(a: Attempt): String {
        val msg = extractMessage(a.body)
        val detail = if (msg.isNotBlank()) shorten(msg) else shorten(a.body).ifBlank { tr("无响应内容") }
        return tr("HTTP ${a.code}：$detail\n请求地址：${a.url}", "HTTP ${a.code}: $detail\nRequest URL: ${a.url}")
    }

    private fun shorten(s: String): String {
        val oneLine = s.replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= 220) oneLine else oneLine.take(220) + "…"
    }
}
