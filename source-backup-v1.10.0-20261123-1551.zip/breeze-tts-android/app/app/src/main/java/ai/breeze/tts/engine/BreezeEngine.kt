package ai.breeze.tts.engine

import ai.breeze.tts.i18n.tr

import android.util.Log
import androidx.annotation.Keep
import ai.breeze.tts.diag.DiagLog
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 端上推理引擎的唯一入口。
 *
 * 生命周期：load() 一次（约 1.6 GB 权重，冷启动 3-8 s）→ 多次 synthesize() → release()。
 * 线程模型：synthesize() 阻塞执行，必须放在后台线程；音频块从 native 线程回调进来，
 * 由上层（ViewModel）转成 Flow 再喂给 AudioTrack。
 */
class BreezeEngine {

    @Volatile
    private var handle: Long = 0L
    private val busy = AtomicBoolean(false)

    var onChunk: ((ShortArray) -> Unit)? = null
    var onProgress: ((frame: Int, maxFrames: Int) -> Unit)? = null
    /** 1.9.54 音色转换进度：(已完成帧, 总帧)。转换不流式出音，进度是唯一的反馈。 */
    /**
     * 转换进度：phase 0 = 逐帧重说（done/total 为帧号），1 = 声码器合成（done/total 为窗口号）。
     * 两段耗时接近四六开，所以要分开报，否则进度会长时间停在 99%。
     */
    var onConvertProgress: ((phase: Int, done: Int, total: Int) -> Unit)? = null
    var onDone: ((EngineStats) -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    var onStats: ((StageTimings) -> Unit)? = null

    val isLoaded: Boolean get() = handle != 0L
    val isBusy: Boolean get() = busy.get()

    /**
     * 1.9.87：声码器外置委托（VocoderGpu.delegate）。非空时声码器后半段走 GPU，
     * 空则整条链路纯 CPU——也就是关闭开关时的行为，和 1.9.84 之前完全一样。
     */
    var vocoderDelegate: Any? = null
        set(value) {
            field = value
            handle.takeIf { it != 0L }?.let { nativeSetVocoder(it, value, LATENT_DIM) }
        }

    /** 加载 GGUF。纯 CPU 后端（1.9.55 起 GPU / Vulkan 路径整体移除）。 */
    @Synchronized
    fun load(modelDir: String, threads: Int = 4) {
        if (handle != 0L) return
        val h = nativeCreate(modelDir, threads)
        if (h == 0L) error(tr("引擎加载失败：$modelDir", "Engine failed to load: $modelDir"))
        handle = h
        // 句柄换新后，之前注册过的委托要重新挂上去（native 侧按 ctx 存）
        vocoderDelegate?.let { nativeSetVocoder(h, it, LATENT_DIM) }
        Log.i(TAG, "loaded $modelDir threads=$threads backend=${backendName()}")
    }

    /** 阻塞直到整段合成结束；返回 false 表示被取消或失败。 */
    fun synthesize(req: SynthRequest): Boolean {        val h = handle
        if (h == 0L) {
            onError?.invoke(tr("引擎未加载"))
            return false
        }
        if (!busy.compareAndSet(false, true)) {
            // 上一段的 native 调用还没返回（可能在收尾）。等它退出再重试一次，
            // 而不是直接把「上一段还在生成」甩给用户——这正是「停了以后点不动」的观感。
            if (!awaitIdle(PREV_JOB_GRACE_MS) || !busy.compareAndSet(false, true)) {
                onError?.invoke(tr("上一段还在收尾，请稍候再试"))
                return false
            }
        }
        return try {
            // 先落一条起始标记：如果连 native 的 gen:prompt 都没写出来就崩了，
            // 看到的会是 req:start，说明崩在进 native 之前或最开头。
            tracePath?.let { runCatching { java.io.File(it).writeText("req:start") } }
            val v = req.voice
            val rc = nativeSynthesize(
                h,
                req.text,
                req.instruction,
                v?.refWav ?: "",
                v?.refText ?: "",
                v?.codes ?: "",
                req.codesOut ?: "",
                v?.designPrompt ?: "",
                when (v?.kind) {
                    VoiceProfile.Kind.CLONE -> "clone"
                    VoiceProfile.Kind.DESIGN -> "design"
                    null -> ""
                },
                req.seed,
                req.temperature,
                req.topP,
                req.maxFrames,
                req.chunkFirst,
                req.cfgScale,
                req.reusePrefixEmb,
                req.cfgDecayFrames,
                req.vocThreads,
                req.depthMode,
                req.chunkMax,
                req.depthCfgOff,
                req.codebooks,
            )
            // native 返回码是判断「到底跑没跑」的第一手证据：0 = 正常结束，
            // -4 = 生成失败（错误已由 emitError 上报），-9 = 取消。
            DiagLog.log(
                if (rc == 0) 'I' else 'W', "engine",
                "nativeSynthesize rc=$rc depth=${req.depthMode} chunk=${req.chunkFirst}/${req.chunkMax}",
            )
            rc == 0
        } catch (t: Throwable) {
            Log.e(TAG, "synthesize failed", t)
            DiagLog.e("engine", tr("synthesize 抛异常"), t)
            onError?.invoke(t.message ?: tr("未知错误"))
            false
        } finally {
            busy.set(false)
        }
    }

    /**
     * 1.9.54 音色转换：把源音频里说的话用目标音色重说一遍。
     *
     * 阻塞执行；结果一次性写进 [ConvertRequest.outWav]，进度走 [onConvertProgress]。
     * 返回 true 表示成功；false 可能是失败，也可能是被 [cancel] 中断，由调用方区分。
     */
    fun convert(req: ConvertRequest): Boolean {
        val h = handle
        if (h == 0L) {
            onError?.invoke(tr("引擎未加载"))
            return false
        }
        if (!busy.compareAndSet(false, true)) {
            if (!awaitIdle(PREV_JOB_GRACE_MS) || !busy.compareAndSet(false, true)) {
                onError?.invoke(tr("上一段还在收尾，请稍候再试"))
                return false
            }
        }
        return try {
            tracePath?.let { runCatching { java.io.File(it).writeText("cv:start") } }
            nativeConvert(
                h,
                req.srcWav,
                req.refWav,
                req.refText,
                req.srcText,
                req.outWav,
                req.temperature,
                req.topK,
                req.keepAcoustic,
                req.seed,
            ) == 0
        } catch (t: Throwable) {
            Log.e(TAG, "convert failed", t)
            onError?.invoke(t.message ?: tr("未知错误"))
            false
        } finally {
            busy.set(false)
        }
    }

    fun cancel() {
        val h = handle
        if (h != 0L) nativeCancel(h)
    }

    /**
     * 这台机器上 libggml 探测到的 CPU 指令集特性（NEON / DOTPROD / SME2 / REPACK…）。
     * 纯查询，不依赖模型是否加载完成——判断「重编内核能不能吃到矩阵单元」就看它。
     */
    fun cpuFeatures(): String {
        val h = handle
        return if (h != 0L) nativeCpuFeatures(h) else ""
    }

    /**
     * 1.9.43 核心绑定：把合成线程钉在 cpufreq 最高的 n 个核上。
     * 返回实际绑定的核数；0 表示没绑成（读不到拓扑或权限不足），此时行为与未开启一致。
     */
    fun setCorePin(on: Boolean, n: Int): Int {
        val h = handle
        return if (h != 0L) nativeSetCorePin(h, on, n) else 0
    }

    /** 当前绑定的核号列表，例如 "7,6,5,4,3,2"。 */
    fun pinnedCpus(): String {
        val h = handle
        return if (h != 0L) nativePinnedCpus(h) else ""
    }

    /** 轮询等待空闲；只能在工作线程调用。 */
    fun awaitIdle(timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (!busy.get()) return true
            try {
                Thread.sleep(20)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                return !busy.get()
            }
        }
        return !busy.get()
    }

    /**
     * 按文本估算的口语长度（codec 帧，12.5 帧/秒）。native 的估算器（按 CJK 加权）
     * 比自己数汉字靠谱，用来定 maxFrames 上限与流式预缓冲长度。
     */
    fun estimateFrames(text: String): Int {
        val h = handle
        return if (h != 0L && text.isNotBlank()) nativeEstimateFrames(h, text) else 0
    }

    /** 设置页改线程数时即时生效，无需重新加载 2.4 GB 权重。 */
    fun setThreads(n: Int) {
        val h = handle
        if (h != 0L) nativeSetThreads(h, n)
    }

    /** 实际生效的后端（1.4 起恒为 "CPU"）。 */
    fun backendName(): String {
        val h = handle
        return if (h != 0L) nativeBackendName(h) else "none"
    }

    /**
     * 分阶段线程：prefill 用满线程，逐帧 decode 降到 2–4 线程，
     * 避免 ggml barrier 在小核上空转导致降频。
     */
    fun setPhaseThreads(enabled: Boolean, decodeThreads: Int = 3) {
        val h = handle
        if (h != 0L) nativeSetPhaseThreads(h, enabled, decodeThreads)
    }

    @Synchronized
    fun release() {
        val h = handle
        handle = 0L
        if (h != 0L) nativeDestroy(h)
    }

    // ------------------------------------------------------------ JNI → Kotlin
    @Keep
    private fun emitChunk(pcm: ShortArray, sampleRate: Int) {
        onChunk?.invoke(pcm)
    }

    @Keep
    private fun emitProgress(frame: Int, maxFrames: Int) {
        onProgress?.invoke(frame, maxFrames)
    }

    @Keep
    private fun emitConvertProgress(phase: Int, done: Int, total: Int) {
        onConvertProgress?.invoke(phase, done, total)
    }

    @Keep
    private fun emitDone(prefillMs: Long, frames: Int, audioMs: Long) {
        onDone?.invoke(EngineStats(prefillMs, frames, audioMs))
    }

    @Keep
    private fun emitError(msg: String) {
        DiagLog.e("engine", tr("native 错误：$msg", "native error: $msg"))
        onError?.invoke(msg)
    }

    @Keep
    private fun emitStats(
        promptMs: Double, prefillMs: Double, backboneMs: Double, depthMs: Double,
        vocoderMs: Double, firstAudioMs: Double, tailMs: Double,
        frames: Int, flushes: Int, steps: Int, stoppedEarly: Int,
        prefillTokens: Int, prefillReused: Int,
        depthFused: Int, depthSteps: Int,
    ) {
        onStats?.invoke(
            StageTimings(
                promptMs = promptMs, prefillMs = prefillMs, backboneMs = backboneMs,
                depthMs = depthMs, vocoderMs = vocoderMs, firstAudioMs = firstAudioMs,
                tailMs = tailMs, frames = frames, flushes = flushes, steps = steps,
                stoppedEarly = stoppedEarly != 0,
                prefillTokens = prefillTokens, prefillReused = prefillReused,
                depthFusedFrames = depthFused, depthStepFrames = depthSteps,
            ),
        )
    }

    private external fun nativeCreate(modelDir: String, threads: Int): Long
    private external fun nativeDestroy(h: Long)
    private external fun nativeSynthesize(
        h: Long,
        text: String,
        instruction: String,
        refWav: String,
        refText: String,
        codesPath: String,
        codesOut: String,
        designPrompt: String,
        voiceKind: String,
        seed: Int,
        temperature: Float,
        topP: Float,
        maxFrames: Int,
        chunkFirst: Int,
        cfgScale: Float,
        reusePrefixEmb: Boolean,
        cfgDecayFrames: Int,
        vocThreads: Int,
        depthMode: Int,
        chunkMax: Int,
        depthCfgOff: Boolean,
        codebooks: Int,
    ): Int

    private external fun nativeSetCorePin(h: Long, on: Boolean, n: Int): Int
    private external fun nativePinnedCpus(h: Long): String

    private external fun nativeConvert(
        h: Long,
        srcWav: String,
        refWav: String,
        refText: String,
        srcText: String,
        outWav: String,
        temperature: Float,
        topK: Int,
        keepAcoustic: Int,
        seed: Int,
    ): Int

    private external fun nativeCancel(h: Long)
    private external fun nativeCpuFeatures(h: Long): String
    private external fun nativeSetThreads(h: Long, n: Int)
    private external fun nativeBackendName(h: Long): String
    private external fun nativeSetPhaseThreads(h: Long, on: Boolean, decodeThreads: Int)

    /**
     * 1.9.87：声码器外置。cb 非空时，native 只跑到 transformer 输出，把
     * [frames, 1024] 的 latent 交给它，由它返回 PCM；cb 为 null 恢复纯 CPU。
     *
     * 回调发生在 native 的合成线程上（不是调用线程），实现方必须无副作用。
     */
    private external fun nativeSetVocoder(h: Long, cb: Any?, latentDim: Int)

    private external fun nativeVocoderCheck(h: Long, frames: Int): FloatArray?

    /**
     * 端到端校验：用固定 codes 跑一次真实链路（native 解码 → 回调 → GPU），
     * 同时跑一次纯 CPU 全链路，比两者。
     *
     * 与设置页那张「同一份人工 latent，CPU 后端 vs GPU 后端」的自检不同：
     * 那个只能证明 delegate 没引入误差，这个才能证明**交给 GPU 的数据本身是对的**。
     * 1.9.87 的 latent 布局错到输出全是噪声，前者照样报 0.01%，后者会报 100%+。
     *
     * 返回 [返回码, 相对误差, GPU饱和占比, CPU饱和占比, GPU毫秒]；码含义见 native。
     */
    fun vocoderCheck(frames: Int): FloatArray? {
        val h = handle
        return if (h == 0L) null else nativeVocoderCheck(h, frames)
    }
    private external fun nativeEstimateFrames(h: Long, text: String): Int
    private external fun nativeSetTrace(path: String?)

    /**
     * 1.9.51 崩溃定位：开启后，native 每进入一个阶段（prompt / prefill / 每帧的
     * depth / voc / backbone / 图 alloc 与 compute）就覆盖写这个文件。
     * 进程被 SIGSEGV 杀掉时，文件里剩下的内容就是崩溃点。
     *
     * 传 null 关闭；路径非空时每次合成前先写 `req:start`，避免读到上一段的残留。
     */
    @Volatile
    private var tracePath: String? = null

    fun setTraceFile(path: String?) {
        tracePath = path
        nativeSetTrace(path)
    }

    companion object {
        private const val TAG = "BreezeEngine"

        /** 声码器 transformer 输出的通道数，也是 GPU 图的输入宽度 */
        private const val LATENT_DIM = 1024

        /** 等上一段 native 收尾的宽限时间：一次真实单步 ~150-300 ms，4 s 足够。 */
        private const val PREV_JOB_GRACE_MS = 4_000L

        init {
            // 先加载 GGUF 运行时（linker 会连带加载其依赖的 libggml*.so），再加载 JNI 桥接层
            System.loadLibrary("breeze_gguf")
            System.loadLibrary("breeze")
        }
    }
}
