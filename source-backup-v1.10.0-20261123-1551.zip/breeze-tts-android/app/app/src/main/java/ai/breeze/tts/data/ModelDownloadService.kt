package ai.breeze.tts.data

import ai.breeze.tts.i18n.tr

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import ai.breeze.tts.BreezeApplication
import ai.breeze.tts.MainActivity
import ai.breeze.tts.R

/**
 * 前台服务跑模型包下载：锁屏/切后台不断，通知栏显示总进度。
 * 大文件（1.7 GB）必须走前台服务，否则 Doze 一睡就断。
 *
 * ## 1.9.92 修的两件事
 *
 * 1. **点了按钮立刻有反应**。以前要等镜像探测 + 首个 256 KB 到达才发第一个
 *    Downloading，网络慢时这段空白能有十几秒。[start] 现在同步写一个
 *    0 字节的状态，界面立刻变「连接中…」。
 * 2. **取消真的能取消**。以前的 `cancel()` 只 cancel 协程，而阻塞的
 *    `InputStream.read` 不响应协程取消，文件会继续写完；`.part` 也没人删。
 *    现在取消会同时置 [ModelRepository.abort] 标记并断开连接，由下载循环
 *    自己抛出来，顺手删掉半成品。
 */
class ModelDownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    /** 下载轮次。取消时 +1，用来丢弃上一轮迟到的进度回调。 */
    @Volatile
    private var gen = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        current = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 先把前台服务契约履行掉：即使这一条是「取消」，只要服务是被
        // startForegroundService 拉起来的，5 秒内不 startForeground 就会被
        // 系统判成 ForegroundServiceDidNotStartInTime 直接崩。
        startForegroundCompat(tr("正在准备下载…"))
        if (intent?.action == ACTION_CANCEL) {
            cancelWork()
            return START_NOT_STICKY
        }
        val variantId = intent?.getStringExtra(EXTRA_VARIANT) ?: run {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val repo = intent.getStringExtra(EXTRA_REPO)
        val variant = ModelCatalog.byId(variantId)
        val repoImpl = (application as BreezeApplication).models
        current = this

        job?.cancel()
        // 每轮一个代号：取消后上一轮的进度回调可能还在路上（它从 IO 线程
        // 直接写 StateFlow），过期的回调不能把界面又拉回「下载中」。
        val myGen = ++gen
        job = scope.launch {
            try {
                repoImpl.download(variant, repo) { st ->
                    if (myGen != gen) return@download
                    progress.value = st
                    if (st is ModelState.Downloading) {
                        getSystemService(NotificationManager::class.java)
                            .notify(NOTIF_ID, build(st.file, st.doneBytes, st.totalBytes))
                    }
                }
                if (myGen == gen) progress.value = repoImpl.state.value
            } catch (c: CancellationException) {
                // 取消不是错误：界面应该回到「未安装」，而不是弹一条「下载失败」
                if (myGen == gen) progress.value = null
                android.util.Log.i("ModelDownload", "cancelled ${variant.id}")
            } catch (t: Throwable) {
                if (myGen == gen) progress.value = ModelState.Failed(t.message ?: tr("下载失败"))
            } finally {
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    /**
     * 停掉当前下载并清场。可以由 [cancel]（同进程内直接调用）或
     * ACTION_CANCEL intent（服务已被系统重建）触发。
     */
    private fun cancelWork() {
        val impl = (application as BreezeApplication).models
        gen++
        impl.abort()
        job?.cancel()
        progress.value = null
        getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startForegroundCompat(text: String) {
        val n = build(text, 0, 0)
        ServiceCompat.startForeground(
            this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
        )
    }

    private fun build(text: String, done: Long, total: Long): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(tr("正在下载语音模型"))
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pi)
            .setOnlyAlertOnce(true)
        if (total > 0 && done > 0) {
            b.setProgress(1000, ((done * 1000) / total).toInt(), false)
            b.setSubText("${formatBytes(done)} / ${formatBytes(total)}")
        } else {
            b.setProgress(0, 0, true)
            b.setSubText(tr("正在连接…"))
        }
        return b.build()
    }

    private fun ensureChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, tr("模型下载"), NotificationManager.IMPORTANCE_LOW),
            )
        }
    }

    override fun onDestroy() {
        if (current === this) current = null
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "model_download"
        private const val NOTIF_ID = 42
        const val ACTION_CANCEL = "ai.breeze.tts.DOWNLOAD_CANCEL"
        const val EXTRA_VARIANT = "variant"
        const val EXTRA_REPO = "repo"

        /** 当前活着的服务实例；取消时直接调，避免依赖 intent 送达 */
        @Volatile
        private var current: ModelDownloadService? = null

        /** 下载状态的唯一真源，UI 直接 collect。null 表示当前没有下载任务。 */
        val progress = MutableStateFlow<ModelState?>(null)

        fun start(ctx: Context, variantId: String, repo: String?) {
            val v = ModelCatalog.byId(variantId)
            // 同步发一个 0 字节的状态：镜像探测和首包都可能很慢，界面不能空着
            progress.value = ModelState.Downloading(
                variantId, v.fileName, 0, v.approximateBytes, 0,
            )
            val i = Intent(ctx, ModelDownloadService::class.java).apply {
                putExtra(EXTRA_VARIANT, variantId)
                putExtra(EXTRA_REPO, repo)
            }
            runCatching { ctx.startForegroundService(i) }
                .onFailure { progress.value = ModelState.Failed(tr("无法启动下载服务：${it.message}", "Can't start the download service: ${it.message}")) }
        }

        fun cancel(ctx: Context) {
            // 同进程：直接停，最可靠
            current?.cancelWork()
            // 服务已被系统回收时走 intent；顺带把残留状态清掉
            runCatching {
                ctx.startService(Intent(ctx, ModelDownloadService::class.java).apply {
                    action = ACTION_CANCEL
                })
            }
            progress.value = null
        }
    }
}
