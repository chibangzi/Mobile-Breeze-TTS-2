package ai.breeze.tts.audio

import ai.breeze.tts.i18n.tr

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** 播放器对外暴露的状态。positionMs / durationMs 用于进度条与「反复播放」。 */
data class PlaybackState(
    val path: String = "",
    val label: String = "",
    val playing: Boolean = false,
    val positionMs: Int = 0,
    val durationMs: Int = 0,
    val error: String? = null,
) {
    val hasAudio: Boolean get() = path.isNotEmpty() && durationMs > 0
    val fraction: Float get() = if (durationMs <= 0) 0f else positionMs.toFloat() / durationMs
}

/**
 * 生成结果 / 历史条目的本地 WAV 播放器。
 *
 * 用 MODE_STREAM 分块写入，和生成阶段的 StreamingPlayer 走完全相同的 AudioTrack
 * 配置（24 kHz / MONO / PCM16）——这条路径已在真机验证能正常出声。
 *
 * 之前用 MODE_STATIC 一次性把整段 PCM 塞进静态缓冲，部分机型会因静态 buffer
 * 过大 / 帧未对齐 / OEM 音频策略而直接 STATE_UNINITIALIZED，导致「播放失败：
 * AudioTrack 初始化失败」，且结果与历史都播不了。改流式后不再有这些限制，
 * 同时保留播放 / 暂停 / 拖动 / 播完从头重播。
 */
class WavPlayer {

    private val handler = Handler(Looper.getMainLooper())
    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state.asStateFlow()

    private var pcm: ShortArray = ShortArray(0)
    private var sampleRate = 24_000
    private var track: AudioTrack? = null

    @Volatile private var writer: Thread? = null

    /** 每次重建播放都自增，旧写线程据此自行退出。 */
    @Volatile private var generation = 0

    /** 本次播放从 pcm 的第几帧开始（seek 后非 0）。 */
    private var startFrame = 0
    private var curPath = ""
    private var curLabel = ""

    private val ticker = object : Runnable {
        override fun run() {
            publish()
            if (_state.value.playing) handler.postDelayed(this, 100L)
        }
    }

    /** 播放某个文件；同一文件重复调用＝播放/暂停切换（播完后则从头重播）。 */
    fun play(file: File, label: String) {
        if (!file.isFile) {
            _state.value = PlaybackState(error = tr("音频文件不存在"))
            return
        }
        if (curPath == file.absolutePath && track != null) {
            toggle()
            return
        }
        val d = try {
            readPcm(file) ?: throw IllegalStateException(tr("不是有效的 16-bit PCM WAV"))
        } catch (t: Throwable) {
            fail(t)
            return
        }
        if (d.data.isEmpty()) {
            fail(IllegalStateException(tr("音频数据为空")))
            return
        }
        stopInternal()
        // 少数机型的音频策略不接受 24 kHz 直出（AudioTrack 会 STATE_UNINITIALIZED）。
        // 先探测一次，不行就上采样到 48 kHz——所有 Android 设备都支持的采样率。
        if (d.rate == 24_000 && !supportsRate(d.rate)) {
            pcm = upsample2(d.data)
            sampleRate = 48_000
        } else {
            pcm = d.data
            sampleRate = d.rate
        }
        curPath = file.absolutePath
        curLabel = label
        startFrom(0)
    }

    /**
     * 只装载、不出声：给「波形上拖动定位」用。
     *
     * 拖动时还没点播放，没必要建 AudioTrack（建了再 pause 会有一下爆音）。
     * 这里只把 PCM 和时长读进来，播放头停在 0，随后 seek() 只改位置。
     * 同一文件已装载时直接复用，不重复扫盘。
     */
    fun load(file: File, label: String) {
        if (!file.isFile) return
        if (curPath == file.absolutePath && pcm.isNotEmpty()) return
        val d = runCatching { readPcm(file) }.getOrNull() ?: return
        if (d.data.isEmpty()) return
        stopInternal()
        if (d.rate == 24_000 && !supportsRate(d.rate)) {
            pcm = upsample2(d.data)
            sampleRate = 48_000
        } else {
            pcm = d.data
            sampleRate = d.rate
        }
        curPath = file.absolutePath
        curLabel = label
        startFrame = 0
        _state.value = PlaybackState(
            path = curPath,
            label = curLabel,
            playing = false,
            positionMs = 0,
            durationMs = (pcm.size * 1000L / sampleRate).toInt(),
        )
    }

    /** 探测该采样率能否创建流式 AudioTrack，避免真正播放时才失败。 */
    private fun supportsRate(rate: Int): Boolean = runCatching {
        val min = AudioTrack.getMinBufferSize(
            rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
        )
        if (min <= 0) return false
        val t = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(rate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .build(),
            min * 2,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE,
        )
        val ok = t.state == AudioTrack.STATE_INITIALIZED
        t.release()
        ok
    }.getOrDefault(false)

    /** 24k → 48k：插一个两点均值，等价于简易低通，避免镜像混叠。 */
    private fun upsample2(input: ShortArray): ShortArray {
        val out = ShortArray(input.size * 2)
        for (i in input.indices) {
            val v = input[i]
            out[2 * i] = v
            out[2 * i + 1] = if (i + 1 < input.size)
                ((v.toInt() + input[i + 1].toInt()) / 2).toShort() else v
        }
        return out
    }

    /** 建一个流式 AudioTrack，从 frame 帧开始喂数据并播放。 */
    private fun startFrom(frame: Int) {
        val t = try {
            val min = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
            )
            val bufSize = maxOf(min * 2, sampleRate / 2) // 至少 0.5 s
            AudioTrack(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build(),
                bufSize,
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE,
            )
        } catch (t: Throwable) {
            fail(t)
            return
        }
        if (t.state != AudioTrack.STATE_INITIALIZED) {
            t.release()
            fail(IllegalStateException(tr("AudioTrack 初始化失败（采样率 ${sampleRate}Hz 可能不受支持）", "AudioTrack failed to initialise (${sampleRate} Hz may be unsupported)")))
            return
        }

        startFrame = frame.coerceIn(0, pcm.size)
        track = t
        val gen = ++generation
        val durationMs = (pcm.size * 1000L / sampleRate).toInt()
        _state.value = PlaybackState(
            path = curPath,
            label = curLabel,
            playing = true,
            positionMs = (startFrame * 1000L / sampleRate).toInt(),
            durationMs = durationMs,
        )
        t.play()

        // 非阻塞写：暂停时内部缓冲填满后 write 返回 0，sleep 让出 CPU；
        // generation 变化或 stop 时能立刻退出，不会卡在阻塞写里。
        writer = Thread({
            var off = startFrame
            val chunk = 2048
            while (gen == generation && off < pcm.size) {
                val n = minOf(chunk, pcm.size - off)
                val w = try {
                    t.write(pcm, off, n, AudioTrack.WRITE_NON_BLOCKING)
                } catch (t: Throwable) {
                    break
                }
                if (w > 0) off += w
                else if (gen == generation) {
                    try { Thread.sleep(8) } catch (_: InterruptedException) { break }
                }
            }
        }, "wav-player").apply { isDaemon = true; start() }

        startTicker()
    }

    fun toggle() {
        val t = track ?: run { playAgainOrStop(); return }
        try {
            val s = _state.value
            if (s.playing) {
                t.pause()
                stopTicker()
                _state.value = s.copy(playing = false)
            } else {
                if (s.positionMs >= s.durationMs - 20) {
                    // 已播完 → 从头重播
                    startFrom(0)
                } else {
                    t.play()
                    _state.value = s.copy(playing = true, error = null)
                    startTicker()
                }
            }
        } catch (t: Throwable) {
            fail(t)
        }
    }

    private fun playAgainOrStop() {
        if (curPath.isNotEmpty()) startFrom(startFrame)
    }

    /**
     * 波形 / 进度条拖动，fraction ∈ [0,1]。
     *
     * 播放中：重建 AudioTrack，从新位置继续播。
     * 暂停中：只挪播放头、释放旧 track，等用户点播放时从这一点开始 ——
     * 旧实现会先建 track 再立刻 pause，听感上是一下「咔」。
     */
    fun seek(fraction: Float) {
        if (pcm.isEmpty()) return
        val target = (pcm.size * fraction.coerceIn(0f, 1f)).toInt().coerceIn(0, pcm.size)
        val s = _state.value
        if (!s.playing) {
            stopInternal(keepMeta = true)
            startFrame = target
            _state.value = s.copy(
                positionMs = (target * 1000L / sampleRate).toInt(),
                error = null,
            )
            return
        }
        stopInternal(keepMeta = true)
        startFrom(target)
    }

    fun stop() {
        stopInternal(keepMeta = false)
        _state.value = PlaybackState()
    }

    private fun publish() {
        val t = track ?: return
        if (!_state.value.playing) return
        runCatching {
            val head = t.playbackHeadPosition
            val abs = (startFrame + head).coerceIn(0, pcm.size)
            val positionMs = (abs * 1000L / sampleRate).toInt()
            val w = writer
            val finished = (w == null || !w.isAlive) && abs >= pcm.size - 1
            if (finished) {
                // 播完：停在末尾，playing=false；再点播放会从 0 重播
                stopTicker()
                _state.value = _state.value.copy(playing = false, positionMs = _state.value.durationMs)
            } else {
                _state.value = _state.value.copy(positionMs = positionMs)
            }
        }
    }

    private fun startTicker() {
        stopTicker()
        handler.postDelayed(ticker, 100L)
    }

    private fun stopTicker() {
        handler.removeCallbacks(ticker)
    }

    private fun fail(t: Throwable) {
        Log.e(TAG, "play", t)
        stopInternal(keepMeta = false)
        _state.value = PlaybackState(error = tr("播放失败：${t.message ?: "无法读取该 WAV"}", "Playback failed: ${t.message ?: "can't read this WAV"}"))
    }

    /** 停写线程并释放 track；keepMeta=true 时保留 pcm/标签供 seek 复用。 */
    private fun stopInternal(keepMeta: Boolean = false) {
        generation++
        stopTicker()
        val t = track
        track = null
        writer?.let { runCatching { it.interrupt() } }
        writer = null
        runCatching {
            t?.pause()
            t?.flush()
            t?.release()
        }
        if (!keepMeta) {
            pcm = ShortArray(0)
            curPath = ""
            curLabel = ""
            startFrame = 0
        }
    }

    private class Pcm(val data: ShortArray, val rate: Int)

    /** 解析标准 PCM WAV，多声道降为单声道；采样率原样返回给 AudioTrack。 */
    private fun readPcm(file: File): Pcm? = runCatching {
        val b = file.readBytes()
        if (b.size < 44 ||
            String(b, 0, 4, Charsets.US_ASCII) != "RIFF" ||
            String(b, 8, 4, Charsets.US_ASCII) != "WAVE"
        ) return null
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        var rate = 0
        var channels = 0
        var bits = 0
        var data: ShortArray? = null
        var pos = 12
        while (pos + 8 <= b.size) {
            val id = String(b, pos, 4, Charsets.US_ASCII)
            val size = bb.getInt(pos + 4)
            val body = pos + 8
            if (size < 0 || body + size > b.size) break
            when (id) {
                "fmt " -> if (size >= 16) {
                    channels = bb.getShort(body + 2).toInt()
                    rate = bb.getInt(body + 4)
                    bits = bb.getShort(body + 14).toInt()
                }
                "data" -> {
                    val n = size / 2
                    val arr = ShortArray(n)
                    for (i in 0 until n) arr[i] = bb.getShort(body + i * 2)
                    data = arr
                }
            }
            pos = body + size + (size and 1)
            if (id == "data" && data != null) break
        }
        if (rate <= 0 || channels <= 0 || bits != 16 || data == null || data.isEmpty()) return null
        if (channels == 1) return Pcm(data, rate)
        val frames = data.size / channels
        val mono = ShortArray(frames)
        for (i in 0 until frames) {
            var v = 0
            for (c in 0 until channels) v += data[i * channels + c].toInt()
            mono[i] = (v / channels).toShort()
        }
        Pcm(mono, rate)
    }.getOrNull()

    companion object {
        private const val TAG = "WavPlayer"
    }
}
