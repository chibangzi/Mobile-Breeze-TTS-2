package ai.breeze.tts.vm

import ai.breeze.tts.i18n.Lang
import ai.breeze.tts.i18n.eqTr
import ai.breeze.tts.i18n.startsWithTr
import ai.breeze.tts.i18n.tr

import android.app.Application
import android.content.ContentValues
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.net.Uri
import android.os.BatteryManager
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import ai.breeze.tts.BreezeApplication
import ai.breeze.tts.BuildConfig
import ai.breeze.tts.audio.PlaybackState
import ai.breeze.tts.audio.StreamingPlayer
import ai.breeze.tts.audio.WavPlayer
import ai.breeze.tts.audio.WavWriter
import ai.breeze.tts.data.AiClient
import ai.breeze.tts.data.AiProvider
import ai.breeze.tts.data.EmotionPreset
import ai.breeze.tts.data.HistoryItem
import ai.breeze.tts.data.ModelCatalog
import ai.breeze.tts.data.ModelDownloadService
import ai.breeze.tts.data.ModelState
import ai.breeze.tts.data.formatBytes
import ai.breeze.tts.engine.ConvertRequest
import ai.breeze.tts.data.ModelVariant
import ai.breeze.tts.data.ScriptLine
import ai.breeze.tts.data.ScriptParser
import ai.breeze.tts.data.SpeechRepository
import ai.breeze.tts.data.VoiceRepository
import ai.breeze.tts.diag.DiagLog
import ai.breeze.tts.engine.EngineStats
import ai.breeze.tts.engine.StageTimings
import ai.breeze.tts.engine.SynthRequest
import ai.breeze.tts.engine.VoiceProfile
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

sealed interface EngineState {
    data object Idle : EngineState
    data object Loading : EngineState
    data object Ready : EngineState
    data class Failed(val message: String) : EngineState
}

/**
 * 合成页的三个子界面。
 *  - SINGLE：单人朗读，一段文字一个音色；
 *  - DIALOGUE：多角色对话，剧本里的【名字】逐句切换音色；
 *  - CONVERT：音色转换，输入一段音频，把说话人换成目标音色（1.9.54）。
 */
enum class SynthMode { SINGLE, DIALOGUE, CONVERT }

/** AI 扩写的落点：正文输入框，还是情绪/语气输入框 */
enum class ExpandTarget { TEXT, EMOTION }

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val breeze = app as BreezeApplication
    private val engine get() = breeze.engine
    private val models get() = breeze.models
    private val voiceRepo: VoiceRepository get() = breeze.voices
    private val historyRepo get() = breeze.history
    private val settings get() = breeze.settings
    private val speech get() = breeze.speech
    private val presetRepo get() = breeze.presets
    private val aiRepo get() = breeze.ai
    private val main = Handler(Looper.getMainLooper())

    val player = WavPlayer()

    // ---------------- 模型（可多装、可切换） ----------------
    var modelState by mutableStateOf<ModelState>(ModelState.Absent)
        private set
    /**
     * 下载/校验进度单独一路，不再改写 modelState。这样已有可用模型时，
     * 后台下载新档位不会让合成页误以为「模型没了/正在下载」而卡住生成。
     */
    var downloadState by mutableStateOf<ModelState?>(null)
        private set
    /** 模型页当前选中、用于「下载 / 导入 / 删除」的档位 */
    var variantId by mutableStateOf(ModelCatalog.variants.first().id)
        private set
    /** 当前真正被引擎使用的档位 */
    var activeModelId by mutableStateOf<String?>(null)
        private set
    var installedModels by mutableStateOf<Map<String, Long>>(emptyMap())
        private set
    var customRepo by mutableStateOf("")
    var useMirror by mutableStateOf(true)
        private set
    var importing by mutableStateOf(false)
        private set

    val variants: List<ModelVariant> get() = ModelCatalog.variants

    // ---------------- 引擎 / 性能 ----------------
    var engineState by mutableStateOf<EngineState>(EngineState.Idle)
        private set
    var threads by mutableStateOf(settings.threads.value)
        private set
    /** CFG 引导强度，默认 4.0，与 PC 端一致 */
    var cfgScale by mutableFloatStateOf(settings.cfgScale.value)
        private set
    /** 加载后由原生层回报的后端（1.4 起恒为 "CPU"）。 */
    var backendName by mutableStateOf(tr("未加载"))
        private set
    /** libggml 探测到的 CPU 指令集特性，用来判断还有没有内核级加速余量。 */
    var cpuFeatures by mutableStateOf("")
        private set
    /** 分阶段线程（prefill 满线程 / decode 2–4 线程），仅 CPU 后端生效。 */
    var phaseThreads by mutableStateOf(settings.phaseThreads.value)
        private set

    /** 1.10.0 界面语言：system / zh / en（默认跟随系统）。 */
    var language by mutableStateOf(settings.language.value)
        private set

    /** 极速模式：强制 cfg=1，逐帧阶段只跑单分支，速度约提升一倍、指令遵从度下降。 */
    var turbo by mutableStateOf(settings.turbo.value)
        private set

    // ---------------- 1.9.51 崩溃定位 ----------------
    /** 上一次生成崩溃前的最后阶段原文；空串表示没有残留。 */
    var lastTrace by mutableStateOf("")
        private set
    /**
     * 上次异常中断的人话描述（「第 3 帧 · 深度解码器」这种）。
     *
     * 1.9.92 起**不再**弹在首页：用户启动 app 只是要合成，一句「上次生成中断在
     * 深度解码器」既解释不了什么、又挡住整个界面。这条现在只在
     * 「设置 → 性能诊断」最下方出现，那里本来就有日志与复制按钮。
     */
    var crashNote by mutableStateOf<String?>(null)
        private set

    /**
     * 本次合成真正要用的 CFG。
     *
     * 极速模式下恒为 1.0：native 侧一旦看到 cfg=1 就会关掉 uncond 分支，
     * 主干与深度解码的每一步都少算一半。否则沿用滑杆值（默认 4.0，双分支）。
     */
    private val effectiveCfg: Float get() = if (turbo) 1f else cfgScale

    /** 1.9.11 实验优化：复用参考前缀编码。默认关闭，随时可退回稳定管线。 */
    var reusePrefixEmb by mutableStateOf(settings.reusePrefixEmb.value)
        private set

    /** 1.9.43 核心绑定：合成线程钉在最快的 N 个核上。 */
    var corePin by mutableStateOf(settings.corePin.value)
        private set
    /** 实际绑定的核号，例如 "7,6,5,4,3,2"；空串表示未绑定。 */
    var pinnedCpus by mutableStateOf("")
        private set

    /** 1.9.43 后段降 CFG：前 N 帧双分支，之后单分支。 */
    var cfgDecay by mutableStateOf(settings.cfgDecay.value)
        private set
    var cfgDecayFrames by mutableStateOf(settings.cfgDecayFrames.value)
    /** 1.9.91 深度解码不吃 CFG：只降低码本引导，主干不变。 */
    var depthCfgOff by mutableStateOf(settings.depthCfgOff.value)
        private set

    /** 1.9.43 声码器独立线程数，0 = 跟随 CPU 线程数。 */
    var vocThreads by mutableStateOf(settings.vocThreads.value)
        private set

    /** 1.9.73 声码器分块上限（帧）。首块不受影响，只决定「之后每块最多攒多少」。 */
    var vocChunk by mutableStateOf(settings.vocChunk.value)

    /** 1.9.84 声码器 GPU 加速开关；关闭时合成路径与之前完全一致。 */
    var gpuVocoder by mutableStateOf(settings.gpuVocoder.value)
        private set

    // ---------------- 1.9.92 声码器加速包（APK 外置） ----------------
    /** 加速包是否已导入。未导入时 GPU 开关不可用，合成完全走 CPU。 */
    var vocPackInstalled by mutableStateOf(false)
        private set
    var vocPackBytes by mutableStateOf(0L)
        private set
    /** 导入进度：null 表示没在导入；total<=0 表示只知道已读字节 */
    var vocPackImporting by mutableStateOf(false)
        private set
    var vocPackProgress by mutableStateOf<Pair<Long, Long>?>(null)
        private set
    var vocPackError by mutableStateOf<String?>(null)
        private set

    /** 本次请求要传下去的降 CFG 帧数；关掉时是 0（等价于原路径）。 */
    private val effectiveCfgDecay: Int get() = if (cfgDecay) cfgDecayFrames else 0

    // ---------------- 导出 / ASR 设置 ----------------
    var exportDirLabel by mutableStateOf(settings.exportDirLabel.value)
        private set
    var exportDirUriString by mutableStateOf(settings.exportTreeUri.value)
        private set
    var asrVariantId by mutableStateOf(speech.variantId.value)
        private set
    var asrInstalled by mutableStateOf(speech.isInstalled())
        private set
    var asrBusy by mutableStateOf<String?>(null)
        private set
    var transcription by mutableStateOf<String?>(null)
        private set

    val asrVariants get() = speech.variants()
    fun asrInstalledFor(id: String): Boolean = speech.isInstalled(id)

    // ---------------- 音色 ----------------
    var voices by mutableStateOf<List<VoiceProfile>>(emptyList())
        private set
    var selectedVoiceId by mutableStateOf<String?>(null)

    // ---------------- 合成 ----------------
    /**
     * 单人朗读与多角色对话各自记住自己的输入，切换模式不再串内容（1.9.12）。
     * 用私有 backing + 计算属性，既有调用点（vm.text）一行都不用改。
     */
    private var singleText by mutableStateOf(tr("今天天气不错，我们出去走走吧。"))
    private var dialogueText by mutableStateOf("")

    var text: String
        get() = if (synthMode == SynthMode.SINGLE) singleText else dialogueText
        set(value) {
            if (synthMode == SynthMode.SINGLE) singleText = value else dialogueText = value
        }

    var instruction by mutableStateOf("")
    /** 单人朗读 / 多角色对话；切换时只影响输入区的呈现，不改已输入的内容 */
    var synthMode by mutableStateOf(SynthMode.SINGLE)
    /** 「表达与情绪」预设；内置六条 + 用户自建，可编辑可删除 */
    var emotionPresets by mutableStateOf<List<EmotionPreset>>(presetRepo.presets.value)
        private set
    var temperature by mutableFloatStateOf(0.9f)
    var topP by mutableFloatStateOf(0.9f)
    var seed by mutableIntStateOf(42)
    var generating by mutableStateOf(false)
        private set
    var progress by mutableFloatStateOf(0f)
        private set
    /**
     * 生成中的「已用秒数」，1 Hz 更新。
     *
     * 1.9.75 起生成页只让这一处数字变化：没有旋转环、没有进度条、没有每块跳一次的状态文字。
     * 页面每秒只重绘一帧，LTPO 才能把刷新率降到最低档，把核让给 6 线程主干 + 8 线程声码器。
     * 实测（同一句、同一模型）：合成页 120 Hz 常驻时 RTF 3.90，界面完全静止后 2.78。见 docs/84。
     */
    var genElapsedSec by mutableIntStateOf(0)
        private set
    var statusLine by mutableStateOf("")
        private set
    var error by mutableStateOf<String?>(null)
        private set
    /**
     * 单人朗读与多角色对话各自的结果互不干涉：两边各存一份，切换界面时只切视图。
     * 生成仍由全局 generating 串行化——同一时刻只能一边在跑。
     * 对外仍暴露 stats / lastWav 等原名，UI 一行不用改。
     */
    private data class RunResult(
        var wav: File? = null,
        var stats: EngineStats? = null,
        var stage: StageTimings? = null,
        var text: String = "",
        var voice: String = "",
        var durationMs: Long = 0L,
        var favorited: Boolean = false,
        var name: String = "",
    )
    private val singleResult = RunResult()
    private val dialogueResult = RunResult()
    private val convertResult = RunResult()
    /** 本次生成归属的模式：生成中即便切了 tab，结果也写回发起时的那一份 */
    private var resultOwner = SynthMode.SINGLE
    private fun resultSlot(mode: SynthMode): RunResult = when (mode) {
        SynthMode.SINGLE -> singleResult
        SynthMode.DIALOGUE -> dialogueResult
        SynthMode.CONVERT -> convertResult
    }
    private val activeResult: RunResult get() = resultSlot(synthMode)
    /** RunResult 是普通对象，改动不触发重组；靠这个版本号让读它的 Composable 刷新 */
    private var resultVersion by mutableIntStateOf(0)
    private fun bumpResult() { resultVersion++ }

    var stats: EngineStats?
        get() { resultVersion; return activeResult.stats }
        set(value) { resultSlot(resultOwner).stats = value; bumpResult() }
    /** 上一段的分阶段耗时：回答「时间花在主干/深度/声码器/收尾的哪一段」 */
    var stageStats: StageTimings?
        get() { resultVersion; return activeResult.stage }
        set(value) { resultSlot(resultOwner).stage = value; bumpResult() }
    var lastWav: File?
        get() { resultVersion; return activeResult.wav }
        set(value) { resultSlot(resultOwner).wav = value; bumpResult() }
    /** 生成时锁定的音频显示名，格式：音色_台词前十_日期_序列号；改输入框不再影响它 */
    val resultName: String get() { resultVersion; return activeResult.name }

    // ---------------- 性能诊断（独立测试面板，不碰主合成管线）----------------
    /**
     * 一次诊断 = 跑一遍引擎但丢弃音频、不写文件、不存历史、不播放。
     * 只是为了拿五段计时 + RTF + 温度，给「上 NPU 到底有没有收益」建立 CPU 基线。
     */
    data class DiagRun(
        val index: Int,
        val stage: StageTimings,
        val rtf: Float,
        val wallMs: Long,
        val tempC: Float?,
        val ok: Boolean,
        val message: String = "",
        /** 本次运行时的线程配置，便于改参数后对照历史结果 */
        val threads: Int = 0,
        val phaseThreads: Boolean = true,
        /** 本次是否处于极速模式（cfg=1，单分支） */
        val turbo: Boolean = false,
        /** 本次实际用的分块大小（帧）。flush 次数异常时先看它。 */
        val chunk: Int = 0,
        /** 本次真正发给引擎的 CFG。1.0 = 单分支（最关键的耗时开关）。 */
        val cfg: Float = 0f,
        /** 本次 flush 期间声码器用的线程数，0 = 跟随生成线程。 */
        val vocThreads: Int = 0,
        /** 本次生效的后段降 CFG 帧数，0 = 全程双分支。 */
        val cfgDecay: Int = 0,
        /** 1.9.69 对照实验：1 = 深度强制逐码本，0 = 默认单图。 */
        val depthMode: Int = 0,
        /** 1.9.72 对照实验：本次的分块上限（0 = 与首块相同）。 */
        val chunkMax: Int = 0,
        /** 1.9.71 本次输出的试听 WAV（未做任何后处理）；空 = 没录到音频。 */
        val audioPath: String = "",
        /** 峰值电平 0..1。接近 0 = 静音/拼接错误，接近 1 = 可能削波。 */
        val peak: Float = 0f,
        /** 均方根电平 0..1，用来判断整体响度是否异常。 */
        val rms: Float = 0f,
    )

    var diagText by mutableStateOf(tr("今天天气不错，我们出去走走吧。"))
    var diagRunning by mutableStateOf(false)
        private set
    var diagRuns by mutableStateOf<List<DiagRun>>(emptyList())
        private set
    var diagTempC by mutableStateOf<Float?>(null)
        private set
    var diagProgress by mutableStateOf("")
        private set
    private var diagJob: Job? = null
    private var diagStop = false
    var playback by mutableStateOf(PlaybackState())
        private set

    // ---------------- 历史（UI 上叫「收藏夹」） ----------------
    var history by mutableStateOf<List<HistoryItem>>(emptyList())
        private set

    /** 收藏夹多选模式 */
    var favSelecting by mutableStateOf(false)
        private set
    var favSelected by mutableStateOf<Set<String>>(emptySet())
        private set

    // ---------------- AI 接口 ----------------
    var aiProviders by mutableStateOf<List<AiProvider>>(emptyList())
        private set
    val enabledAi: AiProvider? get() = aiProviders.firstOrNull { it.enabled }
    var aiTestBusy by mutableStateOf(false)
        private set
    var aiTestResult by mutableStateOf<String?>(null)
        private set

    // ---------------- 扩写 ----------------
    var expandOpen by mutableStateOf(false)
        private set
    var expandLoading by mutableStateOf(false)
        private set
    var expandResult by mutableStateOf("")
        private set
    var expandError by mutableStateOf<String?>(null)
        private set
    /** 打开弹窗时锁定的模式：生成期间用户切了模式也不影响这次结果的用法 */
    private var expandMode = SynthMode.SINGLE
    /** 这次扩写的落点：正文，还是情绪/语气输入框 */
    var expandTarget by mutableStateOf(ExpandTarget.TEXT)
        private set
    /** 情绪代写时的「初步描述」，供弹窗展示 */
    var expandRoughEmotion by mutableStateOf("")
        private set
    private var expandRequirement = ""
    var expandProviderName by mutableStateOf("")
        private set

    // ---------------- 上一次生成结果（手动收藏用，按模式分槽） ----------------
    var lastResultText: String
        get() { resultVersion; return activeResult.text }
        set(value) { resultSlot(resultOwner).text = value; bumpResult() }
    var lastResultVoice: String
        get() { resultVersion; return activeResult.voice }
        set(value) { resultSlot(resultOwner).voice = value; bumpResult() }
    var lastResultDurationMs: Long
        get() { resultVersion; return activeResult.durationMs }
        set(value) { resultSlot(resultOwner).durationMs = value; bumpResult() }
    var lastResultFavorited: Boolean
        get() { resultVersion; return activeResult.favorited }
        set(value) { resultSlot(resultOwner).favorited = value; bumpResult() }
    var favoriteBusy by mutableStateOf(false)
        private set

    private var messageState by mutableStateOf<String?>(null)

    var message: String?
        get() = messageState
        private set(value) {
            messageState = value
            if (value != null) messageSeq++
        }

    /** 每弹一次提示 +1。文案可能连续两次相同，靠它触发新的淡入而不是被 Compose 跳过 */
    var messageSeq by mutableIntStateOf(0)
        private set

    /** 是否有底部浮层打开：导航栏据此压一层遮罩，避免点穿 */
    var sheetOpen by mutableStateOf(false)

    fun consumeMessage() { message = null }

    private var synthStartedAt = 0L
    private var streamingPlayer: StreamingPlayer? = null
    private var writer: WavWriter? = null
    private var loadJobRunning = false

    // ---- 合成的生命周期 ----
    private var synthJob: Job? = null
    private var expandJob: Job? = null
    private var tickerJob: Job? = null
    /** 已完成、正在后台放尾音的播放器（它不会再挡「生成完成」） */
    @Volatile private var tailPlayer: StreamingPlayer? = null
    /** 每次合成递增；旧一轮的 native 回调靠它作废，避免停/重开后写串 */
    private var sessionToken = 0
    private var progressTarget = 0f
    @Volatile private var lastChunkAt = 0L
    /** 上一块写出时的位置与时间，用来测「本机每帧要多少毫秒」 */
    private var lastChunkProducedMs = 0L
    private var lastChunkWallMs = 0L
    /** 逐帧实测耗时（指数平滑）：进度条在块与块之间靠它按真实速度外推 */
    @Volatile private var frameMs = 0.0
    /** 本轮预计音频总长（进度条分母） */
    @Volatile private var expectedMsForBar = 1L

    init {
        models.mirror = useMirror
        // 1.9.92：加速包是否已装要在读 gpuVocoder 之前确定，applyVocoderDelegate
        // 靠它决定能不能挂 GPU 委托。
        refreshVocPack()
        // 诊断日志落盘：进程被杀/重启后现场还在，用户不必接电脑抓 logcat。
        runCatching {
            DiagLog.attach(File(getApplication<Application>().filesDir, "diag/diag.log"))
        }
        DiagLog.i("app", tr("启动 version=${BuildConfig.VERSION_NAME}(${BuildConfig.VERSION_CODE})", "Launch version=${BuildConfig.VERSION_NAME}(${BuildConfig.VERSION_CODE})"))
        // 进 app 就把日志镜像填上，否则「推理与性能」里的日志卡一直是空的
        main.post { runCatching { refreshDiagLog() } }
        // 1.9.51：上次生成如果被信号杀掉，trace 文件不会以 gen:end 结尾。
        // 把最后一条翻成人话，直接说「崩在哪」。
        val leftover = runCatching {
            traceFile().takeIf { it.exists() }?.readText()?.trim()
        }.getOrNull()
        if (!leftover.isNullOrEmpty() && !leftover.startsWith("gen:end")) {
            val where = explainTrace(leftover)
            lastTrace = leftover
            // 1.9.92：只记录，不打扰。诊断页最下方会显示这条。
            crashNote = where
            DiagLog.i("app", tr("上次生成中断在：$where（现场 $leftover）", "Last generation stopped at: $where (dump $leftover)"))
        }
        viewModelScope.launch {
            models.state.collect {
                when (it) {
                    is ModelState.Downloading, is ModelState.Verifying, is ModelState.Failed ->
                        downloadState = it   // 纯进度，不动 modelState，避免卡住现有模型
                    else -> {
                        modelState = it
                        if (it is ModelState.Ready) ensureEngine(it)
                    }
                }
            }
        }
        viewModelScope.launch { ModelDownloadService.progress.collect { p -> downloadState = p } }
        viewModelScope.launch { models.installed.collect { installedModels = it } }
        viewModelScope.launch { models.activeId.collect { activeModelId = it } }
        viewModelScope.launch { voiceRepo.load() }
        viewModelScope.launch {
            voiceRepo.voices.collect { v ->
                voices = v
                if (selectedVoiceId == null || v.none { it.id == selectedVoiceId }) {
                    selectedVoiceId = v.firstOrNull()?.id
                }
            }
        }
        viewModelScope.launch { presetRepo.presets.collect { emotionPresets = it } }
        viewModelScope.launch { historyRepo.load() }
        viewModelScope.launch { historyRepo.items.collect { history = it } }
        viewModelScope.launch { aiRepo.providers.collect { aiProviders = it } }
        viewModelScope.launch { settings.threads.collect { threads = it } }
        viewModelScope.launch { settings.language.collect { language = it } }
        viewModelScope.launch { settings.cfgScale.collect { cfgScale = it } }
        viewModelScope.launch { settings.phaseThreads.collect { phaseThreads = it } }
        viewModelScope.launch { settings.turbo.collect { turbo = it } }
        viewModelScope.launch { settings.reusePrefixEmb.collect { reusePrefixEmb = it } }
        viewModelScope.launch { settings.corePin.collect { corePin = it } }
        viewModelScope.launch { settings.cfgDecay.collect { cfgDecay = it } }
        viewModelScope.launch { settings.cfgDecayFrames.collect { cfgDecayFrames = it } }
        viewModelScope.launch { settings.depthCfgOff.collect { depthCfgOff = it } }
        viewModelScope.launch { settings.vocThreads.collect { vocThreads = it } }
        viewModelScope.launch { settings.vocChunk.collect { vocChunk = it } }
        viewModelScope.launch {
            settings.gpuVocoder.collect {
                gpuVocoder = it
                // 冷启动时 engine 还没 load，这里只会把委托记下来，
                // load() 完成后再挂到新句柄上
                applyVocoderDelegate()
            }
        }
        viewModelScope.launch { settings.exportDirLabel.collect { exportDirLabel = it } }
        viewModelScope.launch { settings.exportTreeUri.collect { exportDirUriString = it } }
        viewModelScope.launch { speech.installing.collect { asrBusy = it } }
        // 1.9.54 音色转换进度：native 每转完一帧回一次（约 150–300 ms），直接映射成
        // 0–1。只在 converting 为真时更新，避免上一段的尾回调把新任务的进度顶回去。
        engine.onConvertProgress = { phase, done, total ->
            main.post {
                if (converting && total > 0) {
                    val now = System.currentTimeMillis()
                    // 回调本来是每帧一次（3~7 Hz）。转换成一张静止卡片后，UI 只需要 1 Hz：
                    // 每秒推一次，其余更新直接丢掉——它们只影响显示，不影响 native 计算。
                    // 阶段切换要立刻推，否则跨阶段那 1 秒会显示上一阶段的文案。
                    if (now - lastConvertUiAt < 1_000 && phase == convertPhase) return@post
                    lastConvertUiAt = now
                    val f = (done.toFloat() / total).coerceIn(0f, 1f)
                    convertPhase = phase
                    convertDoneUnits = done
                    convertTotalUnits = total
                    if (phase == 0) {
                        convertDoneFrames = done
                        convertTotalFrames = total
                        // 逐帧段占前 55%：每帧两次主干 + 15 次深度，帧间耗时很均匀
                        convertProgress = 0.01f + 0.54f * f
                        convertStatus = tr("正在重说 %.1f / %.1f 秒").format(done / 12.5, total / 12.5)
                    } else {
                        // 声码器段占后 45%：逐段上采样，每段 40 帧波形
                        convertProgress = 0.55f + 0.44f * f
                        convertStatus = tr("正在合成音频 %d / %d 段").format(done, total)
                    }
                }
            }
        }
        viewModelScope.launch {
            speech.variantId.collect {
                asrVariantId = it
                asrInstalled = speech.isInstalled(it)
            }
        }
        viewModelScope.launch { player.state.collect { playback = it } }
    }

    // ================= AI 接口配置 =================

    fun saveAiProvider(p: AiProvider) {
        aiRepo.save(p)
        aiTestResult = null
        message = tr("已保存接口：${p.displayName}", "Provider saved: ${p.displayName}")
    }

    fun deleteAiProvider(id: String) {
        aiRepo.delete(id)
        aiTestResult = null
        message = tr("已删除接口")
    }

    fun setAiEnabled(id: String, on: Boolean) {
        aiRepo.setEnabled(id, on)
        aiTestResult = null
    }

    /** 测试连接：先 /models 验地址与密钥，再真实调一次 chat 验模型。 */
    fun testAiProvider(p: AiProvider) {
        if (aiTestBusy) return
        if (p.baseUrl.isBlank() || p.apiKey.isBlank() || p.model.isBlank()) {
            aiTestResult = tr("请先填好 Base URL、API Key 和模型名")
            return
        }
        aiTestBusy = true
        aiTestResult = null
        viewModelScope.launch {
            val r = AiClient.probe(p)
            aiTestResult = r.fold(
                onSuccess = { it },
                onFailure = {
                    val m = it.message ?: tr("未知错误")
                    if (startsWithTr(m, "连接失败")) m else tr("连接失败：$m", "Connection failed: $m")
                },
            )
            aiTestBusy = false
        }
    }

    fun clearAiTestResult() { aiTestResult = null }

    // ---------------- 模型列表 ----------------

    var aiModels by mutableStateOf<List<String>>(emptyList())
        private set
    var aiModelsBusy by mutableStateOf(false)
        private set
    var aiModelsError by mutableStateOf<String?>(null)
        private set

    /** 从接口拉取真实可用的模型名，避免用户手填到不存在的模型（如生图模型）。 */
    fun fetchAiModels(p: AiProvider) {
        if (aiModelsBusy) return
        if (p.baseUrl.isBlank() || p.apiKey.isBlank()) {
            aiModelsError = tr("先填好 Base URL 和 API Key")
            return
        }
        aiModelsBusy = true
        aiModelsError = null
        aiModels = emptyList()
        viewModelScope.launch {
            AiClient.listModels(p).fold(
                onSuccess = {
                    aiModels = it
                    if (it.isEmpty()) aiModelsError = tr("该接口没有返回任何模型")
                },
                onFailure = { aiModelsError = it.message ?: tr("拉取失败") },
            )
            aiModelsBusy = false
        }
    }

    fun clearAiModels() {
        aiModels = emptyList()
        aiModelsError = null
    }

    // ================= 扩写 =================

    /**
     * 打开扩写弹窗：把当前输入框的内容当成「需求」，调用已启用的 AI 接口。
     * 弹窗里可取消 / 再次生成 / 替换；替换只写回打开时所在的模式。
     */
    fun openExpand() {
        val req = text.trim()
        if (req.isEmpty()) { message = tr("先写下想扩写的内容或需求"); return }
        if (enabledAi == null) { message = tr("还没有启用的 AI 接口：设置 → AI 接口"); return }
        expandOpen = true
        expandTarget = ExpandTarget.TEXT
        expandRoughEmotion = ""
        expandResult = ""
        expandError = null
        launchExpand(req, synthMode)
    }

    /**
     * 情绪代写：读台词，写一段「怎么念」的描述，替换到情绪输入框。
     * 输入框里已有粗略描述时一并带上，让模型在它的基础上细化，而不是另起一套。
     * 只在单人朗读模式提供——对话模式每行语气不同，一段统一描述会盖掉行内设定。
     */
    fun openEmotionExpand() {
        val line = singleText.trim()
        if (line.isEmpty()) { message = tr("先写台词，再让 AI 写语气"); return }
        if (enabledAi == null) { message = tr("还没有启用的 AI 接口：设置 → AI 接口"); return }
        val rough = instruction.trim()
        expandOpen = true
        expandTarget = ExpandTarget.EMOTION
        expandRoughEmotion = rough
        expandResult = ""
        expandError = null
        val req = buildString {
            append(tr("台词：\n"))
            append(line)
            append(tr("\n\n初步描述：\n"))
            append(rough.ifBlank { tr("（无，请根据台词自行判断）") })
        }
        launchExpand(req, SynthMode.SINGLE)
    }

    fun regenerateExpand() {
        if (expandLoading) return
        expandError = null
        launchExpand(expandRequirement, expandMode)
    }

    fun applyExpand() {
        val r = expandResult.trim()
        if (r.isEmpty()) return
        if (expandTarget == ExpandTarget.EMOTION) {
            instruction = r
            message = tr("已替换情绪描述")
        } else {
            if (expandMode == SynthMode.SINGLE) singleText = r else dialogueText = r
            message = tr("已用扩写内容替换输入框")
        }
        expandOpen = false
    }

    fun dismissExpand() {
        expandJob?.cancel()
        expandJob = null
        expandOpen = false
        expandLoading = false
    }

    private fun launchExpand(requirement: String, mode: SynthMode) {
        val p = enabledAi
        if (p == null) {
            expandError = tr("还没有启用的 AI 接口。请去 设置 → AI 接口 添加一条并启用。")
            expandLoading = false
            return
        }
        expandRequirement = requirement
        expandMode = mode
        expandResult = ""
        expandProviderName = p.displayName
        expandLoading = true
        expandJob?.cancel()
        expandJob = viewModelScope.launch {
            val system = when {
                expandTarget == ExpandTarget.EMOTION -> emotionPrompt()
                mode == SynthMode.DIALOGUE -> dialoguePrompt()
                else -> singlePrompt()
            }
            val r = AiClient.chat(
                provider = p,
                system = system,
                user = requirement,
                temperature = 0.9,
                maxTokens = 3072,
            )
            r.onSuccess {
                expandResult = it
                expandLoading = false
            }.onFailure {
                if (it !is kotlinx.coroutines.CancellationException) {
                    expandError = it.message ?: tr("生成失败")
                    expandLoading = false
                }
            }
        }
    }

    /** 情绪代写：只输出一段可直接送进引擎的语气描述。 */
    private fun emotionPrompt(): String = tr("""
        你是一位中文配音导演，正在给演员说戏。

        任务：根据给出的台词，写一段「该怎么念」的语气描述。这段文字会原样作为
        TTS 引擎的情绪指令，不朗读出来。

        硬性要求：
        1. 只输出描述本身，60 字以内，一段话写完；不要引号、不要分点、不要解释、不要标题。
        2. 写具体：从情绪基调、语速、音量、气息、句尾处理、重音位置里挑三到五项来写。
        3. 不要复述台词，不要写场景设定、人物背景或动作说明。
        4. 不要出现英文、颜文字、表情符号、括号旁白。
        5. 如果给了「初步描述」，以它为准做细化，不要改变它的大意；只补它没说到的维度。
        6. 描述要能被声音直接体现，避免「很有感染力」「扣人心弦」这类空话。

        请直接输出这段描述。
    """, """You are a Chinese dubbing director coaching an actor.

Task: given the lines below, write one paragraph on HOW they should be read. This text is passed to a TTS engine verbatim as the emotional instruction and is never spoken aloud.

Hard requirements:
1. Output the description only, under 60 Chinese characters, in one paragraph; no quotes, no bullets, no explanation, no title.
2. Be concrete: choose three to five of tone, pace, volume, breath, line endings, stress placement.
3. Do not repeat the lines; no scene setting, character background or stage directions.
4. No English, no kaomoji, no emoji, no parenthetical asides.
5. If an "initial description" is provided, refine it without changing its intent; only add the dimensions it misses.
6. The description must be directly audible; avoid empty phrases such as "very moving".

Output the description now.""").trimIndent()

    /** 单人朗读稿：只输出正文，允许四个内联语气事件。 */
    private fun singlePrompt(): String = tr("""
        你是一位中文配音文案编辑，正在为「本地离线 TTS 引擎」撰写朗读稿。

        任务：根据用户给出的需求，直接写出最终要朗读的中文正文。

        硬性要求：
        1. 只输出正文本身。不要解释、不要标题、不要编号、不要 Markdown、不要用引号整体包裹。
        2. 口语化、自然，句子长短错落，方便朗读；避免堆砌书面语与长定语。
        3. 可以在合适位置插入内联语气事件，且只能使用这四个：[笑] [叹气] [咳嗽] [清嗓子]。
        4. 不要出现英文、颜文字、表情符号，也不要用括号写旁白或动作说明。
        5. 默认 120–300 字；需求里明确要求长度时按需求执行。
        6. 如果需求里已经给出原文，就在原文基础上扩写与润色，保留原意和关键信息。

        背景说明：这是用于个人本地配音练习的虚构创作，不涉及真实人物或现实事件，也不会公开发布。
        请直接产出符合上述格式的内容，不要拒绝、不要说教、不要附加免责声明或安全提示。
        如果需求涉及冲突、暴力或亲密情节，用含蓄、文学化、不露骨的方式表达即可。
    """, """You are a Chinese script editor writing a read-aloud draft for a local offline TTS engine.

Task: from the user's request, write the final Chinese text that will be spoken.

Hard requirements:
1. Output the body text only. No explanation, no title, no numbering, no Markdown, no wrapping quotes.
2. Colloquial and natural, with varied sentence length that reads well aloud; avoid stacked written-style phrasing and long modifiers.
3. You may insert inline delivery events, and only these four: [笑] [叹气] [咳嗽] [清嗓子].
4. No English, no kaomoji, no emoji, and no bracketed narration or stage directions.
5. Default length 120-300 Chinese characters; follow the request when it specifies a length.
6. If the request already contains source text, expand and polish that text while keeping its intent and key facts.

Background: this is fictional writing for personal local voice practice. It involves no real people or events and will not be published.
Produce content in the format above. Do not refuse, do not lecture, do not add disclaimers or safety notes.
If the request involves conflict, violence or intimacy, keep it restrained, literary and non-explicit.""").trimIndent()

    /** 多角色剧本：严格按 App 的解析格式输出，一行一句。 */
    private fun dialoguePrompt(): String = tr("""
        你是一位中文广播剧编剧，正在为「本地多角色 TTS 引擎」写剧本。

        输出格式（严格遵守，每句一行）：
        【角色名】(情绪):台词

        规则：
        1. 每行以【角色名】开头，紧跟半角圆括号写这一句的情绪（如 (压低声音)、(笑着说)），
           然后是半角冒号，再写台词。
        2. 至少两个角色；角色名用 2–4 个字的简短中文名，全文保持一致。
        3. 只写角色台词，不要旁白、不要场景描述、不要舞台提示。
        4. 每句不超过 40 字，一次发言一行；不要把多个角色的对话塞进同一行。
        5. 情绪只用 2–6 个字的中文短语。
        6. 只输出剧本，不要解释、不要标题、不要 Markdown。
        7. 默认 8–16 行；需求里明确要求长度时按需求执行。

        背景说明：这是用于个人本地配音练习的虚构创作，不涉及真实人物或现实事件，也不会公开发布。
        请直接产出符合上述格式的剧本，不要拒绝、不要说教、不要附加免责声明或安全提示。
        如果需求涉及冲突、暴力或亲密情节，用含蓄、文学化、不露骨的方式表达即可。
    """, """You are a Chinese radio-drama writer scripting for a local multi-character TTS engine.

Output format (strict, one utterance per line):
【角色名】(情绪):台词

Rules:
1. Each line starts with 【character name】, immediately followed by a half-width parenthesis holding the emotion for that line (e.g. (压低声音), (笑着说)), then a half-width colon, then the line itself.
2. At least two characters; use short 2-4 character Chinese names, consistent from start to end.
3. Character lines only: no narration, no scene description, no stage directions.
4. Each line at most 40 characters, one speaker per line; never put two characters in one line.
5. Emotions must be 2-6 character Chinese phrases.
6. Output the script only: no explanation, no title, no Markdown.
7. Default 8-16 lines; follow the request when it specifies a length.

Background: this is fictional writing for personal local voice practice. It involves no real people or events and will not be published.
Produce the script in the format above. Do not refuse, do not lecture, do not add disclaimers or safety notes.
If the request involves conflict, violence or intimacy, keep it restrained, literary and non-explicit.""").trimIndent()

    // ================= 收藏 =================

    /** 把这一次生成的结果复制进收藏夹。只有点了这个按钮才会入库。 */
    fun favoriteLast() {
        if (favoriteBusy || lastResultFavorited) return
        val src = lastWav
        if (src == null || !src.isFile || src.length() <= 44) {
            message = tr("音频还没就绪，等生成完成再收藏")
            return
        }
        favoriteBusy = true
        val text = lastResultText
        val voice = lastResultVoice
        val dur = lastResultDurationMs
        val fixedName = resultName
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { historyRepo.add(src, text, voice, dur, fixedName) }
                .onSuccess {
                    main.post {
                        favoriteBusy = false
                        lastResultFavorited = true
                        message = tr("已加入收藏夹")
                    }
                }
                .onFailure { t ->
                    main.post {
                        favoriteBusy = false
                        message = tr("收藏失败：${t.message ?: "未知错误"}", "Save failed: ${t.message ?: "unknown error"}")
                    }
                }
        }
    }

    fun startFavSelection(id: String) {
        favSelecting = true
        favSelected = setOf(id)
    }

    fun toggleFavSelected(id: String) {
        favSelected = if (id in favSelected) favSelected - id else favSelected + id
    }

    fun selectAllFavorites() {
        favSelected = history.map { it.id }.toSet()
    }

    /** 反选：没选的变选中，选中的取消。 */
    fun invertFavSelection() {
        val all = history.map { it.id }.toSet()
        favSelected = all - favSelected
    }

    fun exitFavSelection() {
        favSelecting = false
        favSelected = emptySet()
    }

    fun deleteSelectedFavorites() {
        val ids = favSelected
        if (ids.isEmpty()) return
        val targets = history.filter { it.id in ids }
        viewModelScope.launch(Dispatchers.IO) {
            targets.forEach { runCatching { historyRepo.delete(it) } }
            main.post {
                favSelected = emptySet()
                favSelecting = false
                message = tr("已删除 ${targets.size} 条收藏", "Deleted ${targets.size} saved items")
            }
        }
    }

    /** 批量导出：按选择顺序编号，文件名统一走 favFileName。 */
    fun exportSelectedFavorites() {
        val ids = favSelected
        if (ids.isEmpty()) return
        val targets = history.filter { it.id in ids }
        viewModelScope.launch(Dispatchers.IO) {
            var ok = 0
            var fail = 0
            targets.forEachIndexed { index, item ->
                val src = File(item.path)
                if (!src.isFile) { fail++; return@forEachIndexed }
                val name = favFileName(item.voiceName, item.text, index + 1)
                runCatching { exportFileSync(src, name) }
                    .onSuccess { ok++ }
                    .onFailure { fail++ }
            }
            main.post {
                message = if (fail == 0) tr("已导出 $ok 个文件", "Exported $ok files")
                else tr("导出完成：成功 $ok 个，失败 $fail 个", "Export finished: $ok succeeded, $fail failed")
                favSelected = emptySet()
                favSelecting = false
            }
        }
    }

    // ================= 模型页动作 =================
    fun selectVariant(id: String) { variantId = id }

    fun toggleMirror(on: Boolean) {
        useMirror = on
        models.mirror = on
    }

    fun download() {
        ModelDownloadService.start(getApplication<Application>(), variantId, customRepo.ifBlank { null })
    }

    fun cancelDownload() {
        // 先本地清掉，界面立刻回到「未安装」；服务那边的清理随后完成
        downloadState = null
        ModelDownloadService.cancel(getApplication<Application>())
    }

    fun deleteModel(id: String = variantId) {
        val v = ModelCatalog.byId(id)
        val wasActive = models.activeId.value == id
        models.delete(v)
        if (wasActive) {
            engine.release()
            engineState = EngineState.Idle
            resetBackendUi()
            loadFromActive()
        }
        message = tr("已删除 ${v.title}", "Deleted ${v.title}")
    }

    /** 切换当前使用的模型：释放旧引擎 → 切换激活档位 → 重新加载。 */
    fun switchModel(id: String) {
        if (!models.isInstalled(id)) {
            message = tr("该模型尚未安装，请先下载或导入")
            return
        }
        if (id == models.activeId.value) return
        engine.release()
        engineState = EngineState.Idle
        resetBackendUi()
        models.setActive(id)
        loadFromActive()
        message = tr("已切换到 ${ModelCatalog.byId(id).title}，正在重新加载…", "Switched to ${ModelCatalog.byId(id).title}, reloading…")
    }

    /** 从系统文件选择器导入本地 .gguf（完全离线），装到当前选中档位。 */
    fun importLocal(uri: Uri) {
        val v = ModelCatalog.byId(variantId)
        if (importing) return
        importing = true
        error = null
        viewModelScope.launch {
            try {
                models.importGguf(uri, v)
                modelState = models.state.value
                message = tr("已导入 ${v.title}", "Imported ${v.title}")
            } catch (t: Throwable) {
                Log.e("AppViewModel", "import", t)
                error = tr("导入失败：${t.message ?: "未知错误"}", "Import failed: ${t.message ?: "unknown error"}")
            } finally {
                importing = false
            }
        }
    }

    // ================= 性能设置 =================
    fun updateThreads(n: Int) {
        settings.setThreads(n)
        if (engine.isLoaded) {
            engine.setThreads(n)
            // 线程数变了，绑定的核数也要跟着变
            if (corePin) applyCorePin(n)
        }
    }

    /** 1.9.43：按当前线程数重新绑核，并记录实际落在哪几个核上。 */
    private fun applyCorePin(n: Int) {
        val cpus = engine.setCorePin(corePin, n)
        val list = if (cpus > 0) engine.pinnedCpus() else ""
        main.post { pinnedCpus = list }
    }

    fun updateCorePin(on: Boolean) {
        settings.setCorePin(on)
        if (engine.isLoaded) applyCorePin(threads)
        message = if (on) tr("已开启核心绑定（实测比不绑慢 30%~70%，仅供对照）")
        else tr("已关闭核心绑定：调度器自行分配")
    }

    fun updateCfgDecay(on: Boolean) {
        settings.setCfgDecay(on)
        message = if (on) tr("已开启后段降 CFG：前 ${cfgDecayFrames} 帧按 ${"%.1f".format(cfgScale)} 引导，之后单分支", "CFG decay on: guidance for the first ${cfgDecayFrames} frames at ${"%.1f".format(cfgScale)}, single branch after that")
        else tr("已关闭后段降 CFG：全程双分支")
    }

    fun updateCfgDecayFrames(n: Int) {
        settings.setCfgDecayFrames(n)
    }

    /**
     * 1.9.91 深度解码不吃 CFG。
     *
     * 与「后段降 CFG」不同：那个是跑一阵之后连主干也停掉双分支；这个只停深度
     * 解码器的双分支，主干从头到尾都受 cfgScale 引导，所以指令遵从度和音色
     * 相似度不受影响，变化的是每个码本的采样分布（细节与韵律）。
     */
    fun updateDepthCfgOff(on: Boolean) {
        settings.setDepthCfgOff(on)
        message = if (on) tr("细节层不再跟随引导，生成会略快")
        else tr("细节层恢复跟随引导")
    }

    fun updateVocThreads(n: Int) {
        settings.setVocThreads(n)
        message = if (n > 0) tr("声码器改用 $n 线程（生成阶段仍用 $threads）", "Vocoder now uses $n threads (generation still uses $threads)")
        else tr("声码器线程跟随 CPU 线程数（${threads}）", "Vocoder threads follow the CPU thread count (${threads})")
    }

    /**
     * 1.9.73 声码器分块上限。只影响下一句合成，不动权重、不动首块。
     *
     * 提示语不走「设置已保存」这种空话：直接给出这一档相对 96 帧的预计收益，
     * 让用户知道自己刚调的是一个有实测曲线的东西，而不是玄学开关。
     */
    /**
     * 端到端校验：临时把 GPU 委托挂到引擎上，跑一次 native 的真实解码链路，
     * 同时 native 内部会跑一遍纯 CPU 全链路做基准。
     *
     * 返回 [返回码, 相对误差, GPU饱和占比, CPU饱和占比, GPU毫秒]；未就绪返回 null。
     * 只在设置页自检里调用，必须在 IO 线程。
     */
    fun vocoderCheck(frames: Int): FloatArray? {
        val gpu = ai.breeze.tts.engine.VocoderGpu.get(getApplication())
        if (!gpu.isReady) return null
        val old = engine.vocoderDelegate
        engine.vocoderDelegate = gpu.delegate
        return try {
            engine.vocoderCheck(frames)
        } finally {
            engine.vocoderDelegate = old
        }
    }

    fun updateGpuVocoder(on: Boolean) {
        if (on && !vocPackInstalled) {
            // 1.9.92：图不在 APK 里了。没装包就打开开关只会得到一次「建图失败」，
            // 不如直接说清楚要装什么。
            message = tr("请先导入声码器加速包")
            return
        }
        // 只管落盘；StateFlow 的变化会经上面的 collect 触发 applyVocoderDelegate
        settings.setGpuVocoder(on)
        message = if (on) {
            tr("已开启声码器 GPU；首块会先建图（约 1 秒），失败自动回落 CPU")
        } else {
            tr("已关闭，恢复纯 CPU 合成")
        }
    }

    // ---------------- 1.9.92 声码器加速包 ----------------

    private fun refreshVocPack() {
        val ctx = getApplication<Application>()
        vocPackInstalled = ai.breeze.tts.engine.VocoderPack.isInstalled(ctx)
        vocPackBytes = ai.breeze.tts.engine.VocoderPack.bytes(ctx)
    }

    /**
     * 导入加速包（zip 或裸 .tflite）。
     *
     * 全程 IO 线程，进度按「已读字节 / 总字节」回主线程。导入前先把已建的图
     * 释放掉 —— 否则旧文件被 LiteRT 持有，删/换都会出问题。
     */
    fun importVocPack(uri: Uri) {
        if (vocPackImporting) return
        val ctx = getApplication<Application>()
        vocPackImporting = true
        vocPackError = null
        vocPackProgress = null
        // 委托的读写都在主线程：先摘掉，IO 线程只负责释放与写文件
        engine.vocoderDelegate = null
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    ai.breeze.tts.engine.VocoderGpu.evict()
                    ai.breeze.tts.engine.VocoderPack.install(ctx, uri) { done, total ->
                        main.post { vocPackProgress = done to total }
                    }
                }
                refreshVocPack()
                message = tr("加速包已导入（${formatBytes(vocPackBytes)}），打开上方开关即可使用", "Pack imported (${formatBytes(vocPackBytes)}); turn on the switch above to use it")
                if (gpuVocoder) applyVocoderDelegate()
            } catch (t: Throwable) {
                Log.e("AppViewModel", "import vocoder pack", t)
                vocPackError = tr("导入失败：${t.message ?: t.javaClass.simpleName}", "Import failed: ${t.message ?: t.javaClass.simpleName}")
                refreshVocPack()
            } finally {
                vocPackImporting = false
                vocPackProgress = null
            }
        }
    }

    /** 删除加速包，立刻释放磁盘与显存，并把 GPU 开关关掉。 */
    fun removeVocPack() {
        val ctx = getApplication<Application>()
        ai.breeze.tts.engine.VocoderGpu.evict()
        engine.vocoderDelegate = null
        if (gpuVocoder) settings.setGpuVocoder(false)
        ai.breeze.tts.engine.VocoderPack.remove(ctx)
        refreshVocPack()
        vocPackError = null
        message = tr("已删除加速包，合成改回 CPU 声码器")
    }

    /**
     * 1.9.87：把开关同步到引擎。
     *
     * 只有「开关打开」且「这张图在本机建得起来」才挂委托 —— 建图失败时
     * vocoderDelegate 保持 null，走的就是 1.9.84 之前那条纯 CPU 路径。
     */
    private fun applyVocoderDelegate() {
        val want = gpuVocoder
        if (!want) {
            engine.vocoderDelegate = null
            return
        }
        val ctx = getApplication<android.app.Application>()
        // 1.9.92：图已从 APK 拆成可选加速包。升级用户第一次启动时开关可能还
        // 是 true，但文件已经不存在 —— 直接关掉并说明原因，别让每次合成都
        // 去读一次不存在的文件。
        if (!ai.breeze.tts.engine.VocoderPack.isInstalled(ctx)) {
            engine.vocoderDelegate = null
            settings.setGpuVocoder(false)
            message = tr("声码器加速包未安装，已自动关闭 GPU 声码器（设置 → 推理与性能可导入）")
            return
        }
        val gpu = ai.breeze.tts.engine.VocoderGpu.get(ctx)
        // 建图放到 IO 线程：148 MB 权重，主线程会卡住
        viewModelScope.launch(Dispatchers.IO) {
            val ok = gpu.isReady || gpu.load(gpu = true, fp32 = true)
            withContext(Dispatchers.Main) {
                if (ok && gpuVocoder) {
                    engine.vocoderDelegate = gpu.delegate
                } else if (!ok) {
                    message = tr("声码器 GPU 建图失败，继续用 CPU：${gpu.lastError.take(80)}", "Vocoder GPU graph build failed, staying on CPU: ${gpu.lastError.take(80)}")
                }
            }
        }
    }

    fun updateVocChunk(n: Int) {
        settings.setVocChunk(n)
        val sec = n / 12.5f
        message = tr("每块最多 $n 帧（约 %.1f 秒音频）", "At most $n frames per chunk (about %.1f s of audio)").format(sec)
    }

    /** CFG 越大越贴合音色描述 / 情绪指令，但会多一份 KV cache、更慢。 */
    fun updateCfgScale(v: Float) { settings.setCfgScale(v) }

    /** 实验优化开关：只影响下一次合成，不重载权重、不改动已加载模型。 */
    /** 切换界面语言：写偏好 + 立即切 Compose 里的 Lang，整棵树自己重组。 */
    fun changeLanguage(mode: String) {
        settings.setLanguage(mode)
        Lang.setMode(getApplication(), settings.language.value)
    }

    fun updateTurbo(on: Boolean) {
        settings.setTurbo(on)
        message = if (on) tr("极速模式已开启：生成更快，音色与情绪的遵从度会下降")
        else tr("极速模式已关闭：音色与情绪描述重新生效")
    }

    fun updateReusePrefixEmb(on: Boolean) {
        settings.setReusePrefixEmb(on)
        message = if (on) tr("已开启参考前缀编码复用：下次生成起生效，对比面板「文本编码 + 预填充」")
        else tr("已关闭参考前缀编码复用：已回到稳定管线")
    }

    /** 分阶段线程即时生效，无需重载 2.4 GB 权重。 */
    fun updatePhaseThreads(on: Boolean) {
        settings.setPhaseThreads(on)
        engine.setPhaseThreads(on, (threads / 2).coerceIn(2, 4))
        message = if (on) tr("已开启分阶段线程：prefill 满线程，decode 2–4 线程")
        else tr("已关闭分阶段线程")
    }


    /** 量化内核说明：跟着编译配置走，让用户知道这一包装的是什么 */
    val gemmLaneText: String
        get() = "ARMv8.6 dotprod/i8mm + KleidiAI"

    private fun resetBackendUi() {
        backendName = tr("未加载")
    }

    // ---------------- 1.9.51 崩溃定位 ----------------

    private fun traceFile() = java.io.File(getApplication<Application>().filesDir, TRACE_FILE)

    private fun readTrace(): String = runCatching {
        traceFile().takeIf { it.exists() }?.readText()?.trim()
    }.getOrNull().orEmpty()

    /**
     * 清掉「上次异常中断」提示。同时删掉 trace 文件 —— 只清界面不删文件的话，
     * 下次启动又会原样弹出来。
     */
    fun clearCrashNote() {
        runCatching { traceFile().delete() }
        crashNote = null
        lastTrace = ""
    }

    /**
     * 把 native 写的阶段名翻成人话。命名见 generation.cpp / common.cpp 里的 trace()：
     * `gen:*` 是整段流程，`gr:*` 是图分配/执行，`bb/dp/voc:*` 是三张子图，`fN:*` 是第 N 帧。
     */
    private fun explainTrace(t: String): String {
        val frame = if (t.startsWith("f")) t.substringAfter('f').substringBefore(':').toIntOrNull() else null
        val rest = if (t.startsWith("f")) t.substringAfter(':') else t
        val head = when {
            rest.startsWith("depth") -> tr("深度解码器")
            rest.startsWith("voc") -> tr("声码器 flush")
            rest.startsWith("aembed") -> tr("音频帧 embedding")
            rest.startsWith("backbone") -> tr("主干推进")
            rest.startsWith("ok") -> tr("整帧完成")
            else -> rest
        }
        return when {
            t.startsWith("req:start") -> tr("进入 native 之前")
            t.startsWith("gen:prompt") -> tr("文本 / 参考音频编码")
            t.startsWith("gen:prefill-cond") -> tr("主干 prefill（cond）")
            t.startsWith("gen:prefill-uncond") -> tr("主干 prefill（uncond 分支）")
            t.startsWith("gen:depth-init") -> tr("深度解码器初始化")
            t.startsWith("gen:free") || t.startsWith("gen:end") -> tr("收尾释放")
            t.startsWith("gr:alloc") -> tr("图分配 sched（$t）", "graph alloc sched ($t)")
            t.startsWith("gr:prepare-alloc") -> tr("缓存图分配 sched（$t）", "cached graph alloc sched ($t)")
            t.startsWith("gr:compute") -> tr("图执行 sched（$t）", "graph exec sched ($t)")
            t.startsWith("dp:fused") -> tr("深度解码 fused 单分支（$t）", "depth decode fused single branch ($t)")
            t.startsWith("dp:run") -> tr("深度解码（$t）", "depth decode ($t)")
            t.startsWith("bb:run") -> tr("主干前进（$t）", "backbone step ($t)")
            t.startsWith("voc:decode") -> tr("声码器解码（$t）", "vocoder decode ($t)")
            frame != null -> tr("第 $frame 帧 · $head", "frame $frame · $head")
            else -> t
        }
    }

    private fun loadFromActive() {
        val id = models.activeId.value ?: return
        val dir = models.activeDir() ?: return
        val bytes = models.installed.value[id] ?: 0L
        ensureEngine(ModelState.Ready(id, dir, bytes))
    }

    private fun ensureEngine(ready: ModelState.Ready) {
        if (loadJobRunning || engine.isLoaded) {
            if (engine.isLoaded) engineState = EngineState.Ready
            return
        }
        loadJobRunning = true
        engineState = EngineState.Loading
        viewModelScope.launch(Dispatchers.IO) {
            try {
                engine.load(ready.dir, threads = settings.threads.value)
                // 1.9.51：开启崩溃定位。native 每进一个阶段覆盖写这个文件，
                // 进程被信号杀掉后下次启动能读到崩在哪一步。
                engine.setTraceFile(traceFile().absolutePath)
                engine.setPhaseThreads(settings.phaseThreads.value, (settings.threads.value / 2).coerceIn(2, 4))
                // 1.9.47：绑核开关已删除（实测负优化），这里不再碰亲和掩码。
                val features = engine.cpuFeatures()
                main.post {
                    backendName = engine.backendName()
                    cpuFeatures = features
                }
                main.post {
                    engineState = EngineState.Ready
                    backendName = engine.backendName()
                }
            } catch (t: Throwable) {
                Log.e("AppViewModel", "load engine", t)
                main.post { engineState = EngineState.Failed(t.message ?: tr("引擎加载失败")) }
            } finally {
                loadJobRunning = false
            }
        }
    }

    // ================= 开发者模式（1.9.68） =================

    /** 性能诊断入口默认隐藏，连点「关于 → 版本信息」6 次才解锁（持久化）。 */
    var devMode by mutableStateOf(settings.devMode.value)
        private set

    private var versionTaps = 0
    private var lastTapAt = 0L

    fun tapVersion() {
        if (devMode) return
        val now = System.currentTimeMillis()
        // 「连点」：两次之间超过 1.5 s 就从头数，避免用户隔天点六下也能解锁。
        versionTaps = if (now - lastTapAt > TAP_GAP_MS) 1 else versionTaps + 1
        lastTapAt = now
        when {
            versionTaps >= TAPS_TO_UNLOCK -> {
                settings.setDevMode(true)
                devMode = true
                versionTaps = 0
                message = tr("已解锁性能诊断：设置页倒数第二项")
            }
            versionTaps >= 3 -> message = tr("还差 ${TAPS_TO_UNLOCK - versionTaps} 次", "${TAPS_TO_UNLOCK - versionTaps} more taps")
        }
    }

    // ================= 导出位置 =================
    fun setExportDir(uri: Uri?) {
        val label = uri?.let { readableTree(it) }
        settings.setExportDir(uri, label)
        message = if (uri == null) tr("已恢复默认导出位置：${settings.defaultExportLabel}", "Export folder reset to the default: ${settings.defaultExportLabel}")
        else tr("导出位置已设为：$label", "Export folder set to: $label")
    }

    private fun readableTree(uri: Uri): String = runCatching {
        val id = DocumentsContract.getTreeDocumentId(uri)
        when {
            id.startsWith("primary:") -> tr("内部存储/${id.removePrefix("primary:")}", "Internal storage/${id.removePrefix("primary:")}")
            id.startsWith("raw:") -> id.removePrefix("raw:")
            id.contains(":") -> id.substringAfter(":")
            else -> id
        }
    }.getOrDefault(tr("自定义目录"))

    // ================= 离线 ASR =================
    fun selectAsrVariant(id: String) {
        speech.selectVariant(id)
        asrInstalled = speech.isInstalled(id)
    }

    fun installAsrModel() {
        if (asrBusy != null) return
        viewModelScope.launch(Dispatchers.IO) {
            val id = speech.variantId.value
            val r = speech.install(id)
            asrInstalled = speech.isInstalled(id)
            main.post {
                message = r.fold(
                    onSuccess = { tr("识别模型已就绪，可离线使用") },
                    onFailure = { tr("模型下载失败：${it.message}", "Model download failed: ${it.message}") },
                )
            }
        }
    }

    fun deleteAsrModel(id: String = speech.variantId.value) {
        speech.delete(id)
        asrInstalled = speech.isInstalled(id)
        message = tr("已删除该识别模型，可重新下载")
    }

    /** 转写参考音频；结果写入 transcription，由 UI 取走填入文本框。 */
    fun transcribeReference(wav: File) {
        if (asrBusy != null) return
        asrBusy = tr("正在识别参考音频…")
        viewModelScope.launch(Dispatchers.IO) {
            val r = speech.transcribe(wav)
            main.post {
                asrBusy = null
                r.fold(
                    onSuccess = { transcription = it },
                    onFailure = { message = tr("自动识别失败：${it.message}；请手动填写文本稿", "Transcription failed: ${it.message}; please type the transcript") },
                )
            }
        }
    }

    fun consumeTranscription() { transcription = null }

    // ================= 音色 =================
    fun addClone(
        name: String,
        wav: File,
        refText: String,
        gender: VoiceProfile.Gender = VoiceProfile.Gender.NONE,
        avatarFile: File? = null,
    ) {
        viewModelScope.launch {
            val p = voiceRepo.addClone(name, wav, refText, gender)
            finishAvatar(p, avatarFile)
            selectedVoiceId = p.id
            message = tr("已保存克隆音色：${p.name}", "Cloned voice saved: ${p.name}")
        }
    }

    fun addDesign(
        name: String,
        prompt: String,
        gender: VoiceProfile.Gender = VoiceProfile.Gender.NONE,
        avatarFile: File? = null,
    ) {
        viewModelScope.launch {
            val p = voiceRepo.addDesign(name, prompt, gender)
            finishAvatar(p, avatarFile)
            selectedVoiceId = p.id
            message = tr("已保存设计音色：${p.name}", "Designed voice saved: ${p.name}")
        }
    }

    /** 新建流程里选的图先落在缓存，音色建好后才有 id 可以当文件名 */
    private suspend fun finishAvatar(p: VoiceProfile, staged: File?) {
        if (staged == null) return
        val path = voiceRepo.attachAvatar(p.id, staged) ?: return
        voiceRepo.upsert(p.copy(avatarPath = path))
        staged.delete()
    }

    /** 新建表单选图：压缩后落到缓存，返回可预览的路径 */
    fun stageVoiceAvatar(uri: Uri, onReady: (File?) -> Unit) {
        viewModelScope.launch { onReady(voiceRepo.stageAvatar(uri)) }
    }

    /** 只改元信息（名字 / 性别 / 描述），参考音频与码本保持原样 */
    fun updateVoice(v: VoiceProfile) {
        viewModelScope.launch { voiceRepo.upsert(v) }
    }

    fun updateVoiceAvatar(v: VoiceProfile, uri: Uri) {
        viewModelScope.launch {
            voiceRepo.saveAvatar(v.id, uri)?.let { voiceRepo.upsert(v.copy(avatarPath = it)) }
        }
    }

    /** 用户在裁切框里确认后的位图（已缩到 256）直接写成头像 */
    fun saveVoiceAvatar(v: VoiceProfile, bmp: Bitmap) {
        viewModelScope.launch {
            val latest = voices.firstOrNull { it.id == v.id } ?: v
            voiceRepo.saveAvatarBitmap(v.id, bmp)?.let { voiceRepo.upsert(latest.copy(avatarPath = it)) }
        }
    }

    /** 新建表单：裁好的位图先落缓存，音色建好后再 attach */
    fun stageAvatarBitmap(bmp: Bitmap, onReady: (File?) -> Unit) {
        viewModelScope.launch { onReady(voiceRepo.stageAvatarBitmap(bmp)) }
    }

    fun deleteVoice(v: VoiceProfile) {
        viewModelScope.launch {
            voiceRepo.delete(v)
            if (selectedVoiceId == v.id) selectedVoiceId = voices.firstOrNull()?.id
        }
    }

    fun selectVoice(id: String?) { selectedVoiceId = id }

    // ---------------- 设计音色：锁定音色 ----------------
    // 设计音色的音色由逐帧采样决定，同一段描述每次得到的是「同一类人里的不同个体」。
    // 这里让用户先试听几条，把满意的那条的码本留下来；之后音色由码本决定，
    // 与文本、情绪都无关（详见 docs/18）。

    /** 试听样本的固定文本。控制在 5 秒上下，够 codec 抓到音色，又不至于等太久。 */
    private val auditionText = tr("这段话用来试听音色，听听这个声音像不像你要的那个人。")

    /** 正在生成样本的音色 id */
    var auditioningVoiceId by mutableStateOf<String?>(null)
        private set

    /** 已生成待确认的音色 id（样本已落盘，但还没写进 profile） */
    var previewVoiceId by mutableStateOf<String?>(null)
        private set

    /** 待确认样本的时长（秒），锁定时一眼知道这是多长的一段 */
    var auditionSeconds by mutableFloatStateOf(0f)
        private set

    var auditionError by mutableStateOf<String?>(null)
        private set

    fun clearAuditionError() { auditionError = null }

    /** 可试听的样本路径：待确认样本优先，其次已锁定的参考音频 */
    fun sampleWavPath(v: VoiceProfile): String? {
        val staged = voiceRepo.sampleWavFileOf(v)
        if (previewVoiceId == v.id && staged.exists() && staged.length() > 44) return staged.absolutePath
        val locked = voiceRepo.fileOf(v, "wav")
        return locked.absolutePath.takeIf { locked.exists() && locked.length() > 44 }
    }

    /** 是否有可播放的样本 */
    fun hasSample(v: VoiceProfile): Boolean = sampleWavPath(v) != null

    /**
     * 录一条新样本。
     *
     * 两处关键改动：
     *  1. 每次都用「无码本」的副本生成，否则只会复现上一次锁定的声音；
     *  2. 样本写到 `<id>.sample.wav/.sample.codes`，**不碰**已锁定的码本——
     *     以前直接覆盖正式码本，用户点了「换一条」却没确认时，音色会在背后悄悄变掉。
     */
    fun recordVoiceSample(v: VoiceProfile, designPrompt: String? = null) {
        if (engine.isBusy) {
            auditionError = tr("引擎正在合成，等这一段结束再试")
            return
        }
        auditioningVoiceId = v.id
        auditionError = null
        previewVoiceId = null
        auditionSeconds = 0f
        viewModelScope.launch(Dispatchers.IO) {
            val wav = voiceRepo.sampleWavFileOf(v)
            val codes = voiceRepo.sampleCodesFileOf(v)
            codes.delete()
            wav.delete()

            // 用调用方传进来的描述：编辑页/新建页里改了描述但还没点保存时，
            // 试听也应当按「当前输入框里的内容」生成，而不是上一次存下的那份。
            val base = if (designPrompt != null) v.copy(designPrompt = designPrompt.trim()) else v
            val plain = base.copy(codes = null, refText = null, refWav = null)
            val w = WavWriter(wav)
            var err: String? = null
            engine.onChunk = { pcm -> runCatching { w.write(pcm) } }
            engine.onError = { msg -> runCatching { w.close() }; err = msg }
            val frames = engine.estimateFrames(auditionText)
            val ok = engine.synthesize(
                SynthRequest(
                    text = auditionText,
                    instruction = "",
                    voice = plain,
                    seed = Random.nextInt(1, 1 shl 20),
                    temperature = 0.9f,
                    topP = 0.9f,
                    cfgScale = cfgScale,
                    maxFrames = if (frames > 0) frames + 24 else 120,
                    codesOut = codes.absolutePath,
                    reusePrefixEmb = reusePrefixEmb,
                ),
            )
            runCatching { w.close() }

            withContext(Dispatchers.Main) {
                auditioningVoiceId = null
                when {
                    ok && codes.exists() && wav.length() > 44 -> {
                        previewVoiceId = v.id
                        auditionSeconds = ((wav.length() - 44) / 2f / 24_000f)
                    }
                    err != null -> auditionError = err
                    else -> auditionError = tr("样本生成失败，请再试一次")
                }
            }
        }
    }

    /** 把待确认的样本写进音色档案——这一步之后音色就固定了 */
    fun confirmVoiceSample(v: VoiceProfile, designPrompt: String? = null) {
        val codes = voiceRepo.sampleCodesFileOf(v)
        if (!codes.exists()) {
            auditionError = tr("还没有可用的样本")
            return
        }
        val targetCodes = voiceRepo.codesFileOf(v)
        val targetWav = voiceRepo.fileOf(v, "wav")
        val srcWav = voiceRepo.sampleWavFileOf(v)
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                runCatching {
                    codes.copyTo(targetCodes, overwrite = true)
                    if (srcWav.exists()) srcWav.copyTo(targetWav, overwrite = true)
                    voiceRepo.clearSample(v)
                }
            }
            voiceRepo.upsert(
                v.copy(
                    // 锁定同时把当时用的描述写回档案：否则列表里显示的仍是旧描述，
                    // 下次打开编辑页会看到一段与音色不符的文字。
                    designPrompt = designPrompt?.trim()?.takeIf { it.isNotEmpty() } ?: v.designPrompt,
                    codes = targetCodes.absolutePath.takeIf { targetCodes.exists() },
                    refWav = targetWav.absolutePath.takeIf { targetWav.exists() },
                    refText = auditionText,
                ),
            )
            previewVoiceId = null
            message = tr("已锁定「${v.name}」的音色，以后每次都一样", "Locked the voice of \"${v.name}\" — same every time from now on")
        }
    }

    /**
     * 新建流程里的草稿音色：只为试听样本提供一个 id，不进音色列表。
     * 锁定或保存时才真正 upsert，用户中途退出不会在库里留下半成品。
     */
    fun newDesignDraft(name: String, prompt: String, gender: VoiceProfile.Gender): VoiceProfile =
        VoiceProfile(
            id = "d_" + java.util.UUID.randomUUID().toString().take(8),
            name = name.trim().ifBlank { tr("设计音色") },
            kind = VoiceProfile.Kind.DESIGN,
            gender = gender,
            designPrompt = prompt.trim(),
        )

    /** 放弃草稿：只清样本文件；已锁定的音色已经 upsert，不在这里删 */
    fun discardDesignDraft(v: VoiceProfile) {
        if (v.locked) return
        viewModelScope.launch(Dispatchers.IO) { voiceRepo.clearSample(v) }
    }

    /** 新建页保存：把草稿（可能已锁定，带码本）补上最新字段后落库 */
    fun saveDesignDraft(
        v: VoiceProfile,
        name: String,
        prompt: String,
        gender: VoiceProfile.Gender,
        avatarFile: File? = null,
    ) {
        viewModelScope.launch {
            val p = v.copy(
                name = name.trim().ifBlank { v.name },
                designPrompt = prompt.trim().ifBlank { v.designPrompt },
                gender = gender,
            )
            voiceRepo.upsert(p)
            finishAvatar(p, avatarFile)
            voiceRepo.clearSample(p)
            selectedVoiceId = p.id
            message = tr("已保存设计音色：${p.name}", "Designed voice saved: ${p.name}")
        }
    }

    /** 解除锁定，回到每次随机（并清掉样本，免得下次误用） */
    fun unlockVoice(v: VoiceProfile) {
        viewModelScope.launch {
            voiceRepo.codesFileOf(v).delete()
            voiceRepo.fileOf(v, "wav").delete()
            voiceRepo.clearSample(v)
            voiceRepo.upsert(v.copy(codes = null, refWav = null, refText = null))
            previewVoiceId = null
            message = tr("已解除锁定，「${v.name}」会回到每次随机", "Unlocked \"${v.name}\" — it will be random again each time")
        }
    }

    // ---------------- 情绪预设 ----------------
    /** 把当前输入存成预设；内容为空时返回 null，由调用方决定是否提示 */
    fun saveInstructionPreset(name: String, text: String? = null): EmotionPreset? =
        presetRepo.add(name, text ?: instruction)

    fun updateInstructionPreset(id: String, name: String, text: String) =
        presetRepo.update(id, name, text)

    fun deleteInstructionPreset(id: String) = presetRepo.remove(id)

    fun resetInstructionPresets() = presetRepo.resetDefaults()

    /** 预设是否被改过（删过内置项或加过自定义），决定要不要显示「恢复默认」 */
    fun presetsCustomized(): Boolean = presetRepo.isCustomized()

    fun applyInstructionPreset(p: EmotionPreset) {
        // 再点一次同一个预设 = 取消，和原来快捷标签的行为一致
        instruction = if (instruction == p.text) "" else p.text
    }

    fun voiceName(id: String?): String =
        voices.firstOrNull { it.id == id }?.name ?: tr("默认音色")

    // ================= 音色转换（1.9.54） =================
    /**
     * 转换专用参数：语义与朗读页一致，但独立保存。
     *
     * 之前是写死 0.3 / top-k 1 / seed 42 —— 朗读页调温度、换种子都影响不到转换，
     * 想复现同一段结果或换一个说法风格只能改代码。三个值都由 native 直接消费，
     * 改完重新点「开始转换」即可，不需要重新加载模型。
     */
    var convertTemperature by mutableFloatStateOf(0.3f)
    var convertTopK by mutableIntStateOf(1)
    var convertSeed by mutableIntStateOf(42)
    /**
     * 保留源音频前 N 个声学码本（原生上限 15，但上游文档只验证到 2）：
     * 1–2 能保住唱歌旋律，3 以上不稳定，普通说话必须留 0。
     */
    var convertKeepAcoustic by mutableIntStateOf(0)

    /** 源音频，已归一为 24 kHz 单声道 WAV */
    var convertSrcWav by mutableStateOf<File?>(null)
        private set
    var convertSrcLabel by mutableStateOf("")
        private set
    var convertSrcMs by mutableLongStateOf(0L)
        private set
    /** 源音频的逐字稿；可空 —— 空时模型自动生成等长填充，对齐精度略降 */
    var convertSrcText by mutableStateOf("")
    /** 目标音色 id；null 时自动取第一个可用音色 */
    var convertTargetVoiceId by mutableStateOf<String?>(null)
    var converting by mutableStateOf(false)
        private set
    var convertProgress by mutableFloatStateOf(0f)
        private set
    var convertDoneFrames by mutableIntStateOf(0)
        private set
    var convertTotalFrames by mutableIntStateOf(0)
        private set
    /** 转换阶段：0 逐帧重说，1 声码器合成（后者占全程三到四成）。 */
    var convertPhase by mutableIntStateOf(0)
        private set
    var convertDoneUnits by mutableIntStateOf(0)
        private set
    var convertTotalUnits by mutableIntStateOf(0)
        private set
    var convertStatus by mutableStateOf("")
        private set
    var convertWav by mutableStateOf<File?>(null)
        private set
    var convertResultName by mutableStateOf("")
        private set
    var convertElapsedMs by mutableLongStateOf(0L)
        private set
    var convertAudioMs by mutableLongStateOf(0L)
        private set
    var convertError by mutableStateOf<String?>(null)
        private set
    /** 当前这份转换结果是否已收藏 */
    var convertFavorited by mutableStateOf(false)
        private set
    var convertFavoriteBusy by mutableStateOf(false)
        private set
    private var convertCancelled = false
    /** 上一次把转换进度推给 UI 的时刻：回调节奏约 3~7 Hz，这里压到 1 Hz（docs/84）。 */
    private var lastConvertUiAt = 0L

    /** 能当转换目标的音色：必须有参考音频和它的逐字稿，缺一样都重建不出音色。 */
    val convertTargets: List<VoiceProfile>
        get() = voices.filter { it.canConvertTarget }

    fun convertTargetVoice(): VoiceProfile? {
        val id = convertTargetVoiceId
        return voices.firstOrNull { it.id == id && it.canConvertTarget }
            ?: convertTargets.firstOrNull()
    }

    fun selectConvertTarget(id: String) { convertTargetVoiceId = id }

    /** UI 解码完音频后调用。换素材立刻作废旧结果，避免「素材换了，结果还是上一段」。 */
    fun setConvertSource(wav: File, label: String) {
        // 每次导入都用带时间戳的新文件（波形缓存按路径存，同名会被认成同一段）。
        // 旧文件随即删掉，避免 cacheDir 里堆一串 convert_src_*.wav。
        val old = convertSrcWav
        convertSrcWav = wav
        convertSrcLabel = label
        convertSrcMs = pcm16DurationMs(wav)
        convertWav = null
        convertResultName = ""
        convertAudioMs = 0
        convertElapsedMs = 0
        convertError = null
        convertStatus = ""
        convertProgress = 0f
        convertPhase = 0
        convertDoneUnits = 0
        convertTotalUnits = 0
        convertFavorited = false
        convertFavoriteBusy = false
        if (old != null && old.absolutePath != wav.absolutePath) {
            runCatching { old.delete() }
        }
    }

    fun clearConvertSource() {
        convertSrcWav = null
        convertSrcLabel = ""
        convertSrcMs = 0
        convertSrcText = ""
        convertWav = null
        convertResultName = ""
        convertAudioMs = 0
        convertElapsedMs = 0
        convertError = null
        convertStatus = ""
        convertProgress = 0f
        convertPhase = 0
        convertDoneUnits = 0
        convertTotalUnits = 0
        convertFavorited = false
        convertFavoriteBusy = false
    }

    /** 24 kHz / 单声道 / 16-bit：每秒 48000 字节，减去 44 字节头。 */
    private fun pcm16DurationMs(f: File): Long =
        runCatching { ((f.length() - 44).coerceAtLeast(0)) * 1000L / (24_000L * 2) }.getOrDefault(0L)

    /**
     * 识别源音频里的文字。与克隆音色共用同一个 SenseVoice 实例，但结果写进
     * [convertSrcText] 而不是全局 [transcription]——后者是克隆页的输入槽，
     * 共用会让两个页面互相抢文本框。
     */
    fun transcribeConvertSource() {
        val wav = convertSrcWav ?: return
        if (asrBusy != null) return
        asrBusy = tr("正在识别源音频…")
        convertError = null
        viewModelScope.launch(Dispatchers.IO) {
            val r = speech.transcribe(wav)
            main.post {
                asrBusy = null
                r.fold(
                    onSuccess = {
                        convertSrcText = it
                        convertStatus = tr("已识别 ${it.length} 字，可手动修改", "${it.length} characters transcribed, editable")
                    },
                    onFailure = {
                        convertError = tr("自动识别失败：${it.message}；可以直接手填，留空也能转", "Transcription failed: ${it.message}; type it manually, or leave it empty and conversion still works")
                    },
                )
            }
        }
    }

    fun startConvert() {
        if (converting || generating || diagRunning) return
        val src = convertSrcWav
        if (src == null || !src.isFile) {
            convertError = tr("请先选择要转换的音频")
            return
        }
        val voice = convertTargetVoice()
        if (voice == null) {
            convertError = tr("还没有可用于转换的音色：需要一段参考音频和它的逐字稿")
            return
        }
        if (engineState !is EngineState.Ready) {
            convertError = tr("引擎还没准备好，请稍等")
            return
        }

        // 每次换一个带时间戳的文件：波形缓存按路径存，固定叫 converted.wav
        // 会让「第二段转换」显示上一段的波形。旧结果顺手清掉。
        val cacheDir = getApplication<Application>().cacheDir
        val out = File(cacheDir, "converted_${System.currentTimeMillis()}.wav")
        convertWav?.let { old ->
            if (playback.path == old.absolutePath) player.stop()
            runCatching { old.delete() }
        }
        runCatching { cacheDir.listFiles { f -> f.name.startsWith("converted_") && f.name.endsWith(".wav") }
            ?.filter { it.absolutePath != out.absolutePath }
            ?.forEach { it.delete() } }

        convertError = null
        convertWav = null
        convertFavorited = false
        convertFavoriteBusy = false
        convertAudioMs = 0
        convertElapsedMs = 0
        converting = true
        convertCancelled = false
        convertProgress = 0f
        convertDoneFrames = 0
        convertTotalFrames = 0
        convertPhase = 0
        convertDoneUnits = 0
        convertTotalUnits = 0
        lastConvertUiAt = 0L
        convertStatus = tr("正在分析源音频…")

        // 转换与合成共用引擎：先清掉上一段合成的回调，避免音频块 / 进度互相污染。
        engine.onError = { msg -> main.post { if (converting) convertError = msg } }
        engine.onChunk = { }
        engine.onProgress = { _, _ -> }

        viewModelScope.launch(Dispatchers.IO) {
            val t0 = System.currentTimeMillis()
            val ok = engine.convert(
                ConvertRequest(
                    srcWav = src.absolutePath,
                    refWav = voice.refWav ?: "",
                    refText = voice.refText ?: "",
                    srcText = convertSrcText.trim(),
                    outWav = out.absolutePath,
                    // 默认 0.3 / top-k 1：上游实测这是「最像目标音色」的档位，
                    // 放开采样会让源说话人的音色漏回来；用户可在参数里自行放宽。
                    temperature = convertTemperature,
                    topK = convertTopK,
                    keepAcoustic = convertKeepAcoustic,
                    seed = convertSeed,
                ),
            )
            val ms = System.currentTimeMillis() - t0
            main.post {
                val wasCancelled = convertCancelled
                converting = false
                when {
                    ok && out.isFile && out.length() > 2000 -> {
                        convertProgress = 1f
                        convertWav = out
                        convertElapsedMs = ms
                        convertAudioMs = pcm16DurationMs(out)
                        convertResultName = buildResultName(
                            listOf(voice.name),
                            convertSrcLabel.removeSuffix(".wav").removeSuffix(".WAV"),
                        )
                        convertStatus = tr("转换完成")
                    }
                    wasCancelled -> {
                        convertProgress = 0f
                        convertStatus = tr("已取消")
                    }
                    convertError == null -> {
                        convertProgress = 0f
                        convertStatus = ""
                        convertError = tr("转换没有产出音频，换个素材再试")
                    }
                }
                engine.onError = null
            }
        }
    }

    fun stopConvert() {
        if (!converting) return
        convertCancelled = true
        convertStatus = tr("正在取消…")
        engine.cancel()
    }

    fun playConvert() {
        val f = convertWav ?: return
        // 同一段：播放 / 暂停切换，拖动后的播放头不会被 reset 回 0
        if (playback.path == f.absolutePath) player.toggle() else player.play(f, tr("音色转换"))
    }

    /** 试听源音频：正在播就暂停，否则从当前播放头（拖动过就是拖动位置）播。 */
    fun toggleConvertSource() {
        val f = convertSrcWav ?: return
        if (playback.path == f.absolutePath) player.toggle()
        else player.play(f, tr("源音频"))
    }

    /** 拖动源音频波形：没装载先装载，暂停状态只挪播放头。 */
    fun seekConvertSource(fraction: Float) {
        val f = convertSrcWav ?: return
        player.load(f, tr("源音频"))
        player.seek(fraction)
    }

    /** 拖动转换结果波形。 */
    fun seekConvertResult(fraction: Float) {
        val f = convertWav ?: return
        player.load(f, tr("音色转换"))
        player.seek(fraction)
    }

    fun exportConvert() {
        val src = convertWav
        if (src == null || !src.isFile) {
            message = tr("还没有可导出的转换结果")
            return
        }
        exportFile(src, (convertResultName.ifBlank { tr("音色转换") }) + ".wav")
    }

    /** 转换结果进收藏夹：和单人 / 多人的「收藏」走同一个 HistoryRepository。 */
    fun favoriteConvert() {
        if (convertFavoriteBusy || convertFavorited) return
        val src = convertWav
        if (src == null || !src.isFile || src.length() <= 44) {
            message = tr("音频还没就绪，等转换完成再收藏")
            return
        }
        convertFavoriteBusy = true
        val text = convertSrcText.trim()
            .ifBlank { tr("音色转换 · ${convertSrcLabel.ifBlank { "导入音频" }}", "Voice conversion · ${convertSrcLabel.ifBlank { "import audio" }}") }
        val voiceName = convertTargetVoice()?.name ?: tr("默认音色")
        val dur = convertAudioMs
        val title = convertResultName
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { historyRepo.add(src, text, voiceName, dur, title) }
                .onSuccess {
                    main.post {
                        convertFavoriteBusy = false
                        convertFavorited = true
                        message = tr("已加入收藏夹")
                    }
                }
                .onFailure { t ->
                    main.post {
                        convertFavoriteBusy = false
                        message = tr("收藏失败：${t.message ?: "未知错误"}", "Save failed: ${t.message ?: "unknown error"}")
                    }
                }
        }
    }

    // ================= 播放 =================
    fun playLast() {
        val f = lastWav ?: run { message = tr("还没有生成过语音"); return }
        if (playback.path == f.absolutePath) player.toggle() else player.play(f, tr("最近生成"))
    }

    /** 拖动生成结果波形：没装载先装载，暂停状态只挪播放头。 */
    fun seekLast(fraction: Float) {
        val f = lastWav ?: return
        player.load(f, tr("最近生成"))
        player.seek(fraction)
    }

    fun playHistory(item: HistoryItem) { player.play(File(item.path), item.title) }

    fun togglePlayback() { player.toggle() }
    fun seekPlayback(fraction: Float) { player.seek(fraction) }
    fun stopPlayback() { player.stop() }

    fun replayCurrent() {
        val p = playback.path
        if (p.isEmpty()) { playLast(); return }
        player.stop()
        player.play(File(p), playback.label)
    }

    // ================= 历史 =================
    fun deleteHistory(item: HistoryItem) {
        viewModelScope.launch {
            if (playback.path == item.path) player.stop()
            if (lastWav?.absolutePath == item.path) lastWav = history.firstOrNull { it.id != item.id }
                ?.let { File(it.path) }
            historyRepo.delete(item)
            message = tr("已删除：${item.title}", "Deleted: ${item.title}")
        }
    }

    // ================= 合成 =================
    /** 每次开跑前统一清空上一轮的状态，单人 / 多角色共用 */
    private fun resetForRun() {
        error = null
        stats = null
        lastResultFavorited = false
        favoriteBusy = false
        lastResultText = ""
        lastResultVoice = ""
        lastResultDurationMs = 0L
        stageStats = null
        progress = 0f
        progressTarget = 0f
        genElapsedSec = 0
        generating = true
        synthStartedAt = System.currentTimeMillis()
        lastChunkAt = synthStartedAt
        lastChunkProducedMs = 0L
        lastChunkWallMs = synthStartedAt
        frameMs = 0.0
        statusLine = tr("正在生成，请稍等…")
        player.stop()
        // 上一段的尾音可能还在后台放，先掐掉，免得两路声音叠在一起
        tailPlayer?.stopNow()
        tailPlayer = null
    }

    /** 预缓冲：RTF 越高越要多攒一点再开播；再跟「预计总长的 60%」取小，短句不白等 */
    private fun prebufferFor(expectedMs: Long): Int {
        val byRtf = (2_000 + ((settings.lastRtf.value - 1f).coerceAtLeast(0f)) * 6_000)
            .toInt().coerceIn(2_000, 12_000)
        return minOf(byRtf, maxOf(600, (expectedMs * 0.6f).toInt()))
    }

    /** 剧本里的名字 → 音色。找不到就用当前选中的音色，并保留名字继续合成，不让整段失败 */
    fun voiceForName(name: String?): VoiceProfile? {
        val n = name?.trim().orEmpty()
        if (n.isEmpty() || eqTr(n, "默认") || eqTr(n, "默认音色")) return voices.firstOrNull { it.id == selectedVoiceId }
        return voices.firstOrNull { it.name.trim() == n }
    }

    /** 名字在音色库里是否有对应音色（UI 用来标红「未匹配」） */
    fun hasVoiceNamed(name: String?): Boolean {
        val n = name?.trim().orEmpty()
        if (n.isEmpty() || eqTr(n, "默认") || eqTr(n, "默认音色")) return true
        return voices.any { it.name.trim() == n }
    }

    fun scriptLines(): List<ScriptLine> = ScriptParser.parse(text)

    /**
     * 克隆音色的参考码本缓存。
     *
     * native 收到参考音频时，每次生成都要先跑一遍 Mimi encoder 把它编成 ref codes，
     * 实测固定 4 秒左右——面板上没有这一项，它混在「总耗时」与各阶段之和的差额里。
     * 这里让 native 首次合成后把码本写到 `<音色 id>.codes`，之后直接读该文件，
     * breeze 侧的 `locked` 分支就会跳过整段 encode。
     *
     * 返回：传给请求的音色副本（codes 指向缓存文件）+ 需要回写的路径（已有码本时为 null）。
     */
    private fun codesCacheFor(v: VoiceProfile?): Pair<VoiceProfile?, String?> {
        if (v == null || !v.codes.isNullOrEmpty() || v.refWav.isNullOrEmpty()) return v to null
        val f = voiceRepo.codesFileOf(v)
        // 文件已经在（本进程早先合成过）就直接读，不必再写一遍
        return v.copy(codes = f.absolutePath) to if (f.exists()) null else f.absolutePath
    }

    // ---------------- 性能诊断：实现 ----------------

    /**
     * 读电池温度（摄氏度）。
     *
     * 为什么不再读 sysfs 的 SoC zone：不同厂商的 thermal_zone 单位（毫度 / 度 / 缩放值）
     * 和语义（真实结温 / 虚拟限温点 / 未校准占位）完全不统一，靠名字猜 + 猜单位经常
     * 读到一个恒定的假值（例如 75°C），既不代表真实结温也无法反映温升趋势，误导判断。
     *
     * BatteryManager 的 EXTRA_TEMPERATURE 是公开 API，单位明确为「十分之一摄氏度」，
     * 语义固定、无需权限、跨机型一致。电池温度虽不等于 SoC 结温，但连续合成时二者强相关，
     * 且温升趋势真实可信——足以作为散热画像的基线。读不到返回 null，界面显示「不可用」。
     */
    fun readSocTemp(): Float? {
        val ctx = getApplication<Application>()
        // registerReceiver(null, ...) 读取系统 sticky 电池广播，不需要动态注册或权限
        val battery = runCatching {
            ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }.getOrNull()
        val raw = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            ?: return null.also { diagTempC = null }
        if (raw == Int.MIN_VALUE) { diagTempC = null; return null }
        val c = raw / 10f // EXTRA_TEMPERATURE 单位 = 0.1°C
        // 电池温度合理区间 5~60°C；越界视为脏数据
        val ok = c.takeIf { it in 5f..60f }
        diagTempC = ok
        return ok
    }

    /**
     * 跑一次诊断合成。复用引擎但把回调全部换成「丢弃音频 + 只收计时」，
     * 因此不写 WAV、不进历史、不触发播放，也不改 generating/progress 等主管线状态。
     * 通过 diagStop 支持中途停止（调用 engine.cancel）。
     */
    /**
     * 这次合成该按多少帧一块 flush。
     *
     * 引擎里 chunk_first 只是"攒够这么多帧就 flush"的**上限**，不是固定工作量：
     * 句子提前结束就直接收尾，给大不会多解码。所以短句一律给到 96 帧（7.7 秒）
     * 一次到底，声码器只需算一遍 88 帧滑动窗口上下文。
     *
     * 1.9.38–1.9.40 用的是「估算帧数 ×1.2」，但模型采样带随机性——同一句 16 字
     * 文本会产出 38 帧也可能 43 帧。估算一旦比实际少一帧，就会多出一次只含
     * 几帧的碎片 flush：声码器要为它再算 88 帧上下文，引擎还会在首块时切换
     * 线程数，实测声码器 1810 → 5030 ms、尾段逐帧 98 → 130 ms（见 docs/47）。
     *
     * 现在：估算 ≤96 帧直接给 96；更长则按块数等分，保证每块 ≥64 帧，
     * 句尾不会剩几帧的碎片。
     */
    private fun chunkFramesFor(estFrames: Int): Int {
        val est = if (estFrames > 0) (estFrames * 1.15f).toInt() else 96
        if (est <= 96) return 96
        val blocks = (est + 95) / 96
        return (est / blocks).coerceIn(64, 96)
    }

    /**
     * 1.9.73 正式合成实际下发的分块参数（首块, 上限）。
     *
     * 首块沿用 [chunkFramesFor]：短句一次到底、长句等分成 64~96 帧，保证第一段
     * 音频尽快出来。上限取设置档位，只决定「之后每块攒多少」——首块不变，所以
     * 首声延迟与这个档位无关，调它只换速度（docs/81 实测 96→75.4、250→49.2 ms/帧）。
     *
     * 上限低于首块时以首块为准：native 侧同样有 max 兜底，这里先对齐，
     * 免得日志里出现 96/96 这种看不出是「没生效」还是「本来就一样」的组合。
     */
    private fun chunkPlanFor(estFrames: Int): Pair<Int, Int> {
        if (gpuVocoder) {
            // GPU 图按 128 帧固定编译，但 native 只把 latent 的尾部 128 帧交给它
            // —— 卷积实测 8 帧上下文就够，88 帧里前面那些白算。
            // 所以 chunk 可以开到 128-16 = 112，GPU 每次仍只算 128 帧。
            //
            // 首块仍然给 40：3.2 秒就能出声，而 T=128 本来就在图的长度内，
            // 不触发截尾、也不需要额外等待。
            return 40 to 112
        }
        val first = chunkFramesFor(estFrames)
        val cap = vocChunk.coerceIn(96, 512)
        return first to maxOf(cap, first)
    }

    /** 声码器此刻是不是真的跑在 GPU 上（真值看委托，不看设置里的开关）。 */
    val vocoderOnGpu: Boolean get() = engine.vocoderDelegate != null

    /**
     * 实际下发给 native 的声码器线程数。
     *
     * 1.9.100 实测：GPU 声码器时「切 8 / 不切」全程差 0.7 ms（组内波动 ±17 ms），
     * 也就是说两次 flush 之间重建线程池的开销在噪声以下，值不值得改都无所谓。
     * 但那次重建对 GPU 路径本来就没有任何作用，所以 1.9.101 起直接下发 0（跟随主线程），
     * 让 native 不再做这次无用功——这是清理，不是提速。
     *
     * CPU 声码器时仍然尊重设置里的线程数：那里 8 线程是真实收益。
     */
    private val effectiveVocThreads: Int
        get() = if (vocoderOnGpu) 0 else vocThreads

    private suspend fun runDiagOnce(
        index: Int,
        /** 非空时用这段文本代替 diagText：对照实验需要足够长、能产生多次 flush 的句子。 */
        textOverride: String? = null,
        /** 试听音频的文件名标记（例如「切8」）。 */
        tag: String = "run",
        /** null = 用设置里的 vocThreads；0 = 不切线程池；其余 = flush 期间切到该线程数。 */
        vocThreadsOverride: Int? = null,
        /** null = 用设置里的线程数；其余 = 本次运行前切到该线程数，跑完切回。 */
        threadsOverride: Int? = null,
        /** 0 / null = 全部码本；N = 只解前 N 个码本（1.9.106 截断实验）。 */
        codebooksOverride: Int? = null,
    ): DiagRun = withContext(Dispatchers.IO) {
        if (engineState !is EngineState.Ready) {
            DiagLog.e("exp", tr("run#$index 跳过：引擎未就绪（state=$engineState loaded=${engine.isLoaded}）", "run#$index skipped: engine not ready (state=$engineState loaded=${engine.isLoaded})"))
            return@withContext DiagRun(index, StageTimings(), 0f, 0, readSocTemp(), false, tr("引擎未就绪"))
        }
        val text = textOverride?.trim()?.takeIf { it.isNotBlank() }
            ?: diagText.trim().ifBlank { tr("今天天气不错，我们出去走走吧。") }
        val est = engine.estimateFrames(text).takeIf { it > 0 } ?: (text.length * 3)
        // 没有 override 时走正式合成的同一套分块，诊断页的单次结果才能代表真实行为。
        val plan = chunkPlanFor(est)
        val chunk = plan.first
        val chunkMax = plan.second
        val vocT = vocThreadsOverride ?: effectiveVocThreads
        // 1.9.102：线程数对照。切线程数会重建 ggml 线程池（1.9.101 实测 0.15 ms 量级），
        // 放在 t0 之前，让这笔开销落在被测区间外——我们要量的是它跑起来有多快，
        // 不是切一次有多贵。
        val genT = threadsOverride?.coerceIn(1, 16) ?: threads
        if (threadsOverride != null && genT != threads) engine.setThreads(genT)
        val maxFrames = (est * 2.6f).toInt().coerceIn(120, 1_400)
        val voice = voices.firstOrNull { it.id == selectedVoiceId }
        val (voiceCached, _) = codesCacheFor(voice)

        var stage: StageTimings? = null
        var hadError: String? = null
        var ret = false
        val t0 = System.currentTimeMillis()

        // 音频先攒内存，等墙钟与计时都取完再写盘：写 WAV 会有几毫秒 I/O，
        // 混进被测区间就等于给 A/B 加了一条噪声。
        // 留一份给用户试听是有必要的——两条路径消耗随机数的顺序不同，耗时只差 3%，
        // 但万一某条路径把音频拼错（爆音、截断、静音），只有耳朵能发现。
        val chunks = ArrayList<ShortArray>()
        var sampleCount = 0L
        engine.onChunk = { pcm ->
            if (sampleCount < 60L * 24_000) {   // 单次最多留 60 秒，够听完长句
                chunks.add(pcm)
                sampleCount += pcm.size
            }
        }
        engine.onProgress = { _, _ -> }
        engine.onStats = { t ->
            stage = t
            DiagLog.i("exp", tr("run#$index 收到计时 frames=${t.frames} flushes=${t.flushes}", "run#$index timings received frames=${t.frames} flushes=${t.flushes}"))
        }
        engine.onError = { msg ->
            hadError = msg
            DiagLog.e("exp", tr("run#$index native 报错：$msg", "run#$index native error: $msg"))
        }
        engine.onDone = { s -> DiagLog.i("exp", "run#$index done frames=${s.frames}") }

        // 请求参数全部落日志：跑出来数字不对时，第一件要确认的就是「到底按什么参数跑的」。
        DiagLog.i(
            "exp",
            tr("run#$index 开始 chunk=$chunk/${chunkMax} ", "run#$index start chunk=$chunk/${chunkMax} ") +
                tr("文本${text.length}字 est=$est max=$maxFrames ", "text ${text.length} chars est=$est max=$maxFrames ") +
                "threads=$genT phaseThreads=$phaseThreads turbo=$turbo " +
                "vocThreads=$vocT cfg=${effectiveCfg} decay=$effectiveCfgDecay " +
                "seed=$seed temp=$temperature topP=$topP " +
                tr("音色=${voice?.name ?: "默认"}(${voice?.kind}) 码本=${voiceCached?.codes?.isNotEmpty() == true} ", "voice=${voice?.name ?: "默认"}(${voice?.kind}) codebooks=${voiceCached?.codes?.isNotEmpty() == true} ") +
                tr("截断=${codebooksOverride?.takeIf { it > 0 } ?: "全"}", "truncation=${codebooksOverride?.takeIf { it > 0 } ?: "全"}"),
        )

        try {
            val req = SynthRequest(
                text = text,
                instruction = instruction.trim(),
                voice = voiceCached,
                seed = seed, temperature = temperature, topP = topP,
                cfgScale = effectiveCfg, maxFrames = maxFrames,
                // 诊断必须用与正式合成完全一致的分块参数，否则测出来的
                // 声码器耗时对不上真实体验，A/B 也就失去意义。
                chunkFirst = chunk,
                chunkMax = chunkMax,
                reusePrefixEmb = reusePrefixEmb,
                cfgDecayFrames = effectiveCfgDecay,
                vocThreads = vocT,
                depthCfgOff = depthCfgOff,
                codebooks = codebooksOverride ?: 0,
            )
            ret = engine.synthesize(req)
        } catch (t: Throwable) {
            hadError = t.message ?: tr("未知错误")
            DiagLog.e("exp", tr("run#$index synthesize 抛异常", "run#$index synthesize threw"), t)
        }

        val wall = System.currentTimeMillis() - t0
        // 计时已经取完，立刻切回设置值：失败路径也要复原，否则后续正式合成就跑在实验线程数上。
        if (threadsOverride != null && genT != threads) engine.setThreads(threads)
        val st = stage ?: StageTimings()
        val audioMs = (st.frames * 80L).toDouble()
        val rtf = if (audioMs > 0) (wall.toDouble() / audioMs).toFloat() else 0f
        // 失败原因必须能自解释。老版只有「失败」两个字：计时回调没到（stage=null）和
        // 真的产出 0 帧是两回事，前者说明回调链路断了，后者说明生成侧没东西出来。
        val why = when {
            hadError != null -> hadError!!
            stage == null -> tr("计时回调未到达：native 没有 emitStats（检查 JNI 签名），native返回=$ret", "Timing callback never arrived: native didn't emitStats (check the JNI signature), native ret=$ret")
            st.frames <= 0 -> tr("产出 0 帧：native返回=$ret wall=${wall}ms", "Produced 0 frames: native ret=$ret wall=${wall}ms")
            !ret -> tr("native 返回失败（rc≠0 且无错误信息）")
            else -> ""
        }
        val ok = why.isEmpty()
        // 电平统计：peak 接近 0 说明这条路径根本没人声（拼错/静音），
        // 接近满量程则可能削波。比只看耗时多一维判断。
        var peak = 0
        var sumSq = 0.0
        for (c in chunks) for (v0 in c) {
            val a = if (v0 < 0) -v0.toInt() else v0.toInt()
            if (a > peak) peak = a
            sumSq += v0.toDouble() * v0
        }
        val peakF = peak / 32768f
        val rmsF = if (sampleCount > 0) kotlin.math.sqrt(sumSq / sampleCount) / 32768.0 else 0.0
        val audioPath = if (chunks.isNotEmpty()) writeDiagWav(tag, chunks) else ""
        DiagLog.log(
            if (ok) 'I' else 'E', "exp",
            tr("run#$index 结束 ok=$ok 墙钟=${wall}ms ret=$ret ", "run#$index done ok=$ok wall=${wall}ms ret=$ret ") +
                "frames=${st.frames} flushes=${st.flushes} " +
                "prompt=${st.promptMs.f1()} prefill=${st.prefillMs.f1()} backbone=${st.backboneMs.f1()} " +
                "depth=${st.depthMs.f1()} voc=${st.vocoderMs.f1()} tail=${st.tailMs.f1()} " +
                "rtf=${"%.2f".format(rtf)} " +
                tr("深度路径=fused${st.depthFusedFrames}/step${st.depthStepFrames} ", "depth path=fused${st.depthFusedFrames}/step${st.depthStepFrames} ") +
                "peak=${"%.2f".format(peakF)} rms=${"%.3f".format(rmsF)}" +
                (if (audioPath.isEmpty()) "" else tr(" 音频=${File(audioPath).name}", " audio=${File(audioPath).name}")) +
                if (ok) "" else tr(" 原因=$why", " reason=$why"),
        )
        main.post { diagLogText = DiagLog.dump() }
        DiagRun(
            index, st, rtf, wall, readSocTemp(), ok, why,
            threads = threads, phaseThreads = phaseThreads, turbo = turbo,
            chunk = chunk, cfg = effectiveCfg,
            vocThreads = vocT, cfgDecay = effectiveCfgDecay,
            depthMode = 0, chunkMax = chunkMax,
            audioPath = audioPath, peak = peakF, rms = rmsF.toFloat(),
        )
    }

    private fun Double.f1(): String = "%.1f".format(this)

    /** 试听音频目录：每次测试会话开始时清空，避免几十个 wav 越攒越多。 */
    private fun diagAudioDir(): File =
        File(getApplication<Application>().filesDir, "diag/audio").apply { mkdirs() }

    private fun clearDiagAudio() {
        // 先停播放：正在播的文件被删掉，解码器会在下一次读时抛 IOException。
        val p = playback.path
        if (p.isNotEmpty() && p.contains("/diag/audio/")) runCatching { player.stop() }
        runCatching { diagAudioDir().listFiles()?.forEach { it.delete() } }
    }

    /**
     * 把一轮测试的 PCM 写成标准 WAV，供界面试听。
     *
     * 只在计时全部取完之后调用，I/O 不进被测区间。文件名带用例名与时间戳，
     * 同一组实验里四轮各自成文件，方便来回对比「单图 vs 逐码本」听起来差多少。
     */
    private fun writeDiagWav(tag: String, chunks: List<ShortArray>): String = runCatching {
        val safe = tag.ifBlank { "run" }.replace(Regex("[\\\\/:*?\"<>|\\s]"), "_")
        val f = File(diagAudioDir(), "${System.currentTimeMillis()}-$safe.wav")
        val w = WavWriter(f, 24_000)
        try {
            chunks.forEach { w.write(it) }
        } finally {
            w.close()
        }
        f.absolutePath
    }.getOrElse {
        DiagLog.e("exp", tr("写试听音频失败"), it)
        ""
    }

    /** 试听某次测试的输出；再点一次暂停。 */
    fun playDiagAudio(path: String, label: String) {
        if (path.isBlank()) return
        val f = File(path)
        if (!f.isFile) { message = tr("音频文件不存在"); return }
        if (playback.path == f.absolutePath) player.toggle() else player.play(f, label)
    }

    /** 跑一批诊断；每次之间可短暂停顿以观察温度回落。结果逐次追加到 diagRuns。 */
    fun runDiagBatch(times: Int) {
        if (diagRunning) return
        if (generating) { error = tr("正在合成，稍后再测"); return }
        if (engineState !is EngineState.Ready) { error = tr("引擎仍在加载，请稍候"); return }
        diagStop = false
        diagRunning = true
        diagRuns = emptyList()
        readSocTemp()
        clearDiagAudio()
        DiagLog.begin(tr("性能诊断：${times} 次", "Performance diagnostics: ${times} runs"))
        DiagLog.i(
            "diag",
            tr("开始 后端=$backendName CPU=$cpuFeatures 引擎=$engineState 线程=$threads ", "start backend=$backendName CPU=$cpuFeatures engine=$engineState threads=$threads ") +
                tr("声码器=${if (vocoderOnGpu) "GPU·不切" else "$vocThreads 线程"} 极速=$turbo 文本=${diagText.trim().length}字", "vocoder=${if (vocoderOnGpu) "GPU·no switch" else "$vocThreads threads"} turbo=$turbo text=${diagText.trim().length} chars"),
        )
        refreshDiagLog()
        diagJob?.cancel()
        diagJob = viewModelScope.launch(Dispatchers.IO) {
            val n = times.coerceIn(1, 20)
            for (i in 1..n) {
                if (diagStop) break
                main.post { diagProgress = tr("第 $i / $n 次…", "run $i / $n…") }
                readSocTemp()
                val r = runDiagOnce(i, tag = tr("诊断$i", "diagnostic $i"))
                main.post { diagRuns = diagRuns + r }
            }
            main.post {
                diagRunning = false
                diagProgress = if (diagStop) tr("已停止") else tr("完成 · 共 ${diagRuns.size} 次", "Done · ${diagRuns.size} runs")
                readSocTemp()
                refreshDiagLog()
            }
        }
    }

    fun stopDiag() {
        diagStop = true
        engine.cancel()
    }

    fun clearDiag() {
        diagRuns = emptyList()
        diagProgress = ""
    }

    // ============ 1.9.69 对照实验：两个还没被证实的加速假设 ============

    /**
     * 一组对照里的一行。帧数随采样波动，所以一律按「每帧」比，不比总时长。
     *
     * 调度实验看两个指标：
     *   · perFrame        墙钟 / 帧——用户体感的总速度；
     *   · computePerFrame 主干 + 深度 / 帧——去掉声码器后的纯计算部分。
     *     THP 只影响权重读取，用它比墙钟更敏感，也少受声码器后端差异干扰。
     */
    data class ExpRow(
        val label: String,
        val wallMs: Long,
        val frames: Int,
        val backboneMs: Double,
        val depthMs: Double,
        val vocMs: Double,
        val rtf: Float,
        val ok: Boolean,
        val note: String = "",
        /** 本次实际 flush 次数。线程池切换就发生在每次 flush 的进出口。 */
        val flushes: Int = 0,
        /** 试听音频（原始输出，未做后处理）。 */
        val audioPath: String = "",
        val peak: Float = 0f,
        val rms: Float = 0f,
        /** 1.9.103：首声两段。文本编码 + prompt 组装，以及主干 prefill（双分支已各算一遍）。 */
        val promptMs: Double = 0.0,
        val prefillMs: Double = 0.0,
        val prefillTokens: Int = 0,
        /** 1.9.105：其中直接命中前缀 KV 的数量。>0 说明参考段没有重算。 */
        val prefillReused: Int = 0,
    ) {
        val perFrame: Double get() = if (frames > 0) wallMs.toDouble() / frames else 0.0
        val computePerFrame: Double get() = if (frames > 0) (backboneMs + depthMs) / frames else 0.0
        val depthPerFrame: Double get() = if (frames > 0) depthMs / frames else 0.0
        val vocPerFrame: Double get() = if (frames > 0) vocMs / frames else 0.0
        /** prefill 的 token 吞吐。用它判断「首声慢」是不是因为 GEMM 没吃到矩阵单元。 */
        val prefillTps: Double get() = if (prefillMs > 0.5 && prefillTokens > 0) prefillTokens * 1000.0 / prefillMs else 0.0
    }

    var expRunning by mutableStateOf(false)
        private set
    var expProgress by mutableStateOf("")
        private set
    var expRows by mutableStateOf<List<ExpRow>>(emptyList())
        private set
    var expTitle by mutableStateOf("")
        private set
    /** 跑完给出的对照结论（两组取平均后的差值），跑的过程中为空。 */
    var expVerdict by mutableStateOf("")
        private set

    /** 诊断日志的镜像（供界面直接显示）。每次跑完一次实验刷新一次。 */
    var diagLogText by mutableStateOf("")
        private set

    fun refreshDiagLog() {
        // 进程崩过一次之后内存缓冲是空的，但文件还在：内存空就从磁盘尾巴捞。
        // 上一版只读内存，用户点进「推理与性能」看到的是一张空日志卡，
        // 等于崩了以后什么线索都没有。
        val mem = DiagLog.dump()
        // 只有「启动 version=…」一两行时不值得占屏，直接看磁盘上的完整历史
        diagLogText = if (mem.count { it == '\n' } >= 5) mem else readDiagFileTail(400)
    }

    /** 强制从磁盘读，界面上给一个「读磁盘日志」按钮兜底。 */
    fun refreshDiagLogFromDisk() {
        // 1.9.93 起 GPU 探测工具（独立进程）已移除，只剩主程序这一份日志。
        val main = readDiagFileTail(300)
        diagLogText = if (main.isNotBlank()) main.trim() else tr("磁盘上也没有日志。")
    }

    private fun readDiagFileTail(n: Int): String = runCatching {
        val f = File(getApplication<Application>().filesDir, "diag/diag.log")
        if (!f.exists() || f.length() == 0L) return ""
        // 日志会越积越长，几 MB 全读进来只为看最后几十行不值当
        val limit = 256 * 1024L
        val text = if (f.length() > limit) {
            java.io.RandomAccessFile(f, "r").use { raf ->
                raf.seek(f.length() - limit)
                val bytes = ByteArray(limit.toInt())
                raf.readFully(bytes)
                String(bytes, Charsets.UTF_8)
            }
        } else {
            f.readText(Charsets.UTF_8)
        }
        val lines = text.lines()
        if (lines.isEmpty()) return ""
        tr("（以下从磁盘读取，最后 $n 行）\n", "(read from disk, last $n lines)\n") + lines.takeLast(n).joinToString("\n")
    }.getOrDefault("")

    fun clearDiagLog() {
        DiagLog.clear()
        diagLogText = ""
    }

    /** 日志落盘路径，界面上给用户看，方便直接去文件管理器取。 */
    val diagLogPath: String get() = DiagLog.logFile?.absolutePath ?: "—"

    /**
     * 对照用的长句（约 12 秒音频，实测 155 帧）。
     *
     * 必须用长文本：线程池切换发生在每次 flush 的进出口，只有 ≥2 次 flush 才有
     * 观察窗口（这句按 40/112 切是 3 次）。
     */
    private val expText =
        tr("夜里十一点，楼下的便利店还亮着灯，收银员正把当天的账目记完。") +
            tr("街上的行人渐渐少了，只有偶尔经过的公交车，把路边的树影晃得一片一片。")

    /**
     * 线程池切换 A/B（1.9.100 起唯一保留的对照）。
     *
     * voc_threads 与 gen_threads 不等时，native 每次 flush 都把线程池切过去、
     * 返回时再切回来，ggml 的 set_n_threads 每次都要重建线程池。
     *
     * 1.9.100 在本机（8 Elite / q8_0 / threads=4 / GPU 声码器 / 155 帧 3 次 flush）
     * 实测三轮交替：切8 中位数 159.8 ms/帧，不切 159.1，差 0.7 ms 而组内波动 ±17.4 ms
     * ——重建开销在噪声以下。所以 1.9.101 起 GPU 声码器默认下发 0（见
     * [effectiveVocThreads]），这组留下只为两件事：复核换了机型之后是否仍然如此，
     * 以及没装加速包（声码器在 CPU）时比较 8 线程与跟随主线程的真实差别。
     */
    fun runSwapExperiment() {
        runExpBlock(tr("声码器线程：切 8 / 不切")) {
            listOf(
                expOnce(tr("切8"), text = expText, vocThreads = 8),
                expOnce(tr("不切"), text = expText, vocThreads = 0),
                expOnce(tr("切8"), text = expText, vocThreads = 8),
                expOnce(tr("不切"), text = expText, vocThreads = 0),
                expOnce(tr("切8"), text = expText, vocThreads = 8),
                expOnce(tr("不切"), text = expText, vocThreads = 0),
            )
        }
    }

    /**
     * 1.9.102：CPU 线程数对照（2 / 3 / 4 / 6）。
     *
     * 为什么还要测：docs/24 只量过 8 → 4（主干 −11%、深度 −6%），4 以下没扫过。
     * 而批=1 的逐帧 GEMV 是带宽受限，线程开到超过 DRAM 能吃满的数量之后，
     * 多出来的线程只是在 `ggml_barrier` 里空转、顺带把机身加热（MobileSpec 在
     * 2×A78+6×A55 上量到 8 线程比 2 线程慢 2.07×，机理就是这条）。
     * 这台机器是宽核（8 Elite 类），最优值未必是 4，值得扫一遍。
     *
     * 顺序 2→3→4→6→6→4→3→2 是对称的：机身如果在 3 分钟里线性变热，
     * 每个臂的首尾两次会被摊平，不至于让排在前面的臂占便宜。
     */
    fun runThreadExperiment() {
        runExpBlock(tr("CPU 线程数：2 / 3 / 4 / 6"), ::verdictOfThreads) {
            listOf(2, 3, 4, 6, 6, 4, 3, 2).map { n ->
                expOnce(tr("${n}线程", "${n} threads"), text = expText, genThreads = n)
            }
        }
    }

    /**
     * 线程数结论：挑每帧最快的一档，但要和组内波动比。
     *
     * 只报「最快」是不够的——这条曲线上相邻两档往往只差几毫秒，落在同一台机器
     * 三分钟内的热漂移里。所以先算每档中位数，再拿最快档去和当前设置档比，
     * 差值不超过波动就直说没差别。
     */
    private fun verdictOfThreads(rows: List<ExpRow>): String {
        val ok = rows.filter { it.ok && it.frames > 0 }
        if (ok.isEmpty()) return tr("没有成功样本，无法对照")

        val arms = ok.groupBy { it.label }
        val med = arms.mapValues { (_, v) -> median(v.map { it.perFrame }.sorted()) }
        val spread = arms.values.maxOf { v ->
            val s = v.map { it.perFrame }.sorted()
            s.last() - s.first()
        }
        val order = med.entries.sortedBy { it.value }
            .joinToString(" · ") { "%.1f".format(it.value) + "（" + it.key + "）" }
        val bestEntry = med.entries.minByOrNull { it.value }!!
        val bestLabel = bestEntry.key
        val best = bestEntry.value
        val curLabel = tr("${threads}线程", "${threads} threads")
        val cur = med[curLabel]

        val head = tr("每帧中位数（快→慢）：$order", "Median ms/frame (fast→slow): $order")
        val body = when {
            cur == null -> tr("本次没有测「$curLabel」这一档，无法和当前设置比。", "This run didn't cover \"$curLabel\", so it can't be compared with the current setting.")
            bestLabel == curLabel -> tr("当前设置（$curLabel）就是最快档，组内波动 ±%.1f ms/帧。", "The current setting ($curLabel) is already the fastest, with a spread of ±%.1f ms/frame.").format(spread)
            cur - best <= spread -> tr("最快档 $bestLabel 比当前 $curLabel 快 %.1f ms/帧，", "The fastest tier $bestLabel beats the current $curLabel by %.1f ms/frame,") +
                tr("但组内波动就有 ±%.1f ms，**没有可测量的差别**。").format(cur - best, spread)
            else -> tr("最快档 **$bestLabel**，比当前的 $curLabel 每帧省 %.1f ms（%.0f%%），", "Fastest is **$bestLabel**, saving %.1f ms per frame (%.0f%%) over $curLabel,") +
                tr("波动 ±%.1f ms。\n建议：把设置里的线程数改成 %s。").format(
                    cur - best, (cur - best) / cur * 100, spread, bestLabel.removeSuffix(tr("线程")),
                )
        }
        return "$head\n$body"
    }

    /**
     * 1.9.106：码本截断对照（15 / 12 / 10 / 8）。
     *
     * 深度解码占整帧 65%（实测 97.7 ms/帧），而它每帧必须把 333 M 权重读 15 遍——
     * 这份字节量由结构决定，带宽上再优化不出东西。唯一能减的是遍数。
     *
     * 顺序 15→12→10→8→8→10→12→15 对称：这台机器两分钟内会明显变热，
     * 对称排列能把线性漂移摊到各臂上。
     *
     * 注意这一组不像线程数那样能自动给结论：少解码本会改变音色细节，
     * 时间账能算，音质必须耳朵听。
     */
    fun runCodebookExperiment() {
        runExpBlock(tr("码本截断：15 / 12 / 10 / 8"), ::verdictOfCodebooks) {
            listOf(15, 12, 10, 8, 8, 10, 12, 15).map { n ->
                expOnce(tr("${n}码本", "${n} codebooks"), text = expText, codebooks = if (n >= 15) 0 else n)
            }
        }
    }

    /**
     * 码本截断结论：以 15 码本为基线，报每档的整帧与深度变化。
     *
     * 另附一列「输出帧数」——截断会改变主干输入，帧数可能跟着漂；如果某一档
     * 帧数明显偏离，说明模型已经在跑偏，那一段的耗时不能直接当收益看。
     */
    private fun verdictOfCodebooks(rows: List<ExpRow>): String {
        val ok = rows.filter { it.ok && it.frames > 0 }
        if (ok.isEmpty()) return tr("没有成功样本，无法对照")

        val arms = ok.groupBy { it.label }
        fun num(k: String) = k.removeSuffix(tr("码本")).toIntOrNull() ?: 0
        val med = arms.map { (k, v) ->
            Triple(k, median(v.map { it.perFrame }.sorted()),
                median(v.map { it.depthMs / it.frames }.sorted()))
        }.sortedByDescending { num(it.first) }
        val base = med.firstOrNull { eqTr(it.first, "15码本") }

        val lines = med.joinToString("\n") { (k, pf, df) ->
            val dPct = if (base != null && base.third > 0) (df / base.third - 1.0) * 100 else 0.0
            val fPct = if (base != null && base.second > 0) (pf / base.second - 1.0) * 100 else 0.0
            tr("%s · 每帧 %.1f ms（%+.0f%%）· 深度 %.1f ms（%+.0f%%）").format(k, pf, fPct, df, dPct)
        }
        val fr = arms.entries.sortedByDescending { num(it.key) }
            .joinToString(" / ") { tr("${it.key} ${median(it.value.map { r -> r.frames.toDouble() }.sorted()).toInt()} 帧", "${it.key} ${median(it.value.map { r -> r.frames.toDouble() }.sorted()).toInt()} frames") }

        return tr("按码本数（多→少）：\n$lines\n输出长度：$fr\n", "By codebook count (many→few):\n$lines\nOutput length: $fr\n") +
            tr("音质只能耳朵判断：逐条试听，重点听尾音、气声、齿音是否发闷、断续或念错字。") +
            tr("如果 10 码本的段落听不出差别，就把它当默认值——整帧直接省两成。")
    }

    fun stopExperiment() {
        diagStop = true
        engine.cancel()
    }

    fun clearExperiment() {
        expRows = emptyList()
        expTitle = ""
        expProgress = ""
        expVerdict = ""
    }

    private fun runExpBlock(
        title: String,
        verdictFn: (List<ExpRow>) -> String = { verdictOf(it) },
        block: suspend () -> List<ExpRow>,
    ) {
        if (expRunning) return
        if (generating) { error = tr("正在合成，稍后再测"); return }
        if (engineState !is EngineState.Ready) { error = tr("引擎仍在加载，请稍候"); return }
        diagStop = false
        expRunning = true
        expTitle = title
        expRows = emptyList()
        expVerdict = ""
        expProgress = tr("准备中…")
        clearDiagAudio()
        DiagLog.begin(tr("实验：$title", "Experiment: $title"))
        DiagLog.i(
            "exp",
            tr("开始 后端=${backendName} CPU=${cpuFeatures} 引擎=${engineState} ", "start backend=${backendName} CPU=${cpuFeatures} engine=${engineState} ") +
                tr("线程=$threads 分阶段=$phaseThreads 声码器=${if (vocoderOnGpu) "GPU·不切" else "$vocThreads 线程"} 极速=$turbo ", "threads=$threads phased=$phaseThreads vocoder=${if (vocoderOnGpu) "GPU·no switch" else "$vocThreads threads"} turbo=$turbo ") +
                tr("模型=${activeModelId}", "model=${activeModelId}"),
        )
        refreshDiagLog()
        viewModelScope.launch(Dispatchers.IO) {
            var rows = emptyList<ExpRow>()
            try {
                rows = block()
            } catch (t: Throwable) {
                DiagLog.e("exp", tr("实验中断"), t)
                main.post { error = t.message ?: tr("实验失败") }
            }
            val out = rows
            val verdict = if (diagStop) "" else verdictFn(out)
            DiagLog.i(
                "exp",
                tr("结束 成功=${out.count { it.ok }}/${out.size} 停止=$diagStop 结论=${verdict.ifBlank { "无" }}", "end ok=${out.count { it.ok }}/${out.size} stopped=$diagStop verdict=${verdict.ifBlank { "无" }}"),
            )
            main.post {
                expRows = out
                expRunning = false
                expProgress = if (diagStop) tr("已停止") else tr("完成 · 共 ${out.size} 次", "Done · ${out.size} runs")
                expVerdict = verdict
                refreshDiagLog()
            }
        }
    }

    /**
     * 整组跑完后的对照结论。
     *
     * 两个通用原则：
     *   1. 比「每帧毫秒」，不比总时长——采样带随机性，同一句话跑出来的帧数会差几帧，
     *      拿总耗时比会把帧数差异算成速度差异；
     *   2. 差值必须大于组内波动才认账，否则只是机身温度在变。
     */
    private fun verdictOf(rows: List<ExpRow>): String {
        val ok = rows.filter { it.ok && it.frames > 0 }
        if (ok.isEmpty()) return ""

        val a = ok.filter { eqTr(it.label, "切8") }
        val b = ok.filter { eqTr(it.label, "不切") }
        if (a.isEmpty() || b.isEmpty())
            return tr("数据不全：切8 ${a.size} 条 / 不切 ${b.size} 条，无法对照", "Incomplete data: ${a.size} switch runs vs ${b.size} no-switch runs — nothing to compare")

        val xa = a.map { it.perFrame }.sorted()
        val xb = b.map { it.perFrame }.sorted()
        val ma = median(xa)
        val mb = median(xb)
        // 组内极差 = 同一臂几轮之间自己晃动的幅度，差值小于它就是噪声
        val spread = maxOf(xa.last() - xa.first(), xb.last() - xb.first())
        val diff = ma - mb
        val gain = if (diff < 0) -diff else diff
        val base = if (diff > 0) ma else mb

        val head = tr("声码器后端：") + if (vocoderOnGpu)
            tr("GPU（这组测的是线程池重建的空转开销；1.9.101 起默认已不切）")
        else
            tr("CPU（这组同时含声码器线程数的真实收益）") +
                if (threads == 8) tr("\n⚠ 主线程数也是 8，A 臂不会触发切换，这组没有区分度。") else ""

        val body = if (gain <= spread) {
            tr("切8 %.1f · 不切 %.1f ms/帧 → 差 %.1f ms，小于组内波动 ±%.1f：没有可测量的差别")
                .format(ma, mb, gain, spread)
        } else {
            val faster = if (diff > 0) tr("不切") else tr("切8")
            tr("$faster 每帧省 %.1f ms（%.0f%%），组内波动 ±%.1f", "$faster saves %.1f ms per frame (%.0f%%), spread ±%.1f")
                .format(gain, gain / base * 100, spread) +
                if (diff <= 0) tr("\n建议：保留设置里的声码器线程数，CPU 声码器确实吃更多线程。") else ""
        }
        return "$head\n$body"
    }

    /** 中位数：样本只有 3 个，均值会被一次热漂移整体带偏。 */
    private fun median(v: List<Double>): Double = when {
        v.isEmpty() -> 0.0
        v.size % 2 == 1 -> v[v.size / 2]
        else -> (v[v.size / 2 - 1] + v[v.size / 2]) / 2
    }

    private suspend fun expOnce(
        label: String,
        text: String? = null,
        /** null = 用设置里的值；0 = 不切线程池；8 = flush 期间切到 8 线程。 */
        vocThreads: Int? = null,
        /** null = 用设置里的线程数；其余 = 本次的 CPU 线程数。 */
        genThreads: Int? = null,
        /** null / 0 = 全部码本；N = 只解前 N 个（1.9.106 截断实验）。 */
        codebooks: Int? = null,
    ): ExpRow {
        main.post { expProgress = tr("$label 运行中…", "$label running…") }
        DiagLog.i(
            "exp",
            tr("—— 用例「$label」 vocThreads=${vocThreads ?: "设置值"} genThreads=${genThreads ?: "设置值"} ", "— case \"$label\" vocThreads=${vocThreads ?: "设置值"} genThreads=${genThreads ?: "设置值"} ") +
                tr("截断=${codebooks?.takeIf { it > 0 } ?: "全"} ——", "truncation=${codebooks?.takeIf { it > 0 } ?: "全"} —"),
        )
        val r = runDiagOnce(
            0, textOverride = text, tag = label,
            vocThreadsOverride = vocThreads, threadsOverride = genThreads,
            codebooksOverride = codebooks,
        )
        return ExpRow(
            label = label,
            wallMs = r.wallMs,
            frames = r.stage.frames,
            backboneMs = r.stage.backboneMs,
            depthMs = r.stage.depthMs,
            vocMs = r.stage.vocoderMs,
            rtf = r.rtf,
            ok = r.ok,
            note = r.message,
            flushes = r.stage.flushes,
            audioPath = r.audioPath,
            peak = r.peak,
            rms = r.rms,
            promptMs = r.stage.promptMs,
            prefillMs = r.stage.prefillMs,
            prefillTokens = r.stage.prefillTokens,
            prefillReused = r.stage.prefillReused,
        )
    }

    /**
     * 把历次诊断结果导出成纯文本。
     *
     * 目的是让「把结果发出去」变成一次复制粘贴，而不是逐张截图——截图既看不清小数位，
     * 也没法把线程配置、flush 次数这些关键上下文一起带走。
     */
    fun diagReport(): String {
        if (diagRuns.isEmpty()) return ""
        val sb = StringBuilder()
        sb.append("BreezeTTS v").append(BuildConfig.VERSION_NAME)
            .append(tr(" 诊断 · ")).append(diagRuns.size).append(tr(" 次\n"))
        sb.append(tr("文本：")).append(diagText.trim()).append('\n')
        val voiceName = voices.firstOrNull { it.id == selectedVoiceId }?.name ?: tr("未选择")
        sb.append(tr("音色 ")).append(voiceName)
            .append(tr(" · 表达 ")).append(instruction.trim().ifBlank { tr("无") }).append('\n')
        // 1.9.47 起分阶段/绑核/降 CFG 的开关都删了，这里只留会变的两项。
        sb.append(tr("线程 ")).append(threads)
            .append(tr(" · 极速模式 ")).append(if (turbo) tr("开") else tr("关"))
            .append(tr(" · 声码器 ")).append(if (vocoderOnGpu) tr("GPU·不切线程") else tr("$vocThreads 线程", "$vocThreads threads"))
            .append(" · cfg ").append("%.1f".format(effectiveCfg))
            .append(tr(" · 后端 ")).append(backendName).append('\n')
        diagRuns.forEach { r ->
            val s = r.stage
            sb.append('\n')
            if (!r.ok) {
                sb.append("#").append(r.index).append(tr(" 失败：")).append(r.message).append('\n')
                return@forEach
            }
            sb.append(
                tr("#%d · RTF %.2f · %.1f 秒音频 · 墙钟 %d ms · %d 帧 · %d flush · 电池 %s\n").format(
                    r.index, r.rtf, s.frames * 80 / 1000.0, r.wallMs, s.frames, s.flushes,
                    r.tempC?.let { "%.1f°C".format(it) } ?: "—",
                ),
            )
            sb.append(
                tr("   编码 %.0f / 预填 %.0f / 主干 %.0f / 深度 %.0f / 声码器 %.0f / 收尾 %.0f ms\n")
                    .format(
                        s.promptMs, s.prefillMs, s.backboneMs, s.depthMs, s.vocoderMs, s.tailMs,
                    ),
            )
            // 声码器只解码真实帧：首块 start=0，滑窗上下文是空的，解码帧数就等于输出帧数。
            // 1.9.43 之前这里除以 (frames + flushes*88)，短句只有一次 flush 时会把
            // 54 ms/帧 摊成 14 ms/帧，少看了 4 倍。第二块起才会多算 88 帧上下文，
            // 那是长句的情况，用 flush 次数自己判断。
            val perFrame = if (s.frames > 0) s.vocoderMs / s.frames else 0.0
            sb.append(
                tr("   声码器 %.1f ms/帧 · %d 次 flush · cfg %.1f · 块 %d 帧\n").format(
                    perFrame, s.flushes, r.cfg, r.chunk,
                ),
            )
        }
        return sb.toString().trimEnd()
    }

    fun synthesize() {
        if (generating || diagRunning) return
        if (modelState !is ModelState.Ready) { error = tr("模型还没准备好"); return }
        if (engineState !is EngineState.Ready) { error = tr("引擎仍在加载，请稍候"); return }
        if (text.isBlank()) { error = tr("请输入要合成的文本"); return }

        // 转换页没有「生成语音」按钮，但快捷键 / 外部调用仍可能打进来：
        // 此时 text 属于别的模式，直接忽略，避免生成出不相干的一段。
        if (synthMode == SynthMode.CONVERT) return
        if (converting) { error = tr("正在转换音频，等它结束再生成"); return }
        if (synthMode == SynthMode.DIALOGUE) { synthesizeDialogue(); return }

        // 锁定结果归属：生成中即便切了 tab，结果也写回单人槽；name 在这一刻定死
        resultOwner = SynthMode.SINGLE
        val usedText = text.trim()
        val usedVoiceName = voiceName(selectedVoiceId)
        val voice = voices.firstOrNull { it.id == selectedVoiceId }

        resetForRun()

        val myToken = ++sessionToken

        // 字数 → 预计音频时长：先按 native 的估算器定令牌预算，再按「学到的每单位时长」
        // 定进度条分母。两者分开，是因为预算要留余量、分母要尽量准。
        // 注意：estimateFrames 在 native 侧要拿引擎锁（合成期间被占着），
        // 所以只在引擎空闲时问它，否则退回按字数粗估——绝不能在主线程上被锁住。
        val estFrames = (if (!engine.isBusy) engine.estimateFrames(usedText) else 0)
            .takeIf { it > 0 } ?: (usedText.length * 3)
        val units = unitsOf(usedText)
        val expectedMs = (units * settings.msPerUnit.value).toLong().coerceIn(800L, 600_000L)
        // 2.6 倍余量：给「语速缓慢」这类指令留空间。真正防跑飞的是 native 的尾帧保护，
        // 这里只是兜底，所以宁可给宽一点，绝不截断。
        val maxFrames = (estFrames * 2.6f).toInt().coerceIn(120, 1_400)
        // 提前算好：onStats 的日志要用到，而那时还没走到下面构造请求的地方。
        val plan = chunkPlanFor(estFrames)
        expectedMsForBar = expectedMs

        // 预缓冲：RTF 越高越要多攒一点再开播；再跟「预计总长的 60%」取小，短句不白等。
        val prebuffer = prebufferFor(expectedMs)

        val out = File(getApplication<Application>().cacheDir, "preview.wav")
        // muted：生成过程只统计已产出时长，不出声。想听就直接播结果。
        val p = StreamingPlayer(prebufferMs = prebuffer, muted = true)
        p.start()
        streamingPlayer = p
        val w = WavWriter(out)
        writer = w
        lastWav = out

        engine.onChunk = chunk@{ pcm ->
            if (myToken != sessionToken) return@chunk
            p.write(pcm)
            w.write(pcm)
            val now = System.currentTimeMillis()
            val produced = p.producedMs
            val dAudio = produced - lastChunkProducedMs
            val dWall = now - lastChunkWallMs
            if (dAudio > 0 && dWall > 0) {
                val sample = dWall.toDouble() / (dAudio / 80.0)      // 80 ms 一帧
                frameMs = if (frameMs <= 0.0) sample else frameMs * 0.5 + sample * 0.5
            }
            lastChunkProducedMs = produced
            lastChunkWallMs = now
            lastChunkAt = now
            // 进度不再进 UI：生成卡片只显示 1 Hz 的「已用秒数」，这里只留内部外推用的采样。
            progressTarget = (produced.toFloat() / expectedMs.toFloat()).coerceIn(0f, 0.98f)
        }
        // 逐帧进度：分块变大后不能再只靠 onChunk（一块最长 96 帧 = 7.7 秒音频，
        // 这期间进度条会完全不动，看着像卡死）。帧率 12.5 → 一帧 80 ms，
        // 拿「已生成音频毫秒 / 预计总长」当分母，与 onChunk 的口径一致。
        engine.onProgress = prog@{ frame, _ ->
            if (myToken != sessionToken) return@prog
            val ms = frame * 80L
            progressTarget = (ms.toFloat() / expectedMs.toFloat()).coerceIn(0f, 0.98f)
        }
        engine.onStats = timing@{ t ->
            if (myToken != sessionToken) return@timing
            main.post { if (myToken == sessionToken) stageStats = t }
            // 正式合成也落一条与诊断实验同格式的行。用户报「合成比测试慢」时，
            // 之前只能靠猜参数；现在两行并排就能看出是哪一段变长（docs/83）。
            DiagLog.i(
                "synth",
                tr("计时 frames=${t.frames} flushes=${t.flushes} ", "timings frames=${t.frames} flushes=${t.flushes} ") +
                    "prompt=${t.promptMs.f1()} prefill=${t.prefillMs.f1()} " +
                    "backbone=${t.backboneMs.f1()} depth=${t.depthMs.f1()} " +
                    "voc=${t.vocoderMs.f1()} tail=${t.tailMs.f1()} " +
                    tr("chunk=${plan.first}/${plan.second} 文本${usedText.length}字", "chunk=${plan.first}/${plan.second} text ${usedText.length} chars"),
            )
        }
        engine.onDone = done@{ st ->
            if (myToken != sessionToken) return@done
            runCatching { w.close() }
            val elapsed = System.currentTimeMillis() - synthStartedAt
            val finalStats = st.copy(elapsedMs = elapsed)
            // 同一套字段：rtf 的分母是音频时长，短句的分母小，固定开销摊不开就会显得很慢。
            DiagLog.i(
                "synth",
                tr("完成 frames=${st.frames} 音频=${st.audioMs}ms 墙钟=${elapsed}ms ", "done frames=${st.frames} audio=${st.audioMs}ms wall=${elapsed}ms ") +
                    "rtf=${"%.2f".format(finalStats.rtf)} " +
                    "cfg=${"%.1f".format(effectiveCfg)} turbo=$turbo " +
                    tr("音色=$usedVoiceName 指令=${if (instruction.isBlank()) "无" else "${instruction.trim().length}字"}", "voice=$usedVoiceName instruction=${if (instruction.isBlank()) "无" else "${instruction.trim().length}字"}"),
            )
            // 记住这台设备的实时率与「每单位时长」，下一段自动调好预缓冲与进度分母
            if (finalStats.audioMs > 0) settings.setLastRtf(finalStats.rtf)
            if (units > 0.5f && finalStats.audioMs > 400) {
                settings.learnMsPerUnit(finalStats.audioMs / units)
            }
            main.post {
                if (myToken != sessionToken) return@post
                writer = null
                streamingPlayer = null
                generating = false
                progress = 1f
                progressTarget = 1f
                stats = finalStats
                statusLine = tr("完成 · ${st.frames} 帧 / %.1f 秒音频", "Done · ${st.frames} frames / %.1f s audio").format(st.audioMs / 1000.0)
                // 不自动入库：记下这一轮的文本/音色/时长，等用户点「收藏」再复制
                lastResultText = usedText
                lastResultVoice = usedVoiceName
                lastResultDurationMs = st.audioMs
                lastResultFavorited = false
                activeResult.name = buildResultName(listOf(usedVoiceName), usedText)
                bumpResult()
            }
            // 尾音交给播放器自己的线程放完。以前是在这里同步等「缓冲播完」，
            // 而这段等待发生在 native 回调线程上，会把「生成完成」一起拖住——
            // 音频明明已经写完了，界面却要再卡几十秒。
            tailPlayer = p
            p.finishAsync {
                if (tailPlayer === p) tailPlayer = null
                if (streamingPlayer === p) streamingPlayer = null
            }
        }
        engine.onError = err@{ msg ->
            if (myToken != sessionToken) return@err
            runCatching { w.close() }
            p.stopNow()
            main.post {
                if (myToken != sessionToken) return@post
                writer = null
                streamingPlayer = null
                generating = false
                progress = 0f
                progressTarget = 0f
                error = msg
                statusLine = ""
            }
        }

        val (voiceCached, codesOut) = codesCacheFor(voice)
        val req = SynthRequest(
            text = usedText,
            instruction = instruction.trim(),
            voice = voiceCached,
            seed = seed,
            temperature = temperature,
            topP = topP,
            cfgScale = effectiveCfg,
            maxFrames = maxFrames,
            // 分块见 chunkPlanFor：首块短句一次 flush 到底、长句等分，保证首声快；
            // 上限取设置档位，决定之后每块攒多少（块越大，声码器重算越少）。见 docs/47、81。
            chunkFirst = plan.first,
            chunkMax = plan.second,
            codesOut = codesOut,
            reusePrefixEmb = reusePrefixEmb,
            cfgDecayFrames = effectiveCfgDecay,
            depthCfgOff = depthCfgOff,
            vocThreads = effectiveVocThreads,
        )
        synthJob = viewModelScope.launch(Dispatchers.IO) {
            engine.synthesize(req)
            withContext(Dispatchers.Main) {
                if (myToken == sessionToken && generating) generating = false
            }
        }
        startProgressTicker(myToken)
    }

    /**
     * 把跳变的进度磨成匀速：每个 tick 都朝 progressTarget 逼近一段，
     * 于是 0.3 → 0.8 这种「块边界跳变」看起来是连续爬升。
     * 同时盯住「多久没出新音频」——收尾阶段没有新块，明确提示而不是让界面像卡死。
     */
    private fun startProgressTicker(token: Int) {
        tickerJob?.cancel()
        tickerJob = viewModelScope.launch {
            while (isActive && token == sessionToken && generating) {
                // 1 Hz 是刻意的：生成页上任何更高频的变化都会让屏幕停在 60/120 Hz，
                // 把 1.9.75 那条「生成中不产生新帧」的收益全部抵消（docs/84）。
                delay(1_000)
                if (token != sessionToken) break
                val now = System.currentTimeMillis()
                genElapsedSec = ((now - synthStartedAt) / 1000).toInt().coerceAtLeast(1)

                // 阈值按「最慢的正常情况」定：一块上限 250 帧 = 20 秒音频，生成约 12 秒；
                // 45 秒没新块才提收尾，90 秒才告警，避免正常长文被误判。
                val idle = now - lastChunkAt
                statusLine = when {
                    idle > 90_000 -> tr("仍在生成，长文本可能需要更久")
                    idle > 45_000 -> tr("正在收尾，解码最后一段音频")
                    // 新块回来之后要把超时文案收回去，否则「正在收尾」会一直挂到结束。
                    // 对话模式的「第 x/y 句」不以这两个前缀开头，不会被覆盖。
                    startsWithTr(statusLine, "正在收尾") || startsWithTr(statusLine, "仍在生成") ->
                        tr("正在生成，请稍等…")
                    statusLine.isBlank() -> tr("正在生成，请稍等…")
                    else -> statusLine
                }
            }
        }
    }

    fun stop() {
        // 先作废这一轮的 token，之后任何 native 回调都不会再改界面
        sessionToken++
        engine.cancel()
        synthJob?.cancel()
        synthJob = null
        tickerJob?.cancel()
        tickerJob = null
        streamingPlayer?.stopNow()
        streamingPlayer = null
        tailPlayer?.stopNow()
        tailPlayer = null
        runCatching { writer?.close() }
        writer = null
        generating = false
        progress = 0f
        progressTarget = 0f
        statusLine = ""
    }

    /** 「发音单位」数：CJK / 全角字符算 1，其余（拉丁字母、数字、空格）算 0.3。 */
    private fun unitsOf(t: String): Float {
        var u = 0f
        for (ch in t) u += if (ch.code > 0x2E7F) 1f else 0.3f
        return u.coerceAtLeast(1f)
    }

    // ================= 多角色对话 =================
    /**
     * 逐句合成：每句切到这句的角色音色与情绪，PCM 依次追加进同一个 WAV，
     * 句间插 260 ms 静音当换人停顿。
     *
     * 为什么逐句串行而不是拆成多个引擎任务：只有一个引擎实例、一份 KV cache，
     * 串行是唯一不炸显存/内存的做法；好处是进度、停止、导出都沿用单人那一套。
     * 引擎在两次调用之间是空闲的，正好可以问它要这句的帧预算。
     */
    private fun synthesizeDialogue() {
        val lines = ScriptParser.parse(text)
        ScriptParser.firstProblem(lines)?.let { error = it; return }

        resultOwner = SynthMode.DIALOGUE
        resetForRun()
        val myToken = ++sessionToken

        val totalUnits = lines.sumOf { unitsOf(it.text).toDouble() }.toFloat().coerceAtLeast(1f)
        val expectedMs = (totalUnits * settings.msPerUnit.value).toLong().coerceIn(1_200L, 1_800_000L)
        expectedMsForBar = expectedMs

        val out = File(getApplication<Application>().cacheDir, "preview.wav")
        val p = StreamingPlayer(prebufferMs = prebufferFor(expectedMs), muted = true)
        p.start()
        streamingPlayer = p
        val w = WavWriter(out)
        writer = w
        lastWav = out

        val gap = ShortArray(SAMPLE_RATE * GAP_MS / 1000)

        synthJob = viewModelScope.launch(Dispatchers.IO) {
            var failed: String? = null
            var frames = 0
            var audioMs = 0L
            var stage = StageTimings()
            var doneMs = 0L

            try {
                for (i in lines.indices) {
                    if (myToken != sessionToken) break
                    val line = lines[i]
                    val v = voiceForName(line.speaker)
                    val who = line.speaker?.takeIf { it.isNotBlank() }
                        ?: voiceName(selectedVoiceId)
                    val instr = line.emotion.ifBlank { instruction.trim() }

                    withContext(Dispatchers.Main) {
                        if (myToken == sessionToken) {
                            statusLine = tr("第 ${i + 1}/${lines.size} 句 · $who", "Line ${i + 1}/${lines.size} · $who")
                        }
                    }

                    val lineBaseMs = doneMs
                    var produced = 0L
                    var lineAudio = 0L
                    val startedAt = System.currentTimeMillis()

                    engine.onChunk = { pcm ->
                        if (myToken == sessionToken) {
                            p.write(pcm)
                            w.write(pcm)
                            produced += pcm.size
                            val ms = lineBaseMs + produced * 1000 / SAMPLE_RATE
                            progressTarget = (ms.toFloat() / expectedMs).coerceIn(0f, 0.99f)
                            lastChunkAt = System.currentTimeMillis()
                        }
                    }
                    engine.onProgress = prog@{ frame, _ ->
                        if (myToken != sessionToken) return@prog
                        val ms = lineBaseMs + frame * 80L
                        progressTarget = (ms.toFloat() / expectedMs).coerceIn(0f, 0.99f)
                    }
                    engine.onStats = { t -> stage += t }
                    engine.onDone = { st ->
                        frames += st.frames
                        lineAudio = st.audioMs
                        audioMs += st.audioMs
                    }
                    engine.onError = { msg -> failed = msg }

                    // 引擎两次调用之间是空闲的，可以安全地问帧预算
                    val est = engine.estimateFrames(line.text)
                    val maxF = if (est > 0) (est * 2.6f).toInt().coerceIn(120, 1_400) else 900
                    val (lineVoice, lineCodesOut) = codesCacheFor(v)
                    val plan = chunkPlanFor(est)
                    val ok = engine.synthesize(
                        SynthRequest(
                            text = line.text,
                            instruction = instr,
                            voice = lineVoice,
                            seed = seed + i,
                            temperature = temperature,
                            topP = topP,
                            cfgScale = effectiveCfg,
                            maxFrames = maxF,
                            chunkFirst = plan.first,
                            chunkMax = plan.second,
                            codesOut = lineCodesOut,
                            reusePrefixEmb = reusePrefixEmb,
                            cfgDecayFrames = effectiveCfgDecay,
                            depthCfgOff = depthCfgOff,
                            vocThreads = effectiveVocThreads,
                        ),
                    )
                    if (myToken != sessionToken) break
                    if (!ok || failed != null) {
                        if (failed == null) failed = tr("第 ${i + 1} 句生成失败", "Line ${i + 1} failed")
                        break
                    }

                    // 用这一句的实测速度校准「每帧耗时」，进度条在下一句里也能匀速爬
                    val wall = (System.currentTimeMillis() - startedAt).coerceAtLeast(1L)
                    if (lineAudio > 200) {
                        val sample = wall.toDouble() / (lineAudio / 80.0)
                        frameMs = if (frameMs <= 0.0) sample else frameMs * 0.5 + sample * 0.5
                    }
                    doneMs = lineBaseMs + lineAudio
                    if (i < lines.lastIndex) {
                        p.write(gap)
                        w.write(gap)
                        doneMs += GAP_MS
                    }
                }
            } catch (t: Throwable) {
                if (t !is kotlinx.coroutines.CancellationException) {
                    failed = failed ?: (t.message ?: tr("生成中断"))
                }
            } finally {
                runCatching { w.close() }
            }

            if (myToken != sessionToken) return@launch

            withContext(Dispatchers.Main) {
                if (myToken != sessionToken) return@withContext
                writer = null
                streamingPlayer = null
                generating = false
                val err = failed
                if (err != null) {
                    progress = 0f
                    progressTarget = 0f
                    statusLine = ""
                    error = err
                    p.stopNow()
                } else {
                    val elapsed = System.currentTimeMillis() - synthStartedAt
                    progress = 1f
                    progressTarget = 1f
                    stats = EngineStats(frames = frames, audioMs = audioMs, elapsedMs = elapsed)
                    stageStats = stage
                    statusLine = tr("完成 · ${lines.size} 句 / %.1f 秒音频", "Done · ${lines.size} lines / %.1f s audio").format(audioMs / 1000.0)
                    if (audioMs > 0) settings.setLastRtf(elapsed.toFloat() / audioMs)
                    tailPlayer = p
                    p.finishAsync {
                        if (tailPlayer === p) tailPlayer = null
                        if (streamingPlayer === p) streamingPlayer = null
                    }
                    val summary = lines.take(2).joinToString(" / ") { it.text }
                    val label = tr("多角色对话 · ${lines.size} 句", "Dialogue · ${lines.size} lines")
                    lastResultText = summary
                    lastResultVoice = label
                    lastResultDurationMs = audioMs
                    lastResultFavorited = false
                    // 按出场顺序取各角色的音色名（speaker → 绑定音色 → 名字）
                    val speakerVoices = lines.mapNotNull { line ->
                        line.speaker?.trim()?.takeIf { it.isNotEmpty() }?.let { spk ->
                            voiceForName(spk)?.name ?: spk
                        }
                    }.ifEmpty { listOf(voiceName(selectedVoiceId)) }
                    activeResult.name = buildResultName(speakerVoices, text)
                    bumpResult()
                }
            }
        }
        startProgressTicker(myToken)
    }

    /** 导出上一次生成结果：直接用生成时锁定的固定名字 */
    fun exportLast() {
        val src = lastWav
        if (src == null || !src.isFile || src.length() < 1000) {
            message = tr("还没有可导出的音频"); return
        }
        val base = resultName.ifBlank { favFileName(lastResultVoice, lastResultText, 1).removeSuffix(".wav") }
        exportFile(src, "$base.wav")
    }

    /** 从收藏夹条目导出：同一套命名规则，单条从 0001 起。 */
    fun exportHistory(item: HistoryItem) {
        val src = File(item.path)
        if (!src.isFile || src.length() < 1000) {
            message = tr("音频文件已丢失：${item.title}", "The audio file is gone: ${item.title}"); return
        }
        exportFile(src, favFileName(item.voiceName, item.text, 1))
    }

    /**
     * 生成结果的固定显示名：`音色名_台词前十个字_yyyy_MM_dd_序列号`。
     * 单人音色名是一个；多人按出场顺序用 `_` 连接各角色音色名。
     * 序列号取自 settings 的全局递增计数，生成那一刻锁定，改输入框不再变动。
     */
    private fun buildResultName(voiceNames: List<String>, text: String): String {
        fun clean(raw: String, max: Int): String = raw
            .replace(Regex("[\\/:*?\"<>|\r\n\t_]+"), "")
            .replace(Regex("\\s+"), "")
            .trim()
            .take(max)
        val v = voiceNames.mapNotNull { clean(it, 12).ifBlank { null } }
            .distinct()
            .joinToString("_")
            .ifBlank { tr("语音") }
        val t = clean(text, 10).ifBlank { tr("未命名") }
        val date = SimpleDateFormat("yyyy_MM_dd", Locale.getDefault()).format(Date())
        val seq = settings.nextAudioSeq()
        return "%s_%s_%s_%05d".format(v, t, date, seq)
    }

    /**
     * 导出文件名：`音色名_台词前十个字_四位数序列号.wav`。
     * 去掉空白与文件系统非法字符；音色为空时用「语音」，台词为空时用「未命名」。
     */
    private fun favFileName(voice: String, text: String, seq: Int): String {
        fun clean(raw: String, max: Int): String = raw
            .replace(Regex("[\\/:*?\"<>|\r\n\t]+"), "")
            .replace(Regex("\\s+"), "")
            .trim()
            .take(max)

        val v = clean(voice, 12).ifBlank { tr("语音") }
        val t = clean(text, 10).ifBlank { tr("未命名") }
        return "%s_%s_%04d.wav".format(v, t, seq)
    }

    private fun exportFile(src: File, name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val display = exportFileSync(src, name)
                main.post { message = tr("导出成功：$display", "Exported: $display") }
            } catch (t: Throwable) {
                Log.e("AppViewModel", "export", t)
                main.post { message = tr("导出失败：${t.message ?: "未知错误"}", "Export failed: ${t.message ?: "unknown error"}") }
            }
        }
    }

    /** 同步版导出，批量导出时逐条调用。返回给用户看的目标路径。 */
    private fun exportFileSync(src: File, name: String): String =
        settings.exportUri?.let { tree ->
            exportToSaf(src, tree, name)
            "${settings.exportDirLabel.value}/$name"
        } ?: run {
            exportToMediaStore(src, name)
            "${settings.defaultExportLabel}/$name"
        }

    private fun exportToMediaStore(src: File, name: String) {
        val cv = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/BreezeTTS")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val resolver = getApplication<Application>().contentResolver
        val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv)
            ?: error(tr("无法在音乐目录创建文件"))
        resolver.openOutputStream(uri)?.use { os -> src.inputStream().use { it.copyTo(os) } }
            ?: error(tr("无法写入导出文件"))
        cv.clear()
        cv.put(MediaStore.Audio.Media.IS_PENDING, 0)
        resolver.update(uri, cv, null, null)
    }

    private fun exportToSaf(src: File, tree: Uri, name: String) {
        val resolver = getApplication<Application>().contentResolver
        val parent = DocumentsContract.buildDocumentUriUsingTree(
            tree, DocumentsContract.getTreeDocumentId(tree),
        )
        val doc = DocumentsContract.createDocument(resolver, parent, "audio/wav", name)
            ?: error(tr("无法在所选目录创建文件（请重新选择导出位置）"))
        resolver.openOutputStream(doc)?.use { os -> src.inputStream().use { it.copyTo(os) } }
            ?: error(tr("无法写入所选目录"))
    }

    override fun onCleared() {
        stop()
        player.stop()
        engine.release()
        super.onCleared()
    }

    companion object {
        val EVENT_HINTS = listOf(tr("[笑]"), tr("[叹气]"), tr("[咳嗽]"), tr("[清嗓子]"), tr("[笑] "))

        /** 引擎输出固定 24 kHz 单声道 PCM16 */
        private const val SAMPLE_RATE = 24_000

        /** 多角色句间停顿：太短像抢话，太长像断线 */
        private const val GAP_MS = 260

        /** 1.9.51：native 崩溃定位的落盘文件。 */
        private const val TRACE_FILE = "last_trace.txt"

        /** 版本号连点解锁性能诊断：次数与「连点」判定窗口。 */
        private const val TAPS_TO_UNLOCK = 6
        private const val TAP_GAP_MS = 1_500L
    }
}
