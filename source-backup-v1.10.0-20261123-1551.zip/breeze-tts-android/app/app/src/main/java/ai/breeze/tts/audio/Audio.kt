package ai.breeze.tts.audio

import ai.breeze.tts.i18n.tr

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * 24 kHz / 16bit / mono 的流式播放器：native 每来一块就写一块，不需要先落文件。
 *
 * 关键改动（1.5）：**先攒够 prebufferMs 再开播**。
 * 端上生成慢于实时（RTF > 1）时，边生成边播必然会在每块之间饿死 AudioTrack，
 * 听感就是「念几个字停一下」。把开播时刻推迟到缓冲够厚之后再开始，
 * 可以把多次小断流合并成一次起始等待；[prebufferMs] 由调用方按实测 RTF 自适应调大。
 *
 * 1.6：收尾改成 [finishAsync]。写和放都在 native 回调线程上，而「等缓冲播完」
 * 本质是等 1 倍速的播放时间——放在回调里就会把「生成完成」这个 UI 事件一起拖住
 * （旧实现最多等 60 秒）。现在生成一结束就回报完成，尾音在后台自己的线程里放完。
 */
class StreamingPlayer(
    private val sampleRate: Int = 24_000,
    @Volatile var prebufferMs: Int = 3_000,
    /**
     * 只收不发。
     *
     * 合成过程中这个类还兼着「已产出多少毫秒」的计数器（进度条的分母），
     * 但用户并不想在生成时被外放——旧行为是边生成边播，安静场合很尴尬。
     * muted 时完全不创建 AudioTrack：write 只累加计数，finishAsync 立即回调。
     */
    private val muted: Boolean = false,
) {

    private var track: AudioTrack? = null
    @Volatile private var written = 0L          // 已写入的样本数
    @Volatile private var playing = false
    @Volatile private var aborted = false

    fun start() {
        if (muted) {
            written = 0
            aborted = false
            return
        }
        if (track != null) return
        val min = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
        )
        // 14 秒容量：必须显著大于 prebufferMs 的上限（12 s）。
        // 否则「还没攒够预缓冲，写入就已经把缓冲写满」，WRITE_BLOCKING 会永久阻塞，
        // play() 永远等不到 —— 直接死锁。
        val bufSize = maxOf(min * 4, sampleRate * 2 * 14)
        track = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .build(),
            bufSize,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE,
        )
        written = 0
        playing = false
        aborted = false
        // 不在这里 play()：等 bufferedMs 达到 prebufferMs 再开播
    }

    fun write(pcm: ShortArray) {
        if (aborted) return
        if (muted) {
            written += pcm.size
            return
        }
        val t = track ?: return
        // 缓冲快满时必须先开播腾出空间，否则 WRITE_BLOCKING 会卡死
        if (!playing && bufferedMs >= prebufferMs) {
            runCatching { t.play() }
            playing = true
        }
        var off = 0
        while (off < pcm.size) {
            val n = t.write(pcm, off, pcm.size - off, AudioTrack.WRITE_BLOCKING)
            if (n <= 0) break
            off += n
            written += n
            if (!playing && bufferedMs >= prebufferMs) {
                runCatching { t.play() }
                playing = true
            }
        }
    }

    /**
     * 生成结束：立即返回，尾音在后台线程里放完后释放 AudioTrack。
     *
     * 等待条件有两条保险：`playbackHeadPosition` 追上已写样本数（真放完），
     * 以及**头位置连续 1.5 秒不动**（播放被系统掐掉/从未启动时不再空等），
     * 最坏 20 秒硬上限。旧实现的 60 秒空等就是「生成完卡几十秒」的观感来源之一。
     */
    fun finishAsync(onReleased: (() -> Unit)? = null) {
        val t = track
        if (muted || t == null) {
            onReleased?.invoke()
            return
        }
        if (!playing) {
            runCatching { t.play() }
            playing = true
        }
        Thread({
            drain(t)
            runCatching { t.stop() }
            runCatching { t.release() }
            if (track === t) {
                track = null
                playing = false
            }
            onReleased?.invoke()
        }, "breeze-audio-drain").start()
    }

    private fun drain(t: AudioTrack) {
        var lastHead = -1L
        var stalledMs = 0L
        val deadline = System.currentTimeMillis() + 20_000
        while (!aborted && System.currentTimeMillis() < deadline) {
            val head = runCatching { t.playbackHeadPosition }.getOrDefault(0).toLong()
            if (head >= written) return
            if (head == lastHead) {
                stalledMs += 25
                if (stalledMs > 1_500) return
            } else {
                stalledMs = 0
            }
            lastHead = head
            try {
                Thread.sleep(25)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                return
            }
        }
    }

    /** 用户取消 / 重新开始时立即停，不等缓冲播完。 */
    fun stopNow() {
        aborted = true
        val t = track ?: return
        track = null
        playing = false
        runCatching { t.pause() }
        runCatching { t.flush() }
        runCatching { t.stop() }
        runCatching { t.release() }
    }

    /** 已写入但尚未播放的音频长度，用于 prebuffer 判断。 */
    val bufferedMs: Long
        get() {
            val t = track ?: return 0
            if (!playing) return written * 1000 / sampleRate
            val head = runCatching { t.playbackHeadPosition }.getOrDefault(0).toLong()
            val pending = written - head
            return if (pending > 0) pending * 1000 / sampleRate else 0
        }

    /** 已经写进去的总时长（含未播部分），用于界面上报进度。 */
    val producedMs: Long get() = written * 1000 / sampleRate

    val isPlaying: Boolean get() = playing
}

/** 标准 44 字节头 PCM WAV 写入器（先写占位头，close 时回填）。 */
class WavWriter(private val file: File, private val sampleRate: Int = 24_000) {

    private val raf = java.io.RandomAccessFile(file, "rw").apply {
        setLength(0)
        write(ByteArray(44))
    }
    private var dataBytes = 0L

    fun write(pcm: ShortArray) {
        val bb = ByteBuffer.allocate(pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        pcm.forEach { bb.putShort(it) }
        raf.write(bb.array())
        dataBytes += pcm.size * 2L
    }

    fun close() {
        raf.seek(0)
        raf.write(header(dataBytes))
        raf.close()
    }

    private fun header(dataLen: Long): ByteArray {
        val total = 36 + dataLen
        val bb = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(total.toInt())
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1)                      // PCM
        bb.putShort(1)                      // mono
        bb.putInt(sampleRate)
        bb.putInt(sampleRate * 2)           // byte rate
        bb.putShort(2)                      // block align
        bb.putShort(16)                     // bits
        bb.put("data".toByteArray())
        bb.putInt(dataLen.toInt())
        return bb.array()
    }
}

/**
 * 参考音频录制：48 kHz 采集，结束时降采样到 24 kHz 并写 wav。
 * 克隆对干净度很敏感，这里开了回声消除 + 降噪 + 自动增益。
 */
class VoiceRecorder {

    private var record: AudioRecord? = null
    private var thread: Thread? = null
    @Volatile private var running = false
    private val chunks = ArrayList<ShortArray>()

    val isRecording: Boolean get() = running

    fun start(): Boolean {
        if (running) return true
        val rate = 48_000
        val min = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(min * 2, rate),
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, tr("AudioRecord 初始化失败"))
            return false
        }
        chunks.clear()
        record = rec
        running = true
        rec.startRecording()
        thread = Thread({
            val buf = ShortArray(2048)
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) synchronized(chunks) { chunks.add(buf.copyOf(n)) }
            }
        }, "voice-recorder").apply { start() }
        return true
    }

    /** 停止并写盘，返回 24k 单声道 wav。 */
    fun stopTo(file: File): File {
        running = false
        thread?.join(800)
        record?.let {
            runCatching { it.stop() }
            it.release()
        }
        record = null

        val all = synchronized(chunks) {
            val total = chunks.sumOf { it.size }
            val merged = ShortArray(total)
            var pos = 0
            for (c in chunks) {
                c.copyInto(merged, pos)
                pos += c.size
            }
            merged
        }
        val down = downsample2(all)
        file.parentFile?.mkdirs()
        val writer = WavWriter(file, 24_000)
        try {
            writer.write(down)
        } finally {
            writer.close()
        }
        return file
    }

    fun cancel() {
        running = false
        thread?.join(400)
        record?.release()
        record = null
        synchronized(chunks) { chunks.clear() }
    }

    private fun downsample2(input: ShortArray): ShortArray {
        val out = ShortArray(input.size / 2)
        for (i in out.indices) {
            // 两点平均当简易低通，避免 48k→24k 的镜像混叠
            out[i] = ((input[2 * i].toInt() + input[2 * i + 1].toInt()) / 2).toShort()
        }
        return out
    }

    companion object {
        private const val TAG = "VoiceRecorder"
    }
}
