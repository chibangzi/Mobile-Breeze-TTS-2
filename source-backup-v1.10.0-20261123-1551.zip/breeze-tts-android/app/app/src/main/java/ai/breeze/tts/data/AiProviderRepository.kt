package ai.breeze.tts.data

import ai.breeze.tts.i18n.tr

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * 一条 AI 接口配置。字段刻意保持「OpenAI 兼容」这一最小集合：
 * baseUrl + apiKey + model 就够调用 /chat/completions，各家差异都靠 baseUrl 消化。
 */
data class AiProvider(
    val id: String = UUID.randomUUID().toString().take(10),
    /** 用户自己起的备注名，如「DeepSeek 主力」。为空时回落到厂商名 */
    val label: String = "",
    /** 厂商 preset id（openai / deepseek / custom…），只用于展示 */
    val vendor: String = "custom",
    /** 不含 /chat/completions 的根地址，如 https://api.deepseek.com/v1 */
    val baseUrl: String = "",
    val apiKey: String = "",
    val model: String = "",
    val enabled: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
) {
    val displayName: String get() = label.ifBlank { vendorLabel() }

    fun vendorLabel(): String = AiVendors.all.firstOrNull { it.id == vendor }?.label ?: tr("自定义接口")

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("label", label)
        put("vendor", vendor)
        put("baseUrl", baseUrl)
        put("apiKey", apiKey)
        put("model", model)
        put("enabled", enabled)
        put("createdAt", createdAt)
    }

    companion object {
        fun fromJson(o: JSONObject) = AiProvider(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString().take(10) },
            label = o.optString("label", ""),
            vendor = o.optString("vendor", "custom"),
            baseUrl = o.optString("baseUrl", ""),
            apiKey = o.optString("apiKey", ""),
            model = o.optString("model", ""),
            enabled = o.optBoolean("enabled", false),
            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
        )
    }
}

/** 新建配置时的厂商模板。baseUrl / model 只是默认值，用户都能改。 */
data class AiVendor(
    val id: String,
    val label: String,
    val baseUrl: String,
    val model: String,
    val note: String = "",
)

object AiVendors {
    val all = listOf(
        AiVendor(
            "openai", "OpenAI", "https://api.openai.com/v1", "gpt-4o-mini",
            tr("官方接口，国内需自备网络环境"),
        ),
        AiVendor(
            "deepseek", "DeepSeek", "https://api.deepseek.com/v1", "deepseek-chat",
            tr("国内直连，价格低、中文好"),
        ),
        AiVendor(
            "dashscope", tr("通义千问"), "https://dashscope.aliyuncs.com/compatible-mode/v1", "qwen-plus",
            tr("阿里云百炼的 OpenAI 兼容模式"),
        ),
        AiVendor(
            "zhipu", tr("智谱 GLM"), "https://open.bigmodel.cn/api/paas/v4", "glm-4-flash",
            tr("国内直连，glm-4-flash 有免费额度"),
        ),
        AiVendor(
            "moonshot", "Moonshot Kimi", "https://api.moonshot.cn/v1", "moonshot-v1-8k",
            tr("长文本能力较强"),
        ),
        AiVendor(
            "siliconflow", tr("硅基流动"), "https://api.siliconflow.cn/v1", "Qwen/Qwen2.5-7B-Instruct",
            tr("聚合多家开源模型，一个 key 通用"),
        ),
        AiVendor(
            "openrouter", "OpenRouter", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini",
            tr("一个 key 调多家海外模型"),
        ),
        AiVendor(
            "custom", tr("自定义 / 其他 OpenAI 兼容"), "", "",
            tr("填完整 base URL，例如 http://192.168.1.5:11434/v1"),
        ),
    )

    fun byId(id: String): AiVendor = all.firstOrNull { it.id == id } ?: all.last()
}

/**
 * AI 接口配置仓库。持久化到独立 SharedPreferences（键 `providers_v1`），
 * 与其它设置分开，避免一个 JSON 出错把全部设置带崩。
 *
 * 同一时间只允许一条启用：AI 扩写是单点调用，多启用会产生「到底用哪个」的歧义。
 * 启用新的一条会自动关掉旧的。
 */
class AiProviderRepository(app: Context) {

    private val sp = app.getSharedPreferences("breeze_ai", Context.MODE_PRIVATE)

    private val _providers = MutableStateFlow<List<AiProvider>>(emptyList())
    val providers: StateFlow<List<AiProvider>> = _providers.asStateFlow()

    init {
        _providers.value = read()
    }

    val enabledProvider: AiProvider?
        get() = _providers.value.firstOrNull { it.enabled }

    /** 新增或更新。启用时自动把其余条目标为未启用。 */
    fun save(p: AiProvider) {
        val list = _providers.value.toMutableList()
        val idx = list.indexOfFirst { it.id == p.id }
        val normalized = if (p.enabled) p else p.copy(enabled = false)
        if (idx >= 0) list[idx] = normalized else list += normalized
        val finalList = if (normalized.enabled) {
            list.map { if (it.id == normalized.id) it.copy(enabled = true) else it.copy(enabled = false) }
        } else {
            list
        }
        persist(finalList)
    }

    fun delete(id: String) {
        persist(_providers.value.filterNot { it.id == id })
    }

    fun setEnabled(id: String, on: Boolean) {
        val list = _providers.value.map {
            when {
                it.id == id -> it.copy(enabled = on)
                on -> it.copy(enabled = false)
                else -> it
            }
        }
        persist(list)
    }

    private fun persist(list: List<AiProvider>) {
        _providers.value = list
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp.edit().putString(KEY, arr.toString()).apply()
    }

    private fun read(): List<AiProvider> = runCatching {
        val raw = sp.getString(KEY, null) ?: return emptyList()
        val arr = JSONArray(raw)
        (0 until arr.length()).mapNotNull { i ->
            runCatching { AiProvider.fromJson(arr.getJSONObject(i)) }.getOrNull()
        }
    }.getOrDefault(emptyList())

    companion object {
        private const val KEY = "providers_v1"
    }
}
