package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Create
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ai.breeze.tts.audio.AudioDecoder
import ai.breeze.tts.audio.VoiceRecorder
import ai.breeze.tts.engine.VoiceProfile
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeGradients
import ai.breeze.tts.ui.theme.BreezeSize
import ai.breeze.tts.vm.AppViewModel
import java.io.File

/**
 * 音色页按两条独立流程分开：
 *  - 克隆音色：参考音频（WAV/MP3/M4A/AAC/OGG…）+ 逐字文本稿（可自动识别）
 *  - 音色设计：一句描述 + CFG 引导，无需音频
 */
@Composable
fun VoiceScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    /** false=角色列表主页；true=添加新角色（克隆/设计表单） */
    var addMode by remember { mutableStateOf(false) }

    var cloneName by remember { mutableStateOf("") }
    var refText by remember { mutableStateOf("") }
    var cloneMsg by remember { mutableStateOf<String?>(null) }
    var recording by remember { mutableStateOf(false) }
    var pendingWav by remember { mutableStateOf<File?>(null) }
    var decoding by remember { mutableStateOf(false) }
    /** 刚导入、等待剪裁的音频；非空时盖一层编辑页 */
    var editorFile by remember { mutableStateOf<File?>(null) }

    var designName by remember { mutableStateOf("") }
    var designPrompt by remember { mutableStateOf("") }
    var designMsg by remember { mutableStateOf<String?>(null) }
    // 新建页的试听需要一个稳定的 id（样本要落盘），但锁定/保存前不进音色列表。
    // 保存后换一个新 id，避免下一次新建覆盖刚存下的那一条。
    var designDraft by remember {
        mutableStateOf(vm.newDesignDraft("", "", VoiceProfile.Gender.NONE))
    }
    val designPlayer = rememberSamplePlayer()

    // 新建时的头像与性别。头像先落缓存，保存音色时再挪进 voices/
    var cloneGender by remember { mutableStateOf(VoiceProfile.Gender.NONE) }
    var cloneAvatar by remember { mutableStateOf<File?>(null) }
    var designGender by remember { mutableStateOf(VoiceProfile.Gender.NONE) }
    var designAvatar by remember { mutableStateOf<File?>(null) }

    /** 正在编辑的音色；非空时盖一层全屏编辑页 */
    var editingVoice by remember { mutableStateOf<VoiceProfile?>(null) }

    // 选图后先进裁切框：新建流程同样让用户决定留哪一块
    var cloneCrop by remember { mutableStateOf<Uri?>(null) }
    var designCrop by remember { mutableStateOf<Uri?>(null) }

    val cloneAvatarPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia(),
    ) { uri: Uri? ->
        uri?.let { cloneCrop = it }
    }
    val designAvatarPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia(),
    ) { uri: Uri? ->
        uri?.let { designCrop = it }
    }

    val recorder = remember { VoiceRecorder() }

    val liveDraft = vm.voices.firstOrNull { it.id == designDraft.id }
    // 带上输入框里的当前字段：锁定/试听时用的是这个名字与描述，
    // 而不是草稿创建时那份空的。
    val draftVoice = (liveDraft ?: designDraft).copy(
        name = designName.trim().ifBlank { tr("设计音色") },
        designPrompt = designPrompt.trim(),
        gender = designGender,
    )
    val draftPreview = vm.previewVoiceId == draftVoice.id
    LaunchedEffect(draftPreview, vm.sampleWavPath(draftVoice)) {
        val p = vm.sampleWavPath(draftVoice)
        if (draftPreview && p != null) designPlayer.play(p)
    }

    LaunchedEffect(vm.transcription) {
        vm.transcription?.let {
            refText = it
            cloneMsg = tr("已自动识别文本稿，请核对标点后保存")
            vm.consumeTranscription()
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { recorder.start(); recording = true }
        else cloneMsg = tr("需要录音权限才能克隆音色")
    }

    // 音频与视频都行：视频只取音轨，解成 24 kHz 单声道 PCM WAV 后再进剪裁页
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        decoding = true
        cloneMsg = if (uri.toString().isNotEmpty()) tr("正在提取音频…") else null
        scope.launch(Dispatchers.IO) {
            val out = File(ctx.cacheDir, "imported_ref_${System.currentTimeMillis()}.wav")
            val r = runCatching { AudioDecoder.importReference(ctx, uri, out) }
            withContext(Dispatchers.Main) {
                decoding = false
                r.fold(
                    onSuccess = { res ->
                        vm.stopPlayback()
                        editorFile = res.file
                        cloneMsg = when {
                            res.fromVideo -> tr("已从视频里提取音轨，接下来剪出要用的那一段")
                            res.truncated -> tr("文件较长，只取了前 10 分钟，接下来剪出要用的那一段")
                            else -> tr("已载入，接下来剪出要用的那一段")
                        }
                    },
                    onFailure = {
                        cloneMsg = tr("导入失败：${it.message ?: "不支持该格式"}", "Import failed: ${it.message ?: "format not supported"}")
                        runCatching { out.delete() }
                    },
                )
            }
        }
    }

    // 导入/选完视频后先进剪裁页：模型对参考音频敏感，开头换气、结尾杂音都会带偏音色
    editorFile?.let { src ->
        AudioEditorDialog(
            source = src,
            title = tr("裁剪参考音频"),
            onDismiss = {
                runCatching { src.delete() }
                editorFile = null
            },
            onConfirm = { edited ->
                pendingWav = edited
                cloneMsg = tr("已保留 %.1f 秒，可自动识别或手填文本稿").format(
                    ((edited.length() - 44).coerceAtLeast(0)) / 48_000.0,
                )
                runCatching { src.delete() }
                editorFile = null
            },
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        if (!addMode) {
            // ---------------- 主页：只有角色列表 + 添加入口 ----------------
            ScreenHeader(
                title = tr("音色库"),
                subtitle = tr("管理你的角色，或添加一个新角色"),
                icon = Icons.Outlined.Person,
            )
            VoiceListCard(
                tr("我的角色（${vm.voices.size}）", "My characters (${vm.voices.size})"), vm.voices, vm,
                tr("还没有角色，点下方「添加新角色」创建"),
                onEdit = { editingVoice = it },
            )
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = { addMode = true },
                modifier = Modifier.fillMaxWidth().height(BreezeSize.button),
                shape = RoundedCornerShape(13.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Breeze.colors.btnBg,
                    contentColor = Breeze.colors.btnInk,
                ),
            ) {
                Text(tr("添加新角色"), fontWeight = FontWeight.SemiBold)
            }
        } else {
            // ---------------- 添加页：克隆 / 设计表单 ----------------
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    tr("‹ 返回"),
                    fontSize = 13.sp,
                    color = Breeze.colors.t2,
                    modifier = Modifier
                        .clickable {
                            vm.discardDesignDraft(liveDraft ?: designDraft)
                            designDraft = vm.newDesignDraft("", "", VoiceProfile.Gender.NONE)
                            addMode = false
                        }
                        .padding(vertical = 4.dp),
                )
            }
            ScreenHeader(
                title = tr("添加新角色"),
                subtitle = tr("克隆真实声音，或用文字创造全新音色"),
                icon = Icons.Outlined.Person,
            )

            // 分段切换器：比默认 TabRow 的下划线更贴合黑金风格
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                SegmentedItem(tr("克隆音色"), Icons.Outlined.Person, tab == 0, Modifier.weight(1f)) { tab = 0 }
                SegmentedItem(tr("音色设计"), Icons.Outlined.Create, tab == 1, Modifier.weight(1f)) { tab = 1 }
            }

        if (tab == 0) {
            // ---------------- 克隆音色 ----------------
            SectionCard(
                title = tr("克隆音色 · 复刻某个人的声音"),
                subtitle = tr("提供一段 5–15 秒干净人声 + 这段音频的逐字文本稿"),
                icon = Icons.Outlined.Person,
                badge = tr("需要参考音频"),
            ) {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.09f),
                ) {
                    Text(
                        tr("仅克隆本人或已获明确授权的声音，禁止用于冒充、诈骗或伪造内容。"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(11.dp),
                    )
                }
                Spacer(Modifier.height(14.dp))
                ImeAwareTextField(
                    value = cloneName, onValueChange = { cloneName = it },
                    label = { Text(tr("音色名称")) }, modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                Spacer(Modifier.height(14.dp))
                IdentityFields(
                    name = cloneName,
                    gender = cloneGender,
                    avatar = cloneAvatar,
                    onGender = { cloneGender = it },
                    onPick = {
                        cloneAvatarPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                        )
                    },
                    onClear = { cloneAvatar = null },
                )
                Spacer(Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = {
                            if (recording) {
                                val f = recorder.stopTo(File(ctx.cacheDir, "rec.wav"))
                                recording = false
                                pendingWav = f
                                cloneMsg = tr("录音完成（${f.length() / 1024} KB）", "Recording saved (${f.length() / 1024} KB)")
                            } else {
                                val ok = ContextCompat.checkSelfPermission(
                                    ctx, Manifest.permission.RECORD_AUDIO,
                                ) == PackageManager.PERMISSION_GRANTED
                                if (ok) { recorder.start(); recording = true }
                                else permission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        modifier = Modifier.weight(1f),
                    ) { Text(if (recording) tr("停止录音") else tr("开始录音")) }
                    OutlinedButton(
                        onClick = { picker.launch(arrayOf("audio/*", "video/*")) },
                        enabled = !decoding,
                        modifier = Modifier.weight(1f),
                    ) { Text(if (decoding) tr("解码中…") else tr("导入音频")) }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    tr("支持 WAV / MP3 / M4A / AAC / OGG / FLAC，也可以直接选 MP4 等视频（自动提取音轨）。"),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                pendingWav?.let {
                    Spacer(Modifier.height(8.dp))
                    StatusPill(tr("已剪好 · %.1f 秒 · %d KB").format(
                        ((it.length() - 44).coerceAtLeast(0)) / 48_000.0, it.length() / 1024,
                    ))
                    Spacer(Modifier.height(6.dp))
                    Text(
                        tr("想重新剪一段？点上方「导入音频」重选，或再导入一次同一文件。"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                Spacer(Modifier.height(16.dp))
                Text(tr("参考音频的逐字文本稿"), style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                ImeAwareTextField(
                    value = refText, onValueChange = { refText = it },
                    modifier = Modifier.fillMaxWidth().height(110.dp),
                    placeholder = { Text(tr("可点下方「自动识别文本稿」，也可手动输入")) },
                )
                Spacer(Modifier.height(12.dp))

                // ---- 离线 ASR（SenseVoice） ----
                Text(tr("离线识别模型"), style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    vm.asrVariants.forEach { v ->
                        FilterChip(
                            selected = vm.asrVariantId == v.id,
                            onClick = { vm.selectAsrVariant(v.id) },
                            label = { Text(v.title.substringBefore(" · ")) },
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (!vm.asrInstalled) {
                    GradientButton(
                        text = vm.asrBusy ?: tr("下载所选识别模型（可离线使用）"),
                        onClick = { vm.installAsrModel() },
                        enabled = vm.asrBusy == null,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        tr("SenseVoice 大模型，只需下载一次；转写完全在手机本地，音频不上传。") +
                            tr("也可在「模型」页选择更高精度档位。"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GradientButton(
                            text = if (vm.asrBusy != null) tr("识别中…") else tr("自动识别文本稿"),
                            onClick = { pendingWav?.let { vm.transcribeReference(it) } },
                            enabled = pendingWav != null && vm.asrBusy == null,
                            modifier = Modifier.weight(1f),
                        )
                        if (vm.asrBusy != null) {
                            Spacer(Modifier.width(12.dp))
                            CircularProgressIndicator(Modifier.height(22.dp))
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        tr("识别结果会自动填入上方文本框，请人工核对一遍再保存。"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                cloneMsg?.let {
                    Spacer(Modifier.height(10.dp))
                    StatusPill(it, MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(14.dp))
                GradientButton(
                    text = tr("保存为克隆音色"),
                    onClick = {
                        val wav = pendingWav
                        when {
                            wav == null -> cloneMsg = tr("请先录音或导入音频")
                            refText.isBlank() -> cloneMsg = tr("必须填写参考音频的文本稿")
                            else -> {
                                vm.addClone(
                                    cloneName.ifBlank { tr("克隆音色") }, wav, refText,
                                    cloneGender, cloneAvatar,
                                )
                                cloneMsg = tr("已保存")
                                cloneName = ""; refText = ""; pendingWav = null
                                cloneGender = VoiceProfile.Gender.NONE; cloneAvatar = null
                            }
                        }
                    },
                    enabled = pendingWav != null && refText.isNotBlank() && !decoding,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

        } else {
            // ---------------- 音色设计 ----------------
            SectionCard(
                title = tr("音色设计 · 用一句话创造新声音"),
                subtitle = tr("不需要参考音频；描述年龄、性别、气质、语速即可"),
                icon = Icons.Outlined.Create,
                badge = tr("CFG 引导"),
            ) {
                Text(
                    tr("描述会作为 instruction 进入条件分支，再由 CFG 放大与「无描述」的差异。") +
                        tr("若描述不生效（例如输入「老头」却出来年轻声），请到「模型」页把") +
                        tr("「指令遵从强度 (CFG)」调到 4.0（与 PC 端一致）。"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(14.dp))
                ImeAwareTextField(
                    value = designName, onValueChange = { designName = it },
                    label = { Text(tr("音色名称")) }, modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                Spacer(Modifier.height(14.dp))
                IdentityFields(
                    name = designName,
                    gender = designGender,
                    avatar = designAvatar,
                    onGender = { designGender = it },
                    onPick = {
                        designAvatarPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                        )
                    },
                    onClear = { designAvatar = null },
                )
                Spacer(Modifier.height(14.dp))
                ImeAwareTextField(
                    value = designPrompt, onValueChange = { designPrompt = it },
                    label = { Text(tr("音色描述")) },
                    modifier = Modifier.fillMaxWidth().height(130.dp),
                    placeholder = { Text(tr("描述音色特征，越具体越稳定")) },
                )
                Spacer(Modifier.height(10.dp))
                ChipFlow(
                    items = listOf(tr("年迈的老头"), tr("温柔女声"), tr("沉稳男声"), tr("老奶奶"), tr("童声"), tr("播报腔"), tr("慢速耳语")),
                    selected = null,
                ) { tag ->
                    designPrompt = when (tag) {
                        tr("年迈的老头") -> tr("一个年迈的老头苍老的声音")
                        tr("温柔女声") -> tr("一位温柔亲切的年轻女性，声音柔和清晰，语速稍慢，语气自然。")
                        tr("沉稳男声") -> tr("一位成熟稳重的男性，声音低沉有磁性，语速平稳，语气克制。")
                        tr("老奶奶") -> tr("一位年迈的老奶奶，声音苍老沙哑，语速缓慢，语气温和。")
                        tr("童声") -> tr("一个活泼的小孩子，声音清脆明亮，语速轻快，带着好奇。")
                        tr("播报腔") -> tr("标准普通话新闻播报，吐字清晰，语速均匀，语气客观。")
                        else -> tr("用气声轻声说话，像在耳边低语，语速很慢。")
                    }
                }
                Spacer(Modifier.height(16.dp))

                // ---- 试听与锁定：和编辑页同一套逻辑，只是这里还没有落库的音色 ----
                LockSection(
                    vm = vm,
                    voice = draftVoice,
                    busy = vm.auditioningVoiceId == draftVoice.id,
                    preview = draftPreview,
                    playing = designPlayer.playing,
                    samplePath = vm.sampleWavPath(draftVoice),
                    seconds = vm.auditionSeconds,
                    promptOverride = designPrompt,
                    onPlay = {
                        val p = vm.sampleWavPath(draftVoice)
                        if (designPlayer.playing) designPlayer.stop() else p?.let { designPlayer.play(it) }
                    },
                )

                designMsg?.let {
                    Spacer(Modifier.height(8.dp))
                    StatusPill(it, MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(14.dp))
                GradientButton(
                    text = tr("保存为设计音色"),
                    onClick = {
                        when {
                            designPrompt.isBlank() -> designMsg = tr("请填写音色描述")
                            // 试听过（无论是否锁定）就沿用草稿 id，避免把样本和码本留在孤儿文件上
                            liveDraft != null || vm.sampleWavPath(draftVoice) != null -> {
                                vm.saveDesignDraft(
                                    draftVoice, designName, designPrompt,
                                    designGender, designAvatar,
                                )
                                designMsg = tr("已保存")
                                designName = ""; designPrompt = ""
                                designGender = VoiceProfile.Gender.NONE; designAvatar = null
                                designDraft = vm.newDesignDraft("", "", VoiceProfile.Gender.NONE)
                            }
                            else -> {
                                vm.addDesign(
                                    designName.ifBlank { tr("设计音色") }, designPrompt,
                                    designGender, designAvatar,
                                )
                                designMsg = tr("已保存")
                                designName = ""; designPrompt = ""
                                designGender = VoiceProfile.Gender.NONE; designAvatar = null
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
            }

        } // if (tab == 0) ... else 结束
        } // if (!addMode) ... else 结束
        Spacer(Modifier.height(20.dp))
    }

    LaunchedEffect(editingVoice) { if (editingVoice != null) vm.clearAuditionError() }

    editingVoice?.let { v ->
        VoiceEditorDialog(vm, v, onDismiss = { editingVoice = null })
    }

    cloneCrop?.let { u ->
        AvatarCropDialog(
            uri = u,
            onConfirm = { bmp ->
                vm.stageAvatarBitmap(bmp) { f -> cloneAvatar = f }
                cloneCrop = null
            },
            onDismiss = { cloneCrop = null },
        )
    }

    designCrop?.let { u ->
        AvatarCropDialog(
            uri = u,
            onConfirm = { bmp ->
                vm.stageAvatarBitmap(bmp) { f -> designAvatar = f }
                designCrop = null
            },
            onDismiss = { designCrop = null },
        )
    }
}

/**
 * 新建表单里的「头像 + 性别」。头像先落缓存，保存音色时才挪进 voices/<id>.jpg，
 * 因为文件名要用 id。
 */
@Composable
private fun IdentityFields(
    name: String,
    gender: VoiceProfile.Gender,
    avatar: File?,
    onGender: (VoiceProfile.Gender) -> Unit,
    onPick: () -> Unit,
    onClear: () -> Unit,
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AvatarEditField(
                name = name.ifBlank { tr("音") },
                gender = gender,
                avatarPath = avatar?.absolutePath,
                size = 64.dp,
                onClick = onPick,
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(tr("头像与性别"), style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(3.dp))
                Text(
                    if (avatar == null) tr("头像可留空，留空时显示名字首字")
                    else tr("已选头像，点相机可更换"),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (avatar != null) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        tr("移除"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier
                            .clip(CircleShape)
                            .clickable(onClick = onClear)
                            .padding(vertical = 4.dp, horizontal = 6.dp),
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        GenderSelector(gender, onGender)
        Spacer(Modifier.height(6.dp))
        Text(
            tr("性别用于合成页的「女声 / 男声」筛选与头像底色，不影响声音本身。"),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** 黑金风格的分段切换项：选中时用琥珀实底 + 深色文字。 */
@Composable
private fun SegmentedItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val bg = if (selected) {
        Brush.linearGradient(
            listOf(MaterialTheme.colorScheme.primary, ai.breeze.tts.ui.theme.AmberDeep),
        )
    } else {
        Brush.linearGradient(
            listOf(Color.Transparent, Color.Transparent),
        )
    }
    val fg = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        modifier
            .clip(MaterialTheme.shapes.small)
            .background(bg)
            .clickable { onClick() }
            .padding(vertical = 11.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(7.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = fg,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

/**
 * 音色列表：每条一张小卡片，左侧琥珀头像（取名字首字），
 * 中间名称与来源摘要，右侧「选用 / 使用中」和删除。
 */
@Composable
private fun VoiceListCard(
    title: String,
    list: List<VoiceProfile>,
    vm: AppViewModel,
    emptyHint: String,
    onEdit: (VoiceProfile) -> Unit,
) {
    SectionCard(title = title, subtitle = if (list.isEmpty()) null else tr("点整行即可设为当前音色")) {
        if (list.isEmpty()) {
            Text(
                emptyHint,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 8.dp),
            )
            return@SectionCard
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            list.forEach { v ->
                val active = vm.selectedVoiceId == v.id
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .background(
                            if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.09f)
                            else MaterialTheme.colorScheme.surfaceVariant,
                        )
                        .border(
                            1.dp,
                            if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.42f)
                            else MaterialTheme.colorScheme.outlineVariant,
                            MaterialTheme.shapes.medium,
                        )
                        .clickable { vm.selectVoice(v.id) }
                        .padding(horizontal = 12.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    VoiceAvatar(
                        name = v.name,
                        gender = v.gender,
                        avatarPath = v.avatarPath,
                        size = 40.dp,
                        badgeBackground = MaterialTheme.colorScheme.surface,
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                v.name,
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false),
                            )
                            if (active) {
                                Spacer(Modifier.width(8.dp))
                                StatusPill(tr("使用中"))
                            }
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(
                            buildString {
                                append(genderLabel(v.gender))
                                append(" · ")
                                if (v.kind == VoiceProfile.Kind.CLONE) {
                                    append(tr("克隆"))
                                } else {
                                    append(if (v.locked) tr("设计 · 已锁定") else tr("设计 · 每次随机"))
                                }
                                val text = if (v.kind == VoiceProfile.Kind.CLONE) v.refText else v.designPrompt
                                if (!text.isNullOrBlank()) {
                                    append(" · ")
                                    append(text.take(18).replace("\n", " "))
                                }
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        )
                    }
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = { onEdit(v) }, modifier = Modifier.size(34.dp)) {
                        Icon(
                            Icons.Outlined.Edit,
                            contentDescription = tr("编辑"),
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                            modifier = Modifier.size(16.dp),
                        )
                    }
                }
            }
        }
    }
}
