package ai.breeze.tts.engine

import ai.breeze.tts.i18n.tr

import android.content.Context
import android.os.SystemClock
import com.google.ai.edge.litert.Accelerator
import com.google.ai.edge.litert.CompiledModel
import com.google.ai.edge.litert.Environment
import com.google.ai.edge.litert.TensorBuffer
import kotlin.math.sqrt

/**
 * 声码器的 GPU 后端（LiteRT）。
 *
 * 模型是 gguf 里 `dpre` 之后那一段：输入 transformer 输出 [FRAMES, 1024]，
 * 输出 [FRAMES×1920] 采样。`dpre` 与 8 层注意力仍在 CPU 侧跑 —— 注意力有
 * softmax 和动态长度，收益小、风险大。
 *
 * ## 为什么是 128 帧
 *
 * 一次 flush 的 T 是 `sliding_window(72) + 16 + chunk`，前 88 帧是给 transformer
 * 看的上下文，只有后面 chunk 帧是新的。GPU 只需要最后 `chunk + 16` 帧的 latent
 * —— 卷积的感受野极小：实测 8 帧上下文就与全上下文逐位一致（2 帧差 11.9%，
 * 4 帧 0.59%，6 帧 0.087%，8 帧 0.000%）。
 *
 * native 侧只把 latent 的尾部 128 帧交给这张图，所以 chunk 可以开到 112。
 *
 * | chunk | GPU 帧数 | 每帧音频成本 |
 * | --- | --- | --- |
 * | 40 | 128 | 12.2 ms（88 帧上下文全白算） |
 * | 112 | 128 | 4.4 ms |
 *
 * 128 也是显存的分界：末尾 `dblk.3` 输出 245760×192 的 F32 张量，单张 189 MB。
 * 176 帧时涨到 260 MB，实测 GPU 耗时从 488 ms 变成 954 ms（1.375 倍长度换
 * 1.955 倍时间，超线性），得不偿失。
 *
 * ## 转置卷积
 *
 * 图里不是 ConvTranspose，而是按 CPU 版那份**相位拆解**写成的普通卷积：
 * `out[t*s+r] = Σ w[r+j*s]·x[t-j]`。补零由我们写死，不存在「Keras 导出
 * same padding 与代理补零方式不同」造成的 181 采样位移。
 *
 * 权重以 FP16 存、用时反量化，文件 148 MB；代价是 0.006% 的额外误差，
 * 与本图自身和 CPU 版之间 3% 的差距相比可以忽略。
 *
 * ## 1.9.92：不再随 APK 分发
 *
 * 147 MB 的图只有少数人会用到，留在包里让安装包从 69 MB 涨到 216 MB。现在
 * 图由 [VocoderPack] 单独导入到 `filesDir/vocoder/`，这里优先读文件；读到
 * `assets/` 只是兼容老版本（那个 asset 已经删了）。
 */
class VocoderGpu(ctx: Context) {

    companion object {
        /** 老路径：1.9.91 及以前内置在 assets 里，仅作兼容 */
        const val ASSET = "vocoder_gpu.tflite"

        /** 图是按固定长度编的，一次必须喂满这么多帧 */
        const val FRAMES = 128
        const val LATENT = 1024
        const val SAMPLES_PER_FRAME = 1920
        const val OUT = FRAMES * SAMPLES_PER_FRAME

        /** 探测阶段验证过的小图，用来把「设备不支持 GPU」和「这张图建不起来」分开 */
        private const val PROBE_ASSET = "probe_small.tflite"

        @Volatile
        private var shared: VocoderGpu? = null

        /** 全局单例：148 MB 权重不值得为每次合成都重建一次 */
        fun get(ctx: Context): VocoderGpu =
            shared ?: synchronized(this) {
                shared ?: VocoderGpu(ctx.applicationContext).also { shared = it }
            }

        fun peek(): VocoderGpu? = shared

        /**
         * 丢掉单例并释放已建的图。删除加速包时必须调用 —— 否则 147 MB 的
         * 权重还占在显存/内存里，用户删完文件也看不到空间回来。
         */
        fun evict() {
            synchronized(this) {
                shared?.release()
                shared = null
            }
        }

        /** 给自检报告用的一句话：这张图是从哪加载的 */
        fun sourceLabel(ctx: Context): String {
            val f = VocoderPack.modelFile(ctx)
            return when {
                VocoderPack.isInstalled(f) -> tr("加速包 ${"%.1f".format(f.length() / 1e6)} MB", "pack ${"%.1f".format(f.length() / 1e6)} MB")
                assetExists(ctx) -> tr("内置 asset（旧版）")
                else -> tr("未安装")
            }
        }

        private fun assetExists(ctx: Context): Boolean = runCatching {
            ctx.assets.open(ASSET).close(); true
        }.getOrDefault(false)

        /** 把异常展开成一行能贴出来的文本：类名 + message + cause 链 */
        fun describe(t: Throwable): String {
            val sb = StringBuilder()
            var e: Throwable? = t
            var depth = 0
            while (e != null && depth < 4) {
                if (depth > 0) sb.append(" ← ")
                sb.append(e.javaClass.simpleName)
                val m = e.message
                if (!m.isNullOrBlank()) sb.append(": ").append(m.take(300))
                e = e.cause
                depth++
            }
            return sb.toString()
        }
    }

    private val appCtx = ctx.applicationContext
    private var env: Environment? = null
    private var model: CompiledModel? = null
    private var inBuf: TensorBuffer? = null
    private var outBuf: TensorBuffer? = null

    var lastCreateMs = 0.0
        private set
    var lastRunMs = 0.0
        private set
    var lastEngine = ""
    var lastError: String = ""
        private set

    /** 本次建图时环境报告的可用加速器，诊断用 */
    var lastAccels: String = ""
        private set

    val isReady: Boolean get() = model != null

    /**
     * 建图。GPU 失败就返回 false，调用方应当直接走 CPU 路径 ——
     * 声码器占整条链路约四分之一，不值得为它让整次合成失败。
     *
     * 失败原因留在 [lastError]，设置页会原样显示；之前这里把异常直接吞掉，
     * 界面只剩一句「建图失败」，等于没有信息。
     *
     * [fp32] 只对 GPU 有意义：FP16 省显存但激活值也被压到半精度，snake 里
     * `sin²(x·α)/β` 在 β 很小时能冲到 6e4 以上，直接吃满 FP16 的上限。真机
     * 上 FP16 报 70% 误差、输出饱和在 ±1，就是这条路。FP32 精度满分，代价是
     * 显存翻倍、带宽翻倍。
     */
    fun load(gpu: Boolean, fp32: Boolean = false): Boolean {
        release()
        lastError = ""
        val t0 = SystemClock.elapsedRealtime()

        // 图从哪来：优先独立安装的加速包，其次老版本的内置 asset。
        // 两个都没有就直接失败 —— 以前这里会抛 FileNotFound，界面只看到
        // 一句「建图失败」，用户并不知道是自己没装加速包。
        val pack = VocoderPack.modelFile(appCtx)
        val fromFile = VocoderPack.isInstalled(pack)
        if (!fromFile && !assetExists(appCtx)) {
            lastError = tr("未安装声码器 GPU 加速包（设置 → 推理与性能 → GPU 加速）")
            lastCreateMs = 0.0
            return false
        }
        return try {
            val e = Environment.create(appCtx)
            env = e
            lastAccels = runCatching { e.getAvailableAccelerators().joinToString("/") }
                .getOrElse { tr("查询失败:${it.javaClass.simpleName}", "Query failed: ${it.javaClass.simpleName}") }
            val opts = if (gpu) {
                CompiledModel.Options(Accelerator.GPU).apply {
                    gpuOptions = CompiledModel.GpuOptions(
                        precision = if (fp32) CompiledModel.GpuOptions.Precision.FP32
                        else CompiledModel.GpuOptions.Precision.FP16_WITH_FP32_ACCUM,
                        backend = CompiledModel.GpuOptions.Backend.OPENCL,
                    )
                }
            } else {
                CompiledModel.Options(Accelerator.CPU)
            }
            val mo = if (fromFile) {
                // create(String) 接受绝对路径，直接 mmap 私有目录里的文件
                CompiledModel.create(pack.absolutePath, opts, e)
            } else {
                CompiledModel.create(appCtx.assets, ASSET, opts, e)
            }
            model = mo
            inBuf = mo.createInputBuffers()[0]
            outBuf = mo.createOutputBuffers()[0]
            lastCreateMs = (SystemClock.elapsedRealtime() - t0).toDouble()
            lastEngine = when {
                !gpu -> "CPU"
                fp32 -> "GPU · OpenCL · FP32"
                else -> "GPU · OpenCL · FP16"
            }
            true
        } catch (t: Throwable) {
            lastError = describe(t)
            release()
            lastCreateMs = (SystemClock.elapsedRealtime() - t0).toDouble()
            false
        }
    }

    /** 用任意 asset 建图，仅供自检诊断使用。 */
    private fun tryLoadAsset(asset: String, gpu: Boolean): Pair<Boolean, String> {
        return try {
            val e = Environment.create(appCtx)
            lastAccels = runCatching { e.getAvailableAccelerators().joinToString("/") }
                .getOrElse { tr("查询失败:${it.javaClass.simpleName}", "Query failed: ${it.javaClass.simpleName}") }
            val opts = if (gpu) {
                CompiledModel.Options(Accelerator.GPU).apply {
                    gpuOptions = CompiledModel.GpuOptions(
                        precision = CompiledModel.GpuOptions.Precision.FP16_WITH_FP32_ACCUM,
                        backend = CompiledModel.GpuOptions.Backend.OPENCL,
                    )
                }
            } else {
                CompiledModel.Options(Accelerator.CPU)
            }
            val mo = CompiledModel.create(appCtx.assets, asset, opts, e)
            runCatching { mo.createInputBuffers().forEach { it.close() } }
            runCatching { mo.createOutputBuffers().forEach { it.close() } }
            runCatching { mo.close() }
            true to ""
        } catch (t: Throwable) {
            false to describe(t)
        }
    }

    /**
     * 跑一块。latent 长度必须是 FRAMES×LATENT，末尾不足的帧由调用方补零。
     * 返回 OUT 个采样。
     *
     * 计时必须包住 readFloat：GPU 后端的 run 只是**异步提交**，真正的完成点在
     * 回读。只量 run 会得到 0.0 ms —— 1.9.76 那个「0.1 ms / 8071×」就是这么来的，
     * 这次又差点重演一遍。
     */
    fun run(latent: FloatArray): FloatArray {
        val mo = model ?: throw IllegalStateException(tr("声码器 GPU 未就绪"))
        val ib = inBuf ?: throw IllegalStateException(tr("输入缓冲为空"))
        val ob = outBuf ?: throw IllegalStateException(tr("输出缓冲为空"))
        require(latent.size == FRAMES * LATENT) {
            tr("输入长度 ${latent.size}，要求 ${FRAMES * LATENT}", "Input length ${latent.size}, expected ${FRAMES * LATENT}")
        }
        ib.writeFloat(latent)
        val t0 = SystemClock.elapsedRealtime()
        mo.run(listOf(ib), listOf(ob))
        val out = ob.readFloat()
        lastRunMs = (SystemClock.elapsedRealtime() - t0).toDouble()
        return out
    }

    /**
     * 按实际帧数跑一块：不足 FRAMES 的尾部补零，跑完只取前 frames 个。
     *
     * 补零必须补在**尾部**——整条链路是因果的，前面补零会平移整段音频。
     * 大于 FRAMES 直接拒绝（native 侧会捕获失败并回落 CPU）。
     */
    fun runPadded(latent: FloatArray, frames: Int): FloatArray {
        require(frames in 1..FRAMES) { tr("帧数 $frames 超出 1..$FRAMES", "Frame count $frames is outside 1..$FRAMES") }
        val need = frames * LATENT
        require(latent.size >= need) { tr("latent 只有 ${latent.size}，需要 $need", "latent has only ${latent.size}, needs $need") }
        val buf = if (frames == FRAMES) latent else FloatArray(FRAMES * LATENT).also {
            System.arraycopy(latent, 0, it, 0, need)
        }
        val out = run(buf)
        return if (frames == FRAMES) out else out.copyOf(frames * SAMPLES_PER_FRAME)
    }

    /**
     * 交给 native 的回调对象。方法名与签名必须和 breeze_jni.cpp 里的
     * `run([FI)[F` 一致，否则 GetMethodID 返回空、回调永远不被注册。
     *
     * 任何失败都返回空数组：native 看到 <=0 就回落到 CPU 全链路，合成不中断。
     */
    inner class Delegate {
        fun run(latent: FloatArray, frames: Int): FloatArray {
            return try {
                if (!isReady && !load(gpu = true, fp32 = true)) {
                    lastError.let { if (it.isNotBlank()) android.util.Log.w("VocoderGpu", tr("建图失败，回落 CPU：$it", "Graph build failed, falling back to CPU: $it")) }
                    return FloatArray(0)
                }
                runPadded(latent, frames)
            } catch (t: Throwable) {
                android.util.Log.w("VocoderGpu", tr("GPU 推理失败，本块回落 CPU：${describe(t)}", "GPU inference failed, this chunk falls back to CPU: ${describe(t)}"))
                FloatArray(0)
            }
        }
    }

    val delegate: Any by lazy { Delegate() }

    fun release() {
        runCatching { inBuf?.close() }
        runCatching { outBuf?.close() }
        runCatching { model?.close() }
        inBuf = null
        outBuf = null
        model = null
    }

    /**
     * 设置页的自检。分四段，每段单独捕获异常 —— 建图失败时用户要能直接看到
     * 是哪一层挂的，而不是笼统一句失败。全程只建两次图（CPU 一次、GPU 一次），
     * 每建一次要读 148 MB 权重，多来几遍就要等一分钟。
     */
    fun selfTest(log: (String) -> Unit, check: ((Int) -> FloatArray?)? = null): String {
        val sb = StringBuilder()
        fun e(s: String) {
            sb.appendLine(s)
            log(s)
        }
        e(tr("声码器 GPU 自检"))
        sink = { e(it) }
        e(tr("设备：${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} · Android ${android.os.Build.VERSION.RELEASE}", "Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} · Android ${android.os.Build.VERSION.RELEASE}"))
        e(tr("图：${sourceLabel(appCtx)} · $FRAMES 帧 → ${OUT} 采样", "Graph: ${sourceLabel(appCtx)} · $FRAMES frames → ${OUT} samples"))

        // ① 设备层面：小图能不能在 GPU 上建起来
        e("")
        e(tr("① 设备 GPU 能力（$PROBE_ASSET，300 KB）", "① Device GPU capability ($PROBE_ASSET, 300 KB)"))
        val (probeOk, probeErr) = tryLoadAsset(PROBE_ASSET, gpu = true)
        e(tr("   可用加速器：$lastAccels", "   available accelerators: $lastAccels"))
        if (probeOk) {
            e(tr("   建图成功 —— 设备 GPU/OpenCL 本身可用"))
        } else {
            e(tr("   建图失败：$probeErr", "   graph build failed: $probeErr"))
            e(tr("   → 这台设备的 GPU 后端不可用，下面的结果不用看了"))
        }

        val latent = FloatArray(FRAMES * LATENT) { i ->
            val x = (i * 2654435761L).toInt() shr 8
            ((x % 2000) - 1000) / 1000f * 0.8f
        }

        // ② 目标图 CPU：既验证 flatbuffer 合法，也拿到参考输出
        e("")
        e(tr("② 目标图 CPU 建图 + 推理"))
        if (!load(gpu = false)) {
            e(tr("   建图失败（%.0f ms）：%s").format(lastCreateMs, lastError))
            e(tr("   → 图本身有问题，与 GPU 无关"))
            return sb.toString()
        }
        e(tr("   建图 %.0f ms").format(lastCreateMs))
        val ref = try {
            run(latent)
        } catch (t: Throwable) {
            e(tr("   推理失败：${describe(t)}", "   inference failed: ${describe(t)}"))
            return sb.toString()
        }
        val cpuMs = lastRunMs
        e(tr("   推理 %.0f ms · 输出 %d 采样 · 范围 %.3f~%.3f").format(cpuMs, ref.size, ref.min(), ref.max()))

        // ③④ 两档精度各跑一次。FP16 省显存但激活也是半精度，snake 里
        // sin²(x·α)/β 在 β 很小时能冲过 6e4，直接吃满 FP16 上限；FP32 精度满分
        // 但显存和带宽都翻倍。哪一档能用，只有真机能回答。
        val latentB = FloatArray(FRAMES * LATENT) { i ->
            val t = i / LATENT
            val c = i % LATENT
            (kotlin.math.sin(t * 0.11 + c * 0.017) * 0.6).toFloat()
        }

        e("")
        e(tr("③ GPU · FP16（存/累加混合）"))
        val r16 = bench(latent, latentB, ref, fp32 = false)

        e("")
        e("④ GPU · FP32")
        val r32 = bench(latent, latentB, ref, fp32 = true)

        e("")
        e(tr("⑤ 结论"))
        val best = listOfNotNull(r16?.let { "FP16" to it }, r32?.let { "FP32" to it })
            .filter { it.second.moved >= 5.0 && it.second.rel <= 0.10 }
            .minByOrNull { it.second.ms }
        for ((n, r) in listOfNotNull(r16?.let { "FP16" to it }, r32?.let { "FP32" to it })) {
            e(tr("   $n：%.1f ms · 误差 %.2f%% · 饱和 %.1f%% · 敏感性 %.0f%%", "   $n: %.1f ms · error %.2f%% · saturation %.1f%% · sensitivity %.0f%%").format(
                r.ms, r.rel * 100, r.sat, r.moved
            ))
        }
        e("")
        e("   " + when {
            best != null -> tr("选 ${best.first}：单块 %.0f ms，比 CPU 快 %.1f×。", "chose ${best.first}: %.0f ms per chunk, %.1fx faster than CPU.").format(
                best.second.ms, if (best.second.ms > 0) cpuMs / best.second.ms else 0.0
            )
            r16 == null && r32 == null -> tr("两档都建不起来，这条路线在本文档设备上走不通。")
            listOfNotNull(r16, r32).any { it.moved < 5.0 } ->
                tr("输出不随输入变化 —— delegate 没有真正接管这张图，换切图方案。")
            else -> tr("两档都算错了，不是精度问题，是权重或图本身。")
        })

        // ⑥ 真实链路。前面四项都在验证「这张图 + 这个 delegate」，喂的都是我们自己
        // 构造的 latent —— 两边同一块内存，布局错得一致，误差照样是 0。1.9.87 就是
        // 这样把列主序的 latent 喂进 channels-last 的图，输出全是噪声还"自检通过"。
        // 这一段走 native 的真实解码路径，能抓住那一类错。
        e("")
        e(tr("⑥ 真实链路（native 解码 → GPU，对比 CPU 全链路）"))
        if (check == null) {
            e(tr("   未提供校验入口，跳过"))
        } else {
            val r = try {
                check(64)
            } catch (t: Throwable) {
                e(tr("   调用失败：${describe(t)}", "   call failed: ${describe(t)}"))
                null
            }
            if (r != null && r.size >= 5) {
                when (r[0].toInt()) {
                    0 -> {
                        e(tr("   RMS 相对误差 %.2f%%").format(r[1] * 100))
                        e(tr("   饱和：GPU %.2f%% · CPU %.2f%%").format(r[2] * 100, r[3] * 100))
                        e(tr("   GPU 64 帧 %.0f ms").format(r[4]))
                        e("   " + if (r[1] > 0.10) {
                            tr("差太多 —— 交给 GPU 的数据布局不对。这一项才是真判据，上面几项过了也没用。")
                        } else {
                            tr("真实链路上 GPU 与 CPU 一致，合成可以放心用。")
                        })
                    }
                    -1 -> e(tr("   GPU 未接上（开关没开或建图失败），跳过"))
                    -3 -> e(tr("   回调一次都没被调用 —— 整块回落成 CPU 了，等于没开"))
                    else -> e(tr("   native 返回码 ${r[0].toInt()}", "   native return code ${r[0].toInt()}"))
                }
            }
        }
        sink = null
        return sb.toString()
    }

    private data class Bench(val rel: Double, val ms: Double, val moved: Double, val sat: Double)

    /**
     * 建一次图、跑一次、给出四个判据。
     *
     * `moved` 是换一份完全不同的输入后输出变化的比例 —— 判断「图到底有没有在算」
     * 最直接的一条。上一版只看到 0.0 ms 和饱和输出，靠这条才能立刻分清是计时
     * 写错了还是图是死的。
     */
    private fun bench(
        latent: FloatArray,
        latentB: FloatArray,
        ref: FloatArray,
        fp32: Boolean,
    ): Bench? {
        if (!load(gpu = true, fp32 = fp32)) {
            e2(tr("   建图失败（%.0f ms）：%s").format(lastCreateMs, lastError))
            if (lastError.contains("memory", true) || lastError.contains("alloc", true)) {
                e2(tr("   → 显存不足。FP32 的激活是 FP16 的两倍，先看另一档能不能过。"))
            }
            return null
        }
        e2(tr("   建图 %.0f ms").format(lastCreateMs))
        val out = try {
            run(latent)
        } catch (t: Throwable) {
            e2(tr("   推理失败：${describe(t)}", "   inference failed: ${describe(t)}"))
            return null
        }
        e2(tr("   首次 %.1f ms · 范围 %.3f~%.3f").format(lastRunMs, out.min(), out.max()))
        run(latent)
        run(latent)
        val ms = lastRunMs

        val outB = run(latentB)
        var moved = 0
        for (i in out.indices) if (kotlin.math.abs(out[i] - outB[i]) > 1e-3f) moved++
        val movedPct = moved * 100.0 / out.size

        var se = 0.0
        var sn = 0.0
        for (i in ref.indices) {
            val d = out[i] - ref[i]
            se += d.toDouble() * d
            sn += ref[i].toDouble() * ref[i]
        }
        val rel = sqrt(se / ref.size) / (sqrt(sn / ref.size) + 1e-12)
        val sat = out.count { kotlin.math.abs(it) >= 0.998f } * 100.0 / out.size

        e2(tr("   稳态 %.1f ms · 误差 %.2f%% · 饱和 %.2f%% · 换输入变化 %.1f%%").format(
            ms, rel * 100, sat, movedPct
        ))
        return Bench(rel, ms, movedPct, sat)
    }

    private var sink: ((String) -> Unit)? = null

    private fun e2(s: String) {
        sink?.invoke(s)
    }
}
