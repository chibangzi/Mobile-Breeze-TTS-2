package ai.breeze.tts.data

import ai.breeze.tts.i18n.tr

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * 一条「表达与情绪」预设。[text] 是真正送进引擎的指令文案，
 * [name] 只用于列表显示——两者分开，是因为同一个意思往往有长句和短句两种写法，
 * 列表里要短、送进去的要全。
 */
data class EmotionPreset(
    val id: String,
    val name: String,
    val text: String,
    /** 内置预设：允许编辑和删除，只是「恢复默认」时能找回来 */
    val builtin: Boolean = false,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("text", text)
        put("builtin", builtin)
    }

    companion object {
        fun fromJson(o: JSONObject) = EmotionPreset(
            id = o.optString("id").ifBlank { newId() },
            name = o.optString("name"),
            text = o.optString("text"),
            builtin = o.optBoolean("builtin", false),
        )

        fun newId(): String = UUID.randomUUID().toString().take(8)
    }
}

/**
 * 情绪预设库。全局只有一份，存在 SharedPreferences 里一条 JSON 数组——
 * 数据量很小（几十条、每条几十字），不值得开文件或数据库。
 *
 * 首次启动写入内置的六条；之后用户怎么改都以存储为准，
 * 所以「删掉内置项」不会在下次启动时自己长回来，只有点「恢复默认」才会。
 */
class EmotionPresetRepository(private val app: Context) {

    private val sp = app.getSharedPreferences("breeze_presets", Context.MODE_PRIVATE)

    private val _presets = MutableStateFlow<List<EmotionPreset>>(emptyList())
    val presets: StateFlow<List<EmotionPreset>> = _presets.asStateFlow()

    init {
        val stored = read()
        if (stored == null) {
            _presets.value = defaults()
            persist()
        } else {
            _presets.value = stored
        }
    }

    /** 新建：插到最前，刚存的立刻出现在最左边，不用横向翻找 */
    fun add(name: String, text: String): EmotionPreset? {
        val n = name.trim()
        val t = text.trim()
        if (n.isEmpty() || t.isEmpty()) return null
        val p = EmotionPreset(id = EmotionPreset.newId(), name = n, text = t)
        _presets.value = listOf(p) + _presets.value
        persist()
        return p
    }

    fun update(id: String, name: String, text: String) {
        val n = name.trim()
        val t = text.trim()
        if (n.isEmpty() || t.isEmpty()) return
        _presets.value = _presets.value.map {
            if (it.id == id) it.copy(name = n, text = t) else it
        }
        persist()
    }

    fun remove(id: String) {
        _presets.value = _presets.value.filterNot { it.id == id }
        persist()
    }

    /** 恢复内置六条：已存在的按文案去重，用户自建的保留在后 */
    fun resetDefaults() {
        val existing = _presets.value
        val builtinTexts = defaults().map { it.text }.toSet()
        val kept = existing.filterNot { it.builtin || it.text in builtinTexts }
        _presets.value = defaults() + kept
        persist()
    }

    fun isCustomized(): Boolean {
        val d = defaults()
        return _presets.value.size != d.size || _presets.value.any { p -> d.none { it.text == p.text } }
    }

    // ---------------- 内部 ----------------

    private fun read(): List<EmotionPreset>? {
        val raw = sp.getString(KEY_PRESETS, null) ?: return null
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val p = EmotionPreset.fromJson(o)
                    if (p.name.isNotBlank() && p.text.isNotBlank()) add(p)
                }
            }
        }.getOrNull()
    }

    private fun persist() {
        val arr = JSONArray()
        _presets.value.forEach { arr.put(it.toJson()) }
        sp.edit().putString(KEY_PRESETS, arr.toString()).apply()
    }

    companion object {
        private const val KEY_PRESETS = "emotion_presets"

        /** 内置预设：沿用 1.x 快捷条目的文案，用户不需要重新理解一套说法 */
        fun defaults(): List<EmotionPreset> = listOf(
            tr("温柔亲切") to tr("用温柔亲切的语气，语速稍慢，像在跟朋友聊天。"),
            tr("低沉严肃") to tr("用低沉、克制的嗓音，语速缓慢，语气严肃。"),
            tr("兴奋雀跃") to tr("语气兴奋雀跃，语速略快，尾音上扬。"),
            tr("新闻播报") to tr("用标准普通话播报，吐字清晰，语速均匀，语气客观。"),
            tr("讲故事") to tr("像给孩子讲故事，声音有起伏，节奏舒缓，带一点神秘感。"),
            tr("耳语") to tr("用气声轻声说话，像在耳边低语。"),
        ).mapIndexed { i, (name, text) ->
            EmotionPreset(id = "builtin-$i", name = name, text = text, builtin = true)
        }
    }
}
