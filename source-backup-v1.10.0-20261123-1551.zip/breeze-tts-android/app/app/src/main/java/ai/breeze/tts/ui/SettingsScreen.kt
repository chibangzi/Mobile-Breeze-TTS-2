package ai.breeze.tts.ui

import ai.breeze.tts.i18n.eqTr
import ai.breeze.tts.i18n.startsWithTr
import ai.breeze.tts.i18n.Lang
import ai.breeze.tts.i18n.tr

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.layout.heightIn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import ai.breeze.tts.engine.VocoderGpu
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Create
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.List
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Place
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeSize
import ai.breeze.tts.BuildConfig
import ai.breeze.tts.data.ModelCatalog
import ai.breeze.tts.data.ModelState
import ai.breeze.tts.data.formatBytes
import ai.breeze.tts.ui.theme.BrandMint
import ai.breeze.tts.vm.AppViewModel
import ai.breeze.tts.vm.EngineState

/**
 * 设置页（1.9.5 起从「模型」改名并重排）。
 *
 * 旧版把引擎状态、模型库、下载进度、CFG、线程、识别模型、导出目录、
 * 下载源、许可十条全部竖着堆在同一页——431 行滚动，找任何一项都要先滚。
 * 现在是一级分类 + 二级页：一级只回答「要去哪」，二级才摆参数。
 */
@Composable
fun SettingsScreen(vm: AppViewModel) {
    var page by rememberSaveable { mutableStateOf<String?>(null) }

    val pickGguf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importLocal(uri)
    }
    // 1.9.92：声码器加速包（zip 或裸 .tflite）。用 SAF 而不是固定路径 ——
    // 用户从浏览器/网盘下载的文件落在哪由系统决定，不该要求他搬文件。
    val pickVocPack = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importVocPack(uri)
    }
    val pickExportDir = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.setExportDir(uri)
    }

    BackHandler(enabled = page != null) { page = null }

    AnimatedContent(
        targetState = page,
        transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) },
        label = "settingsPage",
    ) { p ->
        when (p) {
            null -> SettingsHome(vm) { page = it }
            "engine" -> EnginePage(
                vm,
                onBack = { page = null },
                onPickVocPack = { pickVocPack.launch(arrayOf("*/*")) },
            )
            "diag" -> DiagPage(vm) { page = null }
            "models" -> ModelsPage(vm, onBack = { page = null }, onPick = { pickGguf.launch(arrayOf("*/*")) })
            "asr" -> AsrPage(vm) { page = null }
            "ai" -> AiSettingsPage(vm) { page = null }
            "lang" -> LanguagePage(vm) { page = null }
            "storage" -> StoragePage(vm, onBack = { page = null }, onPickDir = { pickExportDir.launch(null) })
            else -> AboutPage(vm) { page = null }
        }
    }
}

// ==================== 一级：分类入口 ====================

@Composable
private fun SettingsHome(vm: AppViewModel, onOpen: (String) -> Unit) {
    val engineReady = vm.engineState is EngineState.Ready
    val engineText = when (val s = vm.engineState) {
        is EngineState.Ready -> tr("就绪")
        is EngineState.Loading -> tr("加载中…")
        is EngineState.Failed -> tr("失败")
        else -> tr("未加载")
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        ScreenHeader(
            title = tr("设置"),
            subtitle = tr("推理 · 模型 · 存储"),
            icon = Icons.Outlined.Settings,
        )

        // 顶部状态卡：一眼看到引擎现在的样子，点进去看细节
        Surface(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .clickable { onOpen("engine") },
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (engineReady) BrandMint.copy(alpha = 0.35f)
                else MaterialTheme.colorScheme.outlineVariant,
            ),
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .background(
                            if (engineReady) BrandMint.copy(alpha = 0.16f)
                            else MaterialTheme.colorScheme.surfaceVariant,
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Outlined.Build,
                        contentDescription = null,
                        tint = if (engineReady) BrandMint else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp),
                    )
                }
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        tr("推理引擎"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        tr("$engineText · ${if (vm.backendName == "未加载") "未启动" else vm.backendName}", "$engineText · ${if (vm.backendName == "未加载") "not started" else vm.backendName}"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Icon(
                    Icons.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Spacer(Modifier.height(4.dp))

        SettingEntry(
            icon = Icons.Outlined.Build,
            title = tr("推理与性能"),
            subtitle = tr("速度、引导强度与声码器"),
            value = buildString {
                append(vm.threads).append(tr(" 线程"))
                if (vm.turbo) append(tr(" · 极速"))
                append(tr(" · 块 ")).append(vm.vocChunk)
            },
            onClick = { onOpen("engine") },
        )
        SettingEntry(
            icon = Icons.Outlined.Create,
            title = tr("AI 接口"),
            subtitle = tr("扩写功能使用的模型服务"),
            value = vm.enabledAi?.displayName ?: tr("未配置"),
            onClick = { onOpen("ai") },
        )
        SettingEntry(
            icon = Icons.Outlined.List,
            title = tr("模型管理"),
            subtitle = tr("量化档位、下载与本地导入"),
            value = vm.activeModelId?.let { ModelCatalog.byId(it).title } ?: tr("未安装"),
            onClick = { onOpen("models") },
        )
        SettingEntry(
            icon = Icons.Outlined.Create,
            title = tr("语音识别"),
            subtitle = tr("克隆音色时自动转写文本稿"),
            value = if (vm.asrInstalled) tr("已安装") else tr("未安装"),
            onClick = { onOpen("asr") },
        )
        SettingEntry(
            icon = Icons.Outlined.Place,
            title = tr("存储与下载"),
            subtitle = tr("WAV 导出位置、下载源与镜像"),
            value = vm.exportDirLabel,
            onClick = { onOpen("storage") },
        )
        // 性能诊断默认隐藏：在「关于 → 版本信息」连点 6 次才解锁（1.9.68）。
        if (vm.devMode) {
            SettingEntry(
                icon = Icons.Outlined.Refresh,
                title = tr("性能诊断"),
                subtitle = tr("反复跑合成 · 分段耗时 · 电池温度（NPU 可行性基线）"),
                value = if (vm.diagTempC != null) "%.1f°C".format(vm.diagTempC) else tr("未测"),
                onClick = { onOpen("diag") },
            )
        }
        SettingEntry(
            icon = Icons.Outlined.Create,
            title = tr("语言"),
            subtitle = tr("跟随系统，或固定中文 / English"),
            value = when (vm.language) {
                Lang.MODE_ZH -> tr("中文")
                Lang.MODE_EN -> "English"
                else -> tr("跟随系统")
            },
            onClick = { onOpen("lang") },
        )
        SettingEntry(
            icon = Icons.Outlined.Info,
            title = tr("关于"),
            subtitle = tr("版本与许可信息"),
            value = "v${BuildConfig.VERSION_NAME}",
            onClick = { onOpen("about") },
        )

        Spacer(Modifier.height(16.dp))
    }
}

/** 一级页的一行：图标 + 标题 + 副标题 + 右侧当前值 + 箭头 */
@Composable
private fun SettingEntry(
    icon: ImageVector,
    title: String,
    subtitle: String,
    value: String,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Breeze.colors.fill)
            .border(1.dp, Breeze.colors.line, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(17.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            value,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
            modifier = Modifier.widthInMax(96.dp),
        )
        Icon(
            Icons.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier.size(18.dp),
        )
    }
}

// ==================== 二级页外壳 ====================

@Composable
internal fun PageScaffold(
    title: String,
    subtitle: String,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(
            Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onBack)
                .padding(vertical = 4.dp, horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = tr("返回"),
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(5.dp))
            Text(
                tr("设置"),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        Column {
            Text(
                title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.height(3.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        content()
        Spacer(Modifier.height(24.dp))
    }
}

// ==================== 推理与性能 ====================

@Composable
private fun EnginePage(
    vm: AppViewModel,
    onBack: () -> Unit,
    onPickVocPack: () -> Unit,
) {
    PageScaffold(tr("推理与性能"), tr("线程、引导强度与声码器设置"), onBack) {
        SectionCard(
            title = tr("引擎状态"),
            icon = Icons.Outlined.Build,
            badge = when (vm.engineState) {
                is EngineState.Ready -> tr("就绪")
                is EngineState.Loading -> tr("加载中")
                is EngineState.Failed -> tr("失败")
                else -> tr("未加载")
            },
            badgeColor = when (vm.engineState) {
                is EngineState.Ready -> BrandMint
                is EngineState.Failed -> MaterialTheme.colorScheme.error
                else -> MaterialTheme.colorScheme.tertiary
            },
        ) {
            KeyValueRow(tr("运行状态"), when (val s = vm.engineState) {
                is EngineState.Ready -> tr("就绪")
                is EngineState.Loading -> tr("正在加载权重…")
                is EngineState.Failed -> s.message
                else -> tr("未加载")
            })
            KeyValueRow(tr("计算后端"), if (eqTr(vm.backendName, "未加载")) "—" else vm.backendName)
            KeyValueRow(tr("CPU 特性"), vm.cpuFeatures.ifBlank { "—" })
            KeyValueRow(tr("当前模型"), vm.activeModelId?.let { ModelCatalog.byId(it).title } ?: tr("未安装"))
            vm.error?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }

        SectionCard(title = tr("线程"), icon = Icons.Outlined.Refresh) {
            SliderRow(
                tr("CPU 线程数"), vm.threads.toFloat(), 4f..8f,
                tr("${vm.threads} 线程", "${vm.threads} threads"),
                { vm.updateThreads(it.toInt()) },
                steps = 3,
                caption = tr("同时参与计算的 CPU 线程数。太少用不满性能，超过性能核心数反而会互相抢占、") +
                    tr("变慢；一般与手机的大核数量相当。"),
            )
        }

        SectionCard(
            title = tr("极速模式"),
            icon = Icons.Outlined.Build,
            badge = if (vm.turbo) tr("已开启") else tr("已关闭"),
            badgeColor = if (vm.turbo) BrandMint else MaterialTheme.colorScheme.onSurfaceVariant,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("关闭指令引导"), style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(3.dp))
                    Text(
                        tr("开启后不再同时计算「有指令」和「无指令」两条分支，生成速度更快；") +
                            tr("代价是音色描述与情绪指令的遵从度下降。"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = vm.turbo, onCheckedChange = { vm.updateTurbo(it) })
            }
            Spacer(Modifier.height(8.dp))
            Text(
                tr("适合长文与批量生成；调音色、或需要严格贴合情绪描述时建议关闭。"),
                style = MaterialTheme.typography.labelSmall,
                color = if (vm.turbo) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (vm.turbo) {
                Spacer(Modifier.height(6.dp))
                Text(
                    tr("当前按 CFG=1.0 运行，下方「引导强度」滑杆暂不生效。"),
                    style = MaterialTheme.typography.labelSmall,
                    color = BrandMint,
                )
            }
        }

        SectionCard(
            title = tr("声码器分块"),
            icon = Icons.Outlined.Build,
            badge = tr("${vm.vocChunk} 帧", "${vm.vocChunk} frames"),
            badgeColor = BrandMint,
        ) {
            VocChunkField(value = vm.vocChunk, onCommit = { vm.updateVocChunk(it) })
            Spacer(Modifier.height(10.dp))
            Text(
                tr("推荐档位"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            ChipFlow(
                items = VOC_CHUNK_PRESETS,
                selected = vm.vocChunk.toString(),
                onSelect = { vm.updateVocChunk(it.toInt()) },
            )
            Spacer(Modifier.height(8.dp))
            Text(
                tr("每次解码的音频长度。块越大，前文能被复用得越多，整体生成越快；") +
                    tr("块越小，声音出得越及时。"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                tr("块太大的代价是声音成段出现：要攒满一块才开始播，长文会「等一段、出一段」。") +
                    tr("想尽快听到开头就调小。"),
                style = MaterialTheme.typography.labelSmall,
                color = if (vm.vocChunk > 250) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        SectionCard(title = tr("引导强度"), icon = Icons.Outlined.Settings) {
            SliderRow(
                label = tr("指令遵从强度 (CFG)"),
                value = vm.cfgScale,
                range = 1f..6f,
                valueText = "%.1f".format(vm.cfgScale),
                onChange = { vm.updateCfgScale(it) },
                steps = 9,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                tr("数值越高，结果越贴合音色描述与情绪指令，速度也越慢；设为 1 等于关闭引导，") +
                    tr("完全按模型自己的判断发音。"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            )
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("细节层不受引导（实验）"), style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(3.dp))
                    Text(
                        tr("让音色与情绪的引导只作用于主干，不再约束细节层，生成会略快。"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = vm.depthCfgOff,
                    onCheckedChange = { vm.updateDepthCfgOff(it) },
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                tr("细节失去约束后可能带出明显的高频杂音，默认关闭；") +
                    tr("想自己对比音质时可以打开试试。"),
                style = MaterialTheme.typography.labelSmall,
                color = if (vm.depthCfgOff) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        SectionCard(
            title = tr("声码器 GPU 加速"),
            icon = Icons.Outlined.Build,
            badge = if (vm.vocPackInstalled) tr("加速包已装") else tr("未安装"),
            badgeColor = if (vm.vocPackInstalled) BrandMint else MaterialTheme.colorScheme.onSurfaceVariant,
        ) {
            val scope = rememberCoroutineScope()
            var busy by remember { mutableStateOf(false) }
            var report by remember { mutableStateOf("") }

            // ---- 加速包 ----
            // 1.9.92：147 MB 的图从 APK 里拆出来单独分发，这里负责导入/删除。
            Text(
                tr("加速包：${if (vm.vocPackInstalled) "已安装 · ${formatBytes(vm.vocPackBytes)}" else "未安装"}", "Pack: ${if (vm.vocPackInstalled) "installed · ${formatBytes(vm.vocPackBytes)}" else "not installed"}"),
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium,
                color = if (vm.vocPackInstalled) BrandMint else MaterialTheme.colorScheme.onSurface,
            )
            Spacer(Modifier.height(3.dp))
            Text(
                if (vm.vocPackInstalled) {
                    tr("加速包单独存放，删除后不影响合成，只是回到 CPU 计算。")
                } else {
                    tr("声码器加速包需要单独下载后从这里导入。") +
                        tr("不导入时完全由 CPU 计算，合成功能不受影响。")
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedButton(
                    onClick = onPickVocPack,
                    enabled = !vm.vocPackImporting,
                    modifier = Modifier.weight(1f),
                ) {
                    Text(
                        if (vm.vocPackImporting) tr("导入中…") else if (vm.vocPackInstalled) tr("更换加速包") else tr("导入加速包"),
                        fontSize = 12.sp,
                    )
                }
                if (vm.vocPackInstalled) {
                    OutlinedButton(
                        onClick = { vm.removeVocPack() },
                        enabled = !vm.vocPackImporting,
                        modifier = Modifier.weight(1f),
                    ) { Text(tr("删除（省 147 MB）"), fontSize = 12.sp) }
                }
            }
            vm.vocPackProgress?.let { (done, total) ->
                Spacer(Modifier.height(8.dp))
                ProgressTrack(fraction = if (total > 0) done.toFloat() / total else null)
                Spacer(Modifier.height(5.dp))
                Text(
                    when {
                        total > 0 -> tr("正在解压 ${formatBytes(done)} / ${formatBytes(total)}", "Extracting ${formatBytes(done)} / ${formatBytes(total)}")
                        total == 0L -> tr("正在校验文件完整性…")
                        else -> tr("正在读取 ${formatBytes(done)}…", "Reading ${formatBytes(done)}…")
                    },
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            vm.vocPackError?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, fontSize = 11.5.sp, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            )
            Spacer(Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("声码器走显卡"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        if (vm.vocPackInstalled) {
                            tr("打开后声码器交给 GPU 计算，减轻 CPU 负担；") +
                                tr("关闭则全部由 CPU 计算。改动在下一次合成生效。")
                        } else {
                            tr("需要先导入加速包。")
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.width(10.dp))
                Switch(
                    checked = vm.gpuVocoder,
                    onCheckedChange = { vm.updateGpuVocoder(it) },
                    enabled = vm.vocPackInstalled,
                )
            }

            Spacer(Modifier.height(12.dp))
            Text(
                tr("第一次使用建议先自检：用同一段输入分别交给 CPU 和 GPU 计算，") +
                    tr("确认加速包在本机可用，并显示两者的差异与耗时。需要几十秒。"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            when {
                                !vm.vocPackInstalled -> MaterialTheme.colorScheme.surfaceVariant
                                busy -> MaterialTheme.colorScheme.surfaceVariant
                                else -> MaterialTheme.colorScheme.primary
                            }
                        )
                        .clickable(enabled = !busy && vm.vocPackInstalled) {
                            busy = true
                            report = ""
                            scope.launch {
                                val ctx = vm.getApplication<android.app.Application>()
                                val r = withContext(Dispatchers.IO) {
                                    runCatching { VocoderGpu.get(ctx).selfTest({ }) { vm.vocoderCheck(it) } }
                                        .getOrElse { tr("自检失败：${it.javaClass.simpleName}: ${it.message}", "Self-test failed: ${it.javaClass.simpleName}: ${it.message}") }
                                }
                                report = r
                                busy = false
                            }
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                ) {
                    Text(
                        if (busy) tr("自检中…") else tr("声码器自检"),
                        fontSize = 12.5.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                        color = if (busy || !vm.vocPackInstalled) MaterialTheme.colorScheme.onSurfaceVariant
                        else MaterialTheme.colorScheme.onPrimary,
                    )
                }
            }

            if (report.isNotBlank()) {
                val ctx = LocalContext.current
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        tr("自检报告"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        tr("复制"),
                        fontSize = 12.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE)
                                    as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText(tr("声码器自检"), report))
                            }
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    )
                }
                Spacer(Modifier.height(6.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(max = 260.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 10.dp, vertical = 9.dp),
                ) {
                    Text(
                        report,
                        fontSize = 10.sp,
                        lineHeight = 14.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

/** 1.9.74 推荐档位：96 低延迟 / 160 均衡 / 250 实测最优 / 320 试探 / 512 上限。 */
private val VOC_CHUNK_PRESETS = listOf("96", "160", "250", "320", "512")
private const val VOC_CHUNK_MIN = 96
private const val VOC_CHUNK_MAX = 512

/**
 * 声码器分块上限：手动输入 + 快捷档位。
 *
 * 只在失焦或按「完成」时提交。边打字边提交会被钳位打断——想输 320，敲下第一个 3
 * 就被抬到 96、光标还会跳走。所以输入框自己留 draft，外部改值（点快捷档）时才回灌。
 */
@Composable
private fun VocChunkField(value: Int, onCommit: (Int) -> Unit) {
    val c = Breeze.colors
    val focus = LocalFocusManager.current
    var draft by rememberSaveable { mutableStateOf(value.toString()) }
    var wasFocused by remember { mutableStateOf(false) }

    // 点快捷档位时把新值灌回输入框；用户打字期间 value 不变，不会被打断。
    LaunchedEffect(value) { draft = value.toString() }

    fun commit() {
        val v = (draft.toIntOrNull() ?: value).coerceIn(VOC_CHUNK_MIN, VOC_CHUNK_MAX)
        draft = v.toString()
        if (v != value) onCommit(v)
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(tr("每块上限"), fontSize = 12.5.sp, color = c.t2)
            Spacer(Modifier.height(3.dp))
            Text(
                tr("可输入 $VOC_CHUNK_MIN–$VOC_CHUNK_MAX 之间任意整数，超出会被夹到区间内", "Any integer from $VOC_CHUNK_MIN to $VOC_CHUNK_MAX; out-of-range values are clamped"),
                style = MaterialTheme.typography.labelSmall,
                color = c.t3,
            )
        }
        ImeAwareTextField(
            value = draft,
            onValueChange = { s ->
                // 只收数字、最多 4 位：非法字符直接忽略，比事后校验干净
                if (s.length <= 4 && s.all { it.isDigit() }) draft = s
            },
            singleLine = true,
            textStyle = MaterialTheme.typography.titleMedium,
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done,
            ),
            keyboardActions = KeyboardActions(onDone = {
                commit()
                focus.clearFocus()
            }),
            modifier = Modifier
                .width(104.dp)
                .onFocusChanged {
                    // 首次组合也会回调一次 isFocused=false，用 wasFocused 挡掉，
                    // 否则默认值还没被用户碰过就被「提交」一遍。
                    if (wasFocused && !it.isFocused) commit()
                    wasFocused = it.isFocused
                },
        )
        Spacer(Modifier.width(6.dp))
        Text(tr("帧"), fontSize = 12.sp, color = c.t3)
    }
}

// ==================== 模型管理 ====================
@Composable
private fun ModelsPage(vm: AppViewModel, onBack: () -> Unit, onPick: () -> Unit) {
    val c = Breeze.colors
    val downloading = vm.downloadState as? ModelState.Downloading
    val verifying = vm.downloadState as? ModelState.Verifying
    val failedMessage = (vm.downloadState as? ModelState.Failed)?.message
    val busy = downloading != null || verifying != null

    PageScaffold(tr("模型管理"), tr("可同时装多个量化档位，随时切换"), onBack) {
        SectionCard(
            title = tr("模型库"),
            icon = Icons.Outlined.List,
            badge = tr("${vm.installedModels.size} / ${vm.variants.size} 已安装", "${vm.installedModels.size} / ${vm.variants.size} installed"),
        ) {
            vm.variants.forEach { v ->
                val installed = vm.installedModels.containsKey(v.id)
                val active = vm.activeModelId == v.id
                val selected = vm.variantId == v.id
                // 进度跟着「这一张卡」走：正在下的那个档位自己显示进度条，
                // 不再是页脚里一块和卡片对不上号的「下载状态」。
                val dl = downloading?.takeIf { it.variantId == v.id }
                val vf = verifying?.takeIf { it.variantId == v.id }
                val live = dl != null || vf != null

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .clip(MaterialTheme.shapes.medium)
                        .then(
                            when {
                                live -> Modifier.border(
                                    1.dp, c.accent.copy(alpha = 0.55f), MaterialTheme.shapes.medium,
                                )
                                active -> Modifier.border(
                                    1.5.dp, MaterialTheme.colorScheme.primary, MaterialTheme.shapes.medium,
                                )
                                else -> Modifier.border(
                                    1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium,
                                )
                            }
                        )
                        .clickable { vm.selectVariant(v.id) },
                    shape = MaterialTheme.shapes.medium,
                    color = when {
                        active -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.18f)
                        selected || live -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        else -> Color.Transparent
                    },
                ) {
                    Column(Modifier.padding(13.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(v.title, style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(3.dp))
                                Text(
                                    v.subtitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Text(
                                    "${formatBytes(if (installed) vm.installedModels[v.id] ?: 0 else v.approximateBytes)} · ${v.fileName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            StatusPill(
                                when {
                                    // 1.9.92：点下按钮到首包到达之间可能有一二十秒
                                    // （镜像探测 + 换源重试），这期间要有个明确的
                                    // 「在连」而不是 0% 卡着不动。
                                    dl != null && dl.doneBytes <= 0 -> tr("连接中…")
                                    dl != null -> tr("下载 ${(dl.fraction * 100).toInt()}%", "Download ${(dl.fraction * 100).toInt()}%")
                                    vf != null -> tr("校验中")
                                    active -> tr("使用中")
                                    installed -> tr("已安装")
                                    else -> tr("未安装")
                                },
                                when {
                                    live || active -> BrandMint
                                    installed -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                            )
                        }

                        if (dl != null) {
                            Spacer(Modifier.height(11.dp))
                            ProgressTrack(fraction = if (dl.doneBytes > 0) dl.fraction else null)
                            Spacer(Modifier.height(7.dp))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    if (dl.doneBytes > 0) {
                                        "${formatBytes(dl.doneBytes)} / ${formatBytes(dl.totalBytes)}"
                                    } else {
                                        tr("正在选择下载源并读取文件大小…")
                                    },
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f),
                                )
                                if (dl.doneBytes > 0) {
                                    Text(
                                        "${formatBytes(dl.speedBps)}/s",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                    )
                                }
                            }
                        }
                        if (vf != null) {
                            Spacer(Modifier.height(11.dp))
                            ProgressTrack(fraction = null)
                            Spacer(Modifier.height(7.dp))
                            Text(
                                tr("正在校验 ${vf.file} 的 GGUF 文件头…", "Checking the GGUF header of ${vf.file}…"),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }

                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            when {
                                dl != null -> OutlinedButton(
                                    onClick = { vm.cancelDownload() },
                                    modifier = Modifier.weight(1f),
                                ) { Text(tr("取消下载")) }

                                vf != null -> OutlinedButton(
                                    onClick = {},
                                    enabled = false,
                                    modifier = Modifier.weight(1f),
                                ) { Text(tr("安装中…")) }

                                active -> OutlinedButton(
                                    onClick = { vm.deleteModel(v.id) },
                                    modifier = Modifier.weight(1f),
                                ) { Text(tr("删除")) }

                                installed -> {
                                    OutlinedButton(
                                        onClick = { vm.switchModel(v.id) },
                                        modifier = Modifier.weight(1f),
                                    ) { Text(tr("切换使用")) }
                                    OutlinedButton(
                                        onClick = { vm.deleteModel(v.id) },
                                        modifier = Modifier.weight(1f),
                                    ) { Text(tr("删除")) }
                                }

                                else -> OutlinedButton(
                                    onClick = { vm.selectVariant(v.id); vm.download() },
                                    enabled = !busy,
                                    modifier = Modifier.weight(1f),
                                ) { Text(tr("下载此模型")) }
                            }
                        }
                    }
                }
            }

            if (failedMessage != null) {
                Spacer(Modifier.height(8.dp))
                Text(
                    tr("上次下载失败：$failedMessage", "Last download failed: $failedMessage"),
                    fontSize = 11.5.sp,
                    lineHeight = 17.sp,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = onPick,
                enabled = !vm.importing,
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (vm.importing) tr("正在导入…") else tr("从本地导入 GGUF（装到选中档位）")) }
            Spacer(Modifier.height(6.dp))
            Text(
                tr("GGUF 是单文件完整模型，导入前先选中要装入的档位。"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * 4dp 细进度条。自己画而不是用 M3 的 LinearProgressIndicator：
 * 默认实现带「间隔 + 停止点」，4dp 高度上会显出两个突兀的缺口。
 *
 * @param fraction null 表示不确定进度（校验阶段），整条走强调色的淡填充
 */
@Composable
private fun ProgressTrack(fraction: Float?) {
    val c = Breeze.colors
    Box(
        Modifier
            .fillMaxWidth()
            .height(4.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(c.line2),
    ) {
        Box(
            Modifier
                .fillMaxWidth((fraction ?: 1f).coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(if (fraction == null) c.accent.copy(alpha = 0.45f) else c.accent),
        )
    }
}

// ==================== 语音识别 ====================

@Composable
private fun AsrPage(vm: AppViewModel, onBack: () -> Unit) {
    PageScaffold(tr("语音识别"), tr("克隆音色时自动转写参考音频"), onBack) {
        SectionCard(
            title = tr("离线识别模型"),
            subtitle = tr("全程本地，不上传音频"),
            icon = Icons.Outlined.Create,
        ) {
            vm.asrVariants.forEach { v ->
                val installed = vm.asrInstalledFor(v.id)
                val selected = vm.asrVariantId == v.id
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(MaterialTheme.shapes.small)
                        .clickable { vm.selectAsrVariant(v.id) },
                    shape = MaterialTheme.shapes.small,
                    color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.22f)
                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(v.title, style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(3.dp))
                            Text(
                                v.subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        StatusPill(
                            if (installed) tr("已安装") else tr("未安装"),
                            if (installed) BrandMint else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GradientButton(
                    text = vm.asrBusy ?: if (vm.asrInstalled) tr("重新下载所选模型") else tr("下载所选识别模型"),
                    onClick = { vm.installAsrModel() },
                    enabled = vm.asrBusy == null,
                    modifier = Modifier.weight(1f),
                )
                if (vm.asrInstalled) {
                    OutlinedButton(
                        onClick = { vm.deleteAsrModel(vm.asrVariantId) },
                        modifier = Modifier.weight(1f),
                    ) { Text(tr("删除")) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                tr("离线语音识别模型，用于把克隆音色的参考音频自动转成文字稿。") +
                    tr("首次使用需联网下载，之后完全离线。"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ==================== 存储与下载 ====================

@Composable
private fun StoragePage(vm: AppViewModel, onBack: () -> Unit, onPickDir: () -> Unit) {
    PageScaffold(tr("存储与下载"), tr("导出位置、下载源与镜像"), onBack) {
        SectionCard(
            title = tr("WAV 导出位置"),
            subtitle = tr("导出成功后会提示完整路径"),
            icon = Icons.Outlined.Place,
        ) {
            KeyValueRow(tr("当前位置"), vm.exportDirLabel)
            Text(
                if (vm.exportDirUriString == null)
                    tr("默认保存到系统的「音乐/BreezeTTS」文件夹。")
                else tr("已使用自定义文件夹，重启后仍然有效。"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onPickDir, modifier = Modifier.weight(1f)) { Text(tr("选择文件夹")) }
                OutlinedButton(
                    onClick = { vm.setExportDir(null) },
                    enabled = vm.exportDirUriString != null,
                    modifier = Modifier.weight(1f),
                ) { Text(tr("恢复默认")) }
            }
        }

        SectionCard(title = tr("下载源"), subtitle = tr("GGUF 仓库设置"), icon = Icons.Outlined.Refresh) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("使用 hf-mirror 镜像"), style = MaterialTheme.typography.titleSmall)
                    Text(
                        tr("通过国内镜像下载模型，直连不通时使用。"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = vm.useMirror, onCheckedChange = { vm.toggleMirror(it) })
            }
            Spacer(Modifier.height(12.dp))
            ImeAwareTextField(
                value = vm.customRepo,
                onValueChange = { vm.customRepo = it },
                label = { Text(tr("自定义 HF 仓库（可选）")) },
                placeholder = { Text(ModelCatalog.DEFAULT_REPO) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

// ==================== 性能诊断（NPU 可行性 CPU 基线）====================

/**
 * 独立诊断面板：反复跑合成，拿五段计时 / RTF / 温度。
 * 完全不碰主合成管线——不写 WAV、不进收藏、不播放、不改 generating 状态。
 * 目的是给「要不要上 Hexagon NPU」建立可对比的 CPU 基线与散热画像。
 */
@Composable
private fun DiagPage(vm: AppViewModel, onBack: () -> Unit) {
    val c = Breeze.colors
    val context = LocalContext.current
    var batches by rememberSaveable { mutableStateOf(3) }

    // 进页面先刷一次：否则日志卡显示的是上次刷新时的内容（可能是空的）
    LaunchedEffect(Unit) { runCatching { vm.refreshDiagLog() } }

    PageScaffold(tr("性能诊断"), tr("CPU 基线 · 分段耗时 · 电池温度"), onBack) {
        // 1.9.70：测试日志。
        // 上一版失败只写「失败」两个字，界面没原因、logcat 也拿不到（用户不在电脑边），
        // 只能靠猜。现在每次诊断/实验都把请求参数、native 返回码、计时回调是否到达、
        // 错误栈记进内存并在跑完后立刻刷新到这里，同时追加写盘。
        SectionCard(
            title = tr("测试日志"),
            icon = Icons.Outlined.List,
            badge = if (vm.diagLogText.isBlank()) tr("空") else tr("${vm.diagLogText.count { it == '\n' } + 1} 行", "${vm.diagLogText.count { it == '\n' } + 1} lines"),
            badgeColor = c.accent,
        ) {
            Text(
                tr("失败时先看这里：每条都带 native 返回码与失败原因。") +
                    tr("日志同时写到 ") + vm.diagLogPath + tr("，重启/被系统杀掉后仍在。") +
                    tr("如果这里是空的（比如上次是闪退，内存缓冲随进程没了），点「从磁盘读取」。"),
                style = MaterialTheme.typography.labelSmall,
                color = c.t3,
            )
            if (vm.diagLogText.isNotBlank()) {
                Spacer(Modifier.height(9.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(c.fill)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 10.dp, vertical = 9.dp),
                ) {
                    Text(
                        vm.diagLogText,
                        fontSize = 9.5.sp,
                        lineHeight = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        color = c.t2,
                    )
                }
            } else {
                Spacer(Modifier.height(8.dp))
                Text(
                    tr("内存里没有日志（多半是上次闪退后的第一次进入）。") +
                        tr("磁盘上还留着历史，点下面的「从磁盘读取」。"),
                    fontSize = 11.sp,
                    color = c.t3,
                    lineHeight = 16.sp,
                )
            }
            Spacer(Modifier.height(9.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(
                    onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE)
                            as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText(tr("BreezeTTS 日志"), vm.diagLogText))
                        Toast.makeText(context, tr("日志已复制"), Toast.LENGTH_SHORT).show()
                    },
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                ) { Text(tr("复制日志"), fontSize = 12.sp) }
                Spacer(Modifier.width(10.dp))
                OutlinedButton(
                    onClick = {
                        vm.refreshDiagLogFromDisk()
                        Toast.makeText(context, tr("已读取磁盘日志"), Toast.LENGTH_SHORT).show()
                    },
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                ) { Text(tr("从磁盘读取"), fontSize = 12.sp) }
                Spacer(Modifier.width(10.dp))
                OutlinedButton(
                    onClick = { vm.clearDiagLog() },
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                ) { Text(tr("清空"), fontSize = 12.sp) }
            }
        }

        SectionCard(
            title = tr("用途"),
            icon = Icons.Outlined.Build,
            badge = tr("不影响正常合成"),
            badgeColor = c.accent,
        ) {
            Text(
                tr("在这里反复跑一段合成，只看引擎吐出的分阶段耗时，不落盘、不播放、不进收藏。") +
                    tr("用来摸清这台机器上时间到底花在哪、连续生成时有多热。") +
                    tr("温度取电池温度（公开 API，单位可靠）；普通 App 拿不到真实 SoC 结温，读不到会显示「不可用」。") +
                    tr("每条结果都带 flush 次数与分段耗时，改完线程数后再跑 5 次，") +
                    tr("比这些项就能看出参数调整到底有没有换来速度。") +
                    tr("下面的「声码器线程对照」「CPU 线程数对照」是两组一次性的 A/B，结论只用于决定要不要改默认值。"),
                style = MaterialTheme.typography.labelSmall,
                color = c.t3,
            )
        }

        SectionCard(title = tr("测试内容"), icon = Icons.Outlined.Create) {
            ImeAwareTextField(
                value = vm.diagText,
                onValueChange = { vm.diagText = it },
                label = { Text(tr("合成文本")) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                maxLines = 4,
                textStyle = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(12.dp))
            Text(tr("连续运行次数"), style = MaterialTheme.typography.titleSmall, color = c.t2)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 3, 5, 10).forEach { n ->
                    val on = batches == n
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .background(if (on) c.accent else c.fill)
                            .clickable(enabled = !vm.diagRunning) { batches = n }
                            .padding(horizontal = 16.dp, vertical = 9.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            tr("$n 次", "$n runs"),
                            fontSize = 12.5.sp,
                            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (on) c.onAccent else c.t2,
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BreezePrimaryButton(
                    text = if (vm.diagRunning) tr("测试进行中…") else tr("开始测试"),
                    onClick = { vm.runDiagBatch(batches) },
                    enabled = !vm.diagRunning && vm.engineState is EngineState.Ready,
                    modifier = Modifier.weight(1f),
                    height = BreezeSize.buttonSmall,
                )
                if (vm.diagRunning) {
                    OutlinedButton(
                        onClick = { vm.stopDiag() },
                        modifier = Modifier.weight(1f),
                    ) { Text(tr("停止")) }
                }
            }
            if (vm.diagProgress.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(vm.diagProgress, fontSize = 12.sp, color = c.t3)
            }
        }

        // 1.9.101：调度层两组假设已验完（线程池切换 0.7 ms、THP 本机内核 never），
        // 只留下线程池这一组——GPU 声码器已默认不切，它现在服务于 CPU 声码器的机器。
        SectionCard(
            title = tr("声码器线程对照"),
            icon = Icons.Outlined.Refresh,
            badge = "A/B",
            badgeColor = c.accent,
        ) {
            Text(
                tr("同一句文本、同一组参数，只在 flush 期间把声码器线程切成 8 或跟随主线程，交替三轮。\n") +
                    tr("声码器在 GPU 上时，这组量到的只是「重建 ggml 线程池」这点空转开销，") +
                    tr("1.9.100 实测 0.7 ms（组内波动 ±17 ms），所以 1.9.101 起默认不再切；") +
                    tr("声码器在 CPU 上时，它才反映真实的线程数收益，值得按机型复核。\n") +
                    tr("跑完看「每帧」与「组内波动」：差值小于波动就是机身温度在变，不要当成收益。"),
                style = MaterialTheme.typography.labelSmall,
                color = c.t3,
            )
            Spacer(Modifier.height(10.dp))
            BreezePrimaryButton(
                text = tr("切 8 / 不切（6 次 · 约 2 分半）"),
                onClick = { vm.runSwapExperiment() },
                enabled = !vm.expRunning && !vm.diagRunning && vm.engineState is EngineState.Ready,
                modifier = Modifier.fillMaxWidth(),
                height = BreezeSize.buttonSmall,
            )
            if (vm.expRunning) {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(vm.expProgress, fontSize = 12.sp, color = c.t3, modifier = Modifier.weight(1f))
                    OutlinedButton(
                        onClick = { vm.stopExperiment() },
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    ) { Text(tr("停止"), fontSize = 12.sp) }
                }
            }
            if (vm.expRows.isNotEmpty() && startsWithTr(vm.expTitle, "声码器线程")) {
                Spacer(Modifier.height(12.dp))
                Text(vm.expTitle, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = c.t1)
                Spacer(Modifier.height(6.dp))
                ExpHeader()
                vm.expRows.forEach { row ->
                    ExpRowLine(
                        row = row,
                        playing = vm.playback.playing && vm.playback.path == row.audioPath,
                        onPlay = { vm.playDiagAudio(row.audioPath, "${vm.expTitle} · ${row.label}") },
                    )
                }
                // flush 次数决定线程池切换发生了几次；线程档位说明这几行数字属于哪组配置。
                Text(
                    "flush " + vm.expRows.joinToString("/") { "${it.flushes}" } + tr(" 次") +
                        tr(" · 主干 ${vm.threads} 线程", " · backbone ${vm.threads} threads") +
                        tr(" · 声码器 ") + (if (vm.vocoderOnGpu) tr("GPU（不切线程）") else tr("CPU ${vm.vocThreads} 线程", "CPU ${vm.vocThreads} threads")),
                    fontSize = 10.sp,
                    color = c.t3,
                )
                if (vm.expRows.any { it.audioPath.isNotBlank() }) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        tr("点任意一行试听那一次的输出（原始 WAV，未做后处理）；再点一次暂停。"),
                        fontSize = 10.sp,
                        color = c.t3,
                    )
                }
                if (vm.expVerdict.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        vm.expVerdict,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = c.accent,
                    )
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { vm.clearExperiment() }, modifier = Modifier.fillMaxWidth()) {
                    Text(tr("清空实验"))
                }
            }
        }

        // 1.9.102：批=1 的逐帧 GEMV 是带宽受限，线程开过「DRAM 能吃满」的数量之后，
        // 多出来的线程只在 ggml_barrier 里空转并加热机身。docs/24 只量过 8 → 4，4 以下没扫过。
        SectionCard(
            title = tr("CPU 线程数对照"),
            icon = Icons.Outlined.Refresh,
            badge = "A/B",
            badgeColor = c.accent,
        ) {
            Text(
                tr("同一句文本、同一组参数，只改 CPU 线程数：2 / 3 / 4 / 6，交替两轮共 8 次。\n") +
                    tr("为什么值得测：批=1 的逐帧矩阵乘是内存带宽受限，线程数超过「能把 DDR 吃满」") +
                    tr("的数量后，多出来的线程只是在屏障里空转、顺带把机身加热。") +
                    tr("旧版量过 8 → 4 是正收益（主干 −11%、深度 −6%），但 4 以下一直没扫。\n") +
                    tr("顺序是 2→3→4→6→6→4→3→2，对称排列，抵消三分钟里的线性热漂移。"),
                style = MaterialTheme.typography.labelSmall,
                color = c.t3,
            )
            Spacer(Modifier.height(10.dp))
            BreezePrimaryButton(
                text = tr("2 / 3 / 4 / 6（8 次 · 约 3 分半）"),
                onClick = { vm.runThreadExperiment() },
                enabled = !vm.expRunning && !vm.diagRunning && vm.engineState is EngineState.Ready,
                modifier = Modifier.fillMaxWidth(),
                height = BreezeSize.buttonSmall,
            )
            if (vm.expRunning) {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(vm.expProgress, fontSize = 12.sp, color = c.t3, modifier = Modifier.weight(1f))
                    OutlinedButton(
                        onClick = { vm.stopExperiment() },
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    ) { Text(tr("停止"), fontSize = 12.sp) }
                }
            }
            if (vm.expRows.isNotEmpty() && startsWithTr(vm.expTitle, "CPU 线程数")) {
                Spacer(Modifier.height(12.dp))
                Text(vm.expTitle, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = c.t1)
                Spacer(Modifier.height(6.dp))
                ExpHeader()
                vm.expRows.forEach { row ->
                    ExpRowLine(
                        row = row,
                        playing = vm.playback.playing && vm.playback.path == row.audioPath,
                        onPlay = { vm.playDiagAudio(row.audioPath, "${vm.expTitle} · ${row.label}") },
                    )
                }
                // 1.9.103：首声拆成两段。线程数只影响逐帧，prefill 才是「点下去到出声」的大头，
                // 而它从来没被单独量过 —— 没有 tok/s 就分不清「1.5 s 是 GEMM 慢还是文本编码器慢」。
                val pf = vm.expRows.filter { it.ok && it.prefillTokens > 0 }
                if (pf.isNotEmpty()) {
                    val mid = pf.size / 2
                    val pMs = pf.map { it.prefillMs }.sorted()[mid]
                    val pTk = pf.map { it.prefillTokens }.sorted()[mid]
                    val rTk = pf.map { it.prefillReused }.sorted()[mid]
                    val eMs = pf.map { it.promptMs }.sorted()[mid]
                    val tps = if (pMs > 0.5) pTk * 1000.0 / pMs else 0.0
                    Spacer(Modifier.height(8.dp))
                    Text(
                        tr("首声：文本编码 %.0f ms + 主干 prefill %.0f ms（%d token%s，%.1f tok/s），合计 %.2f s")
                            .format(
                                eMs, pMs, pTk,
                                if (rTk > 0) tr("，其中 $rTk 复用前缀", ", $rTk of them reusing the prefix") else "",
                                tps, (eMs + pMs) / 1000.0,
                            ),
                        fontSize = 11.5.sp,
                        color = c.t1,
                    )
                    Text(
                        if (tps <= 0) tr("prefill 没测到 token 数（旧库），换个包再看。")
                        else if (tps < 60) tr("低于 60 tok/s：GEMM 很可能没走到 i8mm 矩阵指令，重编 KleidiAI 值 1.7 倍。")
                        else if (tps > 150) tr("超过 150 tok/s：prefill 已经吃满矩阵单元，这条封掉，首声只能从别处省。")
                        else tr("60–150 之间：看 prompt 长度，短 prompt 的 GEMM 天然跑不满，先别急着归因。"),
                        fontSize = 10.sp,
                        color = c.t3,
                    )
                }
                if (vm.expVerdict.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        vm.expVerdict,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = c.accent,
                    )
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { vm.clearExperiment() }, modifier = Modifier.fillMaxWidth()) {
                    Text(tr("清空实验"))
                }
            }
        }

        // 1.9.106：深度的字节量由「15 个码本 × 333 M 权重」决定，带宽已经到 80%，
        // 唯一还剩的一刀是遍数。时间账能算，音质只能听。
        SectionCard(
            title = tr("码本截断对照"),
            icon = Icons.Outlined.Refresh,
            badge = "A/B",
            badgeColor = c.accent,
        ) {
            Text(
                tr("同一段文本，深度解码分别只解前 15 / 12 / 10 / 8 个码本，") +
                    tr("剩下的位置复读上一帧同位置的码本（首帧补 0）。对称跑两轮共 8 次。\n") +
                    tr("为什么值得测：深度占整帧 65%（实测 97.7 ms/帧），而它每帧必须把同一份") +
                    tr("333 M 权重读 15 遍——字节量是结构决定的，带宽上再优化不出东西。\n") +
                    tr("这一组不会自动给结论：时间账能算，音质只能听。跑完逐条点开试听，") +
                    tr("重点听尾音、气声、齿音有没有发闷、断续或念错字。"),
                style = MaterialTheme.typography.labelSmall,
                color = c.t3,
            )
            Spacer(Modifier.height(10.dp))
            BreezePrimaryButton(
                text = tr("15 / 12 / 10 / 8（8 次 · 约 2 分钟）"),
                onClick = { vm.runCodebookExperiment() },
                enabled = !vm.expRunning && !vm.diagRunning && vm.engineState is EngineState.Ready,
                modifier = Modifier.fillMaxWidth(),
                height = BreezeSize.buttonSmall,
            )
            if (vm.expRunning) {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(vm.expProgress, fontSize = 12.sp, color = c.t3, modifier = Modifier.weight(1f))
                    OutlinedButton(
                        onClick = { vm.stopExperiment() },
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    ) { Text(tr("停止"), fontSize = 12.sp) }
                }
            }
            if (vm.expRows.isNotEmpty() && startsWithTr(vm.expTitle, "码本截断")) {
                Spacer(Modifier.height(12.dp))
                Text(vm.expTitle, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = c.t1)
                Spacer(Modifier.height(6.dp))
                ExpHeader()
                vm.expRows.forEach { row ->
                    ExpRowLine(
                        row = row,
                        playing = vm.playback.playing && vm.playback.path == row.audioPath,
                        onPlay = { vm.playDiagAudio(row.audioPath, "${vm.expTitle} · ${row.label}") },
                    )
                }
                if (vm.expRows.any { it.audioPath.isNotBlank() }) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        tr("点任意一行试听（原始 WAV）。这一组的判据在耳朵里，不在数字里。"),
                        fontSize = 10.sp,
                        color = c.t3,
                    )
                }
                if (vm.expVerdict.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        vm.expVerdict,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = c.accent,
                    )
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { vm.clearExperiment() }, modifier = Modifier.fillMaxWidth()) {
                    Text(tr("清空实验"))
                }
            }
        }

        SectionCard(
            title = tr("实时状态"),
            icon = Icons.Outlined.Refresh,
            badge = vm.diagTempC?.let { "%.1f°C".format(it) } ?: tr("温度不可用"),
            badgeColor = c.accent,
        ) {
            KeyValueRow(tr("计算后端"), if (eqTr(vm.backendName, "未加载")) "—" else vm.backendName)
            KeyValueRow(tr("CPU 特性"), vm.cpuFeatures.ifBlank { "—" })
            KeyValueRow(
                tr("电池温度"),
                vm.diagTempC?.let { "%.1f °C".format(it) } ?: tr("不可用"),
            )
            KeyValueRow(tr("已完成"), tr("${vm.diagRuns.size} 次", "${vm.diagRuns.size} runs"))
        }

        if (vm.diagRuns.isNotEmpty()) {
            SectionCard(
                title = tr("历次结果"),
                icon = Icons.Outlined.List,
                badge = tr("${vm.diagRuns.size} 条", "${vm.diagRuns.size} rows"),
                badgeColor = c.accent,
            ) {
                vm.diagRuns.forEach { run ->
                    DiagRunCard(
                        run = run,
                        playing = vm.playback.playing && vm.playback.path == run.audioPath,
                        onPlay = { vm.playDiagAudio(run.audioPath, tr("诊断第 ${run.index} 次", "Diagnostic run ${run.index}")) },
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        tr("复制后可整段粘贴，含线程配置与 flush 次数"),
                        fontSize = 10.5.sp, color = c.t3,
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE)
                                as ClipboardManager
                            cm.setPrimaryClip(
                                ClipData.newPlainText(tr("BreezeTTS 诊断"), vm.diagReport()),
                            )
                            Toast.makeText(context, tr("结果已复制"), Toast.LENGTH_SHORT).show()
                        },
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    ) { Text(tr("复制结果"), fontSize = 12.sp) }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { vm.clearDiag() }, modifier = Modifier.fillMaxWidth()) {
                    Text(tr("清空结果"))
                }
            }
        }

        // 1.9.92：上次异常中断的现场。
        // 以前这条会以 Toast 的形式弹在首页 —— 用户打开 app 只是想合成，
        // 一句「上次生成中断在深度解码器」既给不出可操作的信息，又挡住界面。
        // 现在只放在诊断页最下方，配原文与复制，想查的人自己进来查。
        if (vm.crashNote != null) {
            SectionCard(
                title = tr("上次异常中断"),
                icon = Icons.Outlined.Build,
                badge = tr("崩溃现场"),
                badgeColor = MaterialTheme.colorScheme.error,
            ) {
                Text(
                    tr("上一次生成 / 推理没有正常结束，进程退出在下面的阶段。") +
                        tr("如果之后合成都正常，这条可以忽略并清除；如果反复出现，") +
                        tr("复制这段现场能直接定位到 native 的哪一步。"),
                    style = MaterialTheme.typography.labelSmall,
                    color = c.t3,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    vm.crashNote ?: "",
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.error,
                )
                if (vm.lastTrace.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        vm.lastTrace,
                        fontSize = 10.sp,
                        lineHeight = 14.sp,
                        fontFamily = FontFamily.Monospace,
                        color = c.t2,
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedButton(
                        onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE)
                                as ClipboardManager
                            cm.setPrimaryClip(
                                ClipData.newPlainText(
                                    tr("BreezeTTS 崩溃现场"),
                                    tr("上次生成中断在：${vm.crashNote}\n\n${vm.lastTrace}", "Last generation stopped at: ${vm.crashNote}\n\n${vm.lastTrace}"),
                                ),
                            )
                            Toast.makeText(context, tr("已复制"), Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                    ) { Text(tr("复制现场"), fontSize = 12.sp) }
                    OutlinedButton(
                        onClick = { vm.clearCrashNote() },
                        modifier = Modifier.weight(1f),
                    ) { Text(tr("清除"), fontSize = 12.sp) }
                }
            }
        }
    }
}

/** 调度实验表头：列宽与 ExpRowLine 必须一致，否则数字对不齐。 */
@Composable
private fun ExpHeader() {
    val c = Breeze.colors
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Text(tr("配置"), fontSize = 10.5.sp, color = c.t3, modifier = Modifier.width(52.dp))
        Text(tr("墙钟"), fontSize = 10.5.sp, color = c.t3, modifier = Modifier.width(44.dp))
        Text(tr("每帧"), fontSize = 10.5.sp, color = c.t3, modifier = Modifier.width(48.dp))
        Text(
            tr("计算/帧"),
            fontSize = 10.5.sp, color = c.t3,
            modifier = Modifier.weight(1f), textAlign = TextAlign.End,
        )
        Text(
            tr("声码/帧"),
            fontSize = 10.5.sp, color = c.t3,
            modifier = Modifier.width(62.dp), textAlign = TextAlign.End,
        )
    }
}

/**
 * 一行实验结果。失败时只显示原因，不显示 0 值——0 会被误读成「很快」。
 * 点击整行试听那一次的输出：耗时只差几个百分点时，音频有没有拼错（爆音、截断）
 * 只有耳朵能判断。
 */
@Composable
private fun ExpRowLine(
    row: AppViewModel.ExpRow,
    playing: Boolean,
    onPlay: () -> Unit,
) {
    val c = Breeze.colors
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(7.dp))
            .clickable(enabled = row.audioPath.isNotBlank(), onClick = onPlay)
            .background(if (playing) c.accent.copy(alpha = 0.10f) else Color.Transparent)
            .padding(vertical = 3.dp, horizontal = 2.dp),
    ) {
        Text(
            (if (playing) "▶ " else "") + row.label,
            fontSize = 11.5.sp,
            color = if (playing) c.accent else c.t1,
            modifier = Modifier.width(52.dp),
            maxLines = 1,
        )
        if (!row.ok) {
            Text(
                row.note.ifBlank { tr("失败（原因未记录，见下方测试日志）") },
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.error,
                maxLines = 3,
            )
            return@Row
        }
        Text("%.1fs".format(row.wallMs / 1000.0), fontSize = 11.5.sp, color = c.t2, modifier = Modifier.width(44.dp))
        Text("%.1f".format(row.perFrame), fontSize = 11.5.sp, color = c.t2, modifier = Modifier.width(48.dp))
        Text(
            "%.1f ms".format(row.computePerFrame),
            fontSize = 11.5.sp, color = c.t2,
            modifier = Modifier.weight(1f), textAlign = TextAlign.End,
        )
        Text(
            "%.1f ms".format(row.vocPerFrame),
            fontSize = 11.5.sp, color = c.t2,
            modifier = Modifier.width(62.dp), textAlign = TextAlign.End,
        )
    }
}

/** 单次诊断结果：五段耗时横条 + 关键指标 + 试听 */
@Composable
private fun DiagRunCard(
    run: AppViewModel.DiagRun,
    playing: Boolean,
    onPlay: () -> Unit,
) {
    val c = Breeze.colors
    val s = run.stage
    val total = (s.promptMs + s.prefillMs + s.backboneMs + s.depthMs + s.vocoderMs + s.tailMs)
        .coerceAtLeast(1.0)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(c.fill)
            .padding(horizontal = 12.dp, vertical = 11.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("第 ${run.index} 次", "Run ${run.index}"), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.t1)
            Spacer(Modifier.weight(1f))
            if (run.audioPath.isNotBlank()) {
                Text(
                    if (playing) tr("▶ 播放中") else tr("试听"),
                    fontSize = 11.sp,
                    color = c.accent,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable(onClick = onPlay)
                        .padding(horizontal = 7.dp, vertical = 3.dp),
                )
                Spacer(Modifier.width(6.dp))
            }
            if (!run.ok) {
                Text(tr("失败"), fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
            } else {
                Text(
                    tr("RTF %.2f · %.1f 秒音频").format(run.rtf, s.frames * 80 / 1000.0),
                    fontSize = 11.5.sp, color = c.t2,
                )
            }
        }
        if (run.message.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(run.message, fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(9.dp))
        val bars = listOf(
            tr("文本编码") to s.promptMs,
            tr("预填充") to s.prefillMs,
            tr("主干逐帧") to s.backboneMs,
            tr("深度解码") to s.depthMs,
            tr("声码器") to s.vocoderMs,
            tr("收尾") to s.tailMs,
        )
        bars.forEach { (name, ms) ->
            DiagBar(name, ms, (ms / total).toFloat().coerceIn(0f, 1f))
            Spacer(Modifier.height(5.dp))
        }
        Spacer(Modifier.height(3.dp))
        Text(
            tr("墙钟 %d ms · %d 帧 · %d 步 · %d 次 flush（块 %d 帧）· 电池 %s").format(
                run.wallMs, s.frames, s.steps, s.flushes, run.chunk,
                run.tempC?.let { "%.1f°C".format(it) } ?: "—",
            ),
            fontSize = 10.5.sp, color = c.t3,
        )
        if (run.audioPath.isNotBlank()) {
            Text(
                tr("电平 峰值 %.0f%% · 均方根 %.0f%%%s").format(
                    run.peak * 100, run.rms * 100,
                    when {
                        s.frames > 0 && run.peak < 0.01f -> tr("（几乎静音，音频可能没出来）")
                        run.peak > 0.99f -> tr("（接近满量程，可能削波）")
                        else -> ""
                    },
                ),
                fontSize = 10.5.sp, color = c.t3,
            )
        }
        // 声码器「每帧成本」= 声码器耗时 / 产出帧数。首块 start=0 时滑窗上下文是空的，
        // 所以这里不摊 88 帧——摊了会把 54 ms/帧 显示成 14 ms/帧（docs/51）。
        if (run.ok && s.frames > 0) {
            val perFrame = s.vocoderMs / s.frames
            Spacer(Modifier.height(2.dp))
            Text(
                tr("线程 %s · cfg %s · 声码器 %.1f ms/帧").format(
                    if (run.threads > 0) run.threads.toString() else "—",
                    if (run.cfg > 0f) "%.1f".format(run.cfg) else "—",
                    perFrame,
                ),
                fontSize = 10.5.sp, color = c.t3,
            )
        }
    }
}

@Composable
private fun DiagBar(name: String, ms: Double, fraction: Float) {
    val c = Breeze.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(name, fontSize = 10.5.sp, color = c.t3, modifier = Modifier.width(52.dp))
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier
                .weight(1f)
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(c.fill2),
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction.coerceAtLeast(0.01f))
                    .clip(RoundedCornerShape(4.dp))
                    .background(c.accent),
            )
        }
        Spacer(Modifier.width(8.dp))
        Text("%.0f ms".format(ms), fontSize = 10.5.sp, color = c.t2, modifier = Modifier.width(58.dp))
    }
}

// ==================== 关于 ====================

// ==================== 语言 ====================

@Composable
private fun LanguagePage(vm: AppViewModel, onBack: () -> Unit) {
    PageScaffold(tr("语言"), tr("界面语言 · 立即生效，不用重启"), onBack) {
        SectionCard(title = tr("显示语言"), icon = Icons.Outlined.Create) {
            LangRow(tr("跟随系统"), tr("系统是英文就显示英文"), vm.language == Lang.MODE_SYSTEM) {
                vm.changeLanguage(Lang.MODE_SYSTEM)
            }
            LangRow("中文", tr("始终使用中文"), vm.language == Lang.MODE_ZH) {
                vm.changeLanguage(Lang.MODE_ZH)
            }
            LangRow("English", "Always use English", vm.language == Lang.MODE_EN) {
                vm.changeLanguage(Lang.MODE_EN)
            }
        }
        Text(
            tr("英文只影响界面与提示。合成的语音、音色名称、历史记录不会变。"),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun LangRow(title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(2.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (selected) {
            Icon(
                Icons.Outlined.CheckCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

@Composable
private fun AboutPage(vm: AppViewModel, onBack: () -> Unit) {
    PageScaffold(tr("关于"), tr("版本与许可"), onBack) {
        SectionCard(title = tr("版本信息"), icon = Icons.Outlined.Info) {
            // 连点 6 次解锁「性能诊断」（默认隐藏，见 AppViewModel.tapVersion）。
            KeyValueRow(
                key = tr("版本"),
                value = "v${BuildConfig.VERSION_NAME}（${BuildConfig.VERSION_CODE}）",
                modifier = Modifier.clickable { vm.tapVersion() },
            )
            KeyValueRow(tr("推理内核"), "Breeze-TTS-2.cpp + ggml")
            KeyValueRow(tr("量化内核"), vm.gemmLaneText)
            KeyValueRow(tr("计算后端"), if (eqTr(vm.backendName, "未加载")) "—" else vm.backendName)
        }

        SectionCard(title = tr("作者"), icon = Icons.Outlined.Person) {
            val ctx = LocalContext.current
            // 人名不翻译：中文界面和英文界面都显示同一串，避免「Chibangzi」这种
            // 音译把本名弄丢。所以这里不用 tr()，两支语言共用一份。
            KeyValueRow(tr("作者"), "翅膀子（chibangzi）")
            // 点一下复制，按钮才是发信：没有邮件 App 的机型上点「写邮件」会很尴尬，
            // 复制走系统剪贴板，哪儿都能粘贴。
            KeyValueRow(
                tr("邮箱"),
                AUTHOR_EMAIL,
                modifier = Modifier.clickable {
                    copyText(ctx, AUTHOR_EMAIL, tr("邮箱已复制"))
                },
            )
            Text(
                tr("这个 App 是个人作品。有问题或建议，都可以直接找我。"),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { mailTo(ctx, AUTHOR_EMAIL) },
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                ) { Text(tr("写邮件"), fontSize = 12.sp) }
                OutlinedButton(
                    onClick = { copyText(ctx, AUTHOR_EMAIL, tr("邮箱已复制")) },
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                ) { Text(tr("复制邮箱"), fontSize = 12.sp) }
            }
        }

        SectionCard(title = tr("关于许可"), icon = Icons.Outlined.Info) {
            Text(
                tr("Breeze TTS 2 推理代码为 Apache-2.0，但权重、量化派生模型与自托管输出遵循 ") +
                    tr("BreezeBlue Research and Non-Commercial License：仅限研究与非商业用途。") +
                    tr("禁止未授权的音色克隆、冒充与欺诈。商用需向 BreezeBlue 取得书面授权。"),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** 作者联系邮箱，只在「关于」里用；不跟着界面语言翻译。 */
private const val AUTHOR_EMAIL = "49051886@qq.com"

/** 复制到剪贴板并轻提示。 */
private fun copyText(ctx: Context, text: String, tip: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(text, text))
    Toast.makeText(ctx, tip, Toast.LENGTH_SHORT).show()
}

/**
 * 发信。走 `mailto:` 而不是 `ACTION_SEND` —— 后者在没配过邮箱的机器上会弹
 * 「分享到…」，选完还得自己填收件人。没有邮件 App 时退回复制，别让按钮变哑巴。
 */
private fun mailTo(ctx: Context, addr: String) {
    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$addr"))
    try {
        ctx.startActivity(Intent.createChooser(intent, tr("写邮件")))
    } catch (e: Exception) {
        copyText(ctx, addr, tr("没有找到邮件 App，邮箱已复制"))
    }
}

/** 右侧值最多占多少宽，避免长路径把标题挤没 */
private fun Modifier.widthInMax(max: androidx.compose.ui.unit.Dp): Modifier =
    this.widthIn(max = max)
