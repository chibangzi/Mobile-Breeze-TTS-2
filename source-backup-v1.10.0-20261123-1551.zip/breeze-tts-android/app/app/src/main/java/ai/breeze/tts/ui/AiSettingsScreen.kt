package ai.breeze.tts.ui

import ai.breeze.tts.i18n.eqTr
import ai.breeze.tts.i18n.startsWithTr
import ai.breeze.tts.i18n.tr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.breeze.tts.data.AiClient
import ai.breeze.tts.data.AiProvider
import ai.breeze.tts.data.AiVendors
import ai.breeze.tts.ui.theme.BrandMint
import ai.breeze.tts.vm.AppViewModel

/**
 * AI 接口设置（1.9.12）。
 *
 * 只有「扩写」这一个功能会用到这里配置的模型，推理本身仍然完全离线。
 * 同一时间只允许启用一条：扩写是单点调用，多启用会产生「到底用哪个」的歧义。
 */
@Composable
fun AiSettingsPage(vm: AppViewModel, onBack: () -> Unit) {
    var editing by remember { mutableStateOf<AiProvider?>(null) }
    var deleting by remember { mutableStateOf<AiProvider?>(null) }

    PageScaffold(tr("AI 接口"), tr("扩写功能使用的模型服务"), onBack) {
        SectionCard(
            title = tr("用途说明"),
            icon = Icons.Outlined.Info,
            badge = if (vm.enabledAi == null) tr("未启用") else tr("已启用"),
            badgeColor = if (vm.enabledAi == null) MaterialTheme.colorScheme.onSurfaceVariant
            else BrandMint,
        ) {
            Text(
                tr("这里配置的 AI 只用于「扩写」：把你在输入框里写的需求，扩成可以直接朗读的") +
                    tr("正文或多角色剧本。语音合成本身仍然完全在本机离线运行，不会上传任何文本。"),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                tr("可以接入任何兼容 OpenAI 格式的服务。同一时间只启用一条，") +
                    tr("启用新的会自动关闭旧的。"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (vm.aiProviders.isEmpty()) {
            SectionCard(title = tr("还没有配置"), icon = Icons.Outlined.Add) {
                EmptyState(
                    icon = Icons.Outlined.Info,
                    title = tr("先添加一条接口"),
                    subtitle = tr("选一个厂商模板，填上 API Key 就能用"),
                )
            }
        } else {
            vm.aiProviders.forEach { p ->
                ProviderCard(
                    provider = p,
                    onToggle = { vm.setAiEnabled(p.id, it) },
                    onEdit = { vm.clearAiTestResult(); editing = p },
                    onDelete = { deleting = p },
                )
            }
        }

        GradientButton(
            text = tr("添加接口"),
            icon = Icons.Outlined.Add,
            onClick = { vm.clearAiTestResult(); editing = AiProvider() },
            modifier = Modifier.fillMaxWidth(),
        )

        Text(
            tr("API Key 只保存在本机 App 私有目录，不会随导出或日志带出。"),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    editing?.let { initial ->
        ProviderEditorSheet(
            initial = initial,
            vm = vm,
            onDismiss = { editing = null },
            onSave = { p ->
                vm.saveAiProvider(p)
                editing = null
            },
        )
    }

    deleting?.let { p ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(tr("删除接口")) },
            text = { Text(tr("确定删除「${p.displayName}」？删除后无法恢复。", "Delete \"${p.displayName}\"? This can't be undone.")) },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteAiProvider(p.id)
                    deleting = null
                }) { Text(tr("删除"), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text(tr("取消")) }
            },
        )
    }
}

@Composable
private fun ProviderCard(
    provider: AiProvider,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    SectionCard(
        title = provider.displayName,
        subtitle = provider.vendorLabel(),
        icon = Icons.Outlined.Refresh,
        badge = if (provider.enabled) tr("已启用") else tr("未启用"),
        badgeColor = if (provider.enabled) BrandMint else MaterialTheme.colorScheme.onSurfaceVariant,
    ) {
        KeyValueRow(tr("地址"), provider.baseUrl.ifBlank { "—" })
        KeyValueRow(tr("模型"), provider.model.ifBlank { "—" })
        KeyValueRow(
            tr("密钥"),
            if (provider.apiKey.isBlank()) "—" else maskKey(provider.apiKey),
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = provider.enabled, onCheckedChange = onToggle)
            Spacer(Modifier.width(8.dp))
            Text(
                if (provider.enabled) tr("扩写使用这条") else tr("启用"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onEdit) {
                Icon(Icons.Outlined.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(tr("编辑"))
            }
            TextButton(onClick = onDelete) {
                Icon(
                    Icons.Outlined.Delete,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.error,
                )
                Spacer(Modifier.width(4.dp))
                Text(tr("删除"), color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun ProviderEditorSheet(
    initial: AiProvider,
    vm: AppViewModel,
    onDismiss: () -> Unit,
    onSave: (AiProvider) -> Unit,
) {
    var label by remember { mutableStateOf(initial.label) }
    var vendor by remember { mutableStateOf(initial.vendor.ifBlank { "openai" }) }
    var baseUrl by remember { mutableStateOf(initial.baseUrl) }
    var apiKey by remember { mutableStateOf(initial.apiKey) }
    var model by remember { mutableStateOf(initial.model) }
    var showKey by remember { mutableStateOf(false) }
    var enabled by remember { mutableStateOf(initial.enabled) }

    fun draft() = initial.copy(
        label = label.trim(),
        vendor = vendor,
        baseUrl = baseUrl.trim(),
        apiKey = apiKey.trim(),
        model = model.trim(),
        enabled = enabled,
    )

    BreezeSheet(visible = true, onDismiss = onDismiss, heightFraction = 0.92f) {
        SheetTopBar(
            title = if (initial.baseUrl.isBlank() && initial.apiKey.isBlank()) tr("添加接口") else tr("编辑接口"),
            onClose = onDismiss,
        )

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(tr("厂商模板"), style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)

            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                AiVendors.all.forEach { v ->
                    val on = v.id == vendor
                    Surface(
                        Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .clickable {
                                vendor = v.id
                                // 只在用户还没改过地址/模型时套模板，避免覆盖手工输入
                                val untouched = baseUrl.isBlank() ||
                                    AiVendors.all.any { it.baseUrl == baseUrl }
                                val modelUntouched = model.isBlank() ||
                                    AiVendors.all.any { it.model == model }
                                if (untouched) baseUrl = v.baseUrl
                                if (modelUntouched) model = v.model
                            },
                        shape = RoundedCornerShape(999.dp),
                        color = if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
                            else MaterialTheme.colorScheme.outlineVariant,
                        ),
                    ) {
                        Text(
                            v.label,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (on) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            AiVendors.byId(vendor).note.takeIf { it.isNotBlank() }?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            ImeAwareTextField(
                value = label,
                onValueChange = { label = it },
                label = { Text(tr("备注名（可选）")) },
                placeholder = { Text(tr("例如：DeepSeek 主力")) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            ImeAwareTextField(
                value = baseUrl,
                onValueChange = { baseUrl = it },
                label = { Text("Base URL") },
                placeholder = { Text("https://api.deepseek.com/v1") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )

            // 实时显示最终会请求的完整地址。换个 App 能连通、这里不通时，
            // 第一件要核对的就是这个地址和对方填的是不是同一个。
            AiClient.endpointOf(baseUrl).takeIf { it.isNotBlank() }?.let { ep ->
                Text(
                    tr("实际请求：$ep", "Actual request: $ep"),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp,
                )
            }

            ImeAwareTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("API Key") },
                singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None
                else PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
            )

            TextButton(onClick = { showKey = !showKey }) {
                Text(if (showKey) tr("隐藏密钥") else tr("显示密钥"))
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                ImeAwareTextField(
                    value = model,
                    onValueChange = { model = it },
                    label = { Text(tr("模型名")) },
                    placeholder = { Text("deepseek-chat") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                OutlinedButton(
                    onClick = {
                        vm.clearAiModels()
                        vm.fetchAiModels(draft())
                    },
                    enabled = !vm.aiModelsBusy,
                ) {
                    Text(if (vm.aiModelsBusy) "…" else tr("拉取"))
                }
            }

            vm.aiModelsError?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error,
                    lineHeight = 15.sp,
                )
            }

            Text(
                tr("扩写需要对话类模型。点「拉取」可以从这个接口可用的模型里选择。"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp,
            )

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("保存后立即启用"), style = MaterialTheme.typography.titleSmall)
                    Text(
                        tr("启用后，扩写会使用这条配置"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = enabled, onCheckedChange = { enabled = it })
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            OutlinedButton(
                onClick = { vm.testAiProvider(draft()) },
                enabled = !vm.aiTestBusy,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (vm.aiTestBusy) tr("正在测试…") else tr("测试连接"))
            }

            vm.aiTestResult?.let { r ->
                val ok = startsWithTr(r, "连接成功")
                Surface(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = if (ok) BrandMint.copy(alpha = 0.12f)
                    else MaterialTheme.colorScheme.error.copy(alpha = 0.10f),
                ) {
                    Text(
                        r,
                        modifier = Modifier.padding(11.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (ok) BrandMint else MaterialTheme.colorScheme.error,
                    )
                }
            }

            Spacer(Modifier.height(4.dp))
            Text(
                tr("只填服务地址即可，请求路径会自动补全。"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp,
            )
            Spacer(Modifier.height(16.dp))
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                Text(tr("取消"))
            }
            GradientButton(
                text = tr("保存"),
                onClick = {
                    vm.clearAiTestResult()
                    onSave(draft())
                },
                modifier = Modifier.weight(1.2f),
                height = 48.dp,
            )
        }
    }

    // 从接口真实返回的模型列表里挑一个，避免手填到生图模型这种明显不合适的名字
    if (vm.aiModels.isNotEmpty()) {
        ModelPickerDialog(
            models = vm.aiModels,
            current = model,
            onPick = {
                model = it
                vm.clearAiModels()
            },
            onDismiss = { vm.clearAiModels() },
        )
    }
}

@Composable
private fun ModelPickerDialog(
    models: List<String>,
    current: String,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val chatables = models.filter { AiClient.looksChatable(it) }
    val others = models.filterNot { AiClient.looksChatable(it) }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("可用模型（${models.size}）", "Available models (${models.size})")) },
        text = {
            Column(
                Modifier
                    .heightIn(max = 430.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                if (chatables.isNotEmpty()) {
                    Text(
                        tr("对话模型 · 可以用于扩写"),
                        style = MaterialTheme.typography.labelSmall,
                        color = BrandMint,
                    )
                    Spacer(Modifier.height(4.dp))
                    chatables.forEach { id ->
                        ModelRow(id, active = id == current) { onPick(id) }
                    }
                }
                if (others.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        tr("生图 / 向量等 · 不能用于扩写"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(4.dp))
                    others.forEach { id ->
                        ModelRow(id, active = id == current, dim = true) { onPick(id) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(tr("关闭")) }
        },
    )
}

@Composable
private fun ModelRow(id: String, active: Boolean, dim: Boolean = false, onClick: () -> Unit) {
    Text(
        id,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        style = MaterialTheme.typography.bodySmall,
        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
        color = when {
            active -> MaterialTheme.colorScheme.primary
            dim -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
            else -> MaterialTheme.colorScheme.onSurface
        },
        maxLines = 2,
    )
}

private fun maskKey(k: String): String =
    if (k.length <= 8) "••••••" else k.take(4) + "••••" + k.takeLast(4)
