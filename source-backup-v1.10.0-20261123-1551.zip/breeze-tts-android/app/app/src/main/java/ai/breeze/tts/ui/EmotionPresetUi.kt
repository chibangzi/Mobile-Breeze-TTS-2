package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeSize

/**
 * 圆角虚线描边。Compose 没有现成的 dashed border，这里用 drawBehind 自己画——
 * 虚线段长按 dp 折算，密度变化时视觉粗细才一致。
 */
internal fun Modifier.dashedBorder(color: Color, radius: Dp, strokeWidth: Dp = 1.dp) = this.drawBehind {
    val style = Stroke(
        width = strokeWidth.toPx(),
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 6.dp.toPx()), 0f),
    )
    drawRoundRect(color = color, style = style, cornerRadius = CornerRadius(radius.toPx()))
}

/**
 * 预设编辑弹窗（v2）。
 *
 * 用自定义卡片而不是 Material 的 AlertDialog：后者的标题、输入框、按钮全是
 * Material 默认样式（四边圆角、紫色 outline、48dp 文字按钮），和浮层放一起
 * 像两个 App。这里和 [ExpandDialog] 同一套：18dp 圆角 / `surface2` 底 /
 * 1px 描边 / 40dp 按钮。
 */
@Composable
fun PresetEditorDialog(
    title: String,
    initialName: String,
    initialText: String,
    onDismiss: () -> Unit,
    onConfirm: (name: String, text: String) -> Unit,
) {
    val c = Breeze.colors
    var name by rememberSaveable(initialName, initialText) { mutableStateOf(initialName) }
    var body by rememberSaveable(initialName, initialText) { mutableStateOf(initialText) }
    val valid = name.isNotBlank() && body.isNotBlank()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
        ),
    ) {
        Box(
            Modifier.fillMaxSize().padding(horizontal = 24.dp).imePadding(),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(c.surface2)
                    .border(1.dp, c.line2, RoundedCornerShape(18.dp))
                    .padding(16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = c.t1,
                        modifier = Modifier.weight(1f),
                    )
                    CircleClose(onClick = onDismiss)
                }

                Spacer(Modifier.height(14.dp))

                FieldLabel(tr("名称"))
                Spacer(Modifier.height(6.dp))
                FieldBox {
                    if (name.isEmpty()) {
                        Text(tr("列表里显示的名字"), fontSize = 13.5.sp, color = c.t3)
                    }
                    ImeAwareBasicTextField(
                        value = name,
                        onValueChange = { if (it.length <= 16) name = it },
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 13.5.sp, color = c.t1),
                        cursorBrush = SolidColor(c.accent),
                        modifier = Modifier.fillMaxSize(),
                    )
                }

                Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Text(
                        "${name.length}/16",
                        fontSize = 10.5.sp,
                        color = c.t3,
                        modifier = Modifier.weight(1f),
                    )
                    if (body.isNotBlank() && name.isBlank()) {
                        Text(
                            tr("用内容自动起名"),
                            fontSize = 10.5.sp,
                            color = c.accent,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .clip(RoundedCornerShape(5.dp))
                                .clickable { name = suggestPresetName(body) }
                                .padding(horizontal = 4.dp, vertical = 1.dp),
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                FieldLabel(tr("指令内容"))
                Spacer(Modifier.height(6.dp))
                FieldBox(height = 152.dp) {
                    if (body.isEmpty()) {
                        Text(tr("例如：语速稍慢，声音压低，像在讲一个秘密。"), fontSize = 13.sp, color = c.t3)
                    }
                    ImeAwareBasicTextField(
                        value = body,
                        onValueChange = { body = it },
                        textStyle = TextStyle(fontSize = 13.sp, lineHeight = 21.sp, color = c.t1),
                        cursorBrush = SolidColor(c.accent),
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    tr("这段文字会原样作为指令送进模型，语言要和朗读文本一致。"),
                    fontSize = 10.5.sp,
                    color = c.t3,
                    lineHeight = 15.sp,
                )

                Spacer(Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BreezeButton(
                        text = tr("取消"),
                        onClick = onDismiss,
                        tone = BreezeTone.Ghost,
                        height = BreezeSize.buttonTiny,
                        modifier = Modifier.weight(1f),
                    )
                    BreezeButton(
                        text = tr("保存"),
                        onClick = { onConfirm(name.trim(), body.trim()) },
                        tone = BreezeTone.Primary,
                        enabled = valid,
                        height = BreezeSize.buttonTiny,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

/** 删除预设的确认框：预设是用户一点点敲出来的，误删代价高，值得拦一下。 */
@Composable
fun ConfirmDeletePresetDialog(
    name: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
) {
    val c = Breeze.colors
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
        ),
    ) {
        Box(
            Modifier.fillMaxSize().padding(horizontal = 32.dp).imePadding(),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(c.surface2)
                    .border(1.dp, c.line2, RoundedCornerShape(18.dp))
                    .padding(16.dp),
            ) {
                Text(
                    tr("删除预设"),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = c.t1,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    tr("「$name」会被移除。已输入的内容不受影响，之后还可以重新存回来。", "\"$name\" will be removed. What you typed is untouched, and you can save it again later."),
                    fontSize = 12.5.sp,
                    lineHeight = 20.sp,
                    color = c.t2,
                )
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BreezeButton(
                        text = tr("取消"),
                        onClick = onDismiss,
                        tone = BreezeTone.Ghost,
                        height = BreezeSize.buttonTiny,
                        modifier = Modifier.weight(1f),
                    )
                    BreezeButton(
                        text = tr("删除"),
                        onClick = onConfirm,
                        tone = BreezeTone.Warn,
                        height = BreezeSize.buttonTiny,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(
        text,
        fontSize = 10.5.sp,
        color = Breeze.colors.t3,
        letterSpacing = 0.6.sp,
    )
}

/** 输入框外壳：`fill` 底 + 10dp 圆角，聚焦时不加边框，避免弹窗里出现第三个色块。 */
@Composable
private fun FieldBox(
    height: Dp? = null,
    content: @Composable () -> Unit,
) {
    val c = Breeze.colors
    Column(
        Modifier
            .fillMaxWidth()
            .then(if (height != null) Modifier.height(height) else Modifier.height(42.dp))
            .clip(RoundedCornerShape(10.dp))
            .background(c.fill)
            .padding(horizontal = 11.dp, vertical = 11.dp),
        verticalArrangement = Arrangement.Top,
    ) {
        Box(Modifier.fillMaxWidth().weight(1f)) { content() }
    }
}

/** 从指令正文猜一个短名字：去掉标点和引导词，截前 10 个字。 */
fun suggestPresetName(text: String): String {
    val cleaned = text.trim()
        .replace(Regex(tr("^用")), "")
        .replace(Regex("[，。,.！!？?、；;：:\\s]+"), " ")
        .trim()
    return if (cleaned.length <= 10) cleaned else cleaned.take(10)
}
