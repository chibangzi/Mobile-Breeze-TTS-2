package ai.breeze.tts

import android.app.Application
import ai.breeze.tts.data.AiProviderRepository
import ai.breeze.tts.data.EmotionPresetRepository
import ai.breeze.tts.data.HistoryRepository
import ai.breeze.tts.data.ModelRepository
import ai.breeze.tts.data.SettingsRepository
import ai.breeze.tts.data.SpeechRepository
import ai.breeze.tts.data.VoiceRepository
import ai.breeze.tts.engine.BreezeEngine

class BreezeApplication : Application() {

    lateinit var models: ModelRepository
        private set
    lateinit var voices: VoiceRepository
        private set
    lateinit var history: HistoryRepository
        private set
    lateinit var settings: SettingsRepository
        private set
    lateinit var speech: SpeechRepository
        private set
    lateinit var presets: EmotionPresetRepository
        private set
    lateinit var ai: AiProviderRepository
        private set
    lateinit var engine: BreezeEngine
        private set

    override fun onCreate() {
        super.onCreate()
        // GPU 测试跑在 :probe 进程里。那个进程只需要 LiteRT，不需要仓库、不需要引擎，
        // 更不该在它启动时去扫 1.7 GB 的模型目录——那既拖慢「点一下多久才开始测」，
        // 也可能在主进程没准备好的时候踩到状态恢复之类的副作用。
        if (Application.getProcessName() != packageName) return

        models = ModelRepository(this)
        voices = VoiceRepository(this)
        history = HistoryRepository(this)
        settings = SettingsRepository(this)
        speech = SpeechRepository(this)
        presets = EmotionPresetRepository(this)
        ai = AiProviderRepository(this)
        engine = BreezeEngine()
        models.refresh()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // 权重常驻约 1.7 GB。只在进程已被判定为后台可回收时才放，
        // RUNNING_LOW 阶段释放会让用户回到前台后点「生成」直接失败。
        if (!::engine.isInitialized) return
        if (level >= TRIM_MEMORY_COMPLETE && !engine.isBusy) {
            engine.release()
        }
    }
}
