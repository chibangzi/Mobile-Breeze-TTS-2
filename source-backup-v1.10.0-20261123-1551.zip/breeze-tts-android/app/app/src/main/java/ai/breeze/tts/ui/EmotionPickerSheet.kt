package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.breeze.tts.data.EmotionPreset
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeSize

/**
 * 表达预设浮层（v2 重做）。
 *
 * 交互仍是「先选中、再确认」：点一行只改选中态，点底部「确定」才写回输入框，
 * 这样来回比较几条预设时不会把手写的指令冲掉。
 *
 * 排布上的改动：
 *  - 列表从「一张张 16dp 圆角卡片」改成纯粹的 1px 分隔行。预设本质是一个文本清单，
 *    行与行之间不需要额外边界，卡片只会让一屏少放两条；
 *  - 去掉每行左侧 42dp 的首字方块（它占了 1/3 宽度，信息量为零）；
 *  - 保留顶部「将要应用」预览条，但它只是 `fill2` 的浅块，不是强调色卡片；
 *    高度按两行固定，切换选中时列表不会上下跳；
 *  - 右侧勾统一 19dp 圆环，未选中留空心环，右边缘不抖；
 *  - 「不使用表达」从末尾的条件项提成列表首位的正选项：「确定」永远可点，
 *    选它就是把输入框清空，而不是把自己这一项也一起藏掉。
 */
@Composable
fun EmotionPickerSheet(
    visible: Boolean,
    presets: List<EmotionPreset>,
    current: String,
    customized: Boolean,
    onConfirm: (String) -> Unit,
    onNew: () -> Unit,
    onEdit: (EmotionPreset) -> Unit,
    onDelete: (EmotionPreset) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = Breeze.colors
    var picked by remember(visible) { mutableStateOf(current) }
    val matched = presets.firstOrNull { it.text == picked }

    BreezeSheet(visible = visible, onDismiss = onDismiss, heightFraction = 0.76f) {
        SheetTopBar(
            title = tr("表达预设"),
            action = tr("新建"),
            onAction = onNew,
            onClose = onDismiss,
        )

        // ---- 将要应用 ----
        // 高度固定按两行留：选中 / 取消选中时下面的列表不跟着跳。
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = BreezeSize.gutter)
                .clip(RoundedCornerShape(11.dp))
                .background(c.fill2)
                .padding(horizontal = 12.dp, vertical = 11.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    tr("将要应用"),
                    fontSize = 10.5.sp,
                    color = c.t3,
                    letterSpacing = 0.6.sp,
                    modifier = Modifier.weight(1f),
                )
                when {
                    picked.isBlank() -> Text(tr("不添加"), fontSize = 10.5.sp, color = c.t3)
                    matched != null -> Text(matched.name, fontSize = 10.5.sp, color = c.accent, maxLines = 1)
                    else -> Text(tr("自定义"), fontSize = 10.5.sp, color = c.t3)
                }
            }
            Spacer(Modifier.height(5.dp))
            Text(
                if (picked.isBlank()) tr("不追加情绪指令，完全用模型默认语气") else picked,
                fontSize = 12.5.sp,
                lineHeight = 19.sp,
                color = if (picked.isBlank()) c.t3 else c.t2,
                minLines = 2,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = BreezeSize.gutter),
        ) {
            // 「不使用任何表达」本身就是一条正选项，放在列表首位并且带勾选态，
            // 旧版把它做成列表末尾的条件项：清空之后这一项自己消失、底部按钮跟着
            // 变灰，等于选完就再也确认不了。
            item(key = "__none__") {
                NoneRow(selected = picked.isBlank()) { picked = "" }
            }
            if (presets.isEmpty()) {
                item(key = "__hint__") {
                    Text(
                        tr("还没有自定义预设。在合成页写好表达后点「存为预设」，或直接在这里新建。"),
                        fontSize = 12.sp,
                        lineHeight = 19.sp,
                        color = c.t3,
                        modifier = Modifier.padding(vertical = 16.dp),
                    )
                }
            }
            items(presets, key = { it.id }) { p ->
                PresetRow(
                    preset = p,
                    selected = p.text == picked,
                    onPick = { picked = p.text },
                    onEdit = { onEdit(p) },
                    onDelete = { onDelete(p) },
                )
            }
            if (customized) {
                item(key = "__reset__") {
                    FooterAction(tr("恢复默认预设")) { onReset() }
                }
            }
        }

        Column(Modifier.padding(horizontal = BreezeSize.gutter).padding(top = 10.dp, bottom = 16.dp)) {
            BreezePrimaryButton(
                text = tr("确定"),
                onClick = {
                    onConfirm(picked.trim())
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth(),
                height = BreezeSize.buttonSmall,
            )
        }
    }
}

/** 「不使用任何表达」行：与预设同构（标题 + 说明 + 右侧圆勾），可反复点选 */
@Composable
private fun NoneRow(selected: Boolean, onPick: () -> Unit) {
    val c = Breeze.colors
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 62.dp)
                .clickable(onClick = onPick)
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    tr("不使用表达"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (selected) c.accent else c.t1,
                    maxLines = 1,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    tr("清空输入框，交给模型自己判断语气"),
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp,
                    color = c.t3,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.width(12.dp))
            CircleCheck(selected = selected)
        }
        HairlineDivider()
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PresetRow(
    preset: EmotionPreset,
    selected: Boolean,
    onPick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val c = Breeze.colors
    var menu by remember { mutableStateOf(false) }

    Box {
        Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 62.dp)
                    .combinedClickable(onClick = onPick, onLongClick = { menu = true })
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            preset.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (selected) c.accent else c.t1,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        if (preset.builtin) {
                            Spacer(Modifier.width(6.dp))
                            Text(
                                tr("内置"),
                                fontSize = 9.sp,
                                color = c.t3,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(c.fill)
                                    .padding(horizontal = 4.dp, vertical = 1.dp),
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        preset.text,
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp,
                        color = c.t3,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.width(12.dp))
                CircleCheck(selected = selected)
            }
            HairlineDivider()
        }

        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(tr("编辑名称与内容"), fontSize = 13.5.sp) },
                leadingIcon = {
                    Icon(Icons.Outlined.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                },
                onClick = { menu = false; onEdit() },
            )
            DropdownMenuItem(
                text = { Text(tr("删除"), fontSize = 13.5.sp) },
                leadingIcon = {
                    Icon(
                        Icons.Outlined.Delete,
                        contentDescription = null,
                        tint = c.warn,
                        modifier = Modifier.size(18.dp),
                    )
                },
                onClick = { menu = false; onDelete() },
            )
        }
    }
}

@Composable
private fun FooterAction(text: String, onClick: () -> Unit) {
    val c = Breeze.colors
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 15.dp),
        horizontalArrangement = Arrangement.Center,
    ) {
        Text(text, fontSize = 12.sp, color = c.t3)
    }
}
