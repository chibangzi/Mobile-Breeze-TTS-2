package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ai.breeze.tts.audio.AudioTools
import ai.breeze.tts.audio.PcmClip
import ai.breeze.tts.audio.PcmPlayer
import ai.breeze.tts.audio.PeakPyramid
import ai.breeze.tts.ui.theme.Breeze
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 参考音频 / 转换源音频的编辑页。
 *
 * 导入音频之后先进这里，而不是直接拿去合成：模型对参考音频很敏感，一段十秒的
 * 素材里往往只有中间两三秒能用，剩下的开头换气、结尾椅子响会把音色带偏。
 *
 * 交互照手机剪辑软件的习惯做（1.9.59 重做）：
 *  - 波形只有一条窄带（不再撑满整屏），上面一条时间标尺，整体居中；
 *  - **按住波形直接横拖 = 划出一段选区**，拖到哪算到哪，不用先去够那两个小把手；
 *  - 单击波形 = 把播放头挪过去（不动选区），试听就从播放头开始；
 *  - 按住左右把手 = 微调边界，命中区 24dp，到屏幕边缘视图自动跟走；
 *  - 拖动时波形顶部浮一个气泡，显示落点时间 / 选区时长；
 *  - 双指以中点为锚缩放，缩到 0.25 秒视野也还能看清波峰。
 *
 * 选区语义是「我要保留的那一段」：完成时只导出选区，删掉的部分直接丢掉。
 */
@Composable
fun AudioEditorDialog(
    source: File,
    title: String = tr("编辑音频"),
    onDismiss: () -> Unit,
    onConfirm: (File) -> Unit,
) {
    val c = Breeze.colors
    val ctx = LocalContext.current
    val st = remember { EditorState() }
    val player = remember { PcmPlayer() }
    var history by remember { mutableStateOf<List<EditSnapshot>>(emptyList()) }
    var original by remember { mutableStateOf<PcmClip?>(null) }
    var saving by remember { mutableStateOf(false) }
    var processing by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(source) {
        val clip = withContext(Dispatchers.IO) { PcmClip.fromWav(source) }
        if (clip == null) {
            st.message = tr("打不开这段音频")
            return@LaunchedEffect
        }
        original = clip
        st.clip = clip
        st.selFrom = 0
        st.selTo = clip.samples.size
        st.viewStart = 0.0
        st.viewSpan = clip.durationSec.coerceAtLeast(0.3)
        st.playheadSec = -1.0
    }

    DisposableEffect(Unit) {
        player.onTick = { ms ->
            val c0 = st.clip
            if (c0 != null && st.playing) {
                val t = st.playFromSec + ms / 1000.0
                st.playheadSec = t.coerceAtMost(st.playToSec)
                // 播放头跑到视野右侧就翻页，留 1/4 屏的余量看后面
                if (t > st.viewStart + st.viewSpan * 0.93) {
                    st.viewStart = (t - st.viewSpan * 0.25)
                        .coerceIn(0.0, (c0.durationSec - st.viewSpan).coerceAtLeast(0.0))
                }
            }
        }
        player.onEnd = {
            st.playing = false
            val c0 = st.clip
            st.playheadSec = if (c0 != null) st.selFrom.toDouble() / c0.sampleRate else -1.0
        }
        onDispose { player.release() }
    }

    // 先把 playing 摘掉再 stop：PcmPlayer.stop() 会同步回调 onTick(0)，
    // 顺序反了会把播放头弹回起点，暂停时看不出「听到哪了」
    fun stopPlay() {
        if (st.playing) {
            st.playing = false
            player.stop()
        }
    }

    fun togglePlay() {
        val clip = st.clip ?: return
        if (st.playing) {
            st.playing = false
            player.stop()
            return
        }
        val sr = clip.sampleRate
        val selA = min(st.selFrom, st.selTo)
        val selB = max(st.selFrom, st.selTo)
        // 播放头在选区内就从播放头开始，否则从选区起点——反复试听时不用每次从头
        val head = if (st.playheadSec >= 0) clip.sampleAt(st.playheadSec) else -1
        val from = if (head in selA until selB) head else selA
        var to = if (selB > from + sr / 100) selB else clip.samples.size
        if (to - from < sr / 50) to = clip.samples.size
        if (to - from < sr / 50) return
        player.play(clip.samples, from, to)
        st.playFromSec = from.toDouble() / sr
        st.playToSec = to.toDouble() / sr
        st.playheadSec = st.playFromSec
        st.playing = true
    }

    fun applyCut() {
        val clip = st.clip ?: return
        val a = min(st.selFrom, st.selTo)
        val b = max(st.selFrom, st.selTo)
        if (b - a < clip.sampleRate / 10) {
            st.message = tr("选区太短，至少 0.1 秒")
            return
        }
        if (b - a >= clip.samples.size) {
            st.message = tr("不能把整段都删掉")
            return
        }
        stopPlay()
        history = (history + EditSnapshot(clip, st.selFrom, st.selTo)).takeLast(20)
        val next = clip.cut(a, b)
        st.clip = next
        // 删除后回到「整段都是要用的」，避免下次点完成时只导出剩下的一小截
        st.selFrom = 0
        st.selTo = next.samples.size
        st.playheadSec = a.toDouble() / clip.sampleRate
        st.viewSpan = min(st.viewSpan, next.durationSec.coerceAtLeast(MIN_SPAN))
        st.viewStart = st.viewStart.coerceIn(
            0.0, (next.durationSec - st.viewSpan).coerceAtLeast(0.0),
        )
        st.message = tr("已删除 %.1f 秒").format((b - a).toDouble() / clip.sampleRate)
    }

    fun undo() {
        val prev = history.lastOrNull() ?: return
        history = history.dropLast(1)
        stopPlay()
        st.clip = prev.clip
        st.selFrom = prev.from
        st.selTo = prev.to
        st.playheadSec = prev.from.toDouble() / prev.clip.sampleRate
        st.viewSpan = min(st.viewSpan, prev.clip.durationSec.coerceAtLeast(MIN_SPAN))
        st.viewStart = st.viewStart.coerceIn(
            0.0, (prev.clip.durationSec - st.viewSpan).coerceAtLeast(0.0),
        )
        st.message = tr("已撤销")
    }

    fun resetAll() {
        val o = original ?: return
        stopPlay()
        history = emptyList()
        st.clip = o
        st.selFrom = 0
        st.selTo = o.samples.size
        st.playheadSec = -1.0
        st.viewStart = 0.0
        st.viewSpan = o.durationSec.coerceAtLeast(MIN_SPAN)
        st.message = tr("已还原原始音频")
    }

    /** 只留选区：把选区之外全丢掉，之后所有操作都基于这一小段。 */
    fun applyTrim() {
        val clip = st.clip ?: return
        val a = min(st.selFrom, st.selTo)
        val b = max(st.selFrom, st.selTo)
        if (b - a < clip.sampleRate / 10) {
            st.message = tr("选区太短，至少 0.1 秒")
            return
        }
        if (a == 0 && b >= clip.samples.size) {
            st.message = tr("现在就是全部")
            return
        }
        stopPlay()
        history = (history + EditSnapshot(clip, st.selFrom, st.selTo)).takeLast(20)
        val next = clip.trim(a, b)
        st.clip = next
        st.selFrom = 0
        st.selTo = next.samples.size
        st.viewStart = 0.0
        st.viewSpan = next.durationSec.coerceAtLeast(MIN_SPAN)
        st.playheadSec = -1.0
        st.message = tr("已只保留这段 %.1f 秒").format(next.durationSec)
    }

    /** 降噪：内容长度不变，所以选区、视野都保持原样，直接 A/B 听效果。 */
    fun applyDenoise() {
        val clip = st.clip ?: return
        if (processing.isNotBlank()) return
        stopPlay()
        processing = tr("降噪中")
        scope.launch {
            val (before, next, after) = withContext(Dispatchers.Default) {
                val b = AudioTools.floorDb(clip)
                val n = AudioTools.denoise(clip)
                Triple(b, n, AudioTools.floorDb(n))
            }
            history = (history + EditSnapshot(clip, st.selFrom, st.selTo)).takeLast(20)
            st.clip = next
            processing = ""
            st.message = tr("底噪 %.0f → %.0f dB").format(before, after)
        }
    }

    /** 压缩空白：超过 1 秒的静音砍到 1 秒，头尾各留 0.2 秒。 */
    fun applySqueeze() {
        val clip = st.clip ?: return
        if (processing.isNotBlank()) return
        stopPlay()
        processing = tr("清理空白")
        scope.launch {
            val result = withContext(Dispatchers.Default) { AudioTools.squeezeSilence(clip) }
            if (!result.changed) {
                processing = ""
                st.message = tr("没找到超过 1 秒的空白")
                return@launch
            }
            history = (history + EditSnapshot(clip, st.selFrom, st.selTo)).takeLast(20)
            st.clip = result.clip
            st.selFrom = 0
            st.selTo = result.clip.samples.size
            st.viewStart = 0.0
            st.viewSpan = result.clip.durationSec.coerceAtLeast(MIN_SPAN)
            st.playheadSec = -1.0
            processing = ""
            st.message = tr("已压缩 %d 处空白，省 %.1f 秒").format(result.gaps, result.savedSec)
        }
    }


    LaunchedEffect(st.clip) {
        val clip = st.clip ?: return@LaunchedEffect
        st.pyramidBusy = true
        val p = withContext(Dispatchers.Default) { PeakPyramid(clip.samples) }
        st.pyramid = p
        st.pyramidBusy = false
    }

    Dialog(
        onDismissRequest = {
            player.stop()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        // 波形高度按屏高给，但上下限压死：大屏也不会被拉成一块幕布
        val screenH = LocalConfiguration.current.screenHeightDp
        val waveH = (screenH * 0.24f).dp.coerceIn(122.dp, 186.dp)

        Box(
            Modifier
                .fillMaxSize()
                .background(c.bg)
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp),
        ) {
            Column(Modifier.fillMaxSize()) {
                // ---------------- 顶栏 ----------------
                Row(
                    Modifier.fillMaxWidth().height(52.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .clickable {
                                player.stop()
                                onDismiss()
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = tr("取消"),
                            tint = c.t2,
                            modifier = Modifier.size(19.dp),
                        )
                    }
                    Spacer(Modifier.width(4.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            title,
                            fontSize = 15.sp,
                            lineHeight = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = c.t1,
                        )
                        Text(
                            tr("横拖选段，长按拖动平移，双指缩放"),
                            fontSize = 10.5.sp,
                            lineHeight = 14.sp,
                            color = c.t3,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (original != null && (history.isNotEmpty() || st.clip !== original)) {
                        Text(
                            tr("还原"),
                            fontSize = 11.5.sp,
                            color = c.t2,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { resetAll() }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                }

                Spacer(Modifier.weight(1f))

                // ---------------- 时间轴 ----------------
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(waveH)
                        .clip(RoundedCornerShape(14.dp))
                        .background(c.surface)
                        .border(1.dp, c.line, RoundedCornerShape(14.dp)),
                ) {
                    val clip = st.clip
                    if (clip == null || st.pyramid == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(
                                Modifier.size(18.dp),
                                strokeWidth = 1.8.dp,
                                color = c.accent,
                                trackColor = c.line2,
                            )
                        }
                    } else {
                        EditorWave(
                            st = st,
                            modifier = Modifier.fillMaxSize(),
                            onPause = { stopPlay() },
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                // ---------------- 缩放 ----------------
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ZoomButton("−") { st.zoomBy(0.55f) }
                    Spacer(Modifier.width(8.dp))
                    ZoomBar(
                        value = st.zoomFraction(),
                        modifier = Modifier.weight(1f).height(26.dp),
                    ) { st.setZoomFraction(it) }
                    Spacer(Modifier.width(8.dp))
                    ZoomButton("＋") { st.zoomBy(1.8f) }
                }

                Spacer(Modifier.height(6.dp))

                // ---------------- 选区信息 ----------------
                val clipInfo = st.clip
                val selLen = if (clipInfo != null) {
                    (max(st.selFrom, st.selTo) - min(st.selFrom, st.selTo)).toDouble() / clipInfo.sampleRate
                } else 0.0
                val allSel = clipInfo != null &&
                    st.selFrom == 0 && st.selTo >= clipInfo.samples.size
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 30.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        if (clipInfo == null) tr("正在读取音频…")
                        else tr("已选 %.1f 秒 · 全长 %.1f 秒").format(selLen, clipInfo.durationSec),
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp,
                        color = c.t2,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(10.dp))
                    // 独立胶囊，不跟文字抢宽度；全选状态下变灰但仍占位，避免布局跳动
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .background(if (allSel) c.fill2 else c.accentSoft)
                            .clickable(enabled = clipInfo != null && !allSel) {
                                val x = st.clip ?: return@clickable
                                st.selFrom = 0
                                st.selTo = x.samples.size
                                st.message = tr("已全选")
                            }
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            if (allSel) tr("已全选") else tr("全选"),
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (allSel) c.t3 else c.accent,
                        )
                    }
                }

                Spacer(Modifier.height(2.dp))
                Text(
                    st.message.ifBlank { tr("横拖选段 · 单击定位 · 长按拖动平移 · 双指缩放") },
                    fontSize = 10.5.sp,
                    color = if (st.message.isBlank()) c.t3 else c.accent,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().height(16.dp),
                )

                Spacer(Modifier.weight(0.55f))

                // ---------------- 工具：两行三列 ----------------
                val busy = processing.isNotBlank() || saving
                val canCut = clipInfo != null && selLen > 0.099 &&
                    abs(st.selTo - st.selFrom) < clipInfo.samples.size
                val canTrim = clipInfo != null && !allSel && selLen > 0.099
                Row(
                    Modifier.fillMaxWidth().height(42.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    ToolTile(
                        label = if (st.playing) tr("暂停") else tr("试听"),
                        icon = Icons.Outlined.PlayArrow,
                        enabled = clipInfo != null && !busy,
                        accent = true,
                        onClick = { togglePlay() },
                        modifier = Modifier.weight(1f),
                    )
                    ToolTile(
                        label = tr("只留此段"),
                        enabled = canTrim && !busy,
                        onClick = { applyTrim() },
                        modifier = Modifier.weight(1f),
                    )
                    ToolTile(
                        label = tr("删除"),
                        icon = Icons.Outlined.Delete,
                        enabled = canCut && !busy,
                        warn = true,
                        onClick = { applyCut() },
                        modifier = Modifier.weight(1f),
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().height(42.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    ToolTile(
                        label = tr("降噪"),
                        enabled = clipInfo != null && !busy,
                        onClick = { applyDenoise() },
                        modifier = Modifier.weight(1f),
                    )
                    ToolTile(
                        label = tr("删除空白"),
                        enabled = clipInfo != null && !busy,
                        onClick = { applySqueeze() },
                        modifier = Modifier.weight(1f),
                    )
                    ToolTile(
                        label = tr("撤销"),
                        enabled = history.isNotEmpty() && !busy,
                        onClick = { undo() },
                        modifier = Modifier.weight(1f),
                    )
                }

                Spacer(Modifier.height(10.dp))

                // ---------------- 主操作：只保留选区 ----------------
                val canSave = clipInfo != null && !busy && !st.pyramidBusy &&
                    selLen > 0.099
                val mainLabel = when {
                    processing.isNotBlank() -> "$processing…"
                    clipInfo == null -> tr("载入中…")
                    allSel -> tr("使用全部 %.1f 秒").format(clipInfo.durationSec)
                    else -> tr("使用这段 %.1f 秒").format(selLen)
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (canSave) c.btnBg else c.fill2)
                        .clickable(enabled = canSave) {
                            val clip = st.clip ?: return@clickable
                            val a = min(st.selFrom, st.selTo)
                            val b = max(st.selFrom, st.selTo)
                            saving = true
                            st.playing = false
                            player.stop()
                            val out = File(ctx.cacheDir, "edited_${System.currentTimeMillis()}.wav")
                            val outClip = if (a == 0 && b >= clip.samples.size) clip else clip.trim(a, b)
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { runCatching { outClip.toWav(out) } }
                                saving = false
                                r.fold(
                                    onSuccess = { onConfirm(out) },
                                    onFailure = { st.message = tr("保存失败：${it.message ?: "未知错误"}", "Save failed: ${it.message ?: "未知错误"}") },
                                )
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    if (saving || processing.isNotBlank()) {
                        CircularProgressIndicator(
                            Modifier.size(15.dp),
                            strokeWidth = 1.6.dp,
                            color = c.btnInk,
                            trackColor = Color.Transparent,
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.Check,
                                contentDescription = null,
                                tint = if (canSave) c.btnInk else c.t3,
                                modifier = Modifier.size(15.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                mainLabel,
                                fontSize = 13.5.sp,
                                lineHeight = 18.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (canSave) c.btnInk else c.t3,
                            )
                        }
                    }
                }

                Spacer(Modifier.height(9.dp))
                Text(
                    tr("只保留选区内的声音。参考音频建议 5–30 秒干净人声，去掉开头换气和结尾杂音，克隆更像。"),
                    fontSize = 10.5.sp,
                    lineHeight = 15.sp,
                    color = c.t3,
                )
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

private data class EditSnapshot(val clip: PcmClip, val from: Int, val to: Int)

private const val MIN_SPAN = 0.25

/** 编辑页的全部可变状态。集中放一处，手势回调读写同一份实例，不会被重组重建。 */
private class EditorState {
    var clip by mutableStateOf<PcmClip?>(null)
    var pyramid by mutableStateOf<PeakPyramid?>(null)
    var pyramidBusy by mutableStateOf(false)
    var selFrom by mutableIntStateOf(0)
    var selTo by mutableIntStateOf(0)
    var viewStart by mutableStateOf(0.0)
    var viewSpan by mutableStateOf(1.0)
    var playheadSec by mutableStateOf(-1.0)
    var playing by mutableStateOf(false)
    var playFromSec by mutableStateOf(0.0)
    var playToSec by mutableStateOf(0.0)
    var message by mutableStateOf("")

    /** 拖动中的浮层：横坐标（px）+ 文案，抬手后清空。 */
    var hintX by mutableStateOf(-1f)
    var hintText by mutableStateOf("")

    /** 正在被按住的把手：0 无 / 1 左 / 2 右，按下时画粗一点，给「抓住了」的反馈。 */
    var activeHandle by mutableIntStateOf(0)

    val durationSec: Double get() = clip?.durationSec ?: 1.0

    fun clampView() {
        val dur = durationSec
        viewSpan = viewSpan.coerceIn(MIN_SPAN, dur.coerceAtLeast(MIN_SPAN))
        viewStart = viewStart.coerceIn(0.0, (dur - viewSpan).coerceAtLeast(0.0))
    }

    fun zoomBy(factor: Float) {
        val dur = durationSec
        val newSpan = (viewSpan / factor).coerceIn(MIN_SPAN, dur)
        val center = viewStart + viewSpan / 2
        viewSpan = newSpan
        viewStart = center - newSpan / 2
        clampView()
    }

    fun zoomFraction(): Float {
        val dur = durationSec
        if (dur <= MIN_SPAN) return 1f
        val lo = kotlin.math.ln(MIN_SPAN)
        val hi = kotlin.math.ln(dur)
        val v = kotlin.math.ln(viewSpan.coerceIn(MIN_SPAN, dur))
        return ((hi - v) / (hi - lo)).toFloat().coerceIn(0f, 1f)
    }

    fun setZoomFraction(f: Float) {
        val dur = durationSec
        if (dur <= MIN_SPAN) return
        val lo = kotlin.math.ln(MIN_SPAN)
        val hi = kotlin.math.ln(dur)
        val span = kotlin.math.exp(hi - (hi - lo) * f.coerceIn(0f, 1f))
        val center = viewStart + viewSpan / 2
        viewSpan = span
        viewStart = center - span / 2
        clampView()
    }
}

/**
 * 时间轴：标尺 + 波形 + 手势。
 *
 * 手势判定顺序（对应剪辑软件里的肌肉记忆）：
 *  1. 落在把手 24dp 内 → 调边界；
 *  2. 落在波形上按住横拖 → 从按下点划出新选区；
 *  3. 只是点了一下 → 播放头跳过去，选区不动；
 *  4. 两指 → 以中点为锚缩放。
 */
@Composable
private fun EditorWave(
    st: EditorState,
    modifier: Modifier = Modifier,
    onPause: () -> Unit,
) {
    val c = Breeze.colors
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val labelPaint = remember(density) {
        Paint().apply {
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            textSize = with(density) { 9.5.sp.toPx() }
        }
    }
    val hintPaint = remember(density) {
        Paint().apply {
            isAntiAlias = true
            textAlign = Paint.Align.LEFT
            textSize = with(density) { 10.sp.toPx() }
        }
    }
    labelPaint.color = c.t3.copy(alpha = 0.85f).toArgb()
    hintPaint.color = Color.White.toArgb()

    Canvas(
        modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val clip0 = st.clip ?: return@awaitEachGesture
                val w = size.width.toFloat()
                if (w <= 0f) return@awaitEachGesture
                onPause()
                st.hintText = ""

                val sr = clip0.sampleRate
                val minGap = sr / 20 // 50 ms
                var a = min(st.selFrom, st.selTo)
                var b = max(st.selFrom, st.selTo)
                val origFrom = a
                val origTo = b

                fun xOfSample(s: Int) =
                    (((s.toDouble() / sr) - st.viewStart) / st.viewSpan * w).toFloat()

                fun secOfX(x: Float) =
                    (st.viewStart + (x / w).coerceIn(0f, 1f) * st.viewSpan)
                        .coerceIn(0.0, clip0.durationSec)

                fun sampleOfX(x: Float): Int =
                    (secOfX(x) * sr).toInt().coerceIn(0, clip0.samples.size)

                val grab = 26.dp.toPx()
                val nearL = abs(down.position.x - xOfSample(a))
                val nearR = abs(down.position.x - xOfSample(b))
                // 0=左手柄 1=右手柄 2=波形（划新选区 / 定位播放头） 3=长按后平移视图
                var mode = when {
                    nearL <= grab && nearL <= nearR -> 0
                    nearR <= grab -> 1
                    else -> 2
                }
                st.activeHandle = when (mode) {
                    0 -> 1
                    1 -> 2
                    else -> 0
                }

                val anchorSec = secOfX(down.position.x)
                val anchorSample = (anchorSec * sr).toInt().coerceIn(0, clip0.samples.size)
                var lastX = down.position.x
                var lastT = down.uptimeMillis
                var travelled = 0f
                var moved = false
                var pinched = false
                var vx = 0f
                var tickHalf = Int.MIN_VALUE
                var zoomDist = 0f
                var zoomSpan = 0.0
                var zoomAnchor = 0.0
                var zooming = false

                fun showTime(x: Float, sec: Double) {
                    st.hintX = x
                    st.hintText = clockF(sec)
                }

                var ev: PointerEvent
                do {
                    ev = awaitPointerEvent()
                    val pts = ev.changes.filter { it.pressed }
                    if (pts.size >= 2) {
                        // 双指：以两指中点为锚缩放，缩放期间不改选区
                        pinched = true
                        val p0 = pts.minByOrNull { it.position.x }!!.position
                        val p1 = pts.maxByOrNull { it.position.x }!!.position
                        val d = abs(p1.x - p0.x).coerceAtLeast(1f)
                        val midX = (p0.x + p1.x) / 2f
                        if (!zooming) {
                            zooming = true
                            zoomDist = d
                            zoomSpan = st.viewSpan
                            zoomAnchor = secOfX(midX)
                        } else {
                            val ratio = (d / zoomDist).coerceIn(0.12f, 8f)
                            val newSpan = (zoomSpan / ratio).coerceIn(MIN_SPAN, st.durationSec)
                            // 中点既定缩放锚点，也带着内容走：双指顺手能平移
                            st.viewSpan = newSpan
                            st.viewStart = zoomAnchor - (midX / w) * newSpan
                            st.clampView()
                        }
                        st.hintText = ""
                        ev.changes.forEach { it.consume() }
                    } else if (pts.size == 1 && !pinched) {
                        val x = pts[0].position.x
                        val t = pts[0].uptimeMillis
                        val dx = x - lastX
                        val dt = (t - lastT).coerceAtLeast(1L)
                        vx = vx * 0.65f + (dx / dt * 1000f) * 0.35f
                        // 按住 0.35 秒还没动，再拖就是挪时间轴，不是划选区
                        if (mode == 2 && !moved && t - down.uptimeMillis > 350) mode = 3
                        travelled += abs(dx)
                        if (!moved && travelled > 8.dp.toPx()) {
                            moved = true
                            st.message = ""
                        }
                        val sec = secOfX(x)
                        when (mode) {
                            0 -> {
                                a = (sec * sr).toInt().coerceIn(0, b - minGap)
                                st.selFrom = a
                                st.selTo = b
                                showTime(x, a.toDouble() / sr)
                                // 每跨过半秒轻震一下，拖边界有刻度感
                                val half = (a.toDouble() / sr * 2).toInt()
                                if (tickHalf == Int.MIN_VALUE) tickHalf = half
                                else if (half != tickHalf) {
                                    tickHalf = half
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                            }
                            1 -> {
                                b = (sec * sr).toInt().coerceIn(a + minGap, clip0.samples.size)
                                st.selFrom = a
                                st.selTo = b
                                showTime(x, b.toDouble() / sr)
                                val half = (b.toDouble() / sr * 2).toInt()
                                if (tickHalf == Int.MIN_VALUE) tickHalf = half
                                else if (half != tickHalf) {
                                    tickHalf = half
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                            }
                            3 -> {
                                val shift = -dx / w * st.viewSpan
                                st.viewStart = (st.viewStart + shift)
                                    .coerceIn(0.0, (clip0.durationSec - st.viewSpan).coerceAtLeast(0.0))
                            }
                            else -> if (moved) {
                                // 从按下点往两边划，往回拖也能反向，边界自动排序
                                val s = sampleOfX(x)
                                st.selFrom = min(anchorSample, s)
                                st.selTo = max(anchorSample, s)
                                st.hintX = x
                                st.hintText = tr("%.1f 秒").format(abs(s - anchorSample).toDouble() / sr)
                            }
                        }
                        // 拖到边上视图自己走：越靠边越快，压着边缘能一把扫过整段
                        if (mode != 3) {
                            val edge = 34.dp.toPx()
                            val pull = when {
                                x < edge -> ((edge - x) / edge).coerceIn(0f, 1f)
                                x > w - edge -> ((x - (w - edge)) / edge).coerceIn(0f, 1f)
                                else -> 0f
                            }
                            if (pull > 0f) {
                                val dir = if (x < edge) -1.0 else 1.0
                                val step = st.viewSpan * (0.003 + 0.05 * pull * pull)
                                st.viewStart = (st.viewStart + dir * step)
                                    .coerceIn(0.0, (clip0.durationSec - st.viewSpan).coerceAtLeast(0.0))
                            }
                        }
                        lastX = x
                        lastT = t
                    }
                } while (ev.changes.any { it.pressed })

                st.hintText = ""
                st.hintX = -1f
                st.activeHandle = 0

                if (!moved && !pinched) {
                    // 纯点击：播放头挪过去，选区原样保留
                    st.playheadSec = anchorSec
                    st.message = tr("已定位 ${clockF(anchorSec)}", "Jumped to ${clockF(anchorSec)}")
                } else if (moved && !pinched) {
                    if (mode == 2 && abs(st.selTo - st.selFrom) < sr * 0.15) {
                        // 手滑划出不到 0.15 秒：当点击处理，别把原来的选区弄丢
                        st.selFrom = origFrom
                        st.selTo = origTo
                        st.playheadSec = anchorSec
                        st.message = tr("已定位 ${clockF(anchorSec)}", "Jumped to ${clockF(anchorSec)}")
                    } else if (mode != 3) {
                        // 切点吸到最近的过零点，删完拼回去不会「啪」一声
                        val r = (sr * 0.004).toInt().coerceAtLeast(1)
                        val ns = snapZero(clip0.samples, st.selFrom, r)
                        val ne = snapZero(clip0.samples, st.selTo, r)
                        if (ne - ns >= sr / 10) {
                            st.selFrom = ns
                            st.selTo = ne
                        }
                    }
                }

                // 长按平移松手后的惯性：只滚视图，不动选区
                if (mode == 3 && moved && abs(vx) > 180f) {
                    scope.launch { flingView(st, vx, w) }
                }
            }
        },
    ) {
        val clip = st.clip ?: return@Canvas
        val pyramid = st.pyramid ?: return@Canvas
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas

        val rulerH = 17.dp.toPx()
        val padY = 9.dp.toPx()
        val top = rulerH + padY
        val bot = h - padY
        val midY = (top + bot) / 2f
        val ampH = (bot - top) / 2f
        if (ampH <= 1f) return@Canvas

        val viewA = st.viewStart
        val viewB = st.viewStart + st.viewSpan
        val selA = min(st.selFrom, st.selTo).toDouble() / clip.sampleRate
        val selB = max(st.selFrom, st.selTo).toDouble() / clip.sampleRate

        fun xOfSec(sec: Double) = (((sec - viewA) / st.viewSpan) * w).toFloat()

        // 1) 选区底色：整块淡淡铺一层，不用黑罩把两边压死
        val xa = xOfSec(selA)
        val xb = xOfSec(selB)
        val ca = xa.coerceIn(0f, w)
        val cb = xb.coerceIn(0f, w)
        if (cb > ca) {
            drawRect(c.accent.copy(alpha = 0.11f), Offset(ca, top), Size(cb - ca, bot - top))
        }

        // 2) 标尺刻度 + 竖向网格
        val step = tickStep(st.viewSpan, w / 74.dp.toPx())
        var t = ceil(viewA / step) * step
        val tickColor = c.line.copy(alpha = 0.55f)
        val tickH = 3.dp.toPx()
        while (t <= viewB + 1e-6) {
            val x = xOfSec(t)
            if (x >= -0.5f && x <= w + 0.5f) {
                drawLine(tickColor, Offset(x, top), Offset(x, bot), 1f)
                drawLine(c.line2, Offset(x, rulerH - tickH), Offset(x, rulerH - 1f), 1.dp.toPx())
                val label = if (step < 1.0) "%.1fs".format(t) else clock(t)
                val tw = labelPaint.measureText(label)
                val tx = x.coerceIn(tw / 2 + 1f, (w - tw / 2 - 1f).coerceAtLeast(tw / 2 + 1f))
                drawContext.canvas.nativeCanvas.drawText(label, tx, rulerH * 0.66f, labelPaint)
            }
            t += step
        }

        // 3) 波形：每 2dp 一列，选区内用强调色，外面淡掉
        val colW = 2.dp.toPx()
        val cols = (w / colW).toInt().coerceIn(1, 3000)
        val dim = c.t3.copy(alpha = 0.28f)
        var i = 0
        while (i < cols) {
            val x0 = i * colW
            val t0 = viewA + (x0 / w) * st.viewSpan
            val t1 = viewA + ((x0 + colW) / w) * st.viewSpan
            val amp = pyramid.column(clip.sampleAt(t0), clip.sampleAt(t1))
            val hh = (amp * ampH).coerceAtLeast(0.7f)
            val inside = t1 >= selA && t0 <= selB
            drawLine(
                color = if (inside) c.accent else dim,
                start = Offset(x0 + colW / 2, midY - hh),
                end = Offset(x0 + colW / 2, midY + hh),
                strokeWidth = colW * 0.66f,
            )
            i++
        }
        drawLine(c.line.copy(alpha = 0.8f), Offset(0f, midY), Offset(w, midY), 1f)

        // 4) 选区两条边 + 把手
        val edgeCol = c.accent.copy(alpha = 0.7f)
        val edgeW = 1.4.dp.toPx()
        val over = 4.dp.toPx()
        if (xa > -40f && xa < w + 40f) {
            drawLine(edgeCol, Offset(xa, top - over), Offset(xa, bot + over), edgeW)
            handle(xa, top, bot, c.accent, st.activeHandle == 1)
        }
        if (xb > -40f && xb < w + 40f) {
            drawLine(edgeCol, Offset(xb, top - over), Offset(xb, bot + over), edgeW)
            handle(xb, top, bot, c.accent, st.activeHandle == 2)
        }

        // 5) 播放头：细线 + 顶部三角，位置一眼能认出来
        if (st.playheadSec >= 0 && st.playheadSec <= clip.durationSec) {
            val px = xOfSec(st.playheadSec)
            if (px >= -3f && px <= w + 3f) {
                drawLine(c.t1, Offset(px, rulerH), Offset(px, bot), 1.3.dp.toPx())
                val tri = Path().apply {
                    moveTo(px - 4.5.dp.toPx(), top - 7.dp.toPx())
                    lineTo(px + 4.5.dp.toPx(), top - 7.dp.toPx())
                    lineTo(px, top)
                    close()
                }
                drawPath(tri, c.t1)
            }
        }

        // 6) 拖动气泡：贴在手边，显示落点时间或选区时长
        if (st.hintText.isNotEmpty()) {
            val padH = 7.dp.toPx()
            val tw = hintPaint.measureText(st.hintText)
            val bw = tw + padH * 2
            val bh = 19.dp.toPx()
            val bx = (st.hintX - bw / 2).coerceIn(2f, (w - bw - 2f).coerceAtLeast(2f))
            val by = (top - bh - 2.dp.toPx()).coerceAtLeast(0f)
            drawRoundRect(
                color = Color.Black.copy(alpha = 0.76f),
                topLeft = Offset(bx, by),
                size = Size(bw, bh),
                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
            )
            drawContext.canvas.nativeCanvas.drawText(
                st.hintText, bx + padH, by + bh * 0.71f, hintPaint,
            )
        }
    }
}

/** 把手：贯穿波形的一条竖线，上下各一个圆角块。按下时加粗一圈，给「抓住了」的反馈。 */
private fun DrawScope.handle(
    x: Float,
    top: Float,
    bot: Float,
    color: Color,
    active: Boolean = false,
) {
    val barW = (if (active) 4.5f else 3f).dp.toPx()
    val capW = (if (active) 11f else 9f).dp.toPx()
    val capH = 15.dp.toPx()
    if (active) {
        drawRoundRect(
            color = color.copy(alpha = 0.16f),
            topLeft = Offset(x - 10.dp.toPx(), top),
            size = Size(20.dp.toPx(), bot - top),
            cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx()),
        )
    }
    drawRoundRect(
        color = color,
        topLeft = Offset(x - barW / 2, top),
        size = Size(barW, bot - top),
        cornerRadius = CornerRadius(barW / 2, barW / 2),
    )
    drawRoundRect(
        color = color,
        topLeft = Offset(x - capW / 2, top),
        size = Size(capW, capH),
        cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
    )
    drawRoundRect(
        color = color,
        topLeft = Offset(x - capW / 2, bot - capH),
        size = Size(capW, capH),
        cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
    )
}

/** 刻度间隔：让一屏内的标签不超过 maxLabels 个，优先取整秒。 */
private fun tickStep(span: Double, maxLabels: Float): Double {
    val steps = doubleArrayOf(0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0, 15.0, 30.0, 60.0, 120.0, 300.0, 600.0)
    val n = maxLabels.coerceAtLeast(2f)
    for (s in steps) if (span / s <= n) return s
    return 900.0
}

/** 工具格：等宽、44dp 高、整块可点，图标只在「试听 / 删除」上出现，其余纯文字更稳。 */
@Composable
private fun ToolTile(
    label: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    accent: Boolean = false,
    warn: Boolean = false,
    onClick: () -> Unit,
) {
    val c = Breeze.colors
    val fg = when {
        !enabled -> c.t3.copy(alpha = 0.36f)
        warn -> c.warn
        accent -> c.accent
        else -> c.t2
    }
    Row(
        modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(11.dp))
            .background(if (accent && enabled) c.accentSoft else c.fill)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(
            label,
            fontSize = 12.sp,
            fontWeight = if (accent) FontWeight.Medium else FontWeight.Normal,
            color = fg,
            maxLines = 1,
        )
    }
}

@Composable
private fun ZoomButton(label: String, onClick: () -> Unit) {
    val c = Breeze.colors
    Box(
        Modifier
            .size(30.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(c.fill)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 14.sp, color = c.t2, fontWeight = FontWeight.Medium)
    }
}

/** 对数刻度的缩放条：左端最粗（全长），右端最细（0.25 秒）。 */
@Composable
private fun ZoomBar(value: Float, modifier: Modifier = Modifier, onChange: (Float) -> Unit) {
    val c = Breeze.colors
    Canvas(
        modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                fun map(x: Float) = (x / size.width.toFloat()).coerceIn(0f, 1f)
                onChange(map(down.position.x))
                var ev: PointerEvent
                do {
                    ev = awaitPointerEvent()
                    val p = ev.changes.firstOrNull { it.pressed } ?: break
                    onChange(map(p.position.x))
                    p.consume()
                } while (ev.changes.any { it.pressed })
            }
        },
    ) {
        val h = size.height
        val midY = h / 2
        val trackH = 2.5.dp.toPx()
        drawRoundRect(
            color = c.fill2,
            topLeft = Offset(0f, midY - trackH / 2),
            size = Size(size.width, trackH),
            cornerRadius = CornerRadius(trackH / 2, trackH / 2),
        )
        val x = size.width * value.coerceIn(0f, 1f)
        drawRoundRect(
            color = c.accent.copy(alpha = 0.55f),
            topLeft = Offset(0f, midY - trackH / 2),
            size = Size(x, trackH),
            cornerRadius = CornerRadius(trackH / 2, trackH / 2),
        )
        drawCircle(c.accent, 6.5.dp.toPx(), Offset(x, midY))
        drawCircle(c.bg, 2.5.dp.toPx(), Offset(x, midY))
    }
}

/**
 * 切点吸附：在 [radius] 个样本内找振幅最小的点。
 *
 * 波形上任意一点大概率不在零值上，直接在那里切断再拼回去会留下一个台阶，
 * 听起来是「啪」的一声。4 ms 内总有接近零的样本，吸过去几乎不改变时长。
 */
private fun snapZero(samples: ShortArray, idx: Int, radius: Int): Int {
    if (samples.isEmpty()) return idx
    val a = (idx - radius).coerceAtLeast(0)
    val b = (idx + radius).coerceAtMost(samples.size - 1)
    if (a > b) return idx
    var best = idx.coerceIn(0, samples.size - 1)
    var bestV = abs(samples[best].toInt())
    var i = a
    while (i <= b) {
        val v = abs(samples[i].toInt())
        if (v < bestV) {
            bestV = v
            best = i
        }
        i++
    }
    return best
}

/** 长按平移松手后的惯性滑动，指数衰减，撞到两端就停。 */
private suspend fun flingView(st: EditorState, vx: Float, w: Float) {
    if (w <= 0f) return
    var v = vx
    while (abs(v) > 40f) {
        val maxStart = (st.durationSec - st.viewSpan).coerceAtLeast(0.0)
        val shift = -v * 0.016f / w * st.viewSpan
        val next = (st.viewStart + shift).coerceIn(0.0, maxStart)
        if (next == st.viewStart) return
        st.viewStart = next
        v *= 0.92f
        delay(16)
    }
}

private fun clock(sec: Double): String {
    val total = sec.coerceAtLeast(0.0).roundToInt()
    return "%d:%02d".format(total / 60, total % 60)
}

/** 带一位小数的时钟，拖动时气泡用；超过 1 分钟只显示分秒，避免太长。 */
private fun clockF(sec: Double): String {
    val s = sec.coerceAtLeast(0.0)
    return if (s < 60.0) tr("%.2f 秒").format(s) else "%d:%04.1f".format((s / 60).toInt(), s % 60)
}
