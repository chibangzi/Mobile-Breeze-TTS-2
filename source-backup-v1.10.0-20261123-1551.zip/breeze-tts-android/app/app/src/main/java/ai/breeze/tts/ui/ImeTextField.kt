package ai.breeze.tts.ui

import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.delay

/**
 * 直接向窗口要 IME。
 *
 * 长按选词后焦点落在系统的选择手柄上，`SoftwareKeyboardController.show()` 这时
 * 经常什么都不做（它只对自己认为「应该弹键盘」的场景生效）；操作 WindowInsets
 * 的 IME 控制器是唯一稳定的入口。
 */
internal fun showIme(activity: android.app.Activity?, view: android.view.View) {
    if (activity == null) return
    runCatching {
        WindowCompat.getInsetsController(activity.window, view)
            .show(WindowInsetsCompat.Type.ime())
    }
}

/**
 * 带「选完即弹键盘」的文本输入框。
 *
 * 为什么不能直接用 OutlinedTextField(String)：它只对外暴露文本，拿不到选区，
 * 也就无从判断「长按拖选结束了」。这里在内部持有 [TextFieldValue]。
 *
 * 判定方式：选区每次变化都会重启这个 effect，拖动时它一直在被取消；
 * 停手 250 ms 后才真正执行——也就是松手那一刻。单击定位光标（collapsed）
 * 不会触发，所以不会在用户只想改光标位置时硬弹键盘。
 */
@Composable
fun ImeAwareTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    readOnly: Boolean = false,
    label: (@Composable () -> Unit)? = null,
    placeholder: (@Composable () -> Unit)? = null,
    leadingIcon: (@Composable () -> Unit)? = null,
    trailingIcon: (@Composable () -> Unit)? = null,
    supportingText: (@Composable () -> Unit)? = null,
    singleLine: Boolean = false,
    minLines: Int = 1,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    textStyle: TextStyle = LocalTextStyle.current,
) {
    var field by remember { mutableStateOf(TextFieldValue(value, TextRange(value.length))) }

    // 外部改写（AI 填入、自动识别、切换音色）时把光标收到末尾。
    // 输入法组词期间（composition 非空）不打断，否则中文输入会被吞字。
    LaunchedEffect(value) {
        if (field.text != value && field.composition == null) {
            field = TextFieldValue(value, TextRange(value.length))
        }
    }

    val activity = LocalContext.current as? android.app.Activity
    val view = LocalView.current
    LaunchedEffect(field.selection) {
        if (field.selection.collapsed) return@LaunchedEffect
        delay(250)
        showIme(activity, view)
    }

    OutlinedTextField(
        value = field,
        onValueChange = { next ->
            field = next
            onValueChange(next.text)
        },
        modifier = modifier,
        enabled = enabled,
        readOnly = readOnly,
        label = label,
        placeholder = placeholder,
        leadingIcon = leadingIcon,
        trailingIcon = trailingIcon,
        supportingText = supportingText,
        singleLine = singleLine,
        minLines = minLines,
        maxLines = maxLines,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        visualTransformation = visualTransformation,
        textStyle = textStyle,
    )
}

/**
 * BasicTextField 用的同一套选区逻辑。
 *
 * 返回一个 [TextFieldValue] 状态；调用方直接把它交给 BasicTextField，
 * 再调一次 [ImeSelectionEffect] 即可获得「选完弹键盘」。
 */
@Composable
fun rememberImeField(value: String): androidx.compose.runtime.MutableState<TextFieldValue> {
    val state = remember { mutableStateOf(TextFieldValue(value, TextRange(value.length))) }
    LaunchedEffect(value) {
        val cur = state.value
        if (cur.text != value && cur.composition == null) {
            state.value = TextFieldValue(value, TextRange(value.length))
        }
    }
    return state
}

/** 选区稳定 250 ms 后唤起键盘；配合 [rememberImeField] 使用。 */
@Composable
fun ImeSelectionEffect(field: TextFieldValue) {
    val activity = LocalContext.current as? android.app.Activity
    val view = LocalView.current
    LaunchedEffect(field.selection) {
        if (field.selection.collapsed) return@LaunchedEffect
        delay(250)
        showIme(activity, view)
    }
}

/**
 * BasicTextField 的同类包装：外观完全由调用方决定，只补上「选完弹键盘」。
 * 用于那几处自己画底框的输入框（预设编辑、音色搜索）。
 */
@Composable
fun ImeAwareBasicTextField(
    value: String,
    onValueChange: (String) -> Unit,
    textStyle: TextStyle,
    modifier: Modifier = Modifier,
    singleLine: Boolean = false,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    cursorBrush: Brush = SolidColor(androidx.compose.ui.graphics.Color.Unspecified),
    enabled: Boolean = true,
) {
    val field = rememberImeField(value)
    ImeSelectionEffect(field.value)
    BasicTextField(
        value = field.value,
        onValueChange = {
            field.value = it
            onValueChange(it.text)
        },
        modifier = modifier,
        enabled = enabled,
        singleLine = singleLine,
        maxLines = maxLines,
        textStyle = textStyle,
        cursorBrush = cursorBrush,
    )
}
