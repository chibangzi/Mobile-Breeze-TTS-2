package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.breeze.tts.audio.AudioDecoder
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.vm.AppViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

/**
 * 音色转换（1.9.54）。
 *
 * 与「单人朗读 / 多角色对话」并列的第三个子界面，输入是音频而不是文本：
 * 词、时长、节奏、重音都从源音频复制，只有音高与音色按目标音色重建。
 *
 * 版式沿用合成页的三段式：源音频 → 源文本 → 目标音色，最后是进度 / 结果。
 * 每一块都是一张 13dp 圆角的面，行与行之间不叠卡片，靠留白分隔。
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun ConvertPanel(
    vm: AppViewModel,
    onOpenVoices: () -> Unit,
    onPickVoice: () -> Unit,
) {
    val c = Breeze.colors
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var decoding by remember { mutableStateOf(false) }
    var importError by remember { mutableStateOf<String?>(null) }
    /** 刚导入、等待剪裁的源音频 */
    var editorFile by remember { mutableStateOf<File?>(null) }
    var pendingName by remember { mutableStateOf("") }
    var textFocused by remember { mutableStateOf(false) }
    var paramsOpen by remember { mutableStateOf(false) }

    val src = vm.convertSrcWav

    // 默认目标音色：进来先选第一个能用的，避免「什么都没选」的空状态
    LaunchedEffect(vm.convertTargets.size, vm.convertTargetVoiceId) {
        if (vm.convertTargetVoiceId == null) {
            vm.convertTargets.firstOrNull()?.let { vm.convertTargetVoiceId = it.id }
        }
    }

    // 任意常见音频 → 24 kHz 单声道 WAV（与克隆音色同一条解码通路）
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null || decoding) return@rememberLauncherForActivityResult
        decoding = true
        importError = null
        scope.launch {
            // 每次换一个新文件名：波形缓存按路径存，同名文件会被认成「同一段音频」
            val out = File(ctx.cacheDir, "convert_src_${System.currentTimeMillis()}.wav")
            val r = withContext(Dispatchers.IO) {
                runCatching { AudioDecoder.importReference(ctx, uri, out) }
            }
            decoding = false
            r.fold(
                onSuccess = { res ->
                    // 先剪裁再拿去转换：转换是逐帧复刻节奏，开头一段静音会原样搬过去
                    pendingName = displayNameOf(ctx, uri)
                    vm.stopPlayback()
                    editorFile = res.file
                },
                onFailure = {
                    importError = tr("导入失败：${it.message ?: "不支持该格式"}", "Import failed: ${it.message ?: "format not supported"}")
                    runCatching { out.delete() }
                },
            )
        }
    }

    // ---- 源文本：本地编辑状态，外部（识别结果）变化时把光标收到末尾 ----
    var field by remember {
        mutableStateOf(TextFieldValue(vm.convertSrcText, TextRange(vm.convertSrcText.length)))
    }
    LaunchedEffect(vm.convertSrcText) {
        if (field.text != vm.convertSrcText) {
            field = TextFieldValue(vm.convertSrcText, TextRange(vm.convertSrcText.length))
        }
    }
    val bringIntoView = remember { BringIntoViewRequester() }
    // 键盘弹起时单次 bringIntoView 会赶在布局稳定前算错视口，重试到稳定为止。
    LaunchedEffect(textFocused) {
        if (!textFocused) return@LaunchedEffect
        repeat(18) {
            delay(70)
            runCatching { bringIntoView.bringIntoView() }
        }
    }

    val voice = vm.convertTargetVoice()
    val playingSrc = vm.playback.playing && vm.playback.path == src?.absolutePath
    val peaks = rememberWaveform(src?.absolutePath ?: "", 56)
    val srcFraction = if (vm.playback.path == src?.absolutePath) vm.playback.fraction else 0f

    // 选完音视频先进剪裁页：只保留要说的那几秒，转换更快、对齐也更准
    editorFile?.let { raw ->
        AudioEditorDialog(
            source = raw,
            title = tr("裁剪源音频"),
            onDismiss = {
                runCatching { raw.delete() }
                editorFile = null
            },
            onConfirm = { edited ->
                vm.setConvertSource(edited, pendingName)
                runCatching { raw.delete() }
                editorFile = null
            },
        )
    }

    Column(Modifier.fillMaxWidth()) {
        // ---------------- 源音频 ----------------
        CvCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("源音频"), fontSize = 11.5.sp, lineHeight = 17.sp, color = c.t3)
                Spacer(Modifier.weight(1f))
                Text(
                    when {
                        decoding -> tr("正在解码…")
                        src == null -> tr("点击选择 · 建议 5–60 秒")
                        else -> tr("可点波形试听")
                    },
                    fontSize = 10.5.sp,
                    color = c.t3,
                    maxLines = 1,
                )
            }
            Spacer(Modifier.height(9.dp))

            if (src == null) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(112.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(c.fill)
                        .border(1.dp, c.line, RoundedCornerShape(11.dp))
                        .clickable(enabled = !decoding) {
                            picker.launch(arrayOf("audio/*", "video/*"))
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(c.accentSoft),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (decoding) {
                                CircularProgressIndicator(
                                    Modifier.size(16.dp),
                                    strokeWidth = 1.8.dp,
                                    color = c.accent,
                                    trackColor = c.line2,
                                )
                            } else {
                                Icon(
                                    Icons.Outlined.Add,
                                    contentDescription = null,
                                    tint = c.accent,
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }
                        Spacer(Modifier.height(9.dp))
                        Text(
                            if (decoding) tr("正在解码音频…") else tr("选择要转换的音频"),
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = c.t1,
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "WAV / MP3 / M4A / AAC / OGG / FLAC",
                            fontSize = 10.5.sp,
                            color = c.t3,
                        )
                    }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(c.btnBg)
                            .clickable { vm.toggleConvertSource() },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (playingSrc) {
                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                Box(Modifier.width(2.5.dp).height(11.dp).clip(RoundedCornerShape(1.dp)).background(c.btnInk))
                                Box(Modifier.width(2.5.dp).height(11.dp).clip(RoundedCornerShape(1.dp)).background(c.btnInk))
                            }
                        } else {
                            Icon(
                                Icons.Outlined.PlayArrow,
                                contentDescription = tr("试听源音频"),
                                tint = c.btnInk,
                                modifier = Modifier.size(17.dp),
                            )
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            vm.convertSrcLabel.ifBlank { tr("已导入音频") },
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = c.t1,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "%s · %s".format(secondsText(vm.convertSrcMs), fileSizeText(src.length())),
                            fontSize = 10.5.sp,
                            color = c.t3,
                        )
                    }
                    CvAction(tr("更换")) { picker.launch(arrayOf("audio/*", "video/*")) }
                    CvAction(tr("移除")) { vm.clearConvertSource() }
                }
                Spacer(Modifier.height(4.dp))
                WaveSeekBar(
                    peaks = peaks,
                    fraction = srcFraction,
                    height = 34.dp,
                    // 点 / 拖都是定位，不误触播放；要听就点左侧圆钮
                    onSeek = { vm.seekConvertSource(it) },
                )
            }

            importError?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, fontSize = 11.sp, color = androidx.compose.material3.MaterialTheme.colorScheme.error)
            }
        }

        Spacer(Modifier.height(11.dp))

        // ---------------- 源文本 ----------------
        CvCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("源文本"), fontSize = 11.5.sp, lineHeight = 17.sp, color = c.t3)
                Spacer(Modifier.width(7.dp))
                Text(
                    when {
                        vm.asrBusy != null -> tr("识别中…")
                        vm.convertSrcText.isBlank() -> tr("可留空")
                        else -> tr("${vm.convertSrcText.length} 字", "${vm.convertSrcText.length} chars")
                    },
                    fontSize = 10.5.sp,
                    color = c.t3,
                    maxLines = 1,
                )
                Spacer(Modifier.weight(1f))
                CvAction(
                    if (vm.asrBusy != null) tr("识别中") else tr("自动识别"),
                    enabled = src != null && vm.asrBusy == null,
                    emphasis = true,
                ) { vm.transcribeConvertSource() }
                if (vm.convertSrcText.isNotBlank()) {
                    CvAction(tr("清空")) {
                        field = TextFieldValue("", TextRange(0))
                        vm.convertSrcText = ""
                    }
                }
            }
            Spacer(Modifier.height(9.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(96.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(c.fill)
                    .border(1.dp, if (textFocused) c.accent.copy(alpha = 0.55f) else c.line, RoundedCornerShape(10.dp))
                    .padding(horizontal = 11.dp, vertical = 9.dp)
                    .bringIntoViewRequester(bringIntoView),
            ) {
                if (field.text.isEmpty()) {
                    Text(
                        tr("这段音频说的话。可以不填，留空时模型会自动生成一段等长的占位文本，对齐精度略降。"),
                        fontSize = 12.5.sp,
                        lineHeight = 20.sp,
                        color = c.t3,
                    )
                }
                ImeSelectionEffect(field)
                BasicTextField(
                    value = field,
                    onValueChange = {
                        field = it
                        vm.convertSrcText = it.text
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                        .onFocusChanged { textFocused = it.isFocused },
                    textStyle = TextStyle(
                        fontSize = 13.sp,
                        lineHeight = 21.sp,
                        color = c.t1,
                    ),
                    cursorBrush = SolidColor(c.accent),
                )
            }
            Spacer(Modifier.height(7.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    tr("用于对齐词与时序，越准越稳"),
                    fontSize = 10.5.sp,
                    color = c.t3,
                    modifier = Modifier.weight(1f),
                )
                if (!vm.asrInstalled) {
                    CvAction(
                        if (vm.asrBusy != null) tr("下载中…") else tr("下载识别模型"),
                        enabled = vm.asrBusy == null,
                    ) { vm.installAsrModel() }
                }
            }
        }

        Spacer(Modifier.height(11.dp))

        // ---------------- 目标音色 ----------------
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(13.dp))
                .background(c.surface)
                .border(1.dp, c.line, RoundedCornerShape(13.dp)),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (vm.convertTargets.isEmpty()) onOpenVoices() else onPickVoice()
                    }
                    .padding(horizontal = 13.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.width(46.dp)) {
                    Text(tr("音色"), fontSize = 11.5.sp, lineHeight = 17.sp, color = c.t3, maxLines = 1)
                }
                if (voice != null) {
                    VoiceAvatar(
                        name = voice.name,
                        gender = voice.gender,
                        avatarPath = voice.avatarPath,
                        size = 30.dp,
                        showBadge = false,
                    )
                    Spacer(Modifier.width(10.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        voice?.name ?: tr("还没有可用音色"),
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = c.t1,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 17.sp,
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        when {
                            voice == null -> tr("点这里去创建：需要 5–15 秒干净人声 + 逐字稿")
                            voice.kind == ai.breeze.tts.engine.VoiceProfile.Kind.CLONE -> tr("克隆 · 节奏与语气保留，音色换成它")
                            else -> tr("设计 · 用它的样本音色重说")
                        },
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        color = c.t3,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.width(8.dp))
                Icon(
                    Icons.Outlined.KeyboardArrowRight,
                    contentDescription = null,
                    tint = c.t3,
                    modifier = Modifier.size(14.dp),
                )
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(c.line))

            // 参数行：与「单人朗读」同一套交互 —— 点一下就地展开，不弹浮层
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { paramsOpen = !paramsOpen }
                    .padding(horizontal = 13.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.width(46.dp)) {
                    Text(tr("参数"), fontSize = 11.5.sp, lineHeight = 17.sp, color = c.t3)
                }
                Text(
                    tr("温度 %.2f · 采样 %s · 种子 %d").format(
                        vm.convertTemperature,
                        if (vm.convertTopK <= 1) tr("贪心") else "Top-${vm.convertTopK}",
                        vm.convertSeed,
                    ),
                    fontSize = 12.5.sp,
                    lineHeight = 18.sp,
                    color = c.t2,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Icon(
                    if (paramsOpen) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                    contentDescription = null,
                    tint = c.t3,
                    modifier = Modifier.size(15.dp),
                )
            }

            AnimatedVisibility(paramsOpen) {
                Column(Modifier.padding(horizontal = 13.dp).padding(bottom = 4.dp)) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(c.line))
                    Spacer(Modifier.height(10.dp))
                    CvSlider(
                        label = tr("温度"),
                        value = vm.convertTemperature,
                        range = 0.1f..1f,
                        text = "%.2f".format(vm.convertTemperature),
                    ) { vm.convertTemperature = it }
                    CvSlider(
                        label = tr("采样范围"),
                        value = vm.convertTopK.toFloat(),
                        range = 1f..50f,
                        text = if (vm.convertTopK <= 1) tr("贪心") else "Top-${vm.convertTopK}",
                    ) { vm.convertTopK = it.toInt() }
                    CvSlider(
                        label = tr("随机种子"),
                        value = vm.convertSeed.toFloat(),
                        range = 0f..9999f,
                        text = "${vm.convertSeed}",
                    ) { vm.convertSeed = it.toInt() }
                    CvSlider(
                        label = tr("保留旋律"),
                        value = vm.convertKeepAcoustic.toFloat(),
                        range = 0f..2f,
                        text = if (vm.convertKeepAcoustic == 0) tr("关闭") else tr("${vm.convertKeepAcoustic} 档", "level ${vm.convertKeepAcoustic}"),
                    ) { vm.convertKeepAcoustic = it.toInt() }

                    Spacer(Modifier.height(2.dp))
                    Text(
                        tr("温度越低越像目标音色，越高越自然但源的音色会漏回来；") +
                            tr("采样范围 1 = 每帧取最优（贪心），放开后更活但更容易跑偏；") +
                            tr("同一组参数 + 同一种子可复现同一段结果。"),
                        fontSize = 10.5.sp,
                        lineHeight = 16.sp,
                        color = c.t3,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        tr("保留旋律：把源音频前 1–2 个声学码本原样搬过来，旋律和音高起伏会保留，") +
                            tr("代价是音色更像源说话人。只有唱歌素材需要，先试 0，旋律扁了再上 1 或 2；") +
                            tr("3 以上上游实测会发飘，普通说话留 0（否则音高会被拉宽到 3 倍并出现抖动）。"),
                        fontSize = 10.5.sp,
                        lineHeight = 16.sp,
                        color = c.t3,
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }
        }

        vm.convertError?.let {
            Spacer(Modifier.height(11.dp))
            Text(
                it,
                fontSize = 11.5.sp,
                lineHeight = 17.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.error,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(androidx.compose.material3.MaterialTheme.colorScheme.error.copy(alpha = 0.08f))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            )
        }

        Spacer(Modifier.height(13.dp))

        // ---------------- 进度 / 结果 ----------------
        AnimatedVisibility(
            visible = vm.converting,
            enter = fadeIn(tween(180)) + expandVertically(tween(200)),
            exit = fadeOut(tween(140)) + shrinkVertically(tween(160)),
        ) {
            ConvertProgressCard(vm)
        }

        AnimatedVisibility(
            visible = !vm.converting && vm.convertWav != null,
            enter = fadeIn(tween(220)) + expandVertically(tween(240)),
            exit = fadeOut(tween(120)) + shrinkVertically(tween(140)),
        ) {
            ConvertResultCard(vm)
        }

        Spacer(Modifier.height(14.dp))
        Text(
            tr("词、时长、节奏都来自源音频，只有音色被替换。音高会按目标音色的音域重新生成，") +
                tr("唱歌素材可能整段移调。转换是上游标注的实验性能力，建议先用短素材试效果。"),
            fontSize = 10.5.sp,
            lineHeight = 16.sp,
            color = c.t3,
        )
    }

    // 音色浮层由 SynthesizeScreen 在页面根部渲染。
    // 这里原来直接放 VoicePickerSheet，但本面板处于 verticalScroll 内部：
    // BreezeSheet 的根是 fillMaxSize，在无界高度下只能量到 0，结果只剩背景压暗、
    // 浮层本身一片空白。和「单人朗读」一样放到页面最外层才能拿到整屏高度。
}

// ============================================================
// 局部组件（与合成页同一套视觉规则，避免跨文件耦合 private 实现）
// ============================================================

@Composable
private fun CvCard(content: @Composable ColumnScope.() -> Unit) {
    val c = Breeze.colors
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(c.surface)
            .border(1.dp, c.line, RoundedCornerShape(13.dp))
            .padding(horizontal = 13.dp, vertical = 12.dp),
        content = content,
    )
}

/** 行内文字动作：无底色，热区靠 padding 撑开，避免在 11sp 上点不中。 */
@Composable
private fun CvAction(
    text: String,
    enabled: Boolean = true,
    emphasis: Boolean = false,
    onClick: () -> Unit,
) {
    val c = Breeze.colors
    Text(
        text,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        fontWeight = FontWeight.Medium,
        color = when {
            !enabled -> c.t3.copy(alpha = 0.45f)
            emphasis -> c.accent
            else -> c.t2
        },
        maxLines = 1,
        softWrap = false,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 4.dp),
    )
}

/** 参数滑条：左标签 + 右数值 + 下方轨道，与朗读页的 CompactSlider 同一套尺寸。 */
@Composable
private fun CvSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    text: String,
    onChange: (Float) -> Unit,
) {
    val c = Breeze.colors
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontSize = 12.5.sp, lineHeight = 17.sp, color = c.t2, modifier = Modifier.weight(1f))
            Text(text, fontSize = 12.sp, lineHeight = 17.sp, color = c.t1, fontWeight = FontWeight.Medium)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            modifier = Modifier.height(32.dp),
            colors = SliderDefaults.colors(
                thumbColor = c.accent,
                activeTrackColor = c.accent,
                inactiveTrackColor = c.line2,
            ),
        )
    }
}

@Composable
private fun ConvertProgressCard(vm: AppViewModel) {
    val c = Breeze.colors
    // 转换也走「静止卡片」：去掉不确定进度环和 tween(320) 的插值动画。
    // 后者每来一次进度（3~7 Hz）就重绘 320 ms，实际上等于连续动画。
    // 现在进度每秒跳一格，界面 1 Hz 重绘，屏幕才能降到最低刷新率（docs/84）。
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(c.surface)
            .border(1.dp, c.line, RoundedCornerShape(13.dp)),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(c.accent),
            )
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    vm.convertStatus.ifBlank { tr("正在转换…") },
                    fontSize = 13.sp,
                    color = c.t1,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    when {
                        // 声码器阶段：这一步不出声、也不刷新帧号，最后几段最容易让人以为卡死
                        vm.convertPhase == 1 && vm.convertTotalUnits > 0 ->
                            // done=0 是「刚进入这一段」，显示成第 1 段更自然
                            tr("第 %d / %d 段 · 声码器上采样成波形").format(
                                maxOf(vm.convertDoneUnits, 1), vm.convertTotalUnits,
                            )
                        vm.convertTotalFrames > 0 ->
                            tr("第 %d / %d 帧 · 逐帧重算 15 个声学码本").format(vm.convertDoneFrames, vm.convertTotalFrames)
                        else -> tr("先编码源音频，再逐帧重说")
                    },
                    fontSize = 11.sp,
                    color = c.t3,
                    maxLines = 1,
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                "%d%%".format((vm.convertProgress * 100).toInt().coerceIn(0, 100)),
                fontSize = 11.5.sp,
                color = c.t3,
                fontWeight = FontWeight.Medium,
            )
        }
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 13.dp)
                .height(2.dp)
                .clip(RoundedCornerShape(1.dp))
                .background(c.fill2),
        ) {
            Box(
                Modifier
                    .fillMaxWidth(vm.convertProgress.coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .background(c.accent),
            )
        }
        Text(
            tr("本地推理 · 转换期间别切到后台太久，系统可能回收进程"),
            fontSize = 10.5.sp,
            color = c.t3,
            modifier = Modifier.padding(horizontal = 13.dp).padding(top = 9.dp),
        )
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun ConvertResultCard(vm: AppViewModel) {
    val c = Breeze.colors
    val focus = LocalFocusManager.current
    val file = vm.convertWav ?: return
    val playing = vm.playback.playing && vm.playback.path == file.absolutePath
    val rtf = if (vm.convertAudioMs > 0) vm.convertElapsedMs.toFloat() / vm.convertAudioMs.toFloat() else 0f
    // 与收藏页同一套：真实 PCM 峰值，按路径缓存
    val peaks = rememberWaveform(file.absolutePath, 64)
    val fraction = if (vm.playback.path == file.absolutePath) vm.playback.fraction else 0f

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(c.surface)
            .border(1.dp, c.line, RoundedCornerShape(13.dp)),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(c.btnBg)
                    .clickable { if (playing) vm.togglePlayback() else vm.playConvert() },
                contentAlignment = Alignment.Center,
            ) {
                if (playing) {
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        Box(Modifier.width(2.5.dp).height(11.dp).clip(RoundedCornerShape(1.dp)).background(c.btnInk))
                        Box(Modifier.width(2.5.dp).height(11.dp).clip(RoundedCornerShape(1.dp)).background(c.btnInk))
                    }
                } else {
                    Icon(
                        Icons.Outlined.PlayArrow,
                        contentDescription = tr("播放"),
                        tint = c.btnInk,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    vm.convertResultName.ifBlank { tr("转换结果") },
                    fontSize = 13.sp,
                    color = c.t1,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    buildString {
                        append(secondsText(vm.convertAudioMs))
                        append(tr(" · 耗时 "))
                        append(tr("%.1f 秒").format(vm.convertElapsedMs / 1000.0))
                        if (rtf > 0f) append(" · RTF %.2f".format(rtf))
                        if (playing) append(tr(" · 播放中"))
                    },
                    fontSize = 11.sp,
                    color = c.t3,
                    maxLines = 1,
                )
            }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .clickable { vm.playConvert() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Outlined.Refresh,
                    contentDescription = tr("从头播放"),
                    tint = c.t3,
                    modifier = Modifier.size(15.dp),
                )
            }
        }

        Spacer(Modifier.height(2.dp))
        WaveSeekBar(
            peaks = peaks,
            fraction = fraction,
            height = 34.dp,
            modifier = Modifier.padding(horizontal = 13.dp),
            onSeek = { vm.seekConvertResult(it) },
        )

        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.line))
        Row(Modifier.fillMaxWidth().height(40.dp)) {
            CvResultAction(tr("导出"), Icons.Outlined.Share) { vm.exportConvert() }
            Box(Modifier.width(1.dp).fillMaxHeight().background(c.line))
            CvResultAction(
                when {
                    vm.convertFavorited -> tr("已收藏")
                    vm.convertFavoriteBusy -> tr("收藏中…")
                    else -> tr("收藏")
                },
                Icons.Outlined.Star,
                enabled = !vm.convertFavorited && !vm.convertFavoriteBusy,
                tint = if (vm.convertFavorited) c.accent else null,
            ) { vm.favoriteConvert() }
            Box(Modifier.width(1.dp).fillMaxHeight().background(c.line))
            CvResultAction(tr("重新转换"), Icons.Outlined.Refresh) {
                focus.clearFocus()
                vm.convertWav?.let { runCatching { it.delete() } }
                vm.startConvert()
            }
        }
    }
}

@Composable
private fun RowScope.CvResultAction(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean = true,
    tint: androidx.compose.ui.graphics.Color? = null,
    onClick: () -> Unit,
) {
    val c = Breeze.colors
    val ink = tint ?: if (enabled) c.t2 else c.t3.copy(alpha = 0.45f)
    Row(
        Modifier
            .weight(1f)
            .fillMaxHeight()
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = ink, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, fontSize = 11.5.sp, color = ink, maxLines = 1, softWrap = false)
    }
}

// ============================================================
// 工具
// ============================================================

private fun secondsText(ms: Long): String = when {
    ms <= 0 -> tr("未知时长")
    ms % 1000 == 0L -> tr("${ms / 1000} 秒", "${ms / 1000} s")
    else -> tr("%.1f 秒").format(Locale.getDefault(), ms / 1000.0)
}

private fun fileSizeText(bytes: Long): String = when {
    bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1e6)
    bytes >= 1_000 -> "${bytes / 1000} KB"
    else -> "$bytes B"
}

/** 系统文件选择器只给 content://，这里取回原始文件名给用户看。 */
private fun displayNameOf(ctx: Context, uri: Uri): String {
    var name = tr("导入的音频")
    runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cur ->
                if (cur.moveToFirst()) {
                    val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) cur.getString(i)?.takeIf { it.isNotBlank() }?.let { name = it }
                }
            }
    }
    return name
}

