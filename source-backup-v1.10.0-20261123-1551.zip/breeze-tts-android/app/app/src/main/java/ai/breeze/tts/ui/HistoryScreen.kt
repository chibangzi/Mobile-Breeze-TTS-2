package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ai.breeze.tts.data.HistoryItem
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeSize
import ai.breeze.tts.vm.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 收藏夹（v2 重做）。
 *
 * 生成成功不再自动入库，必须在结果条点「收藏」才出现在这里；长按任意条目进入
 * 多选，可全选 / 反选 / 批量导出 / 批量删除。
 *
 * 视觉上把「一张张圆角卡片」换成了「一列 66dp 的行 + 1px 分隔线」：
 * 音频条目是清单，不是卡片；卡片间距会让一屏只能放 5 条。
 */
@Composable
fun HistoryScreen(vm: AppViewModel) {
    val c = Breeze.colors
    var confirmBatchDelete by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf(0) }

    val shown = remember(vm.history, filter) {
        when (filter) {
            1 -> vm.history.filter { !it.text.contains("【") }
            2 -> vm.history.filter { it.text.contains("【") }
            else -> vm.history
        }
    }

    Column(Modifier.fillMaxSize()) {
        // ---- 标题 ----
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = BreezeSize.gutter, end = BreezeSize.gutter)
                .padding(top = 4.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                if (vm.favSelecting) tr("已选 ${vm.favSelected.size} 项", "${vm.favSelected.size} selected") else tr("收藏夹"),
                style = MaterialTheme.typography.headlineMedium,
                color = c.t1,
                modifier = Modifier.weight(1f),
            )
            if (vm.favSelecting || vm.history.isNotEmpty()) {
                Text(
                    if (vm.favSelecting) tr("完成") else tr("选择"),
                    fontSize = 12.5.sp,
                    color = c.t2,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(7.dp))
                        .clickable {
                            if (vm.favSelecting) vm.exitFavSelection()
                            else vm.history.firstOrNull()?.let { vm.startFavSelection(it.id) }
                        }
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                )
            }
        }

        // ---- 筛选 ----
        if (!vm.favSelecting) {
            Box(Modifier.padding(horizontal = BreezeSize.gutter)) {
                WordTabs(
                    labels = listOf(tr("全部"), tr("朗读"), tr("对话")),
                    selectedIndex = filter,
                    onSelect = { filter = it },
                )
            }
            Spacer(Modifier.height(4.dp))
        }

        if (vm.favSelecting) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = BreezeSize.gutter)
                    .padding(bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SmallTextAction(tr("全选")) { vm.selectAllFavorites() }
                Spacer(Modifier.width(16.dp))
                SmallTextAction(tr("反选")) { vm.invertFavSelection() }
                Spacer(Modifier.weight(1f))
                Text(
                    tr("长按任意一条也可进入多选"),
                    fontSize = 11.sp,
                    color = c.t3,
                )
            }
        }

        // ---- 正在播放 ----
        if (vm.playback.hasAudio && !vm.favSelecting) {
            MiniPlayer(vm)
        }

        // ---- 列表 ----
        if (vm.history.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(
                    Modifier.padding(horizontal = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(tr("还没有收藏"), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = c.t1)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        tr("生成满意的一段后，在结果条点「收藏」；\n之后可以在这里批量导出 WAV。"),
                        fontSize = 12.sp,
                        lineHeight = 19.sp,
                        color = c.t3,
                    )
                }
            }
        } else if (shown.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(tr("这个分类下还没有内容"), fontSize = 12.5.sp, color = c.t3)
            }
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(shown, key = { it.id }) { item ->
                    val playing = vm.playback.playing && vm.playback.path == item.path
                    val selected = item.id in vm.favSelected
                    if (vm.favSelecting) {
                        FavRow(
                            item = item,
                            playing = playing,
                            selecting = true,
                            selected = selected,
                            onClick = { vm.toggleFavSelected(item.id) },
                        )
                    } else {
                        SwipeToDeleteRow(
                            onDelete = { vm.deleteHistory(item) },
                            onClick = { vm.playHistory(item) },
                            onExport = { vm.exportHistory(item) },
                            onLongClick = { vm.startFavSelection(item.id) },
                            modifier = Modifier.background(c.bg),
                        ) {
                            PlayDot(playing = playing)
                            Spacer(Modifier.width(11.dp))
                            FavText(item = item, playing = playing)
                        }
                        HairlineDivider(startPadding = 18.dp)
                    }
                }
                item { Spacer(Modifier.height(12.dp)) }
            }
        }

        // ---- 批量操作 ----
        if (vm.favSelecting) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = BreezeSize.gutter)
                    .padding(top = 10.dp, bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                BreezeButton(
                    text = tr("导出 ${vm.favSelected.size} 项", "Export ${vm.favSelected.size}"),
                    onClick = { vm.exportSelectedFavorites() },
                    tone = BreezeTone.Soft,
                    icon = Icons.Outlined.Share,
                    enabled = vm.favSelected.isNotEmpty(),
                    height = BreezeSize.buttonSmall,
                    modifier = Modifier.weight(1f),
                )
                BreezeButton(
                    text = tr("删除"),
                    onClick = { confirmBatchDelete = true },
                    tone = BreezeTone.Warn,
                    enabled = vm.favSelected.isNotEmpty(),
                    height = BreezeSize.buttonSmall,
                    modifier = Modifier.width(88.dp),
                )
            }
        }
    }

    if (confirmBatchDelete) {
        ConfirmDialog(
            title = tr("删除收藏"),
            body = tr("确定删除选中的 ${vm.favSelected.size} 条收藏？音频文件会一并删除，无法恢复。", "Delete the ${vm.favSelected.size} selected items? The audio files are deleted too and can't be recovered."),
            confirmText = tr("删除"),
            warn = true,
            onConfirm = {
                vm.deleteSelectedFavorites()
                confirmBatchDelete = false
            },
            onDismiss = { confirmBatchDelete = false },
        )
    }
}

@Composable
private fun SmallTextAction(text: String, onClick: () -> Unit) {
    Text(
        text,
        fontSize = 12.sp,
        color = Breeze.colors.t2,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 3.dp),
    )
}

/** 一列 66dp 的收藏行：播放键 / 勾选框 + 台词 + 音色时间 + 时长 */
@Composable
private fun FavRow(
    item: HistoryItem,
    playing: Boolean,
    selecting: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val c = Breeze.colors
    Row(
        Modifier
            .fillMaxWidth()
            .height(66.dp)
            .background(if (selected) c.accentSoft else c.bg)
            .clickable(onClick = onClick)
            .padding(horizontal = BreezeSize.gutter),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (selecting) {
            CircleCheck(selected = selected, size = 18.dp)
        } else {
            PlayDot(playing = playing)
        }
        Spacer(Modifier.width(11.dp))
        FavText(item = item, playing = playing)
    }
}

@Composable
private fun PlayDot(playing: Boolean) {
    val c = Breeze.colors
    Box(
        Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(if (playing) c.accent else c.surface)
            .border(1.dp, if (playing) c.accent else c.line2, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Outlined.PlayArrow,
            contentDescription = null,
            tint = if (playing) c.onAccent else c.t2,
            modifier = Modifier.size(15.dp),
        )
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.FavText(item: HistoryItem, playing: Boolean) {
    val c = Breeze.colors
    Column(Modifier.weight(1f)) {
        Text(
            item.title,
            fontSize = 13.5.sp,
            color = if (playing) c.accent else c.t1,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 18.sp,
        )
        Spacer(Modifier.height(3.dp))
        Text(
            tr("${item.voiceName.ifBlank { "默认音色" }} · ${formatTime(item.createdAt)} · ${item.bytes / 1024} KB", "${item.voiceName.ifBlank { "默认音色" }} · ${formatTime(item.createdAt)} · ${item.bytes / 1024} KB"),
            fontSize = 10.5.sp,
            color = c.t3,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
    Spacer(Modifier.width(10.dp))
    Text(
        "%d:%02d".format((item.durationMs / 60000).toInt(), ((item.durationMs / 1000) % 60).toInt()),
        fontSize = 10.5.sp,
        color = c.t3,
    )
}

/** 收藏页顶部的播放条：一行控制 + 波形，波形本身既是进度也是拖动区。 */
@Composable
private fun MiniPlayer(vm: AppViewModel) {
    val c = Breeze.colors
    val peaks = rememberWaveform(vm.playback.path, buckets = 64)

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = BreezeSize.gutter)
            .padding(bottom = 4.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().height(46.dp).clickable { vm.togglePlayback() },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(28.dp).clip(CircleShape).background(c.btnBg),
                contentAlignment = Alignment.Center,
            ) {
                if (vm.playback.playing) {
                    Row(horizontalArrangement = Arrangement.spacedBy(2.5.dp)) {
                        Box(Modifier.width(2.dp).height(10.dp).clip(RoundedCornerShape(1.dp)).background(c.btnInk))
                        Box(Modifier.width(2.dp).height(10.dp).clip(RoundedCornerShape(1.dp)).background(c.btnInk))
                    }
                } else {
                    Icon(
                        Icons.Outlined.PlayArrow,
                        contentDescription = tr("播放"),
                        tint = c.btnInk,
                        modifier = Modifier.size(15.dp),
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    vm.playback.label.ifBlank { tr("正在播放") },
                    fontSize = 12.5.sp,
                    lineHeight = 16.sp,
                    color = c.t1,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    "%d:%02d / %d:%02d".format(
                        vm.playback.positionMs / 60000,
                        (vm.playback.positionMs / 1000) % 60,
                        vm.playback.durationMs / 60000,
                        (vm.playback.durationMs / 1000) % 60,
                    ),
                    fontSize = 10.5.sp,
                    lineHeight = 14.sp,
                    color = c.t3,
                )
            }
        }
        Spacer(Modifier.height(2.dp))
        WaveSeekBar(
            peaks = peaks,
            fraction = vm.playback.fraction,
            height = 34.dp,
            onSeek = { vm.seekPlayback(it) },
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ConfirmDialog(
    title: String,
    body: String,
    confirmText: String,
    warn: Boolean,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = Breeze.colors
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(Modifier.fillMaxSize().padding(horizontal = 32.dp), contentAlignment = Alignment.Center) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(c.surface2)
                    .border(1.dp, c.line2, RoundedCornerShape(18.dp))
                    .padding(16.dp),
            ) {
                Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = c.t1)
                Spacer(Modifier.height(8.dp))
                Text(body, fontSize = 12.5.sp, lineHeight = 20.sp, color = c.t2)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BreezeButton(
                        text = tr("取消"),
                        onClick = onDismiss,
                        tone = BreezeTone.Ghost,
                        height = BreezeSize.buttonTiny,
                        modifier = Modifier.weight(1f),
                    )
                    BreezeButton(
                        text = confirmText,
                        onClick = onConfirm,
                        tone = if (warn) BreezeTone.Warn else BreezeTone.Primary,
                        height = BreezeSize.buttonTiny,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String =
    SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(ms))
