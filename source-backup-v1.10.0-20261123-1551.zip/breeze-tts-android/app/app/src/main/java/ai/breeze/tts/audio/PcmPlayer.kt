package ai.breeze.tts.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlin.math.min

/**
 * 编辑页用的内存 PCM 播放器。
 *
 * 和 [WavPlayer] 的区别是「不读文件、只播指定区间」：编辑时用户会反复
 * 试听选区、删一段再听，每次都写临时 wav 再让播放器重新扫盘，延迟和磁盘
 * 抖动都会打断手感。这里直接把 [PcmClip.samples] 的某个区间推给 AudioTrack。
 */
class PcmPlayer(private val sampleRate: Int = 24_000) {

    private val main = Handler(Looper.getMainLooper())
    private var track: AudioTrack? = null
    private var worker: Thread? = null

    /** 每次播放自增；旧线程据此退出，避免快速连点时两个线程抢同一个 track。 */
    @Volatile private var gen = 0

    var isPlaying = false
        private set

    /** 已播毫秒（相对本次起点），约 60 ms 一次，主线程回调。 */
    var onTick: ((Long) -> Unit)? = null

    /** 自然播完（不是被 stop 打断）。 */
    var onEnd: (() -> Unit)? = null

    private val ticker = object : Runnable {
        override fun run() {
            val t = track ?: return
            if (!isPlaying) return
            val head = runCatching { t.playbackHeadPosition }.getOrDefault(0)
            onTick?.invoke(head * 1000L / sampleRate)
            if (isPlaying) main.postDelayed(this, 60L)
        }
    }

    fun play(samples: ShortArray, from: Int, to: Int) {
        val a = from.coerceIn(0, samples.size)
        val b = to.coerceIn(a, samples.size)
        if (b - a < sampleRate / 100) return
        stop()

        val t = try {
            val min = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
            )
            AudioTrack(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build(),
                maxOf(min, sampleRate / 2),
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE,
            )
        } catch (e: Throwable) {
            Log.w(TAG, "AudioTrack init failed", e)
            return
        }
        if (t.state != AudioTrack.STATE_INITIALIZED) {
            t.release()
            return
        }

        track = t
        isPlaying = true
        val my = ++gen
        val total = b - a
        t.play()

        worker = Thread({
            try {
                var off = 0
                while (gen == my && off < total) {
                    val n = min(4096, total - off)
                    val w = t.write(samples, a + off, n, AudioTrack.WRITE_BLOCKING)
                    if (w <= 0) break
                    off += w
                }
                // 数据写完不等于放完：等播放头追上，否则尾音会被 release 掐掉
                while (gen == my && runCatching { t.playbackHeadPosition }.getOrDefault(0) < total) {
                    Thread.sleep(20)
                }
                if (gen == my) {
                    main.post {
                        if (gen != my) return@post
                        isPlaying = false
                        main.removeCallbacks(ticker)
                        onEnd?.invoke()
                        releaseTrack()
                    }
                }
            } catch (ignored: Throwable) {
                // stop() 会 pause + flush，阻塞写在这里抛出，属正常退出
            }
        }, "pcm-preview").also { it.start() }

        main.postDelayed(ticker, 60L)
    }

    fun stop() {
        gen++
        isPlaying = false
        main.removeCallbacks(ticker)
        val t = track
        if (t != null) {
            runCatching { t.pause() }
            runCatching { t.flush() }
        }
        releaseTrack()
        onTick?.invoke(0)
    }

    fun release() {
        stop()
        onTick = null
        onEnd = null
    }

    private fun releaseTrack() {
        val t = track ?: return
        track = null
        runCatching { t.stop() }
        runCatching { t.release() }
    }

    private companion object {
        const val TAG = "PcmPlayer"
    }
}
