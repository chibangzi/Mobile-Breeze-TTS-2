package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeSize
import ai.breeze.tts.vm.AppViewModel
import ai.breeze.tts.vm.ExpandTarget

/**
 * AI 扩写弹窗（v2 重做）。
 *
 * 形状从 26dp 圆角 / 占屏 88% 的大卡，收成 18dp 圆角 / 内容自适应高度的小窗——
 * 它只是一个「看一眼、决定要不要」的中转站，不该像一页文档。
 *
 * 三颗按钮固定 1 : 1.06 : 1、40dp 高、单行不换行：
 *   取消（无底无边的纯文字） · 再次生成（灰底） · 替换（主按钮色）
 * 主次全靠底色区分，尺寸完全一致。
 */
@Composable
fun ExpandDialog(vm: AppViewModel) {
    if (!vm.expandOpen) return

    val c = Breeze.colors
    var showFullReq by remember { mutableStateOf(false) }
    val hasResult = vm.expandResult.isNotBlank()
    val forEmotion = vm.expandTarget == ExpandTarget.EMOTION

    Dialog(
        onDismissRequest = { vm.dismissExpand() },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(c.surface2)
                    .border(1.dp, c.line2, RoundedCornerShape(18.dp))
                    .padding(16.dp),
            ) {
                // ---- 标题 ----
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (forEmotion) tr("AI 写语气") else tr("AI 扩写"),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = c.t1,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        vm.expandProviderName.ifBlank { tr("生成中") },
                        fontSize = 10.5.sp,
                        color = c.t3,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(end = 8.dp),
                    )
                    CircleClose(onClick = { vm.dismissExpand() })
                }

                Spacer(Modifier.height(14.dp))

                // ---- 需求 ----
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(c.fill2)
                        .clickable { showFullReq = !showFullReq }
                        .padding(horizontal = 11.dp, vertical = 10.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (forEmotion) tr("台词与初步描述") else tr("需求"),
                            fontSize = 10.5.sp,
                            color = c.t3,
                            letterSpacing = 0.6.sp,
                            modifier = Modifier.weight(1f),
                        )
                        Icon(
                            if (showFullReq) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                            contentDescription = if (showFullReq) tr("收起") else tr("展开"),
                            tint = c.t3,
                            modifier = Modifier.size(14.dp),
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        vm.text.trim().ifBlank { tr("（空）") },
                        fontSize = 12.5.sp,
                        lineHeight = 19.sp,
                        color = c.t2,
                        maxLines = if (showFullReq) Int.MAX_VALUE else 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (forEmotion) {
                        Spacer(Modifier.height(5.dp))
                        Text(
                            tr("初步描述：") + vm.expandRoughEmotion.ifBlank { tr("（无）") },
                            fontSize = 11.5.sp,
                            lineHeight = 17.sp,
                            color = c.t3,
                            maxLines = if (showFullReq) Int.MAX_VALUE else 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                // ---- 结果 ----
                when {
                    vm.expandLoading -> Box(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(min = 236.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.dp,
                                color = c.accent,
                                trackColor = c.line2,
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(if (forEmotion) tr("正在写语气…") else tr("正在写稿…"), fontSize = 12.5.sp, color = c.t2)
                            Spacer(Modifier.height(3.dp))
                            Text(tr("通常几秒到半分钟"), fontSize = 11.sp, color = c.t3)
                        }
                    }

                    vm.expandError != null -> Column(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(min = 236.dp, max = 320.dp)
                            .verticalScroll(rememberScrollState()),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Outlined.Warning,
                                contentDescription = null,
                                tint = c.warn,
                                modifier = Modifier.size(15.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                tr("生成失败"),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = c.warn,
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            vm.expandError ?: "",
                            fontSize = 12.5.sp,
                            lineHeight = 20.sp,
                            color = c.t2,
                        )
                    }

                    hasResult -> SelectionContainer {
                        Text(
                            vm.expandResult,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 236.dp, max = 320.dp)
                                .verticalScroll(rememberScrollState())
                                .padding(vertical = 2.dp),
                            fontSize = 13.5.sp,
                            lineHeight = 25.sp,
                            color = c.t1,
                        )
                    }

                    else -> Box(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(min = 236.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(tr("还没有内容"), fontSize = 12.5.sp, color = c.t3)
                    }
                }

                Spacer(Modifier.height(18.dp))

                // ---- 操作 ----
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    BreezeButton(
                        text = tr("取消"),
                        onClick = { vm.dismissExpand() },
                        tone = BreezeTone.Ghost,
                        height = BreezeSize.buttonTiny,
                        modifier = Modifier.weight(1f),
                    )
                    BreezeButton(
                        text = tr("再次生成"),
                        onClick = { vm.regenerateExpand() },
                        tone = BreezeTone.Soft,
                        enabled = !vm.expandLoading,
                        height = BreezeSize.buttonTiny,
                        modifier = Modifier.weight(1.06f),
                    )
                    BreezeButton(
                        text = tr("替换"),
                        onClick = { vm.applyExpand() },
                        tone = BreezeTone.Primary,
                        enabled = !vm.expandLoading && hasResult,
                        height = BreezeSize.buttonTiny,
                        modifier = Modifier.weight(1f),
                    )
                }

                AnimatedVisibility(visible = !vm.expandLoading && hasResult) {
                    Column {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            if (forEmotion) tr("替换会覆盖情绪输入框里的内容，可用输入的撤销恢复。")
                            else tr("替换会覆盖输入框里的原文，可用输入框的撤销恢复。"),
                            fontSize = 11.sp,
                            color = c.t3,
                            lineHeight = 16.sp,
                        )
                    }
                }
            }
        }
    }
}
