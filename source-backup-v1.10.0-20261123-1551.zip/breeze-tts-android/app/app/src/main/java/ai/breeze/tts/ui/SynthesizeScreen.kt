package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Create
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.breeze.tts.data.EmotionPreset
import ai.breeze.tts.data.ModelState
import ai.breeze.tts.data.ScriptLine
import ai.breeze.tts.engine.VoiceProfile
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeSize
import ai.breeze.tts.vm.AppViewModel
import ai.breeze.tts.vm.EngineState
import ai.breeze.tts.vm.SynthMode
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.delay

/**
 * 语音合成页（v2 重做）。
 *
 * 与旧版的结构差异：
 *  - 页头只有一个 21sp 标题 + 一个 30dp 图标按钮，不再有图标徽章和副标题；
 *  - 模式切换从渐变胶囊改成文字 tab（下划线），顶部不再有第二个焦点；
 *  - 文本输入区去掉边框，只留一块比页面亮一档的底，工具行压在它底部；
 *  - 音色 / 表达 / 参数原来是三张带图标的卡片，现在合并成一组行
 *    （音色 57 · 表达 86 · 参数 50），行与行之间只有 1px 分隔线；
 *  - 表达不再是「只能从预设里挑」：输入框常驻，上方是「存为预设 / 表达预设」；
 *  - 结果从「播放卡片 + 收藏按钮」合并成一条：播放键 + 标题 + 进度线 + 三动作；
 *  - 统计信息收进「技术细节」折叠行，默认不占地方。
 */
@Composable
fun SynthesizeScreen(
    vm: AppViewModel,
    onOpenVoices: () -> Unit,
    onOpenModels: () -> Unit,
    onOpenSettings: () -> Unit = onOpenModels,
) {
    val c = Breeze.colors
    val focus = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val ready = vm.modelState is ModelState.Ready && vm.engineState is EngineState.Ready
    val voice = vm.voices.firstOrNull { it.id == vm.selectedVoiceId }
    val mode = vm.synthMode
    val dialogue = mode == SynthMode.DIALOGUE
    val convert = mode == SynthMode.CONVERT
    // 子界面切换的入场动画：淡入 + 8dp 上浮。比整块 Crossfade 更稳——
    // 转换面板比输入框高得多，做尺寸动画会让滚动位置来回跳。
    val contentAlpha = remember { Animatable(1f) }
    LaunchedEffect(mode) {
        contentAlpha.snapTo(0f)
        contentAlpha.animateTo(1f, tween(240, easing = FastOutSlowInEasing))
    }

    DisposableEffect(Unit) {
        onDispose { vm.dismissExpand() }
    }

    val scriptLines: List<ScriptLine> = remember(vm.text, dialogue) {
        if (dialogue) ai.breeze.tts.data.ScriptParser.parse(vm.text) else emptyList()
    }
    val speakers = remember(scriptLines) {
        ai.breeze.tts.data.ScriptParser.speakers(scriptLines)
    }

    var showVoicePicker by remember { mutableStateOf(false) }
    var showConvertVoicePicker by remember { mutableStateOf(false) }
    var showEmotionPicker by remember { mutableStateOf(false) }
    var presetEditor by remember { mutableStateOf<PresetEditorTarget?>(null) }
    var presetDeleting by remember { mutableStateOf<EmotionPreset?>(null) }

    val sheetVisible = showVoicePicker || showConvertVoicePicker || showEmotionPicker
    LaunchedEffect(sheetVisible) { vm.sheetOpen = sheetVisible }
    LaunchedEffect(mode) {
        // 切到别的子界面时把音色浮层关掉，避免它盖在新页面上
        if (mode != SynthMode.CONVERT) showConvertVoicePicker = false
    }
    DisposableEffect(Unit) { onDispose { vm.sheetOpen = false } }

    // 键盘弹起时窗口不缩放：底部「生成」按钮留在原地，被键盘盖住，整页不往上跳。
    // 只在合成页生效；离开时恢复 manifest 里的 adjustResize（设置页的输入框还要靠它）。
    val win = (LocalContext.current as? android.app.Activity)?.window
    DisposableEffect(Unit) {
        win?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        onDispose {
            win?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
    }

    // 键盘占掉的高度。窗口不缩放，就得自己量：用 getWindowVisibleDisplayFrame，
    // 它算的是「窗口还能看见多少」，与 softInputMode 无关，键盘一升一降都会触发重排。
    // 本工程没开 edge-to-edge，adjustResize 下 WindowInsets.ime 会在 DecorView 层被吃掉；
    // 本页切成 ADJUST_NOTHING 后通常读得到，所以两个都量、取大的。
    var frameImePx by remember { mutableStateOf(0) }
    val decor = win?.decorView
    DisposableEffect(decor) {
        if (decor == null) return@DisposableEffect onDispose {}
        val vto = decor.viewTreeObserver
        val onLayout = android.view.ViewTreeObserver.OnGlobalLayoutListener {
            val r = android.graphics.Rect()
            decor.getWindowVisibleDisplayFrame(r)
            val hidden = decor.height - r.bottom
            // 不到窗口 15% 的差值当噪声（手势条、分屏取整），键盘比这高得多
            frameImePx = if (hidden > decor.height * 0.15f) hidden else 0
        }
        vto.addOnGlobalLayoutListener(onLayout)
        onDispose { if (vto.isAlive) vto.removeOnGlobalLayoutListener(onLayout) }
    }

    // 滚动区要让出的高度。这里不能直接写「键盘高度 − 按钮高度」：
    // 本页的底边并不在窗口底部——外面那层 Scaffold 已经扣掉了底部标签栏
    // （56dp 四列 + 1px 线 + 导航栏）。键盘高度是从窗口底边算的，直接拿来让位，
    // 就会多让出整整一个标签栏，键盘上方空出一条带子（1.9.94-kbd 就是这样）。
    // 所以先量出「按钮底边到窗口底边」的距离，把它从键盘高度里减掉。
    val density = LocalDensity.current
    var barPx by remember { mutableStateOf(0) }          // 底部按钮区高度
    var bottomGapPx by remember { mutableStateOf(-1) }   // 按钮底边 → 窗口底边
    val keyboardPx = maxOf(frameImePx, WindowInsets.ime.getBottom(density))
    val scrollInset = if (keyboardPx <= 0 || bottomGapPx < 0) {
        0.dp
    } else with(density) {
        (keyboardPx - bottomGapPx - barPx).coerceAtLeast(0).toDp()
    }

    // 根容器铺一层页面底色：即使还差一两像素，露出来的也是背景色而不是窗口的黑。
    Box(Modifier.fillMaxSize().background(c.bg)) {
        Column(
            Modifier
                .fillMaxSize()
                // 转换页的音色浮层与合成页共用一个状态：谁打开都让背景虚化
                .backdropBlur(sheetVisible || vm.sheetOpen),
        ) {
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(bottom = scrollInset)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = BreezeSize.gutter),
            ) {
                // ---- 页头 ----
                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 15.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        tr("语音合成"),
                        style = androidx.compose.material3.MaterialTheme.typography.headlineMedium,
                        color = c.t1,
                        modifier = Modifier.weight(1f),
                    )
                    Box(
                        Modifier
                            .size(31.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(c.fill)
                            .border(1.dp, c.line, RoundedCornerShape(9.dp))
                            .clickable(onClick = onOpenSettings),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            Icons.Outlined.Settings,
                            contentDescription = tr("设置"),
                            tint = c.t2,
                            modifier = Modifier.size(15.dp),
                        )
                    }
                }

                // ---- 模式 ----
                WordTabs(
                    labels = listOf(tr("单人朗读"), tr("多角色对话"), tr("音色转换")),
                    selectedIndex = when (mode) {
                        SynthMode.SINGLE -> 0
                        SynthMode.DIALOGUE -> 1
                        SynthMode.CONVERT -> 2
                    },
                    onSelect = { vm.synthMode = SynthMode.entries[it] },
                )
                Spacer(Modifier.height(15.dp))

                Column(
                    Modifier.graphicsLayer {
                        alpha = contentAlpha.value
                        translationY = (1f - contentAlpha.value) * 9.dp.toPx()
                    },
                ) {
                    if (!ready) {
                        ModelNotice(vm, onOpenModels)
                        Spacer(Modifier.height(13.dp))
                    }

                    if (convert) {
                        ConvertPanel(
                            vm = vm,
                            onOpenVoices = onOpenVoices,
                            onPickVoice = { showConvertVoicePicker = true },
                        )
                    } else {
                        // ---- 输入 ----
                        EditorCard(vm, dialogue, scriptLines.size, speakers.size)
                        Spacer(Modifier.height(13.dp))

                        // ---- 配置组 ----
                        ConfigGroup(
                            vm = vm,
                            dialogue = dialogue,
                            voice = voice,
                            speakers = speakers,
                            onPickVoice = { showVoicePicker = true },
                            onPickEmotion = { showEmotionPicker = true },
                            onSavePreset = {
                                presetEditor = PresetEditorTarget.Fresh(
                                    name = suggestPresetName(vm.instruction),
                                    text = vm.instruction.trim(),
                                )
                            },
                        )

                        vm.error?.let {
                            Spacer(Modifier.height(12.dp))
                            Text(
                                it,
                                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                color = androidx.compose.material3.MaterialTheme.colorScheme.error,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(androidx.compose.material3.MaterialTheme.colorScheme.error.copy(alpha = 0.08f))
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                            )
                        }

                        Spacer(Modifier.height(14.dp))

                        // ---- 结果 / 进度 ----
                        if (vm.generating) {
                            GeneratingCard(vm)
                        } else if (vm.lastWav?.exists() == true) {
                            ResultCard(vm, dialogue)
                        }

                        // ---- 统计（默认收起） ----
                        if (!vm.generating && vm.stats != null) {
                            Spacer(Modifier.height(10.dp))
                            TechDetails(vm, dialogue)
                        }
                    }

                    Spacer(Modifier.height(18.dp))
                    Text(
                        tr("权重遵循 BreezeBlue 研究与非商用许可；请勿用于未授权的音色克隆、冒充或欺诈。"),
                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                        color = c.t3,
                        lineHeight = 17.sp,
                    )
                    Spacer(Modifier.height(16.dp))
                }
            }

            // ---- 吸底主操作 ----
            // 量两件事：按钮区高度，以及按钮底边到窗口底边的距离（见上面的 scrollInset）
            Box(
                Modifier.onGloballyPositioned { coords ->
                    barPx = coords.size.height
                    val bottom = coords.positionInWindow().y + coords.size.height
                    decor?.let { bottomGapPx = (it.height - bottom).toInt().coerceAtLeast(0) }
                },
            ) {
                BottomActions(
                    // 转换与合成共用引擎：不管当前在哪个子界面，只要有任务在跑就显示停止，
                    // 否则用户在转换途中切回朗读页会看到一个可以点的「生成」。
                    generating = vm.converting || vm.generating,
                    dialogue = dialogue,
                    convert = convert || vm.converting,
                    canGenerate = !vm.converting && if (convert) {
                        ready && vm.convertSrcWav != null && vm.convertTargetVoice() != null
                    } else {
                        ready && vm.text.isNotBlank()
                    },
                    onGenerate = {
                        // 生成期间页面上不能有任何周期性重绘：输入框的光标每 500 ms 闪一次，
                        // 就足够让合成页停在 60/120 Hz，1 Hz 的静止卡片等于白做。键盘同理。
                        focus.clearFocus()
                        keyboard?.hide()
                        if (convert) vm.startConvert() else vm.synthesize()
                    },
                    onStop = { if (vm.converting) vm.stopConvert() else vm.stop() },
                )
            }
        }

        ExpandDialog(vm)

        VoicePickerSheet(
            visible = showVoicePicker,
            voices = vm.voices,
            selectedId = vm.selectedVoiceId,
            onSelect = { vm.selectVoice(it); showVoicePicker = false },
            onCreate = { showVoicePicker = false; onOpenVoices() },
            onManage = { showVoicePicker = false; onOpenVoices() },
            onDismiss = { showVoicePicker = false },
        )

        // 音色转换的目标音色：和单人朗读共用同一套浮层组件，
        // 只是数据源换成「可用于转换的音色」。必须挂在页面根部，
        // 不能塞进滚动区（那里高度无界，浮层会被量成 0）。
        VoicePickerSheet(
            visible = showConvertVoicePicker,
            voices = vm.convertTargets,
            selectedId = vm.convertTargetVoice()?.id,
            onSelect = { picked ->
                if (picked != null) vm.selectConvertTarget(picked)
                showConvertVoicePicker = false
            },
            onCreate = { showConvertVoicePicker = false; onOpenVoices() },
            onManage = { showConvertVoicePicker = false; onOpenVoices() },
            onDismiss = { showConvertVoicePicker = false },
        )

        EmotionPickerSheet(
            visible = showEmotionPicker,
            presets = vm.emotionPresets,
            current = vm.instruction,
            customized = vm.presetsCustomized(),
            onConfirm = { vm.instruction = it },
            onNew = {
                showEmotionPicker = false
                presetEditor = PresetEditorTarget.Fresh(
                    name = suggestPresetName(vm.instruction),
                    text = vm.instruction,
                )
            },
            onEdit = { showEmotionPicker = false; presetEditor = PresetEditorTarget.Existing(it) },
            onDelete = { presetDeleting = it },
            onReset = { vm.resetInstructionPresets() },
            onDismiss = { showEmotionPicker = false },
        )

        presetEditor?.let { target ->
            PresetEditorDialog(
                title = if (target is PresetEditorTarget.Fresh) tr("新建表达预设") else tr("编辑预设"),
                initialName = target.name,
                initialText = target.text,
                onDismiss = { presetEditor = null },
                onConfirm = { name, text ->
                    when (target) {
                        is PresetEditorTarget.Fresh -> vm.saveInstructionPreset(name, text)
                        is PresetEditorTarget.Existing ->
                            vm.updateInstructionPreset(target.preset.id, name, text)
                    }
                    presetEditor = null
                },
            )
        }

        presetDeleting?.let { preset ->
            ConfirmDeletePresetDialog(
                name = preset.name,
                onDismiss = { presetDeleting = null },
                onConfirm = {
                    vm.deleteInstructionPreset(preset.id)
                    presetDeleting = null
                },
            )
        }
    }
}

// ============================================================
// 输入区
// ============================================================

@Composable
private fun EditorCard(vm: AppViewModel, dialogue: Boolean, lines: Int, roles: Int) {
    val c = Breeze.colors
    // 选区只属于这一屏的编辑状态：ViewModel 里仍然只存纯文本，
    // 但快捷插入需要知道光标在哪，所以这里维护一份带 selection 的值。
    var field by remember(dialogue) {
        mutableStateOf(TextFieldValue(vm.text, TextRange(vm.text.length)))
    }
    // 外部改动（应用扩写结果、切换模式）时把光标收到末尾
    LaunchedEffect(vm.text, dialogue) {
        if (field.text != vm.text) field = TextFieldValue(vm.text, TextRange(vm.text.length))
    }
    var editorFocused by remember { mutableStateOf(false) }
    val editorFocus = remember { FocusRequester() }
    val hostActivity = LocalContext.current as? android.app.Activity
    val hostView = LocalView.current

    // 长按拖选：拖动期间 selection 每帧都在变，这个 effect 会被反复取消重启，
    // 只有停手 250ms 之后才真正走到下面——也就是「松手」那一刻。
    // 长按选择时焦点在系统的选择手柄上，键盘是收起的，想直接改字就得再点一次；
    // 这里主动把 IME 叫出来。
    LaunchedEffect(field.selection) {
        if (field.selection.collapsed) return@LaunchedEffect
        delay(250)
        if (!editorFocused) runCatching { editorFocus.requestFocus() }
        showIme(hostActivity, hostView)
    }

    fun commit(next: TextFieldValue) {
        field = next
        vm.text = next.text
    }

    /** 在光标处插入；没有光标（未聚焦）时退回追加到末尾 */
    fun insertAtCursor(token: String) {
        val cur = field
        val len = cur.text.length
        val a = cur.selection.start.coerceIn(0, len)
        val b = cur.selection.end.coerceIn(0, len)
        val from = minOf(a, b)
        val to = maxOf(a, b)
        val next = cur.text.replaceRange(from, to, token)
        commit(TextFieldValue(next, TextRange(from + token.length)))
    }

    Column(
        Modifier
            .fillMaxWidth()
            .height(if (dialogue) 218.dp else BreezeSize.editor)
            .clip(RoundedCornerShape(13.dp))
            .background(c.surface)
            // 浅色下白色面和米白底只差一点点，必须有一条 1px 才看得出边界
            .border(1.dp, c.line, RoundedCornerShape(13.dp))
            .padding(start = 14.dp, end = 14.dp, top = 13.dp, bottom = 11.dp),
    ) {
        BasicTextField(
            value = field,
            onValueChange = { commit(it) },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .focusRequester(editorFocus)
                .onFocusChanged { editorFocused = it.isFocused },
            textStyle = TextStyle(
                fontSize = 14.5.sp,
                lineHeight = 26.sp,
                color = c.t1,
                letterSpacing = 0.05.sp,
            ),
            cursorBrush = SolidColor(c.accent),
            decorationBox = { inner ->
                Box {
                    if (field.text.isEmpty()) {
                        Text(
                            if (dialogue) tr("【小明】(开心):今天天气真好啊。\n【小红】(温柔):是啊，出去走走吧。")
                            else tr("输入要朗读的内容，或写下想让 AI 扩写的需求…"),
                            fontSize = 14.5.sp,
                            lineHeight = 26.sp,
                            color = c.t3,
                        )
                    }
                    inner()
                }
            },
        )

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                Modifier
                    .height(26.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(c.accentSoft)
                    .clickable { vm.openExpand() }
                    .padding(horizontal = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Outlined.Create,
                    contentDescription = null,
                    tint = c.accent,
                    modifier = Modifier.size(11.dp),
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    tr("AI 扩写"),
                    fontSize = 11.5.sp,
                    color = c.accent,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                )
            }

            Spacer(Modifier.width(7.dp))
            Box(Modifier.width(1.dp).height(13.dp).background(c.line2))
            Spacer(Modifier.width(7.dp))

            if (dialogue) {
                Text(
                    if (lines > 0) tr("每行一句 · 已识别 $lines 句 / $roles 个角色", "One line per utterance · recognised $lines lines / $roles characters")
                    else tr("每行一句 · 【角色】(情绪):台词"),
                    fontSize = 11.sp,
                    color = c.t3,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(tr("笑") to tr("[笑]"), tr("叹气") to tr("[叹气]"), tr("咳嗽") to tr("[咳嗽]"), tr("停顿") to "，").forEach { (label, insert) ->
                        Box(
                            Modifier
                                .height(24.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .border(1.dp, c.line, RoundedCornerShape(6.dp))
                                .clickable { insertAtCursor(insert) }
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(label, fontSize = 11.sp, color = c.t3, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

// ============================================================
// 配置组
// ============================================================

@Composable
private fun ConfigGroup(
    vm: AppViewModel,
    dialogue: Boolean,
    voice: VoiceProfile?,
    speakers: List<String>,
    onPickVoice: () -> Unit,
    onPickEmotion: () -> Unit,
    onSavePreset: () -> Unit,
) {
    val c = Breeze.colors
    var paramsOpen by remember { mutableStateOf(false) }
    val presetName = vm.emotionPresets.firstOrNull { it.text == vm.instruction }?.name

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(c.surface)
            .border(1.dp, c.line, RoundedCornerShape(13.dp)),
    ) {
        if (dialogue) {
            // 角色行：头像组 + 数量，点开音色页
            SettingRow(
                label = tr("角色"),
                value = if (speakers.isEmpty()) tr("未识别角色") else tr("${speakers.size} 个角色", "${speakers.size} characters"),
                hint = if (speakers.isEmpty()) tr("在剧本里用【名字】开头写一句")
                else {
                    val missing = speakers.count { !vm.hasVoiceNamed(it) }
                    if (missing == 0) tr("音色已分配 · 按剧本逐句切换") else tr("$missing 个名字没有同名音色", "$missing names have no matching voice")
                },
                onClick = onPickVoice,
                trailing = {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        speakers.take(3).forEach { name ->
                            val v = vm.voiceForName(name)
                            val ok = vm.hasVoiceNamed(name)
                            VoiceAvatar(
                                name = name,
                                gender = if (ok) (v?.gender ?: VoiceProfile.Gender.NONE) else VoiceProfile.Gender.NONE,
                                avatarPath = v?.avatarPath,
                                size = 24.dp,
                                showBadge = false,
                            )
                        }
                    }
                },
            )
            HairlineDivider()
        } else {
            SettingRow(
                label = tr("音色"),
                value = voice?.name ?: tr("默认音色"),
                hint = when {
                    voice == null -> tr("模型内置女声")
                    voice.kind == VoiceProfile.Kind.CLONE -> tr("克隆 · 音质锁定在参考音频")
                    voice.locked -> tr("设计 · 已锁定")
                    else -> tr("设计 · 每次随机")
                },
                onClick = onPickVoice,
            )
            HairlineDivider()
        }

        EmotionField(
            label = if (dialogue) tr("情绪") else tr("表达"),
            value = vm.instruction,
            dialogue = dialogue,
            presetName = presetName,
            onChange = { vm.instruction = it },
            onOpenPresets = onPickEmotion,
            onSavePreset = onSavePreset,
            onAiWrite = if (dialogue) null else ({ vm.openEmotionExpand() }),
        )
        HairlineDivider()

        // 参数行：单行紧凑行，点开在原位展开，不再是一张独立的折叠卡
        Row(
            Modifier
                .fillMaxWidth()
                .height(50.dp)
                .clickable { paramsOpen = !paramsOpen }
                .padding(horizontal = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.width(38.dp).height(17.dp), contentAlignment = Alignment.TopStart) {
                Text(tr("参数"), fontSize = 11.5.sp, lineHeight = 17.sp, color = c.t3)
            }
            Text(
                if (dialogue) tr("温度 %.2f · 种子按句递增").format(vm.temperature)
                else tr("温度 %.2f · Top-P %.2f · 种子 %d").format(vm.temperature, vm.topP, vm.seed),
                fontSize = 13.sp,
                color = c.t2,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Icon(
                if (paramsOpen) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                contentDescription = null,
                tint = c.t3,
                modifier = Modifier.size(15.dp),
            )
        }

        AnimatedVisibility(visible = paramsOpen) {
            Column(Modifier.padding(horizontal = 13.dp).padding(bottom = 6.dp)) {
                HairlineDivider()
                Spacer(Modifier.height(10.dp))
                CompactSlider(tr("温度"), vm.temperature, 0.1f..1.3f, "%.2f".format(vm.temperature)) {
                    vm.temperature = it
                }
                CompactSlider("Top-P", vm.topP, 0.5f..1f, "%.2f".format(vm.topP)) { vm.topP = it }
                CompactSlider(tr("随机种子"), vm.seed.toFloat(), 0f..9999f, "${vm.seed}") {
                    vm.seed = it.toInt()
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    tr("温度越低越稳，越高越有表现力。CFG %.1f 在「模型」页调整。").format(vm.cfgScale),
                    fontSize = 11.sp,
                    color = c.t3,
                    lineHeight = 16.sp,
                )
                if (dialogue) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        tr("多角色模式下种子按句递增（${vm.seed}、${vm.seed + 1}…），避免每句同一起点。", "In dialogue mode the seed increments per line (${vm.seed}, ${vm.seed + 1}…), so every line doesn't start from the same point."),
                        fontSize = 11.sp,
                        color = c.t3,
                        lineHeight = 16.sp,
                    )
                }
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}

/** 行首标签列宽：音色 / 角色 / 表达 / 参数共用同一列，右侧内容才能严格对齐 */
private val RowLabelWidth = 38.dp
/** 右侧「标题 + 说明」两块的行高之和：17 + 3 + 15 */
private val RowBodyHeight = 35.dp

/**
 * 配置组里的一行：左标签 + 主值 + 说明 + 箭头。
 *
 * 之前「音色名贴着上边框、多角色模式对不齐」的根因是**说明文字没有指定行高**，
 * 它继承了 Material 的 24sp 默认行高，把整个文字块撑到 45dp，在 54dp 的行里
 * 只剩 4dp 余量；同时左侧标签按整行居中，与首行的基线差了近 14dp。
 *
 * 现在两条硬规则：文字块高度写死 35dp（17 + 3 + 15），标签放在同高的盒子顶部，
 * 于是标签与主值首行永远同一条基线，行高由内容决定而不是被撑开。
 */
@Composable
private fun SettingRow(
    label: String,
    value: String,
    hint: String,
    onClick: () -> Unit,
    trailing: (@Composable () -> Unit)? = null,
) {
    val c = Breeze.colors
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(RowLabelWidth).height(RowBodyHeight), contentAlignment = Alignment.TopStart) {
            Text(label, fontSize = 11.5.sp, lineHeight = 17.sp, color = c.t3, maxLines = 1)
        }
        if (trailing != null) {
            trailing()
            Spacer(Modifier.width(11.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                value,
                fontSize = 14.5.sp,
                fontWeight = FontWeight.Medium,
                color = c.t1,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 17.sp,
            )
            Spacer(Modifier.height(3.dp))
            Text(
                hint,
                fontSize = 11.sp,
                lineHeight = 15.sp,
                color = c.t3,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(8.dp))
        Icon(
            Icons.Outlined.KeyboardArrowRight,
            contentDescription = null,
            tint = c.t3,
            modifier = Modifier.padding(top = 2.dp).size(14.dp),
        )
    }
}

/**
 * 表达 / 情绪：一块可以直接写字的输入框，动作条压在它上方。
 *
 * 为什么不再是「点开浮层、选一条」：临时想试一种语气时，用户不想为了几个字
 * 先建一个预设再选中。现在的分工是——
 *   · 想直接用：在这里打字，回车即生效；
 *   · 想反复用：打完点「存为预设」；
 *   · 想从已有的挑：点「表达预设」，选中后确认，内容回填到这个输入框。
 *
 * 版式（1.9.18）：标签行在上、输入框独占一整行。
 * 旧版把输入框塞在 38dp 标签列的右边，可用宽度少了 38dp、高度只有 38dp，
 * 一句「温柔一点，语速稍慢，句尾带笑意」就要横着挤。现在输入框从卡片左内边距
 * 起算（与「表达」这个标签左对齐，而不是与右侧的预设名对齐），
 * 最小高度两行，长句最多三行后内部滚动。
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EmotionField(
    label: String,
    value: String,
    dialogue: Boolean,
    presetName: String?,
    onChange: (String) -> Unit,
    onOpenPresets: () -> Unit,
    onSavePreset: () -> Unit,
    /** 单人模式才有：让 AI 读台词写一段语气描述 */
    onAiWrite: (() -> Unit)? = null,
) {
    val c = Breeze.colors
    val bringIntoView = remember { BringIntoViewRequester() }
    var focused by remember { mutableStateOf(false) }
    // 这个框原来只收 String，拿不到选区；要判断「长按拖选结束」必须自己持有 TextFieldValue。
    var field by remember { mutableStateOf(TextFieldValue(value, TextRange(value.length))) }
    LaunchedEffect(value) {
        if (field.text != value) field = TextFieldValue(value, TextRange(value.length))
    }
    val focusRequester = remember { FocusRequester() }
    val hostActivity = LocalContext.current as? android.app.Activity
    val hostView = LocalView.current

    // 同正文框：selection 连续变化会不断取消这个 effect，停手 250ms 才算选完。
    // 这一行在页面下半部，键盘弹起来还要把它滚到键盘上方（本页 ADJUST_NOTHING，窗口不会自己让）。
    LaunchedEffect(field.selection) {
        if (field.selection.collapsed) return@LaunchedEffect
        delay(250)
        if (!focused) runCatching { focusRequester.requestFocus() }
        showIme(hostActivity, hostView)
        repeat(8) {
            delay(70)
            runCatching { bringIntoView.bringIntoView() }
        }
    }
    val status = when {
        presetName != null -> tr("预设 · $presetName", "Preset · $presetName")
        value.isBlank() -> if (dialogue) tr("台词没写括号情绪时使用") else tr("未设置，用默认语气")
        else -> tr("自定义 · 未存为预设")
    }

    // 本工程用 windowSoftInputMode=adjustResize 且未开 edge-to-edge，键盘弹起时
    // IME insets 在 DecorView 层就被消费掉，Compose 的 WindowInsets.ime 恒为 0，
    // 所以不能靠 insets 触发滚动。改为「获焦后在键盘动画期间持续重试滚入可视区」：
    // 单次调用会赶在键盘完全升起前算错视口，多次重试直到布局稳定即可停在键盘上方。
    LaunchedEffect(focused) {
        if (!focused) return@LaunchedEffect
        repeat(18) {
            delay(70)
            runCatching { bringIntoView.bringIntoView() }
        }
    }
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 13.dp, end = 13.dp, top = 9.dp, bottom = 9.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(RowLabelWidth)) {
                Text(label, fontSize = 11.5.sp, lineHeight = 17.sp, color = c.t3, maxLines = 1)
            }
            Text(
                status,
                fontSize = 10.5.sp,
                lineHeight = 14.sp,
                color = c.t3,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(6.dp))
            if (onAiWrite != null) {
                TextAction(tr("AI 代写"), emphasis = true, onClick = onAiWrite)
                Spacer(Modifier.width(3.dp))
            }
            TextAction(tr("存为预设"), enabled = value.isNotBlank(), onClick = onSavePreset)
            Spacer(Modifier.width(3.dp))
            TextAction(tr("表达预设"), emphasis = true, onClick = onOpenPresets)
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .heightIn(min = EmotionFieldHeight)
                .clip(RoundedCornerShape(9.dp))
                .background(c.fill)
                .padding(horizontal = 11.dp, vertical = 7.dp)
                .bringIntoViewRequester(bringIntoView),
            contentAlignment = Alignment.TopStart,
        ) {
            if (value.isEmpty()) {
                Text(
                    if (dialogue) tr("如：温柔一点") else tr("如：温柔一点，语速稍慢，句尾带一点笑意"),
                    fontSize = 12.5.sp,
                    lineHeight = 19.sp,
                    color = c.t3,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            BasicTextField(
                value = field,
                onValueChange = { field = it; onChange(it.text) },
                textStyle = TextStyle(fontSize = 13.sp, lineHeight = 19.sp, color = c.t1),
                cursorBrush = SolidColor(c.accent),
                maxLines = 3,
                // 输入框自身铺满两行高度：点第一行或第二行空白都能聚焦弹键盘。
                // 获焦即标记 focused，真正的滚动交给上方 IME 高度监听逐帧完成；
                // 这里额外触发一次，兼容「键盘已在显示时切换焦点」的场景。
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = EmotionFieldHeight - 14.dp)
                    .focusRequester(focusRequester)
                    .onFocusChanged { st -> focused = st.isFocused },
            )
        }
    }
}

/** 表达输入框的最小高度：两行正文（19 × 2）加 7dp 上下内边距 */
private val EmotionFieldHeight = 52.dp

/** 行内文字动作：无底色，靠颜色区分主次；热区靠 padding 撑到 22dp */
@Composable
private fun TextAction(
    text: String,
    enabled: Boolean = true,
    emphasis: Boolean = false,
    onClick: () -> Unit,
) {
    val c = Breeze.colors
    Text(
        text,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        fontWeight = FontWeight.Medium,
        color = when {
            !enabled -> c.t3.copy(alpha = 0.45f)
            emphasis -> c.accent
            else -> c.t2
        },
        maxLines = 1,
        softWrap = false,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 4.dp),
    )
}

@Composable
private fun CompactSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    text: String,
    onChange: (Float) -> Unit,
) {
    val c = Breeze.colors
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontSize = 12.5.sp, color = c.t2, modifier = Modifier.weight(1f))
            Text(text, fontSize = 12.sp, color = c.t1, fontWeight = FontWeight.Medium)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            modifier = Modifier.height(32.dp),
            colors = SliderDefaults.colors(
                thumbColor = c.accent,
                activeTrackColor = c.accent,
                inactiveTrackColor = c.line2,
            ),
        )
    }
}

// ============================================================
// 结果
// ============================================================

@Composable
private fun GeneratingCard(vm: AppViewModel) {
    val c = Breeze.colors
    // 这张卡片是整页唯一还在变的东西，而它每秒只变一次（「已用 N 秒」）。
    // 没有旋转环、没有进度条、没有百分比：不确定进度指示器会让 Compose 每个 vsync
    // 重建一次 draw，屏幕被钉在 120 Hz，直接把核从 6 线程主干 + 8 线程声码器手里抢走。
    // 实测同一句：120 Hz 动画 3.90，切走静止 2.78（docs/84）。
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(c.surface)
            .border(1.dp, c.line, RoundedCornerShape(13.dp)),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // 静态圆点：不注册任何动画，画面不动它就一直不动
            Box(
                Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(c.accent),
            )
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    vm.statusLine.ifBlank { tr("正在生成，请稍等…") },
                    fontSize = 13.sp,
                    color = c.t1,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    tr("已用 %d 秒 · 本地离线推理").format(vm.genElapsedSec),
                    fontSize = 11.sp,
                    color = c.t3,
                    maxLines = 1,
                )
            }
        }
        Spacer(Modifier.height(13.dp))
    }
}

@Composable
private fun ResultCard(vm: AppViewModel, dialogue: Boolean) {
    val c = Breeze.colors
    val playing = vm.playback.playing && vm.playback.path == vm.lastWav?.absolutePath
    // 和收藏页同一套波形：真实 PCM 峰值，路径缓存，换一段结果自动重算
    val peaks = rememberWaveform(vm.lastWav?.absolutePath ?: "", 64)
    val (title, meta) = remember(vm.stats, vm.resultName, playing) {
        val st = vm.stats
        // 名字在生成那一刻锁定；此后改输入框不会跟着变
        val head = vm.resultName.ifBlank { tr("最近一次生成") }
        val m = buildString {
            if (st != null) {
                append("%d:%02d".format((st.audioMs / 60000).toInt(), ((st.audioMs / 1000) % 60).toInt()))
                append(" · RTF %.2f".format(st.rtf))
            } else {
                append(tr("已生成"))
            }
            if (playing) append(tr(" · 播放中"))
        }
        head to m
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(c.surface)
            .border(1.dp, c.line, RoundedCornerShape(13.dp)),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(c.btnBg)
                    .clickable {
                        if (playing) vm.togglePlayback() else vm.playLast()
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (playing) {
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        Box(Modifier.width(2.5.dp).height(11.dp).clip(RoundedCornerShape(1.dp)).background(c.btnInk))
                        Box(Modifier.width(2.5.dp).height(11.dp).clip(RoundedCornerShape(1.dp)).background(c.btnInk))
                    }
                } else {
                    Icon(
                        Icons.Outlined.PlayArrow,
                        contentDescription = tr("播放"),
                        tint = c.btnInk,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    fontSize = 13.sp,
                    color = c.t1,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(3.dp))
                Text(meta, fontSize = 11.sp, color = c.t3, maxLines = 1)
            }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .clickable { vm.replayCurrent() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Outlined.Refresh,
                    contentDescription = tr("重播"),
                    tint = c.t3,
                    modifier = Modifier.size(15.dp),
                )
            }
        }

        // 波形进度：既是进度条也是拖动区，样式与收藏页一致
        Spacer(Modifier.height(2.dp))
        WaveSeekBar(
            peaks = peaks,
            fraction = if (vm.playback.path == vm.lastWav?.absolutePath) vm.playback.fraction else 0f,
            height = 34.dp,
            modifier = Modifier.padding(horizontal = 13.dp),
            onSeek = { vm.seekLast(it) },
        )

        Spacer(Modifier.height(8.dp))

        Box(Modifier.fillMaxWidth().height(1.dp).background(c.line))

        Row(Modifier.fillMaxWidth().height(40.dp)) {
            ResultAction(tr("导出"), Icons.Outlined.Share) { vm.exportLast() }
            Box(Modifier.width(1.dp).fillMaxHeight().background(c.line))
            val canFav = vm.stats != null && !vm.lastResultFavorited && !vm.favoriteBusy
            ResultAction(
                when {
                    vm.lastResultFavorited -> tr("已收藏")
                    vm.favoriteBusy -> tr("收藏中…")
                    else -> tr("收藏")
                },
                Icons.Outlined.Star,
                enabled = canFav,
                tint = if (vm.lastResultFavorited) c.accent else null,
            ) { vm.favoriteLast() }
            Box(Modifier.width(1.dp).fillMaxHeight().background(c.line))
            ResultAction(tr("重生成"), Icons.Outlined.Refresh) { vm.synthesize() }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.ResultAction(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean = true,
    tint: androidx.compose.ui.graphics.Color? = null,
    onClick: () -> Unit,
) {
    val c = Breeze.colors
    val color = tint ?: c.t2
    Row(
        Modifier
            .weight(1f)
            .fillMaxHeight()
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, fontSize = 11.5.sp, color = color, maxLines = 1, softWrap = false)
    }
}

/** 2dp 进度线；传入 onSeek 时可点可拖（拖动时按落点在整条线里的比例换算） */
@Composable
private fun ProgressLine(
    progress: Float,
    modifier: Modifier = Modifier,
    onSeek: ((Float) -> Unit)? = null,
) {
    val c = Breeze.colors
    Box(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 13.dp)
            .height(2.dp)
            .clip(RoundedCornerShape(1.dp))
            .background(c.fill2)
            .then(
                if (onSeek == null) Modifier
                else Modifier
                    .pointerInput(Unit) {
                        detectTapGestures { o ->
                            onSeek((o.x / size.width.toFloat()).coerceIn(0f, 1f))
                        }
                    }
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures { change, _ ->
                            onSeek((change.position.x / size.width.toFloat()).coerceIn(0f, 1f))
                        }
                    },
            ),
    ) {
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(c.accent),
        )
    }
}

@Composable
private fun TechDetails(vm: AppViewModel, dialogue: Boolean) {
    val c = Breeze.colors
    var open by remember { mutableStateOf(false) }
    val st = vm.stats ?: return
    val t = vm.stageStats

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(c.surface)
            .border(1.dp, c.line, RoundedCornerShape(13.dp)),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(BreezeSize.rowSlim)
                .clickable { open = !open }
                .padding(horizontal = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(tr("技术细节"), fontSize = 11.5.sp, color = c.t3, modifier = Modifier.width(52.dp))
            Text(
                tr("音频 %.1f 秒 · 耗时 %.1f 秒 · %d 帧").format(
                    st.audioMs / 1000.0, st.elapsedMs / 1000.0, st.frames,
                ),
                fontSize = 13.sp,
                color = c.t2,
                modifier = Modifier.weight(1f),
                maxLines = 1,
            )
            Icon(
                if (open) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                contentDescription = null,
                tint = c.t3,
                modifier = Modifier.size(15.dp),
            )
        }
        AnimatedVisibility(visible = open) {
            Column(Modifier.padding(horizontal = 13.dp).padding(bottom = 12.dp)) {
                HairlineDivider()
                Spacer(Modifier.height(8.dp))
                if (t != null) {
                    Text(
                        if (dialogue) tr("分阶段耗时（全部句子的合计）") else tr("分阶段耗时"),
                        fontSize = 11.sp,
                        color = c.t3,
                    )
                    Spacer(Modifier.height(4.dp))
                    KeyValueLine(tr("文本编码 + 预填充"), "%d ms".format((t.promptMs + t.prefillMs).toInt()))
                    if (t.prefillReused > 0) {
                        KeyValueLine(tr("　参考前缀复用"), "${t.prefillReused}/${t.prefillTokens} tokens")
                    }
                    KeyValueLine(tr("主干（逐帧 · CFG 双分支）"), "%d ms".format(t.backboneMs.toInt()))
                    KeyValueLine(tr("深度解码（15 码本）"), "%d ms".format(t.depthMs.toInt()))
                    KeyValueLine(tr("声码器（${t.flushes} 次）", "Vocoder (${t.flushes} flushes)"), "%d ms".format(t.vocoderMs.toInt()))
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    if (st.rtf <= 1f) tr("RTF ≤ 1：生成快于播放，可边生成边连续播放。")
                    else tr("RTF > 1：生成慢于实时，已自动加大预缓冲，把停顿集中到开头。"),
                    fontSize = 11.sp,
                    color = c.t3,
                    lineHeight = 16.sp,
                )
            }
        }
    }
}

@Composable
private fun KeyValueLine(key: String, value: String) {
    val c = Breeze.colors
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(key, fontSize = 12.sp, color = c.t3, modifier = Modifier.weight(1f))
        Text(value, fontSize = 12.sp, color = c.t2)
    }
}

// ============================================================
// 底部操作
// ============================================================

@Composable
private fun BottomActions(
    generating: Boolean,
    dialogue: Boolean,
    convert: Boolean = false,
    canGenerate: Boolean,
    onGenerate: () -> Unit,
    onStop: () -> Unit,
) {
    val c = Breeze.colors
    Column(
        Modifier
            .fillMaxWidth()
            .background(c.bg)
            .padding(horizontal = BreezeSize.gutter)
            .padding(top = 10.dp, bottom = 12.dp),
    ) {
        if (generating) {
            BreezeButton(
                text = if (convert) tr("停止转换") else tr("停止生成"),
                onClick = onStop,
                tone = BreezeTone.Warn,
                icon = Icons.Outlined.Close,
                height = BreezeSize.button,
                modifier = Modifier.fillMaxWidth(),
            )
        } else {
            BreezePrimaryButton(
                text = when {
                    convert && canGenerate -> tr("开始转换")
                    convert -> tr("先选音频和目标音色")
                    !canGenerate -> tr("输入文本后生成")
                    dialogue -> tr("合成对话")
                    else -> tr("生成语音")
                },
                onClick = onGenerate,
                enabled = canGenerate,
                icon = Icons.Outlined.PlayArrow,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

// ============================================================
// 模型状态提示
// ============================================================

@Composable
private fun ModelNotice(vm: AppViewModel, onOpenModels: () -> Unit) {
    val c = Breeze.colors
    val title = when {
        vm.modelState is ModelState.Downloading -> tr("正在下载模型")
        vm.modelState is ModelState.Ready && vm.engineState is EngineState.Loading -> tr("正在加载引擎")
        vm.engineState is EngineState.Failed -> tr("引擎加载失败")
        else -> tr("还没有可用模型")
    }
    val detail = when (val s = vm.modelState) {
        is ModelState.Downloading ->
            "${s.file} · ${formatBytesLocal(s.doneBytes)} / ${formatBytesLocal(s.totalBytes)}"
        is ModelState.Ready -> when (vm.engineState) {
            is EngineState.Failed -> (vm.engineState as EngineState.Failed).message
            else -> tr("GGUF ${formatBytesLocal(s.totalBytes)}，加载需要几秒", "GGUF ${formatBytesLocal(s.totalBytes)} — loading takes a few seconds")
        }
        is ModelState.Failed -> s.message
        else -> tr("去「设置」页下载或导入 GGUF 量化模型")
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(c.surface)
            .border(1.dp, c.line, RoundedCornerShape(13.dp))
            .padding(13.dp),
    ) {
        Text(title, fontSize = 13.5.sp, fontWeight = FontWeight.Medium, color = c.t1)
        Spacer(Modifier.height(4.dp))
        Text(detail, fontSize = 11.5.sp, color = c.t3, lineHeight = 17.sp)
        Spacer(Modifier.height(10.dp))
        BreezeButton(
            text = tr("打开模型页"),
            onClick = onOpenModels,
            tone = BreezeTone.Soft,
            height = BreezeSize.buttonTiny,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

internal fun formatBytesLocal(b: Long): String = when {
    b >= 1_000_000_000 -> "%.2f GB".format(b / 1e9)
    b >= 1_000_000 -> "%.1f MB".format(b / 1e6)
    else -> "${b / 1000} KB"
}

/** 编辑框的两种来源：新建（内容取当前输入）或改已有预设。 */
private sealed interface PresetEditorTarget {
    val name: String
    val text: String

    data class Fresh(override val name: String, override val text: String) : PresetEditorTarget
    data class Existing(val preset: EmotionPreset) : PresetEditorTarget {
        override val name: String get() = preset.name
        override val text: String get() = preset.text
    }
}
