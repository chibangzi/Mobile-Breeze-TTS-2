package ai.breeze.tts.i18n

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * 界面语言（1.10.0 起全量双语）。
 *
 * 用法：界面上写 `Text(tr("合成"))`，中文原文仍是唯一事实来源，
 * 英文放在 [EN] 这张表里，键就是中文原文。
 *
 * 为什么不用 `tr("中文", "English")` 内联：
 * 1,000 多条文案里有大量 `${...}` 模板与 `%s / %.1f` 占位符，
 * 两处各写一遍最容易出现「中文里有 $model、英文里漏了」这类
 * 只有跑到那一句才崩的错误；放在一张表里可以脚本校验占位符是否一致。
 *
 * 表里查不到时回退中文——漏译只会让英文界面里出现一句中文，
 * 不会崩，也不会空白。
 */
object Lang {

    const val MODE_SYSTEM = "system"
    const val MODE_ZH = "zh"
    const val MODE_EN = "en"

    /** true = 英文界面 */
    var english by mutableStateOf(false)
        private set

    var mode: String = MODE_SYSTEM
        private set

    fun init(ctx: Context, savedMode: String?) {
        mode = normalize(savedMode)
        english = resolve(ctx, mode)
    }

    fun setMode(ctx: Context, newMode: String) {
        mode = normalize(newMode)
        english = resolve(ctx, mode)
    }

    /** 系统语言变了（仅「跟随系统」时生效）。 */
    fun onSystemLocale(ctx: Context) {
        if (mode == MODE_SYSTEM) english = resolve(ctx, mode)
    }

    fun normalize(m: String?): String = when (m) {
        MODE_ZH, MODE_EN, MODE_SYSTEM -> m
        else -> MODE_SYSTEM
    }

    private fun resolve(ctx: Context, mode: String): Boolean = when (mode) {
        MODE_EN -> true
        MODE_ZH -> false
        else -> isEnglishLocale(ctx)
    }

    fun isEnglishLocale(ctx: Context): Boolean {
        val loc = ctx.resources.configuration.locales.get(0)
        return loc.language.equals("en", ignoreCase = true)
    }
}

/** 取当前语言的文案。中文直接返回原文，英文查 [EN]，查不到回退中文。 */
fun tr(zh: String): String = if (Lang.english) EN[zh] ?: zh else zh

/** 少数需要按上下文换说法的地方，显式给英文。 */
fun tr(zh: String, en: String): String = if (Lang.english) en else zh

/**
 * 与「会被存起来」的值做比较时用这两个：语言切换后，旧数据里仍是切换前的
 * 那种写法（中文或英文），直接跟 tr() 比会对不上。
 */
fun eqTr(a: String, zh: String): Boolean = a == zh || EN[zh]?.let { a == it } == true

fun startsWithTr(a: String, zh: String): Boolean =
    a.startsWith(zh) || EN[zh]?.let { a.startsWith(it) } == true

fun containsTr(a: String, zh: String): Boolean =
    a.contains(zh) || EN[zh]?.let { a.contains(it) } == true
