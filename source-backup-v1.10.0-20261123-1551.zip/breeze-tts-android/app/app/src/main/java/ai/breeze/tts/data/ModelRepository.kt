package ai.breeze.tts.data

import ai.breeze.tts.i18n.tr

import android.content.Context
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * 一个 GGUF 量化档位。Breeze-TTS-2.cpp 的 GGUF 是**单文件自带 codec**的完整模型，
 * 不需要清单、不需要额外的码本或声码器文件，导入后可直接推理。
 */
data class ModelVariant(
    val id: String,
    val title: String,
    val subtitle: String,
    val approximateBytes: Long,
    val repo: String,
    /** HF 仓库内的 GGUF 文件名 */
    val fileName: String,
)

object ModelCatalog {
    /** 社区维护的完整 GGUF 量化版（pcloth / HoppouAI 的 Breeze-TTS-2.cpp）。 */
    const val DEFAULT_REPO = "HoppouAI/Breeze-TTS-2.cpp"

    val variants = listOf(
        ModelVariant(
            id = "q4_k",
            title = tr("轻量 · Q4_K"),
            subtitle = tr("推荐。体积最小，适合日常使用；音质略低于更高档位"),
            approximateBytes = 2_400_000_000L,
            repo = DEFAULT_REPO,
            fileName = "breeze-tts-2-q4_k.gguf",
        ),
        ModelVariant(
            id = "q6_k",
            title = tr("均衡 · Q6_K"),
            subtitle = tr("音质与体积折中，适合大多数场景"),
            approximateBytes = 2_900_000_000L,
            repo = DEFAULT_REPO,
            fileName = "breeze-tts-2-q6_k.gguf",
        ),
        ModelVariant(
            id = "q8_0",
            title = tr("高保真 · Q8_0"),
            subtitle = tr("音质最好的一档，体积较大"),
            approximateBytes = 3_300_000_000L,
            repo = DEFAULT_REPO,
            fileName = "breeze-tts-2-q8_0.gguf",
        ),
        ModelVariant(
            id = "f16",
            title = tr("参考 · F16"),
            subtitle = tr("未量化的原版，体积最大、速度最慢，仅作参考"),
            approximateBytes = 5_900_000_000L,
            repo = DEFAULT_REPO,
            fileName = "breeze-tts-2-f16.gguf",
        ),
        // 1.9.72：只压深度解码器（dd = depth decoder）的混合量化。
        //
        // 主干那四档里，占每帧 57% 的深度解码一直保持 F16/F32 —— 所以 Q4_K 与 Q8_0
        // 实测同速（用户 1.9.71 反馈），换档只动了 17% 的主干。这两档才是真正动
        // 到瓶颈的那一刀。上游对长音频的提醒是「量化误差沿帧反馈累积、45 秒后发闷」，
        // 本应用的文本按句切分，单段一般 20~30 秒，正好落在安全区间内。
        ModelVariant(
            id = "q8_0_dd4",
            title = tr("深度 4bit · Q8_0+DD4"),
            subtitle = tr("主干保持高精度，细节层降到 4bit，换取更快速度；长段落的尾音可能变闷"),
            approximateBytes = 3_401_072_320L,
            repo = DEFAULT_REPO,
            fileName = "breeze-tts-2-q8_0-dd4.gguf",
        ),
        ModelVariant(
            id = "q4_k_dd2",
            title = tr("最省 · Q4_K+DD2"),
            subtitle = tr("体积最小、速度最快，音质损失也最明显，建议先试听"),
            approximateBytes = 2_460_266_176L,
            repo = DEFAULT_REPO,
            fileName = "breeze-tts-2-q4_k-dd2.gguf",
        ),
    )

    /**
     * 按 id 找档位。找不到时回退到第一项而不是抛异常：这一项以前是 `first {}`，
     * 一旦装过某个后来被删掉的档位（比如降级安装），启动读配置就会直接崩。
     */
    fun byId(id: String): ModelVariant =
        variants.firstOrNull { it.id == id } ?: variants.first()
}

sealed interface ModelState {
    data object Absent : ModelState
    data class Downloading(
        val variantId: String,
        val file: String,
        val doneBytes: Long,
        val totalBytes: Long,
        val speedBps: Long,
    ) : ModelState {
        val fraction: Float get() = if (totalBytes <= 0) 0f else (doneBytes.toFloat() / totalBytes)
    }

    data class Verifying(val variantId: String, val file: String) : ModelState
    data class Ready(val variantId: String, val dir: String, val totalBytes: Long) : ModelState
    data class Failed(val message: String) : ModelState
}

/**
 * GGUF 模型的下载与本地导入。所有安装方式都把模型落盘为
 * `filesDir/models/<variantId>/model.gguf`，引擎按目录自动发现。
 *
 * - 下载：直接 GET 单个 .gguf（Range 断点续传），镜像失败自动回退官方源；
 * - 导入：从系统文件选择器读入任意 .gguf，校验 GGUF 文件头后原子安装；
 * - 两种路径都先写 `.part` 再改名，失败会清理，不会留下半成品被当成已安装。
 */
class ModelRepository(private val app: Context) {

    private val sp = app.getSharedPreferences("breeze_settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow<ModelState>(ModelState.Absent)
    val state: StateFlow<ModelState> = _state.asStateFlow()

    /** 已安装的全部档位：id → GGUF 字节数。可同时装多个，随时切换。 */
    private val _installed = MutableStateFlow<Map<String, Long>>(emptyMap())
    val installed: StateFlow<Map<String, Long>> = _installed.asStateFlow()

    /** 当前正在使用的档位。 */
    private val _activeId = MutableStateFlow<String?>(sp.getString(KEY_ACTIVE_MODEL, null))
    val activeId: StateFlow<String?> = _activeId.asStateFlow()

    @Volatile
    var mirror: Boolean = true

    /**
     * 取消机制。下载循环每读一块都看一次 [abortToken]；[abort] 同时断开当前
     * 连接，让卡在 `read()` 上的线程立刻抛出来。
     *
     * 1.9.92 之前「取消」只 cancel 了外层协程，而 `InputStream.read` 是不可中断的
     * 阻塞调用，协程取消对它没有任何作用 —— 文件继续长，直到整个包下完。
     * 这是用户反馈「点了取消没用」的根因。
     *
     * 用 token 而不是布尔量：用户取消后立刻重新点下载时，上一轮的清理代码
     * 可能比新一轮的启动更晚执行，布尔量会被"迟到的 finally"清掉，导致新一轮
     * 一开始就自认为已取消。token 只增不减，天生没这个竞态。
     */
    @Volatile
    private var activeToken = 0L

    @Volatile
    private var abortToken = -1L

    private val tokenSeq = java.util.concurrent.atomic.AtomicLong(0)

    @Volatile
    private var liveConn: HttpURLConnection? = null

    /** 请求中止：标记当前这一轮并断连。可从任意线程调用。 */
    fun abort() {
        abortToken = activeToken
        runCatching { liveConn?.disconnect() }
    }

    fun dirOf(v: ModelVariant): File = File(app.filesDir, "models/${v.id}")
    private fun ggufOf(v: ModelVariant): File = File(dirOf(v), MODEL_FILE)

    fun currentVariant(): ModelVariant = activeVariant() ?: ModelCatalog.variants.first()

    fun activeVariant(): ModelVariant? =
        _activeId.value?.let { runCatching { ModelCatalog.byId(it) }.getOrNull() }

    /** 引擎应加载的目录；未安装任何模型时返回 null。 */
    fun activeDir(): String? =
        activeVariant()?.takeIf { isInstalled(it) }?.let { dirOf(it).absolutePath }

    fun isInstalled(v: ModelVariant): Boolean = isInstalled(v.id)

    fun isInstalled(id: String): Boolean =
        runCatching {
            val f = ggufOf(ModelCatalog.byId(id))
            f.isFile && f.length() > MIN_GGUF_BYTES
        }.getOrDefault(false)

    /** 启动 / 增删后扫盘：维护已装列表、校正激活档位，并对外发 Ready。 */
    fun refresh() {
        val map = ModelCatalog.variants.mapNotNull { v ->
            val f = ggufOf(v)
            if (f.isFile && f.length() > MIN_GGUF_BYTES) v.id to f.length() else null
        }.toMap()
        _installed.value = map

        var id = _activeId.value
        if (id == null || !map.containsKey(id)) {
            id = map.keys.firstOrNull()
            _activeId.value = id
            sp.edit().putString(KEY_ACTIVE_MODEL, id).apply()
        }
        _state.value = if (id != null) {
            val v = ModelCatalog.byId(id)
            ModelState.Ready(id, dirOf(v).absolutePath, map[id] ?: 0L)
        } else {
            ModelState.Absent
        }
    }

    /** 切换当前使用的模型；调用方负责先 release 引擎再重新 load。 */
    fun setActive(id: String) {
        if (!isInstalled(id)) return
        _activeId.value = id
        sp.edit().putString(KEY_ACTIVE_MODEL, id).apply()
        refresh()
    }

    /** 下载 / 导入完成后登记，并在首次安装时自动激活。 */
    private fun onInstalled(id: String, bytes: Long) {
        val mutable = _installed.value.toMutableMap()
        mutable[id] = bytes
        _installed.value = mutable
        if (_activeId.value == null) {
            _activeId.value = id
            sp.edit().putString(KEY_ACTIVE_MODEL, id).apply()
        }
        // 对外发的 Ready 必须是「当前激活」的模型，否则 ViewModel 会把刚下载
        // 但用户还没切换的档位误当成引擎应加载的模型。
        val active = _activeId.value
        if (active != null) {
            val v = ModelCatalog.byId(active)
            _state.value = ModelState.Ready(active, dirOf(v).absolutePath, mutable[active] ?: bytes)
        }
    }

    /** 删除某个档位（其他已装档位不受影响）。 */
    fun delete(v: ModelVariant) {
        dirOf(v).deleteRecursively()
        if (_activeId.value == v.id) {
            _activeId.value = null
            sp.edit().remove(KEY_ACTIVE_MODEL).apply()
        }
        refresh()
    }

    /** 下载失败 / 取消后把状态退回到「当前已装的模型」，别把 Downloading 留在那里。 */
    private fun restoreState() {
        val id = _activeId.value
        val v = id?.let { ModelCatalog.byId(it) }
        _state.value = if (id != null && v != null && isInstalled(id)) {
            ModelState.Ready(id, dirOf(v).absolutePath, _installed.value[id] ?: 0L)
        } else {
            ModelState.Absent
        }
    }

    /**
     * 从系统文件选择器直接导入一个 .gguf。不需要 ZIP、不需要清单。
     * 校验文件头必须是 `GGUF`，避免把任意文件当模型装进去。
     */
    suspend fun importGguf(uri: Uri, variant: ModelVariant) = withContext(Dispatchers.IO) {
        val dir = dirOf(variant).apply { mkdirs() }
        val part = File(dir, "$MODEL_FILE.part")
        part.delete()

        var copied = 0L
        app.contentResolver.openInputStream(uri)?.use { ins ->
            FileOutputStream(part).use { fos ->
                val buf = ByteArray(1 shl 20)
                while (true) {
                    val n = ins.read(buf)
                    if (n <= 0) break
                    fos.write(buf, 0, n)
                    copied += n
                }
            }
        } ?: throw IOException(tr("打不开所选文件"))

        try {
            if (copied <= MIN_GGUF_BYTES) {
                throw IOException(tr("文件只有 ${formatBytes(copied)}，不是有效的 GGUF 模型", "The file is only ${formatBytes(copied)} — not a valid GGUF model"))
            }
            checkMagic(part)
        } catch (t: Throwable) {
            part.delete()
            throw t
        }

        val out = ggufOf(variant)
        out.delete()
        if (!part.renameTo(out)) {
            part.delete()
            throw IOException(tr("安装失败（无法重命名文件）"))
        }
        onInstalled(variant.id, out.length())
        Log.i(TAG, "imported GGUF ${out.length()} bytes as ${variant.id}")
    }

    /** 下载并安装；失败抛异常，由 Service 转成 Failed 状态。 */
    suspend fun download(
        variant: ModelVariant,
        repoOverride: String? = null,
        onState: (ModelState) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val repo = repoOverride?.takeIf { it.isNotBlank() } ?: variant.repo
        val dir = dirOf(variant).apply { if (!exists()) mkdirs() }
        val out = ggufOf(variant)
        val part = File(dir, "$MODEL_FILE.part")
        val token = tokenSeq.incrementAndGet()
        activeToken = token
        fun isAborted() = abortToken >= token

        // 点下按钮就先给一个 0 字节的 Downloading：后面还要探测镜像、读
        // Content-Length，快则一两秒、慢则二十秒（换源重试）。这段时间界面
        // 什么都不变，用户会以为按钮没响应。总量先用档位估值，拿到真实
        // 大小后再覆盖。
        _state.value = ModelState.Downloading(variant.id, variant.fileName, 0, variant.approximateBytes, 0)
        onState(_state.value)

        try {
            // 1) 探测可用下载根地址并拿文件大小；镜像挂了自动回退官方源
            var root: String? = null
            var serverSize = -1L
            var lastError: Throwable? = null
            for (base in roots(repo)) {
                if (isAborted()) throw CancellationException(tr("已取消"))
                try {
                    val size = headSize("$base/${variant.fileName}")
                    if (size >= MIN_GGUF_BYTES) {
                        root = base
                        serverSize = size
                        break
                    }
                    lastError = IOException(tr("Content-Length 异常：$size", "Unexpected Content-Length: $size"))
                } catch (t: Throwable) {
                    lastError = t
                    Log.w(TAG, "probe via $base failed: ${t.message}")
                }
            }
            if (isAborted()) throw CancellationException(tr("已取消"))
            if (root == null) {
                throw IOException(
                    tr("拿不到模型信息：${lastError?.message}。", "Can't get model info: ${lastError?.message}.") +
                        tr("若使用自定义仓库，请确认其中含 ${variant.fileName}", "If you use a custom repository, make sure it contains ${variant.fileName}")
                )
            }

            // 服务端不给 Content-Length 时用档位估值做进度与空间预检
            val exact = serverSize >= MIN_GGUF_BYTES
            val total = if (exact) serverSize else variant.approximateBytes

            // 2) 空间预检
            val need = (total * 1.1).toLong() - dir.usableSpaceSafe()
            if (need > 0) throw IOException(tr("存储空间不足：还需要 ${need / 1_000_000} MB", "Not enough space: ${need / 1_000_000} MB more needed"))

            // 3) 单文件断点续传
            if (part.exists() && part.length() >= total) part.delete()
            val resume = if (part.exists()) part.length() else 0L
            val t0 = System.currentTimeMillis()
            var lastTick = t0
            var lastAbs = resume
            fetchTo("$root/${variant.fileName}", part, resume, ::isAborted) { written, effectiveStart ->
                val now = System.currentTimeMillis()
                val abs = effectiveStart + written
                if (now - lastTick >= 250 || abs >= total) {
                    val speed = if (now > lastTick) (abs - lastAbs) * 1000 / (now - lastTick) else 0L
                    lastTick = now
                    lastAbs = abs
                    _state.value = ModelState.Downloading(variant.id, variant.fileName, abs, total, speed)
                    onState(_state.value)
                }
            }

            if (part.length() <= MIN_GGUF_BYTES) {
                throw IOException(tr("下载内容过小（${formatBytes(part.length())}），请切换下载源重试", "The download is too small (${formatBytes(part.length())}) — switch download source and retry"))
            }
            if (exact && part.length() != total) {
                throw IOException(tr("下载不完整（${part.length()} != $total）", "Incomplete download (${part.length()} != $total)"))
            }

            // 4) 校验 GGUF 文件头，防止把 HTML 错误页当成模型装上
            _state.value = ModelState.Verifying(variant.id, variant.fileName)
            onState(_state.value)
            try {
                checkMagic(part)
            } catch (t: Throwable) {
                part.delete()
                throw t
            }
            out.delete()
            if (!part.renameTo(out)) throw IOException(tr("模型落盘失败"))
            onInstalled(variant.id, out.length())
            onState(_state.value)
            Log.i(TAG, "installed $MODEL_FILE (${out.length()} bytes)")
        } catch (t: Throwable) {
            val cancelled = isAborted() || t is CancellationException
            if (cancelled) {
                // 取消 = 用户不要了，半成品留着只会白占 2~3 GB，直接删
                runCatching { part.delete() }
                Log.i(TAG, "download cancelled, partial removed")
            }
            restoreState()
            if (cancelled) throw CancellationException(tr("已取消下载")) else throw t
        } finally {
            // 只清掉自己那一轮的连接引用，别踩到用户取消后立刻重开的新一轮
            if (activeToken == token) liveConn = null
        }
    }

    private fun checkMagic(f: File) {
        val magic = ByteArray(4)
        f.inputStream().use { if (it.read(magic) != 4) throw IOException(tr("文件头读取失败")) }
        if (String(magic, Charsets.US_ASCII) != "GGUF") {
            throw IOException(tr("不是 GGUF 文件（缺少 GGUF 文件头），请选择 .gguf 量化模型"))
        }
    }

    private fun baseUrl(repo: String) =
        if (mirror) "https://hf-mirror.com/$repo/resolve/main" else "https://huggingface.co/$repo/resolve/main"

    private fun directUrl(repo: String) = "https://huggingface.co/$repo/resolve/main"

    /** 当前设置优先，镜像失败时回退官方源。 */
    private fun roots(repo: String): List<String> =
        listOf(baseUrl(repo), directUrl(repo)).distinct()

    private fun open(url: String, rangeStart: Long): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "BreezeTTS-Android/1.0")
        if (rangeStart > 0) c.setRequestProperty("Range", "bytes=$rangeStart-")
        return c
    }

    private fun headSize(url: String): Long {
        val c = open(url, 0)
        // 也挂到 liveConn 上：探测阶段卡在 connect 时，「取消」同样要能立刻断开
        liveConn = c
        try {
            c.connect()
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code: $url")
            return c.getHeaderFieldLong("Content-Length", -1L)
        } finally {
            runCatching { c.disconnect() }
            if (liveConn === c) liveConn = null
        }
    }

    /**
     * 支持断点续传的下载。progress 参数是「本次写入增量, 有效起始偏移」。
     * 服务端若忽略 Range 返回 200，则从头覆盖写并把有效起点归零。
     *
     * 每读一块都检查 [aborted]：协程取消对阻塞 read 是无效的，只有这个标记
     * 能把「取消」真正传到循环里。[liveConn] 让 [abort] 能直接断开挂在
     * read 上的连接，不必等 60 秒读超时。
     */
    private fun fetchTo(
        url: String,
        target: File,
        startAt: Long,
        isAborted: () -> Boolean,
        progress: ((Long, Long) -> Unit)? = null,
    ) {
        val conn = open(url, startAt)
        liveConn = conn
        try {
            conn.connect()
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code: $url")

            val append = code == HttpURLConnection.HTTP_PARTIAL && startAt > 0
            if (!append && startAt > 0) target.delete()  // 服务端忽略 Range → 重新从头写
            val effectiveStart = if (append) startAt else 0L

            var written = 0L
            target.parentFile?.mkdirs()
            FileOutputStream(target, append).use { fos ->
                conn.inputStream.use { ins ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        if (isAborted()) throw CancellationException(tr("已取消"))
                        val n = ins.read(buf)
                        if (n <= 0) break
                        fos.write(buf, 0, n)
                        written += n
                        progress?.invoke(written, effectiveStart)
                    }
                }
            }
        } finally {
            runCatching { conn.disconnect() }
            liveConn = null
        }
    }

    private fun File.usableSpaceSafe(): Long = runCatching { usableSpace }.getOrDefault(0)

    companion object {
        private const val TAG = "ModelRepo"
        const val MODEL_FILE = "model.gguf"
        private const val KEY_ACTIVE_MODEL = "active_model"
        private const val MIN_GGUF_BYTES = 1L shl 20  // 1 MB，仅用于排除空文件/错误页

        fun sha256(f: File): String {
            val md = MessageDigest.getInstance("SHA-256")
            f.inputStream().use { ins ->
                val buf = ByteArray(1 shl 20)
                while (true) {
                    val n = ins.read(buf)
                    if (n <= 0) break
                    md.update(buf, 0, n)
                }
            }
            return md.digest().joinToString("") { "%02x".format(it) }
        }
    }
}

fun formatBytes(b: Long): String = when {
    b >= 1_000_000_000 -> "%.2f GB".format(b / 1e9)
    b >= 1_000_000 -> "%.1f MB".format(b / 1e6)
    b >= 1_000 -> "%.0f KB".format(b / 1e3)
    else -> "$b B"
}
