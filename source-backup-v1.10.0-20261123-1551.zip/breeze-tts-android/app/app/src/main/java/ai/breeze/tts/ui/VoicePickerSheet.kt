package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.breeze.tts.engine.VoiceProfile
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeSize

/**
 * 音色选择浮层（v2 重做）。
 *
 * 交互不变：点一下即切换并关闭。改的是排布：
 *  - 顶部一颗搜索框（35dp），音色多了以后不用一格格找；
 *  - 筛选只按性别（全部 / 女声 / 男声），文字页签，和主界面同一套语言；
 *  - 格子 128dp 高、72dp 头像 —— 头像占卡片的 56%（旧版 50dp / 116dp 只有 43%，
 *    四周留白比头像本身还大，九个格子看起来像九个空框）；
 *  - 选中不再靠整卡变色，而是头像外圈金环 + 右下角 24dp 实心勾（Canvas 画圆抗锯齿）；
 *  - 底部只留一颗主按钮（新建），「管理」挪到右上角文字按钮。
 */
@Composable
fun VoicePickerSheet(
    visible: Boolean,
    voices: List<VoiceProfile>,
    selectedId: String?,
    onSelect: (String?) -> Unit,
    onCreate: () -> Unit,
    onManage: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = Breeze.colors
    var filter by remember { mutableStateOf(VoiceFilter.ALL) }
    var query by remember { mutableStateOf("") }

    val matched = voices.filter { v ->
        val byGender = when (filter) {
            VoiceFilter.ALL -> true
            VoiceFilter.FEMALE -> v.gender == VoiceProfile.Gender.FEMALE
            VoiceFilter.MALE -> v.gender == VoiceProfile.Gender.MALE
        }
        byGender && (query.isBlank() || v.name.contains(query.trim(), ignoreCase = true))
    }

    BreezeSheet(visible = visible, onDismiss = onDismiss, heightFraction = 0.78f) {
        SheetTopBar(
            title = tr("音色"),
            action = tr("管理"),
            onAction = onManage,
            onClose = onDismiss,
        )

        // ---- 搜索 ----
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = BreezeSize.gutter)
                .height(35.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(c.fill)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SearchGlyph(c.t3)
            Spacer(Modifier.width(7.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(tr("搜索音色"), fontSize = 12.5.sp, color = c.t3)
                }
                ImeAwareBasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 12.5.sp, color = c.t1),
                    cursorBrush = SolidColor(c.accent),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (query.isNotEmpty()) {
                Text(
                    tr("清除"),
                    fontSize = 11.sp,
                    color = c.t3,
                    modifier = Modifier
                        .clip(RoundedCornerShape(5.dp))
                        .clickable { query = "" }
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                )
            }
        }

        Spacer(Modifier.height(13.dp))

        // ---- 筛选 ----
        InlineTabs(
            labels = VoiceFilter.entries.map { it.label },
            selectedIndex = VoiceFilter.entries.indexOf(filter),
            onSelect = { filter = VoiceFilter.entries[it] },
            modifier = Modifier.padding(horizontal = BreezeSize.gutter),
        )

        Spacer(Modifier.height(12.dp))

        if (matched.isEmpty() && filter != VoiceFilter.ALL) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        tr("还没有${filter.label}音色", "No ${filter.label} voices yet"),
                        fontSize = 12.5.sp,
                        color = c.t2,
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        tr("在音色页把性别设为${filter.label}，就会归到这里", "Set the gender to ${filter.label} on the Voices page and it lands here"),
                        fontSize = 11.sp,
                        color = c.t3,
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(horizontal = BreezeSize.gutter),
                horizontalArrangement = Arrangement.spacedBy(9.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp),
                modifier = Modifier.weight(1f),
            ) {
                if (filter == VoiceFilter.ALL && query.isBlank()) {
                    item(key = "__default__") {
                        DefaultTile(selected = selectedId == null) { onSelect(null) }
                    }
                }
                items(matched, key = { it.id }) { v ->
                    VoiceTile(profile = v, selected = v.id == selectedId) { onSelect(v.id) }
                }
                item(key = "__new__") { NewTile(onClick = onCreate) }
            }
        }

        Column(Modifier.padding(horizontal = BreezeSize.gutter).padding(top = 12.dp, bottom = 16.dp)) {
            BreezePrimaryButton(
                text = if (voices.isEmpty()) tr("新建第一个音色") else tr("新建音色"),
                onClick = onCreate,
                icon = Icons.Outlined.Add,
                modifier = Modifier.fillMaxWidth(),
                height = BreezeSize.buttonSmall,
            )
        }
    }
}

private enum class VoiceFilter(val label: String) {
    ALL(tr("全部")), FEMALE(tr("女声")), MALE(tr("男声")),
}

// 三列网格的格子里，头像占到卡片的 56%（旧版是 43%）。
// 旧卡片 116dp 高、50dp 头像，四周留白比头像本身还大，九个格子看起来像九个空框。
private val TileHeight = 128.dp
private val TileAvatar = 72.dp
private val TileShape = RoundedCornerShape(12.dp)

@Composable
private fun SearchGlyph(tint: Color) {
    Canvas(Modifier.size(13.dp)) {
        val w = size.width
        val sw = 1.6.dp.toPx()
        drawCircle(tint, radius = w * 0.30f, center = Offset(w * 0.42f, w * 0.42f), style = Stroke(sw))
        drawLine(tint, Offset(w * 0.65f, w * 0.65f), Offset(w * 0.94f, w * 0.94f), sw, StrokeCap.Round)
    }
}

/** 卡片外壳：三种格子（音色 / 默认 / 新建）共用一个高度与圆角 */
@Composable
private fun TileFrame(
    selected: Boolean,
    onClick: () -> Unit,
    dashed: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = Breeze.colors
    Column(
        Modifier
            .fillMaxWidth()
            .height(TileHeight)
            .clip(TileShape)
            .then(
                if (dashed) Modifier.dashedBorder(c.line2, 12.dp)
                else Modifier
                    .background(if (selected) c.accentSoft else c.fill)
                    .border(
                        1.dp,
                        if (selected) c.accent.copy(alpha = 0.34f) else Color.Transparent,
                        TileShape,
                    ),
            )
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content,
    )
}

@Composable
private fun TileLabel(name: String, subtitle: String, selected: Boolean) {
    val c = Breeze.colors
    Spacer(Modifier.height(7.dp))
    Text(
        name,
        fontSize = 12.5.sp,
        lineHeight = 16.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
        color = if (selected) c.accent else c.t1,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
    )
    Spacer(Modifier.height(2.dp))
    Text(
        subtitle,
        fontSize = 9.5.sp,
        lineHeight = 12.sp,
        color = c.t3,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
    )
}

/**
 * 选中角标：头像右下角实心金圆 + 白勾，外圈 2.5dp 用卡片底色挖空。
 *
 * 旧实现是 `.clip(CircleShape)` 之后再加 `border(2.5.dp, …)`：描边有一半画在
 * 裁剪区外，被 clip 硬切成直角像素，23dp 的小圆上一眼就是一圈锯齿。
 * 现在两圈都用 Canvas 画实心圆，抗锯齿交给 Skia，边缘是干净的。
 * 挖空色取卡片的选中底色，不是浮层的 surface2——否则金底上会多一道灰环。
 */
@Composable
private fun TileCheck() {
    val c = Breeze.colors
    Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            drawCircle(c.accentSoft, radius = r, center = center)
            drawCircle(c.accent, radius = r - 2.5.dp.toPx(), center = center)
        }
        Icon(
            Icons.Outlined.Check,
            contentDescription = null,
            tint = c.onAccent,
            modifier = Modifier.size(11.dp),
        )
    }
}

@Composable
private fun VoiceTile(profile: VoiceProfile, selected: Boolean, onClick: () -> Unit) {
    TileFrame(selected = selected, onClick = onClick) {
        Box(contentAlignment = Alignment.BottomEnd) {
            VoiceAvatar(
                name = profile.name,
                gender = profile.gender,
                avatarPath = profile.avatarPath,
                size = TileAvatar,
                selected = selected,
                showBadge = false,
            )
            if (selected) TileCheck()
        }
        TileLabel(profile.name, subtitleOf(profile), selected)
    }
}

@Composable
private fun DefaultTile(selected: Boolean, onClick: () -> Unit) {
    val c = Breeze.colors
    val base = Color(0xFFA8A8B0)
    TileFrame(selected = selected, onClick = onClick) {
        Box(contentAlignment = Alignment.BottomEnd) {
            Box(
                Modifier
                    .size(TileAvatar)
                    .clip(CircleShape)
                    .background(if (c.isDark) lerp(c.surface, base, 0.20f) else lerp(Color.White, base, 0.16f))
                    .then(
                        if (selected) Modifier.border(2.dp, c.accent, CircleShape) else Modifier,
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    tr("默"),
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (c.isDark) base else lerp(base, Color(0xFF111111), 0.55f),
                )
            }
            if (selected) TileCheck()
        }
        TileLabel(tr("默认音色"), tr("模型内置"), selected)
    }
}

@Composable
private fun NewTile(onClick: () -> Unit) {
    val c = Breeze.colors
    TileFrame(selected = false, onClick = onClick, dashed = true) {
        Box(
            Modifier.size(TileAvatar).clip(CircleShape).background(c.fill),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Outlined.Add, contentDescription = null, tint = c.t3, modifier = Modifier.size(24.dp))
        }
        TileLabel(tr("新建"), tr("克隆 / 设计"), false)
    }
}

/** 卡片下方的小字：类型 + 锁定状态 */
private fun subtitleOf(v: VoiceProfile): String = when {
    v.kind == VoiceProfile.Kind.CLONE && v.locked -> tr("克隆 · 锁定")
    v.kind == VoiceProfile.Kind.CLONE -> tr("克隆")
    v.locked -> tr("设计 · 锁定")
    else -> tr("设计 · 随机")
}
