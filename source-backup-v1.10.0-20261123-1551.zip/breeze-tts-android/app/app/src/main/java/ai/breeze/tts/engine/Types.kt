package ai.breeze.tts.engine

import ai.breeze.tts.i18n.tr

import java.io.File

/** 音色：克隆（需要参考音频 + 文本稿）或设计（只需要描述）。 */
data class VoiceProfile(
    val id: String,
    val name: String,
    val kind: Kind,
    /** 性别。只用于筛选与头像底色，老数据没有这个字段时为 NONE（不猜） */
    val gender: Gender = Gender.NONE,
    /** 头像图片绝对路径；为空时界面上显示名字首字 */
    val avatarPath: String? = null,
    /** 参考音频 wav（24k 单声道）绝对路径，仅 CLONE 有 */
    val refWav: String? = null,
    /** 参考音频的逐字文本稿。克隆必填；设计音色锁定后是试听样本的文本 */
    val refText: String? = null,
    /** 预编码的码本文件（int16[T,16]），命中可省掉一次 codec encode */
    val codes: String? = null,
    /** 音色描述，仅 DESIGN 有 */
    val designPrompt: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
) {
    enum class Kind { CLONE, DESIGN }

    enum class Gender(val code: String) {
        NONE(""), FEMALE("f"), MALE("m");

        companion object {
            fun of(code: String?): Gender =
                entries.firstOrNull { it.code == code } ?: NONE
        }
    }

    /**
     * 设计音色是否已锁定：有码本 + 有样本文字稿，两条都满足才会走参考路径。
     * 锁定后音色由码本决定，不再受本次采样的随机性影响（见 docs/18）。
     */
    val locked: Boolean get() = kind == Kind.DESIGN && codes != null && refText != null

    /** 头像上显示的字符：名字的第一个可见字符 */
    val initial: String
        get() = name.trim().firstOrNull()?.toString() ?: tr("音")

    val isFemale: Boolean get() = gender == Gender.FEMALE

    /**
     * 能否作为音色转换的目标：转换必须有一段参考音频和它的逐字稿，
     * 音高与音色都从这两样重建。没录过试听样本的设计音色不行。
     */
    val canConvertTarget: Boolean get() = !refWav.isNullOrBlank() && !refText.isNullOrBlank()

    fun toJson(): String = buildString {
        append("{")
        append("\"id\":\"").append(id.esc()).append("\",")
        append("\"name\":\"").append(name.esc()).append("\",")
        append("\"kind\":\"").append(if (kind == Kind.CLONE) "clone" else "design").append("\",")
        append("\"refWav\":\"").append((refWav ?: "").esc()).append("\",")
        append("\"refText\":\"").append((refText ?: "").esc()).append("\",")
        append("\"codes\":\"").append((codes ?: "").esc()).append("\",")
        append("\"designPrompt\":\"").append((designPrompt ?: "").esc()).append("\",")
        append("\"gender\":\"").append(gender.code).append("\",")
        append("\"avatarPath\":\"").append((avatarPath ?: "").esc()).append("\"")
        append("}")
    }

    private fun String.esc() = replace("\\", "\\\\").replace("\"", "\\\"")

    companion object {
        fun fromJson(o: org.json.JSONObject) = VoiceProfile(
            id = o.getString("id"),
            name = o.optString("name", tr("未命名")),
            kind = if (o.optString("kind") == "clone") Kind.CLONE else Kind.DESIGN,
            refWav = o.optString("refWav").takeIf { it.isNotEmpty() },
            refText = o.optString("refText").takeIf { it.isNotEmpty() },
            codes = o.optString("codes").takeIf { it.isNotEmpty() },
            designPrompt = o.optString("designPrompt").takeIf { it.isNotEmpty() },
            gender = VoiceProfile.Gender.of(o.optString("gender")),
            avatarPath = o.optString("avatarPath").takeIf { it.isNotEmpty() },
        )
    }
}

/** 一次合成请求。模板由 native 侧按「有无参考音频 / 有无指令」自动选择。 */
data class SynthRequest(
    val text: String,
    val instruction: String = "",
    val voice: VoiceProfile? = null,
    val seed: Int = 42,
    val temperature: Float = 0.9f,
    val topP: Float = 0.9f,
    /**
     * CFG 引导强度：决定音色描述 / 情绪指令被遵从的程度。
     * PC 端默认 4.0；1.0 等于完全关闭指令引导（描述会被模型默认先验覆盖）。
     * 仅在存在 instruction 或 designPrompt 时生效。
     */
    val cfgScale: Float = 4.0f,
    /** 最多生成多少帧（12.5 帧/秒），防止跑飞 */
    val maxFrames: Int = 900,
    /**
     * 首块 flush 的目标帧数（12.5 帧/秒）。0 = 引擎默认（16）。
     *
     * 声码器每次 flush 都要重算 72 帧滑动窗口上下文，块越小重复计算越多。
     * 合成过程不播放，首块大小没有「早点听到」的意义，因此由调用方按估算
     * 长度给一个「一次 flush 到底」的值，短句的声码器工作量能降四成以上。
     */
    val chunkFirst: Int = 0,
    /**
     * 1.9.72：后续块的上限。0 = 与 [chunkFirst] 相同（1.9.71 之前的行为）。
     *
     * 声码器每解一块都要重算最多 266 帧上下文（250 滑动窗口 + 16），所以后续块
     * 放大能直接省掉重复计算；只放大上限、不动首块，首包延迟不受影响。
     */
    val chunkMax: Int = 0,
    /** 非空时把本次生成首段的码本写到这个路径（给设计音色录试听样本 / 缓存克隆编码） */
    val codesOut: String? = null,
    /** 1.9.11 实验优化：复用参考前缀的 embedding。默认 false = 原路径。 */
    val reusePrefixEmb: Boolean = false,
    /**
     * 1.9.43 后段降 CFG：前 N 帧按 [cfgScale] 走双分支，之后降到 1.0 只跑 cond。
     * 音色在前若干帧已经定型，尾段再放大引导收益很小，却要多付一倍算力。
     * 0 = 全程使用 [cfgScale]（原路径）。
     */
    val cfgDecayFrames: Int = 0,
    /** 1.9.43 声码器独立线程数，0 = 跟随主线程数。 */
    val vocThreads: Int = 0,
    /**
     * 1.9.69 性能诊断页的对照实验开关，正式合成必须保持默认值：
     * 1 = 深度解码强制走逐码本 replay（用来量出「单图」的收益）。
     */
    val depthMode: Int = 0,
    /**
     * 1.9.91 深度解码不吃 CFG。默认 false = 原行为。
     *
     * CFG 要在 15 个码本上各做一次双分支，实测占每帧深度耗时的 45%
     * （205.8 → 112.2 ms/帧），而它只改变码本的采样分布，不影响主干。
     * 打开后主干仍受 [cfgScale] 引导，只是码本不再被二次放大。
     */
    val depthCfgOff: Boolean = false,
    /**
     * 1.9.106 码本截断实验：0 = 全部码本（正式合成必须保持 0）。
     *
     * 深度解码每帧要把同一份权重读 15 遍，占整帧 65% 的耗时。这个开关只
     * 服务性能诊断页的 A/B：只解前 N 个码本，其余位置复读上一帧。
     */
    val codebooks: Int = 0,
)

/**
 * 一次音色转换请求：输入是音频而不是文本。
 *
 * 词、时长、节奏、重音都从 [srcWav] 里复制（语义码本原样沿用），
 * 音高与音色按 [refWav] + [refText] 重新生成。
 */
data class ConvertRequest(
    /** 源音频（24 kHz 单声道 16-bit WAV，上层已归一） */
    val srcWav: String,
    /** 目标音色的参考音频 */
    val refWav: String,
    /** 目标音色参考音频的逐字稿 */
    val refText: String,
    /** 源音频的逐字稿。留空时模型自动生成等长填充，对齐精度会下降 */
    val srcText: String = "",
    /** 结果写入路径 */
    val outWav: String,
    /** 0.3 接近贪心：最忠实于目标音色。调高更自然，但源音色会漏回来 */
    val temperature: Float = 0.3f,
    val topK: Int = 1,
    /** 保留源音频前 N 个声学码本（0–15），只对唱歌有意义；普通说话会抖 */
    val keepAcoustic: Int = 0,
    val seed: Int = 42,
)

data class EngineStats(    val prefillMs: Long = 0,
    val frames: Int = 0,
    val audioMs: Long = 0,
    /** 端到端墙钟耗时（含 prefill、解码、声码器） */
    val elapsedMs: Long = 0,
) {
    val rtf: Float get() = if (audioMs <= 0) 0f else elapsedMs.toFloat() / audioMs
}

/**
 * 上一次合成的分阶段耗时（毫秒）。回答「时间到底花在哪」：
 * backbone（逐帧主干，CFG 双分支）与 depth（15 个声学码本）是逐帧成本的大头，
 * vocoder 是每块一次的固定开销，tail 是最后一块音频之后「没有任何输出」的空转。
 */
data class StageTimings(
    val promptMs: Double = 0.0,
    val prefillMs: Double = 0.0,
    val backboneMs: Double = 0.0,
    val depthMs: Double = 0.0,
    val vocoderMs: Double = 0.0,
    val firstAudioMs: Double = 0.0,
    val tailMs: Double = 0.0,
    val frames: Int = 0,
    val flushes: Int = 0,
    val steps: Int = 0,
    /** true = 尾帧保护提前收尾（模型连吐空帧） */
    val stoppedEarly: Boolean = false,
    /** prompt 的 token 数 */
    val prefillTokens: Int = 0,
    /** 其中直接复用参考前缀 KV 的数量；等于 prefillTokens 说明整段都命中了 */
    val prefillReused: Int = 0,
    /** 1.9.71 深度解码实际走了哪条路径（帧数）：fused = 单图一次 replay，
     * step = 逐码本 15 次 replay。两者之和等于 frames。
     *
     * 判定条件在 native 里（top_p ≥ 1 且 top_k ≤ 256 才进单图），宿主侧看不到。
     * 没有这两个数，A/B 很可能两臂跑的是同一条路径，量出来的几个百分点全是热漂移。
     */
    val depthFusedFrames: Int = 0,
    val depthStepFrames: Int = 0,
) {
    /** 逐帧主干 + 深度解码的合计（真正随音频长度线性增长的部分） */
    val perFrameMs: Double get() = backboneMs + depthMs

    /** 多角色逐句合成时把每句的耗时累加成整段的账 */
    operator fun plus(o: StageTimings) = StageTimings(
        promptMs = promptMs + o.promptMs,
        prefillMs = prefillMs + o.prefillMs,
        backboneMs = backboneMs + o.backboneMs,
        depthMs = depthMs + o.depthMs,
        vocoderMs = vocoderMs + o.vocoderMs,
        firstAudioMs = firstAudioMs + o.firstAudioMs,
        tailMs = tailMs + o.tailMs,
        frames = frames + o.frames,
        flushes = flushes + o.flushes,
        steps = steps + o.steps,
        stoppedEarly = stoppedEarly || o.stoppedEarly,
        prefillTokens = prefillTokens + o.prefillTokens,
        prefillReused = prefillReused + o.prefillReused,
        depthFusedFrames = depthFusedFrames + o.depthFusedFrames,
        depthStepFrames = depthStepFrames + o.depthStepFrames,
    )
}

fun File.ensureDir(): File = apply { if (!exists()) mkdirs() }
