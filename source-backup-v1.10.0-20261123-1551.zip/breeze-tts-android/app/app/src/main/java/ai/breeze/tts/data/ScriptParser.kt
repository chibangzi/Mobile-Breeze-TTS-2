package ai.breeze.tts.data

import ai.breeze.tts.i18n.tr

/**
 * 多角色剧本的一行。
 *
 * @param speaker 【】里的名字；为 null 表示这一句没有指定角色（用当前音色）
 * @param emotion 圆括号里的情绪指令，可以为空
 * @param text 冒号后面的台词
 */
data class ScriptLine(
    val speaker: String?,
    val emotion: String,
    val text: String,
)

/**
 * 多角色剧本解析：
 *
 * ```
 * 【小明】(开心的语气):今天天气真好啊。
 * 【小红】(温柔的语气):是啊，我们出去走走吧。
 * 小华也一起去吧。          ← 没有角色头 → 并进上一句
 * ```
 *
 * 格式是手写的，所以规则尽量宽松：
 *  - 角色名一律用【】：内联事件写的是 `[笑]` `[叹气]`，两套括号分开，看剧本时不会混；
 *  - 圆括号 / 冒号中英文都认；
 *  - 有情绪可以省冒号（`【小明】(开心) 你好`），没情绪则必须有冒号；
 *  - 旧写法 `[小明](情绪):` 仍然认（它带括号和冒号，和内联事件不会混淆），
 *    新写的剧本请用【】；
 *  - 只有 `【名字】(情绪):` 而没写台词时，等下一行正文；
 *  - 空行忽略，`#` 开头当作注释。
 */
object ScriptParser {

    private const val SENTENCE_END = "。！？!?，,；;：:…、"

    fun parse(script: String): List<ScriptLine> {
        val out = ArrayList<ScriptLine>()
        // 只写了角色头、还没写台词的行
        var pendingSpeaker: String? = null
        var pendingEmotion = ""

        for (raw in script.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue

            val head = parseHead(line)
            if (head != null) {
                if (head.text.isEmpty()) {
                    pendingSpeaker = head.speaker
                    pendingEmotion = head.emotion
                } else {
                    out += ScriptLine(head.speaker, head.emotion, head.text)
                    pendingSpeaker = null
                    pendingEmotion = ""
                }
            } else if (pendingSpeaker != null) {
                // 上一行只写了角色头，这一行是它的台词
                out += ScriptLine(pendingSpeaker, pendingEmotion, line)
                pendingSpeaker = null
                pendingEmotion = ""
            } else if (out.isNotEmpty()) {
                // 纯续行：并进上一句而不是新起一段。多一个段就多一次换人停顿，
                // 也会把一句话的语调切断。上一句没有句末标点时补一个逗号。
                val prev = out.removeAt(out.size - 1)
                val last = prev.text.lastOrNull()
                val joiner = if (last != null && SENTENCE_END.contains(last)) "" else "，"
                out += prev.copy(text = prev.text + joiner + line)
            } else {
                // 开头就没有角色名：整段交给当前音色，不报错
                out += ScriptLine(null, "", line)
            }
        }
        return out
    }

    private class Head(val speaker: String, val emotion: String, val text: String)

    /**
     * 解析形如 `【名字】(情绪): 台词` 的行头；不像角色头就返回 null。
     * `[名字]` 作为旧写法继续支持：它要么带 `(情绪)`、要么带冒号，才可能被认成角色，
     * 所以 `[笑] 今天天气不错` 这类内联事件不会误判。
     */
    private fun parseHead(line: String): Head? {
        val open = line.firstOrNull() ?: return null
        if (open != '【' && open != '[') return null
        val close = line.indexOf(if (open == '[') ']' else '】')
        if (close <= 1) return null
        val speaker = line.substring(1, close).trim()
        if (speaker.isEmpty() || speaker.length > 40) return null

        var i = close + 1
        while (i < line.length && line[i].isWhitespace()) i++

        var emotion = ""
        if (i < line.length && (line[i] == '(' || line[i] == '（')) {
            val end = line.indexOf(if (line[i] == '(') ')' else '）', i + 1)
            if (end < 0) return null
            emotion = line.substring(i + 1, end).trim()
            i = end + 1
            while (i < line.length && line[i].isWhitespace()) i++
        }

        val hasColon = i < line.length && (line[i] == ':' || line[i] == '：')
        // 既没情绪也没冒号：多半是 [笑] / [叹气] 这类内联事件，不是角色
        if (!hasColon && emotion.isEmpty()) return null
        if (hasColon) i++

        return Head(speaker, emotion, line.substring(i).trim())
    }

    /** 剧本里出现过的角色名，按首次出现顺序去重 */
    fun speakers(lines: List<ScriptLine>): List<String> =
        lines.mapNotNull { it.speaker?.trim()?.takeIf(String::isNotEmpty) }.distinct()

    /**
     * 粗略校验。只有「什么都没有」才算错误：没有角色名的文本照常能合成，
     * 只是整段用当前音色（等同于单人朗读），不必拦下来。
     */
    fun firstProblem(lines: List<ScriptLine>): String? =
        if (lines.isEmpty()) tr("剧本是空的：每行按「【名字】(情绪): 台词」写一句") else null
}
