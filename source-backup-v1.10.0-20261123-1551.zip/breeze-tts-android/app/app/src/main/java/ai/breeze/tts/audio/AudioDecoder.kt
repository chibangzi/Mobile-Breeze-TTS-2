package ai.breeze.tts.audio

import ai.breeze.tts.i18n.tr

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/**
 * 把任意常见音频格式统一解码成 24 kHz / 单声道 / 16-bit PCM WAV。
 *
 * 克隆音色的参考音频原来只收 WAV，用户导入 mp3 / m4a 会直接失败。这里用系统
 * MediaExtractor + MediaCodec 解码（无需第三方库、无需联网），再重采样到
 * Breeze 引擎需要的 24 kHz；ASR 侧再二次重采样到 16 kHz。
 *
 * WAV 走直接解析（更快更稳），压缩格式走 MediaCodec。
 */
object AudioDecoder {

    const val REF_RATE = 24_000
    const val ASR_RATE = 16_000

    data class Pcm(val data: ShortArray, val sampleRate: Int, val channels: Int)

    /** 导入结果：除了文件本身，还要告诉界面「是不是截断了 / 是不是视频」。 */
    data class Imported(val file: File, val truncated: Boolean, val fromVideo: Boolean)

    /** 参考音频最长取 10 分钟：再长既超出模型建议区间，解码本身也会占掉上百 MB 内存。 */
    private const val MAX_SECONDS = 600

    /** 解码 content:// 音频到 out（标准 WAV）。返回 out。 */
    fun toReferenceWav(context: Context, uri: Uri, out: File): File =
        importReference(context, uri, out).file

    /**
     * 选中的可能是 mp4 / mov 这类视频：不再复制整份文件（几百 MB 会把 cache 撑满），
     * 直接用 MediaExtractor 从 content:// 读音频轨，解出 PCM 再重采样。
     *
     * 音频文件仍走「复制到 cache + WAV 直读」的老路径：小文件更快，而且 WAV
     * 解析比走 MediaCodec 稳（部分机型的 audio/raw 直通会吐异常块）。
     */
    fun importReference(context: Context, uri: Uri, out: File): Imported {
        val type = runCatching { context.contentResolver.getType(uri) }.getOrNull().orEmpty()
        val size = runCatching {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length }
        }.getOrNull() ?: -1L
        val video = type.startsWith("video/")
        val huge = size > 48L * 1024 * 1024

        val raw = File(context.cacheDir, "ref_src.tmp")
        val (pcm, truncated) = try {
            if (video || huge) {
                decodeFromUri(context, uri)
            } else {
                context.contentResolver.openInputStream(uri)?.use { ins ->
                    raw.outputStream().use { os -> ins.copyTo(os) }
                } ?: error(tr("打不开所选文件"))

                val head = raw.inputStream().use { it.readNBytes(12) }
                val isWav = head.size >= 12 &&
                    String(head, 0, 4, Charsets.US_ASCII) == "RIFF" &&
                    String(head, 8, 4, Charsets.US_ASCII) == "WAVE"
                val fast = if (isWav) readWav(raw) else null
                if (fast != null) fast to false else decodeCompressed(raw)
            }
        } finally {
            raw.delete()
        }

        val mono = downmix(pcm.data, pcm.channels)
        val resampled = if (pcm.sampleRate == REF_RATE) mono
        else resample(mono, pcm.sampleRate, REF_RATE)

        out.parentFile?.mkdirs()
        out.delete()
        val w = WavWriter(out, REF_RATE)
        w.write(resampled)
        w.close()
        if (out.length() < 1000) {
            error(if (video) tr("这个视频里没有可用的音轨") else tr("解码结果为空，请换一段有效文件"))
        }
        return Imported(out, truncated, video)
    }

    /** 读取已归一化的 24k WAV，转成 16 kHz float 供 sherpa-onnx 使用。 */
    fun toAsrFloat(wav: File): FloatArray? {
        val pcm = readWav(wav) ?: return null
        val mono = downmix(pcm.data, pcm.channels)
        val s = if (pcm.sampleRate == ASR_RATE) mono else resample(mono, pcm.sampleRate, ASR_RATE)
        return FloatArray(s.size) { s[it] / 32768f }
    }

    // -------------------------------------------------------------- WAV 直读

    private fun readWav(file: File): Pcm? = runCatching {
        val b = file.readBytes()
        if (b.size < 44 ||
            String(b, 0, 4, Charsets.US_ASCII) != "RIFF" ||
            String(b, 8, 4, Charsets.US_ASCII) != "WAVE"
        ) return null
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        var rate = 0
        var channels = 0
        var bits = 0
        var format = 0
        var data: ShortArray? = null
        var pos = 12
        while (pos + 8 <= b.size) {
            val id = String(b, pos, 4, Charsets.US_ASCII)
            val size = bb.getInt(pos + 4)
            val body = pos + 8
            if (size < 0 || body + size > b.size) break
            when (id) {
                "fmt " -> if (size >= 16) {
                    format = bb.getShort(body).toInt() and 0xffff
                    channels = bb.getShort(body + 2).toInt()
                    rate = bb.getInt(body + 4)
                    bits = bb.getShort(body + 14).toInt()
                }
                "data" -> {
                    // 只处理 16-bit PCM；浮点 / 24-bit 交给 MediaCodec
                    if (format == 1 && bits == 16) {
                        val n = size / 2
                        val arr = ShortArray(n)
                        for (i in 0 until n) arr[i] = bb.getShort(body + i * 2)
                        data = arr
                    }
                }
            }
            pos = body + size + (size and 1)
            if (id == "data" && data != null) break
        }
        val d = data ?: return null
        if (rate <= 0 || channels <= 0 || d.isEmpty()) return null
        Pcm(d, rate, channels)
    }.getOrNull()

    // ---------------------------------------------------------- MediaCodec

    private fun decodeCompressed(file: File): Pair<Pcm, Boolean> {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(file.absolutePath)
            return decodeTrack(ex)
        } finally {
            runCatching { ex.release() }
        }
    }

    /** 视频 / 超大文件直接从 content:// 解码：不落盘，也不把整份文件读进内存。 */
    private fun decodeFromUri(context: Context, uri: Uri): Pair<Pcm, Boolean> {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(context, uri, null)
            return decodeTrack(ex)
        } finally {
            runCatching { ex.release() }
        }
    }

    private fun decodeTrack(ex: MediaExtractor): Pair<Pcm, Boolean> {
        var track = -1
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) { track = i; break }
        }
        if (track < 0) error(tr("文件里没有音频轨，或格式不受支持"))

        val inFmt = ex.getTrackFormat(track)
        val mime = inFmt.getString(MediaFormat.KEY_MIME) ?: error(tr("未知音频编码"))
        ex.selectTrack(track)

        var rate = inFmt.optInt(MediaFormat.KEY_SAMPLE_RATE, 44_100)
        var channels = inFmt.optInt(MediaFormat.KEY_CHANNEL_COUNT, 1)
        var floatOutput = false

        val codec = MediaCodec.createDecoderByType(mime)
        try {
            codec.configure(inFmt, null, null, 0)
            codec.start()
            val info = MediaCodec.BufferInfo()
            val chunks = ArrayList<ShortArray>()
            var acc = 0
            var cut = false
            var inputDone = false
            var outputDone = false
            val timeout = 10_000L

            while (!outputDone) {
                if (!inputDone) {
                    val idx = codec.dequeueInputBuffer(timeout)
                    if (idx >= 0) {
                        val buf = codec.getInputBuffer(idx)
                        if (buf == null) {
                            codec.queueInputBuffer(idx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val n = ex.readSampleData(buf, 0)
                            if (n < 0) {
                                codec.queueInputBuffer(idx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(idx, 0, n, ex.sampleTime, 0)
                                ex.advance()
                            }
                        }
                    }
                }
                when (val oi = codec.dequeueOutputBuffer(info, timeout)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        rate = f.optInt(MediaFormat.KEY_SAMPLE_RATE, rate)
                        channels = f.optInt(MediaFormat.KEY_CHANNEL_COUNT, channels)
                        val enc = f.optInt(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
                        floatOutput = enc == AudioFormat.ENCODING_PCM_FLOAT
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> if (inputDone) outputDone = true
                    else -> if (oi >= 0) {
                        val buf = codec.getOutputBuffer(oi)
                        if (buf != null && info.size > 0) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            val arr = readAsShorts(buf, floatOutput)
                            if (arr.isNotEmpty()) {
                                chunks.add(arr)
                                acc += arr.size
                            }
                        }
                        codec.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        // 一小时视频全解要几分钟、上百 MB：只取前 10 分钟，够模型用
                        if (acc >= MAX_SECONDS * rate) { cut = true; outputDone = true }
                    }
                }
            }
            codec.stop()
            if (chunks.isEmpty()) error(tr("没有解出音频数据，请检查文件是否损坏"))

            val total = chunks.sumOf { it.size }
            val merged = ShortArray(total)
            var p = 0
            for (c in chunks) { c.copyInto(merged, p); p += c.size }
            return Pcm(merged, rate, channels.coerceAtLeast(1)) to cut
        } finally {
            runCatching { codec.release() }
        }
    }

    private fun readAsShorts(buf: ByteBuffer, isFloat: Boolean): ShortArray {
        val b = buf.slice().order(ByteOrder.nativeOrder())
        return if (isFloat) {
            val n = b.remaining() / 4
            ShortArray(n) {
                val v = b.float.coerceIn(-1f, 1f)
                (v * 32767f).roundToInt().toShort()
            }
        } else {
            val n = b.remaining() / 2
            ShortArray(n) { b.short }
        }
    }

    private fun MediaFormat.optInt(key: String, fallback: Int): Int =
        if (containsKey(key)) runCatching { getInteger(key) }.getOrDefault(fallback) else fallback

    // ------------------------------------------------------------- 重采样

    private fun downmix(data: ShortArray, channels: Int): ShortArray {
        if (channels <= 1) return data
        val frames = data.size / channels
        val out = ShortArray(frames)
        for (i in 0 until frames) {
            var v = 0
            for (c in 0 until channels) v += data[i * channels + c].toInt()
            out[i] = (v / channels).toShort()
        }
        return out
    }

    /** 线性插值重采样，对语音足够；避免引入额外依赖。 */
    private fun resample(input: ShortArray, fromRate: Int, toRate: Int): ShortArray {
        if (fromRate == toRate || input.isEmpty()) return input
        val ratio = fromRate.toDouble() / toRate
        val n = (input.size / ratio).toInt().coerceAtLeast(1)
        val out = ShortArray(n)
        for (i in 0 until n) {
            val pos = i * ratio
            val a = pos.toInt().coerceIn(0, input.size - 1)
            val b = (a + 1).coerceIn(0, input.size - 1)
            val f = (pos - a).toFloat()
            out[i] = (input[a] + (input[b] - input[a]) * f).toInt().toShort()
        }
        return out
    }
}
