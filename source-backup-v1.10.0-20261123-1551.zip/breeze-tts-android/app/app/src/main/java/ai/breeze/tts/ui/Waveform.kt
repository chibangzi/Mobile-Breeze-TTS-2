package ai.breeze.tts.ui

import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ai.breeze.tts.ui.theme.Breeze
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * 收藏夹里的波形进度条。
 *
 * 音频条目本来就只是一行文字 + 一条 2dp 的细线，播放时看不出「这一段有没有内容」。
 * 波形是从 wav 的 PCM 里按桶取峰值算出来的（不是随机装饰），所以静音段确实是平的、
 * 重音段确实是高的——这也是它看起来专业的原因。
 *
 * 计算放在 IO 线程，结果按路径缓存：同一段音频来回播放不会重复扫文件。
 */
private object WaveCache {
    private val cache = LruCache<String, FloatArray>(12)

    fun get(path: String): FloatArray? = cache.get(path)
    fun put(path: String, data: FloatArray) = cache.put(path, data)
}

/** 读一遍 PCM，按桶取峰值并归一化。44 字节头 + PCM16 单声道（App 自己写的 wav 都是这个格式）。 */
internal object AudioPeaks {

    fun read(file: File, buckets: Int): FloatArray {
        val empty = FloatArray(buckets) { 0.06f }
        if (buckets <= 0 || !file.isFile || file.length() <= 44) return empty
        val out = FloatArray(buckets)
        val dataBytes = file.length() - 44
        val samples = (dataBytes / 2).coerceAtLeast(1)
        val per = ((samples + buckets - 1) / buckets).coerceAtLeast(1)

        runCatching {
            RandomAccessFile(file, "r").use { raf ->
                raf.seek(44)
                val buf = ByteArray(64 * 1024)
                var idx = 0L
                while (true) {
                    val n = raf.read(buf)
                    if (n <= 0) break
                    var i = 0
                    while (i + 1 < n) {
                        val v = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort().toInt()
                        val a = abs(v) / 32768f
                        val b = (idx / per).toInt().coerceIn(0, buckets - 1)
                        if (a > out[b]) out[b] = a
                        i += 2
                        idx++
                    }
                }
            }
        }.getOrElse { return empty }

        val peak = out.maxOrNull() ?: 0f
        if (peak <= 1e-4f) return empty

        // 开方压缩动态范围：语音的能量集中在低频包络，直接线性会只剩中间一小撮柱子
        for (i in out.indices) out[i] = sqrt((out[i] / peak).coerceIn(0f, 1f))

        // 三点平滑，避免单点毛刺
        val smooth = FloatArray(buckets)
        for (i in 0 until buckets) {
            val a = out[max(0, i - 1)]
            val b = out[i]
            val c = out[min(buckets - 1, i + 1)]
            smooth[i] = ((a + b * 2f + c) / 4f).coerceIn(0.06f, 1f)
        }
        return smooth
    }
}

/** 取波形（带缓存）。文件还没解析完时先给一条低平的占位。 */
@Composable
fun rememberWaveform(path: String, buckets: Int = 64): FloatArray {
    val placeholder = remember(buckets) { FloatArray(buckets) { 0.06f } }
    var data by remember(path, buckets) {
        mutableStateOf(WaveCache.get(path) ?: placeholder)
    }
    LaunchedEffect(path, buckets) {
        if (path.isBlank()) return@LaunchedEffect
        val cached = WaveCache.get(path)
        if (cached != null) {
            data = cached
            return@LaunchedEffect
        }
        val computed = withContext(Dispatchers.IO) { AudioPeaks.read(File(path), buckets) }
        WaveCache.put(path, computed)
        data = computed
    }
    return data
}

/**
 * 波形 + 进度 + 拖动。
 *
 * 已播部分用强调色，未播用描边色；同一根柱子不拆两半，扫过去更像「播放头」，
 * 也不会在 2dp 宽的柱子里出现难看的双色断层。
 */
@Composable
fun WaveSeekBar(
    peaks: FloatArray,
    fraction: Float,
    modifier: Modifier = Modifier,
    height: Dp = 36.dp,
    onSeek: ((Float) -> Unit)? = null,
) {
    val c = Breeze.colors
    val played = c.accent
    val rest = c.line2

    Canvas(
        modifier
            .fillMaxWidth()
            .height(height)
            .then(
                if (onSeek == null) Modifier
                else Modifier
                    .pointerInput(Unit) {
                        detectTapGestures { o ->
                            onSeek((o.x / size.width.toFloat()).coerceIn(0f, 1f))
                        }
                    }
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures { change, _ ->
                            onSeek((change.position.x / size.width.toFloat()).coerceIn(0f, 1f))
                        }
                    },
            ),
    ) {
        val n = peaks.size
        if (n == 0) return@Canvas
        val slot = size.width / n
        val barW = (slot * 0.56f).coerceAtLeast(1.4f)
        val radius = CornerRadius(barW / 2f, barW / 2f)
        val midY = size.height / 2f
        val maxH = size.height
        val head = fraction.coerceIn(0f, 1f) * n

        for (i in 0 until n) {
            val h = (peaks[i].coerceIn(0.06f, 1f) * maxH).coerceAtLeast(barW)
            val x = i * slot + (slot - barW) / 2f
            drawRoundRect(
                color = if (i + 0.5f <= head) played else rest,
                topLeft = Offset(x, midY - h / 2f),
                size = Size(barW, h),
                cornerRadius = radius,
            )
        }
    }
}
