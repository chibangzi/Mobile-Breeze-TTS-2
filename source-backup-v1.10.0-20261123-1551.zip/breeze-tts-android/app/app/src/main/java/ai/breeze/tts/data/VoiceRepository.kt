package ai.breeze.tts.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import ai.breeze.tts.engine.VoiceProfile
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * 音色库：克隆音色（ref wav + 文本稿 + 预编码码本）与设计音色（纯描述）。
 * 落盘为 voices/<id>.json，参考音频为 <id>.wav，码本为 <id>.codes（int16[T,16]）。
 */
class VoiceRepository(private val app: Context) {

    private val root: File get() = File(app.filesDir, "voices").apply { if (!exists()) mkdirs() }

    private val _voices = MutableStateFlow<List<VoiceProfile>>(emptyList())
    val voices: StateFlow<List<VoiceProfile>> = _voices.asStateFlow()

    suspend fun load() = withContext(Dispatchers.IO) {
        _voices.value = root.listFiles { f -> f.extension == "json" }
            ?.mapNotNull { runCatching { VoiceProfile.fromJson(JSONObject(it.readText())) }.getOrNull() }
            ?.sortedByDescending { it.createdAt }
            ?: emptyList()
    }

    fun fileOf(v: VoiceProfile, ext: String) = File(root, "${v.id}.$ext")

    suspend fun upsert(v: VoiceProfile) = withContext(Dispatchers.IO) {
        fileOf(v, "json").writeText(v.toJson())
        load()
    }

    suspend fun delete(v: VoiceProfile) = withContext(Dispatchers.IO) {
        fileOf(v, "json").delete()
        fileOf(v, "wav").delete()
        fileOf(v, "codes").delete()
        clearSample(v)
        avatarFile(v.id).delete()
        load()
    }

    fun newId(): String = UUID.randomUUID().toString().take(8)

    fun codesFileOf(v: VoiceProfile) = fileOf(v, "codes")

    /**
     * 试听样本的**暂存**位置。
     *
     * 单独放一份、而不是直接写 `<id>.codes`：用户点「换一条」只是想要一个新候选，
     * 没点「就这样，锁定」之前，已锁定的音色不该被悄悄改掉。
     */
    fun sampleCodesFileOf(v: VoiceProfile) = File(root, "${v.id}.sample.codes")
    fun sampleWavFileOf(v: VoiceProfile) = File(root, "${v.id}.sample.wav")

    fun clearSample(v: VoiceProfile) {
        sampleCodesFileOf(v).delete()
        sampleWavFileOf(v).delete()
    }

    fun avatarFile(id: String) = File(root, "$id.jpg")

    /**
     * 把相册里的图存成头像：居中裁成正方形，缩到 256×256，JPEG 88。
     * 头像只占几十 KB，不必再走 Glide 之类的加载库——列表里直接 decode 文件即可。
     */
    suspend fun saveAvatar(id: String, uri: Uri): String? =
        writeAvatar(uri, avatarFile(id))?.let { avatarFile(id).absolutePath }

    /** 已经裁好并缩到 256 的位图：直接编码落盘，不再二次裁切 */
    suspend fun saveAvatarBitmap(id: String, bmp: Bitmap): String? = withContext(Dispatchers.IO) {
        runCatching {
            writeBitmap(bmp, avatarFile(id))
            avatarFile(id).absolutePath
        }.getOrNull()
    }

    /** 新建音色时先落到缓存里，等音色建好后再 attach（那时才有 id 决定文件名） */
    suspend fun stageAvatar(uri: Uri): File? =
        writeAvatar(uri, File(app.cacheDir, "avatar_stage.jpg"))?.let {
            File(app.cacheDir, "avatar_stage.jpg")
        }

    suspend fun stageAvatarBitmap(bmp: Bitmap): File? = withContext(Dispatchers.IO) {
        runCatching {
            val f = File(app.cacheDir, "avatar_stage.jpg")
            writeBitmap(bmp, f)
            f
        }.getOrNull()
    }

    private fun writeBitmap(bmp: Bitmap, target: File) {
        target.parentFile?.mkdirs()
        FileOutputStream(target).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
    }

    suspend fun attachAvatar(id: String, src: File): String? = withContext(Dispatchers.IO) {
        runCatching {
            val target = avatarFile(id)
            if (src.absolutePath != target.absolutePath) src.copyTo(target, overwrite = true)
            target.absolutePath
        }.getOrNull()
    }

    /** 居中裁方 + 缩到 256 + JPEG 88，返回落盘后的文件 */
    private suspend fun writeAvatar(uri: Uri, target: File): File? = withContext(Dispatchers.IO) {
        runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            app.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            if (bounds.outWidth <= 0) return@runCatching null
            var sample = 1
            while (bounds.outWidth / sample > 640 || bounds.outHeight / sample > 640) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = app.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return@runCatching null

            val side = minOf(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(
                bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side,
            )
            val scaled = Bitmap.createScaledBitmap(square, 256, 256, true)
            target.parentFile?.mkdirs()
            FileOutputStream(target).use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            if (scaled !== square) scaled.recycle()
            if (square !== bmp) square.recycle()
            bmp.recycle()
            target
        }.getOrNull()
    }

    /** 只改元信息（名字 / 性别 / 描述 / 头像），不动参考音频与码本 */
    suspend fun patch(v: VoiceProfile): VoiceProfile {
        upsert(v)
        return v
    }

    /**
     * 新建克隆音色。refWav 必须是 24 kHz 单声道 16bit，调用方负责转码。
     * codes 由 native 侧首次合成时生成并回写（这里先留空路径）。
     */
    suspend fun addClone(
        name: String,
        refWav: File,
        refText: String,
        gender: VoiceProfile.Gender = VoiceProfile.Gender.NONE,
        avatarUri: Uri? = null,
    ): VoiceProfile {
        val id = newId()
        val target = File(root, "$id.wav")
        refWav.copyTo(target, overwrite = true)
        val codes = File(root, "$id.codes")
        val p = VoiceProfile(
            id = id, name = name, kind = VoiceProfile.Kind.CLONE,
            gender = gender, avatarPath = avatarUri?.let { saveAvatar(id, it) },
            refWav = target.absolutePath, refText = refText.trim(),
            codes = codes.absolutePath.takeIf { codes.exists() },
        )
        upsert(p)
        return p
    }

    suspend fun addDesign(
        name: String,
        prompt: String,
        gender: VoiceProfile.Gender = VoiceProfile.Gender.NONE,
        avatarUri: Uri? = null,
    ): VoiceProfile {
        val id = newId()
        val p = VoiceProfile(
            id = id, name = name, kind = VoiceProfile.Kind.DESIGN,
            gender = gender, avatarPath = avatarUri?.let { saveAvatar(id, it) },
            designPrompt = prompt.trim(),
        )
        upsert(p)
        return p
    }
}
