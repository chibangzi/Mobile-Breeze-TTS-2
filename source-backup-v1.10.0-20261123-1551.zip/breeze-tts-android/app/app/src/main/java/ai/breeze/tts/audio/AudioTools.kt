package ai.breeze.tts.audio

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * 编辑页的整段处理：降噪、压缩空白。
 *
 * 都是单遍 O(n) 扫描：10 分钟、24 kHz 的素材约 1400 万样本，在中端机上降噪
 * 200 ms 左右，所以在后台线程跑就够，不需要动 native 侧。
 *
 * 降噪刻意没做 FFT 谱减：谱减在弱信号下会产生「音乐噪声」（那种水声一样的
 * 咕噜声），而对参考音频来说，底噪只要压下去、人声别动就够。这里用
 * 40 Hz 高通（去直流和低频隆隆）+ 逐帧噪声门（按实测底噪自适应阈值），
 * 帧间增益做快开慢关的平滑，句尾不会被切出「吧嗒」声。
 */
object AudioTools {

    private const val FRAME_SEC = 0.02
    private const val HOP_SEC = 0.01

    /** 一帧 20 ms 的 RMS 序列（dBFS），帧移 10 ms。 */
    private fun frameDb(samples: ShortArray, sr: Int): FloatArray {
        val frame = (sr * FRAME_SEC).toInt().coerceAtLeast(64)
        val hop = (sr * HOP_SEC).toInt().coerceAtLeast(32)
        if (samples.size < frame) return FloatArray(0)
        val frames = (samples.size - frame) / hop + 1
        val db = FloatArray(frames)
        for (i in 0 until frames) {
            val s = i * hop
            var acc = 0.0
            var j = s
            val e = s + frame
            while (j < e) {
                val v = samples[j] / 32768.0
                acc += v * v
                j++
            }
            db[i] = (20 * log10(sqrt(acc / frame).coerceAtLeast(1e-7))).toFloat()
        }
        return db
    }

    /** 分位数取底噪：安静帧占 10~15%，比「取最小值」稳（不受单帧掉采样影响）。 */
    private fun percentile(db: FloatArray, p: Float): Float {
        if (db.isEmpty()) return -90f
        val sorted = db.copyOf()
        sorted.sort()
        return sorted[(db.size * p).toInt().coerceIn(0, db.size - 1)]
    }

    /** 40 Hz 一阶高通，去掉直流偏移和手持噪声的低频隆起。 */
    private fun highpass(x: FloatArray, sr: Int, fc: Double) {
        val a = exp(-2.0 * PI * fc / sr).toFloat()
        var prevIn = 0f
        var prevOut = 0f
        for (i in x.indices) {
            val v = x[i]
            prevOut = a * (prevOut + v - prevIn)
            prevIn = v
            x[i] = prevOut
        }
    }

    /**
     * 降噪：高通 + 噪声门。返回新实例（原对象不动，撤销栈里还要用）。
     *
     * 门限取「底噪 + 7 dB」，门下压到 -20 dB 而不是静音——全静音会让句子之间
     * 出现不自然的「真空」，参考音频听起来会像被剪过。
     */
    fun denoise(clip: PcmClip): PcmClip {
        val sr = clip.sampleRate
        val n = clip.samples.size
        if (n < sr / 4) return clip

        val x = FloatArray(n) { clip.samples[it] / 32768f }
        highpass(x, sr, 40.0)
        val db = frameDb(clip.samples, sr)
        if (db.size < 8) return clip

        val hop = (sr * HOP_SEC).toInt().coerceAtLeast(32)
        val floorDb = percentile(db, 0.10f)
        val gate = floorDb + 7f

        val gains = FloatArray(db.size)
        var g = 1f
        for (i in db.indices) {
            val target = if (db[i] < gate) 0.10f else 1f
            // 快开（约 20 ms 到位）、慢关（约 200 ms），句尾自然收住
            g += (target - g) * if (target > g) 0.55f else 0.045f
            gains[i] = g
        }

        val out = ShortArray(n)
        for (i in 0 until n) {
            val fi = (i / hop).coerceAtMost(gains.size - 1)
            val v = x[i] * gains[fi] * 32767f
            out[i] = v.coerceIn(-32768f, 32767f).toInt().toShort()
        }
        return PcmClip(out, sr)
    }

    /** 降噪后的底噪，用来给用户一个「压了多少」的反馈。 */
    fun floorDb(clip: PcmClip): Float = percentile(frameDb(clip.samples, clip.sampleRate), 0.10f)

    data class SqueezeResult(
        val clip: PcmClip,
        val gaps: Int,
        val savedSec: Double,
        val changed: Boolean,
    )

    /**
     * 压缩空白：超过 [maxGapSec] 的静音段砍到只剩这么长，头尾各留 [edgeSec]。
     *
     * 阈值取「底噪 + 8 dB」且不低于 -45 dBFS。加绝对下限是为了防呆：如果整段
     * 录音底噪很高（-35 dB 左右），相对阈值会把正常的弱音也当成静音剪掉，
     * 这时候宁可不剪。
     *
     * 中间保留 1 秒（前后各半秒），句子之间的呼吸感还在，不会粘成一坨。
     */
    fun squeezeSilence(
        clip: PcmClip,
        maxGapSec: Double = 1.0,
        edgeSec: Double = 0.2,
    ): SqueezeResult {
        val sr = clip.sampleRate
        val n = clip.samples.size
        if (n < sr / 2) return SqueezeResult(clip, 0, 0.0, false)

        val db = frameDb(clip.samples, sr)
        if (db.isEmpty()) return SqueezeResult(clip, 0, 0.0, false)
        val hop = (sr * HOP_SEC).toInt().coerceAtLeast(32)
        val frame = (sr * FRAME_SEC).toInt().coerceAtLeast(64)
        val thr = max(percentile(db, 0.15f) + 8f, -45f)

        val keepGap = (maxGapSec * sr).toInt()
        val edge = (edgeSec * sr).toInt()
        val cuts = ArrayList<IntRange>()
        var gaps = 0
        var saved = 0

        var i = 0
        while (i < db.size) {
            if (db[i] >= thr) {
                i++
                continue
            }
            var j = i
            while (j + 1 < db.size && db[j + 1] < thr) j++
            val s = i * hop
            val e = min(n, j * hop + frame)
            when {
                // 开头：只留 0.2 秒，长前奏全是空调声
                s == 0 -> {
                    val cutEnd = e - edge
                    if (cutEnd > 0) {
                        cuts += 0 until cutEnd
                        gaps++
                        saved += cutEnd
                    }
                }
                // 结尾同理
                e >= n -> {
                    val cutFrom = s + edge
                    if (cutFrom < n) {
                        cuts += cutFrom until n
                        gaps++
                        saved += n - cutFrom
                    }
                }
                e - s > keepGap -> {
                    val a = s + keepGap / 2
                    val b = e - keepGap / 2
                    if (b > a) {
                        cuts += a until b
                        gaps++
                        saved += b - a
                    }
                }
            }
            i = j + 1
        }

        if (cuts.isEmpty()) return SqueezeResult(clip, 0, 0.0, false)

        var outLen = n
        for (r in cuts) outLen -= (r.last - r.first + 1)
        val out = ShortArray(outLen)
        var w = 0
        var cursor = 0
        for (r in cuts) {
            val a = r.first
            val b = r.last + 1
            if (a > cursor) {
                clip.samples.copyInto(out, w, cursor, a)
                w += a - cursor
            }
            cursor = max(cursor, b)
        }
        if (cursor < n) clip.samples.copyInto(out, w, cursor, n)
        return SqueezeResult(PcmClip(out, sr), gaps, saved.toDouble() / sr, true)
    }
}
