package ai.breeze.tts.data

import ai.breeze.tts.i18n.tr

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import ai.breeze.tts.i18n.Lang
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 全局设置：导出目录、推理线程、CFG 引导强度、分阶段线程。
 * 全部持久化在 SharedPreferences，重启后仍生效。
 * GPU / Vulkan 相关设置在 1.9.55 全部删除，只剩纯 CPU 一套参数。
 */
class SettingsRepository(private val app: Context) {

    private val sp = app.getSharedPreferences("breeze_settings", Context.MODE_PRIVATE)

    val defaultExportLabel = "${Environment.DIRECTORY_MUSIC}/BreezeTTS"

    private val _exportTreeUri = MutableStateFlow<String?>(null)
    val exportTreeUri: StateFlow<String?> = _exportTreeUri.asStateFlow()

    private val _exportDirLabel = MutableStateFlow(defaultExportLabel)
    val exportDirLabel: StateFlow<String> = _exportDirLabel.asStateFlow()

    private val _threads = MutableStateFlow(6)
    val threads: StateFlow<Int> = _threads.asStateFlow()

    /** CFG 引导强度。PC 端做音色设计用 4.0，这里保持一致。 */
    private val _cfgScale = MutableStateFlow(4.0f)
    val cfgScale: StateFlow<Float> = _cfgScale.asStateFlow()

    /** 分阶段线程：prefill 用满线程，逐帧 decode 自动降到 2–4 线程。 */
    private val _phaseThreads = MutableStateFlow(false)
    val phaseThreads: StateFlow<Boolean> = _phaseThreads.asStateFlow()

    /**
     * 1.9.11 实验优化：复用参考前缀的 embedding。默认关闭 —— 关闭时生成路径
     * 与稳定版逐位等价，随时可退回。只影响「文本编码」阶段的重复计算。
     */
    private val _reusePrefixEmb = MutableStateFlow(false)
    val reusePrefixEmb: StateFlow<Boolean> = _reusePrefixEmb.asStateFlow()

    /**
     * 极速模式：强制 cfg_scale=1，让主干与深度解码只跑 cond 单分支。
     *
     * CFG 生效时每一步都要同时算 cond 与 uncond 两条分支（两份 KV cache、
     * 两次 depth decode），这正是逐帧阶段占掉七成时间的原因。关掉之后
     * 单帧成本直接减半，代价是音色描述 / 情绪指令不再被放大，
     * 声音会更靠模型的默认先验。
     */
    private val _turbo = MutableStateFlow(false)
    val turbo: StateFlow<Boolean> = _turbo.asStateFlow()

    /** 性能诊断入口是否解锁：设置页默认不显示，在「关于 → 版本信息」连点 6 次才出现。 */
    private val _devMode = MutableStateFlow(false)
    val devMode: StateFlow<Boolean> = _devMode.asStateFlow()

    /**
     * 1.9.43 核心绑定：把合成线程钉在 cpufreq 最高的 N 个核上。
     *
     * 推断来自「八线程比六线程慢」：以为是调度器把线程丢进慢核。1.9.43 真机实测
     * 证明这个推断错了 —— 绑到 6,7,0,1,2,3 之后墙钟从 7174 涨到 9497~12284 ms，
     * 主干从 39 涨到 82~125 ms/帧，并且三轮递增（docs/51）。原因大概是：绑核
     * 剥夺了调度器在簇之间分摊功耗与迁移线程的能力，热和频率反而更差。
     *
     * 所以默认关闭，只留作 A/B 的对照组。
     */
    private val _corePin = MutableStateFlow(false)
    val corePin: StateFlow<Boolean> = _corePin.asStateFlow()

    /**
     * 1.9.43 后段降 CFG：前 N 帧按 cfgScale 走 cond/uncond 双分支，之后降到 1.0
     * 只跑 cond。音色在前十几帧已经定型，尾段继续放大引导几乎不改变听感，
     * 却要多付一倍主干与深度解码的算力。
     */
    private val _cfgDecay = MutableStateFlow(false)
    val cfgDecay: StateFlow<Boolean> = _cfgDecay.asStateFlow()

    /**
     * 1.9.91 深度解码不吃 CFG。CFG 要在 15 个码本上各做一次双分支，
     * 实测占每帧深度耗时 45%（205.8 → 112.2 ms），而它只改变码本的采样
     * 分布、不影响主干。默认关（保持原行为）。
     */
    private val _depthCfgOff = MutableStateFlow(false)
    val depthCfgOff: StateFlow<Boolean> = _depthCfgOff.asStateFlow()

    /** 前多少帧保留原始 cfg；超出的部分走单分支。 */
    private val _cfgDecayFrames = MutableStateFlow(12)
    val cfgDecayFrames: StateFlow<Int> = _cfgDecayFrames.asStateFlow()

    /**
     * 1.9.43 声码器独立线程：flush 期间临时切到这个线程数，结束后恢复。
     * 0 = 跟随「CPU 线程数」。
     *
     * 实测每帧声码器耗时：4 线程 64~70 ms、6 线程 54 ms、8 线程 44 ms。声码器是
     * 逐层卷积、并行粒度比主干细，正好需要更多线程，跟主干「线程越多越慢」相反。
     *
     * 1.9.45 实测（6 线程生成、其余全关，31 帧短句）：声码器线程 4/5/6/8 对应
     * 64.4 / 60.1 / 54.0 / 45.4 ms/帧，单调且三次一致。切换线程数要重建 ggml
     * 线程池，但一次 flush 只重建一次，省下的 9 ms/帧 远大于重建开销，所以默认 8。
     */
    private val _vocThreads = MutableStateFlow(8)
    val vocThreads: StateFlow<Int> = _vocThreads.asStateFlow()

    /**
     * 1.9.73 声码器分块上限（帧，12.5 帧/秒）。首块不受它影响，恒为估算的「一次到底」值。
     *
     * 声码器每解一块都要把整段前文当上下文重算一遍，实测（docs/81，同文本 175 帧）：
     * 块 16 / 96 / 250 对应 250.8 / 75.4 / 49.2 ms/帧，flush 11 / 2 / 1 次。块越大
     * 重复计算越少，但一次要攒更久才出下一段音频。首块仍是 96 帧（7.7 秒），所以首声
     * 延迟不随这个值变化——这正是 1.9.72 把 chunk_first 与 chunk_max 拆开的原因。
     *
     * 上限超过 250 尚未在真机验证：native 的 ggml 暂存缓冲按 chunk_max+88 帧预分配，
     * 给太大可能因缓冲膨胀变慢或占更多内存。默认 250 = 已验证的最优点。
     */
    private val _vocChunk = MutableStateFlow(250)
    val vocChunk: StateFlow<Int> = _vocChunk.asStateFlow()

    /**
     * 1.9.84 声码器 GPU 加速开关。
     *
     * 打开后 dpre 之后那一段（占整条链路约四分之一）交给 LiteRT 的 GPU 后端；
     * 关掉则完全走原来的纯 CPU 路径，行为与之前逐位一致。默认关：这张图在每台
     * 设备上能不能跑、跑多快都要现场验证，不能替用户先假设。
     */
    private val _gpuVocoder = MutableStateFlow(false)
    val gpuVocoder: StateFlow<Boolean> = _gpuVocoder.asStateFlow()

    /**
     * 上一次合成的实测实时率（elapsed / audio）。用来决定流式播放的预缓冲长度：
     * RTF 越高，越需要先攒一段再开播，否则边生成边播会断成一小段一小段。
     */
    private val _lastRtf = MutableStateFlow(1.0f)
    val lastRtf: StateFlow<Float> = _lastRtf.asStateFlow()

    /**
     * 1.10.0 界面语言：system / zh / en。
     * 默认跟随系统，用户可在「设置 → 语言」里手动覆盖。
     */
    private val _language = MutableStateFlow("system")
    val language: StateFlow<String> = _language.asStateFlow()

    /**
     * 每个「发音单位」大约对应多少毫秒音频（CJK 一个字记 1 单位，其他字符记 0.3）。
     * 合成完成后按实测音频时长学习（指数滑动平均），用来算进度条分母和预缓冲长度——
     * 不再拿「maxFrames 上限」当分母，否则进度会在 60% 卡死再跳到 100%。
     */
    private val _msPerUnit = MutableStateFlow(320f)
    val msPerUnit: StateFlow<Float> = _msPerUnit.asStateFlow()

    init {
        _exportTreeUri.value = sp.getString(KEY_EXPORT_URI, null)?.takeIf { it.isNotBlank() }
        _exportDirLabel.value = sp.getString(KEY_EXPORT_LABEL, null) ?: defaultExportLabel
        _threads.value = sp.getInt(KEY_THREADS, 6).coerceIn(1, 16)
        _cfgScale.value = sp.getFloat(KEY_CFG_SCALE, 4.0f).coerceIn(1f, 8f)
        _depthCfgOff.value = sp.getBoolean(KEY_DEPTH_CFG_OFF, false)
        // 1.9.92：真机上「深度解码不吃 CFG」只快一成多，代价却是码本失去 CFG
        // 约束后的高频杂音。一次性强制关掉 —— 开了这个开关的人不会自己想到
        // 「声音变尖是那个开关干的」，留着只会继续被投诉音质。
        if (!sp.getBoolean(KEY_DEPTH_CFG_RESET, false)) {
            _depthCfgOff.value = false
            sp.edit()
                .putBoolean(KEY_DEPTH_CFG_OFF, false)
                .putBoolean(KEY_DEPTH_CFG_RESET, true)
                .apply()
        }
        _lastRtf.value = sp.getFloat(KEY_LAST_RTF, 1.0f).coerceIn(0.1f, 10f)
        _msPerUnit.value = sp.getFloat(KEY_MS_PER_UNIT, 320f).coerceIn(80f, 1_200f)

        // 1.4：GPU 加速已整体移除。清掉 1.2/1.3 残留的开关值——尤其是那些
        // 把 use_gpu 设成 true 后导致启动即崩的用户数据，避免任何旧状态被误读。
        if (sp.contains("use_gpu") || sp.contains("gpu_v13_migrated") ||
            sp.contains("gpu_opencl_enabled")) {
            sp.edit().remove("use_gpu").remove("gpu_v13_migrated")
                .remove("gpu_opencl_enabled").apply()
        }
        // 1.9.55：Vulkan 路径已从代码里删掉，顺手清掉 1.9.48~1.9.54 留下的键，
        // 免得升级用户的 SharedPreferences 里还挂着一条已经没人读的开关。
        if (sp.contains("vulkan_backend") || sp.contains("vulkan_armed") ||
            sp.contains("vk_reset_1_9_53")) {
            sp.edit().remove("vulkan_backend").remove("vulkan_armed")
                .remove("vk_reset_1_9_53").apply()
        }
        _turbo.value = sp.getBoolean(KEY_TURBO, false)
        _language.value = Lang.normalize(sp.getString(KEY_LANGUAGE, Lang.MODE_SYSTEM))
        _devMode.value = sp.getBoolean(KEY_DEV_MODE, false)
        _vocChunk.value = sp.getInt(KEY_VOC_CHUNK, 250).coerceIn(96, 512)
        _gpuVocoder.value = sp.getBoolean(KEY_GPU_VOC, false)

        // 1.9.47：这几个开关在真机上测完就删了 UI，值在这里固定，不再读 SharedPreferences
        // （老版本可能存着 true / 4，读回来等于把坏配置又请回来）。
        //   · 分阶段线程：切换要重建线程池，逐帧 98 → 130 ms（docs/47）
        //   · 核心绑定：墙钟 +32%~71%，且逐轮恶化（docs/51）
        //   · 后段降 CFG：深度不吃收益，只省主干 3~5%，还得冒句尾跑音色的风险（docs/51）
        //   · 声码器线程：4/5/6/8 → 64.4/60.1/54.0/45.4 ms/帧，固定 8（docs/52）
        //   · 复用参考前缀编码：未做过音质回归，保持关闭
        _phaseThreads.value = false
        _corePin.value = false
        _cfgDecay.value = false
        _cfgDecayFrames.value = 12
        _vocThreads.value = 8
        _reusePrefixEmb.value = false
        sp.edit()
            .remove(KEY_PHASE_THREADS).remove(KEY_PHASE_MIGRATED_V2)
            .remove(KEY_CORE_PIN).remove(KEY_PIN_MIGRATED_1944)
            .remove(KEY_CFG_DECAY).remove(KEY_CFG_DECAY_FRAMES)
            .remove(KEY_VOC_THREADS).remove(KEY_REUSE_PREFIX_EMB)
            .apply()
    }

    val exportUri: Uri? get() = _exportTreeUri.value?.let { runCatching { Uri.parse(it) }.getOrNull() }

    fun setExportDir(uri: Uri?, label: String?) {
        if (uri == null) {
            _exportTreeUri.value?.let { old ->
                runCatching {
                    app.revokeUriPermission(
                        Uri.parse(old),
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                    )
                }
            }
            _exportTreeUri.value = null
            _exportDirLabel.value = defaultExportLabel
        } else {
            runCatching {
                app.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
            _exportTreeUri.value = uri.toString()
            _exportDirLabel.value = label?.takeIf { it.isNotBlank() } ?: tr("自定义目录")
        }
        sp.edit()
            .putString(KEY_EXPORT_URI, _exportTreeUri.value)
            .putString(KEY_EXPORT_LABEL, _exportDirLabel.value)
            .apply()
    }

    fun setThreads(n: Int) {
        val v = n.coerceIn(1, 16)
        _threads.value = v
        sp.edit().putInt(KEY_THREADS, v).apply()
    }

    fun setCfgScale(v: Float) {
        val x = v.coerceIn(1f, 8f)
        _cfgScale.value = x
        sp.edit().putFloat(KEY_CFG_SCALE, x).apply()
    }

    fun setPhaseThreads(on: Boolean) {
        _phaseThreads.value = on
        sp.edit().putBoolean(KEY_PHASE_THREADS, on).apply()
    }

    fun setTurbo(on: Boolean) {
        _turbo.value = on
        sp.edit().putBoolean(KEY_TURBO, on).apply()
    }

    /** 界面语言：system / zh / en。写入后由 MainActivity 调 Lang.setMode 生效。 */
    fun setLanguage(mode: String) {
        val v = when (mode) {
            Lang.MODE_ZH, Lang.MODE_EN -> mode
            else -> Lang.MODE_SYSTEM
        }
        _language.value = v
        sp.edit().putString(KEY_LANGUAGE, v).apply()
    }

    fun setDevMode(on: Boolean) {
        _devMode.value = on
        sp.edit().putBoolean(KEY_DEV_MODE, on).apply()
    }

    fun setCorePin(on: Boolean) {
        _corePin.value = on
        sp.edit().putBoolean(KEY_CORE_PIN, on).apply()
    }

    fun setCfgDecay(on: Boolean) {
        _cfgDecay.value = on
        sp.edit().putBoolean(KEY_CFG_DECAY, on).apply()
    }

    fun setDepthCfgOff(on: Boolean) {
        _depthCfgOff.value = on
        sp.edit().putBoolean(KEY_DEPTH_CFG_OFF, on).apply()
    }

    fun setCfgDecayFrames(n: Int) {
        val v = n.coerceIn(4, 96)
        _cfgDecayFrames.value = v
        sp.edit().putInt(KEY_CFG_DECAY_FRAMES, v).apply()
    }

    fun setVocThreads(n: Int) {
        val v = n.coerceIn(0, 8)
        _vocThreads.value = v
        sp.edit().putInt(KEY_VOC_THREADS, v).apply()
    }

    /** 1.9.73 声码器分块上限：只在「下一次合成」生效，不需要重载权重。 */
    fun setVocChunk(n: Int) {
        val v = n.coerceIn(96, 512)
        _vocChunk.value = v
        sp.edit().putInt(KEY_VOC_CHUNK, v).apply()
    }

    fun setGpuVocoder(on: Boolean) {
        _gpuVocoder.value = on
        sp.edit().putBoolean(KEY_GPU_VOC, on).apply()
    }

    fun setReusePrefixEmb(on: Boolean) {
        _reusePrefixEmb.value = on
        sp.edit().putBoolean(KEY_REUSE_PREFIX_EMB, on).apply()
    }

    fun setLastRtf(v: Float) {
        if (v <= 0f || !v.isFinite()) return
        _lastRtf.value = v
        sp.edit().putFloat(KEY_LAST_RTF, v).apply()
    }

    /** 用实测音频时长校准「每单位时长」，慢慢收敛到本机 + 当前音色/语速的真实值。 */
    fun learnMsPerUnit(measured: Float) {
        if (measured <= 0f || !measured.isFinite()) return
        val old = _msPerUnit.value
        val next = if (old <= 0f) measured else old * 0.6f + measured * 0.4f
        val clamped = next.coerceIn(80f, 1_200f)
        _msPerUnit.value = clamped
        sp.edit().putFloat(KEY_MS_PER_UNIT, clamped).apply()
    }

    /**
     * 生成音频的全局递增序列号（用于「音色_台词_日期_序列号」命名）。
     * 单调递增且持久化，删除历史或清空结果都不会让新音频复用旧序号。
     */
    fun nextAudioSeq(): Int {
        val n = (sp.getInt(KEY_AUDIO_SEQ, 0) + 1).coerceAtMost(999_999)
        sp.edit().putInt(KEY_AUDIO_SEQ, n).apply()
        return n
    }

    companion object {
        private const val KEY_AUDIO_SEQ = "audio_seq"
        private const val KEY_EXPORT_URI = "export_tree_uri"
        private const val KEY_EXPORT_LABEL = "export_dir_label"
        private const val KEY_THREADS = "threads"
        private const val KEY_CFG_SCALE = "cfg_scale"
        private const val KEY_PHASE_THREADS = "phase_threads"
        private const val KEY_PHASE_MIGRATED_V2 = "phase_threads_migrated_v2"
        private const val KEY_LAST_RTF = "last_rtf"
        private const val KEY_MS_PER_UNIT = "ms_per_unit"
        private const val KEY_REUSE_PREFIX_EMB = "reuse_prefix_emb"
        private const val KEY_TURBO = "turbo_mode"
        private const val KEY_CORE_PIN = "core_pin"
        private const val KEY_PIN_MIGRATED_1944 = "core_pin_migrated_1944"
        private const val KEY_CFG_DECAY = "cfg_decay"
        private const val KEY_CFG_DECAY_FRAMES = "cfg_decay_frames"
        private const val KEY_DEPTH_CFG_OFF = "depth_cfg_off"
        private const val KEY_VOC_THREADS = "voc_threads"
        private const val KEY_VOC_CHUNK = "voc_chunk"
        private const val KEY_GPU_VOC = "gpu_vocoder"
        private const val KEY_DEPTH_CFG_RESET = "depth_cfg_off_reset_1_9_92"
        private const val KEY_DEV_MODE = "dev_mode"
        private const val KEY_LANGUAGE = "ui_language"
    }
}
