package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.breeze.tts.engine.VoiceProfile
import ai.breeze.tts.ui.theme.Breeze

// ============================================================
// 音色头像
//
// 没有自定义头像时用「名字首字 + 纯色圆底」。底色由性别决定而不是随机色：
// 一列头像的冷暖分布本身就是信息，同性别之间也不会撞色。刻意不用渐变——
// 渐变在 40dp 的小圆里读不出方向，只会显脏。
// ============================================================

/** 三个基础色：暖金（女）/ 冷青（男）/ 中性灰（未设置） */
private val FemaleBase = Color(0xFFD8B27E)
private val MaleBase = Color(0xFF8FB7CC)
private val NeutralBase = Color(0xFFA8A8B0)

/** 角标里的符号填充色（比头像底色亮，缩到 9dp 仍能分辨） */
private val FemaleMark = Color(0xFFFFB23E)
private val MaleMark = Color(0xFF8FB6C9)

/**
 * 头像底色 → 文字色。
 *
 * 不再是写死的深棕/深石板：那套在浅色主题下会变成「浅色卡片里按了四个深色圆点」，
 * 又重又脏。现在按主题现算——深色把基础色 20% 混进面底色，浅色混进白底，
 * 于是同一个色相在两套主题里都只是「一层很淡的色块」，字则分别取亮/暗端。
 */
@Composable
fun genderPalette(gender: VoiceProfile.Gender): Pair<Color, Color> {
    val c = Breeze.colors
    val base = when (gender) {
        VoiceProfile.Gender.FEMALE -> FemaleBase
        VoiceProfile.Gender.MALE -> MaleBase
        VoiceProfile.Gender.NONE -> NeutralBase
    }
    val bg = if (c.isDark) lerp(c.surface, base, 0.22f) else lerp(Color.White, base, 0.17f)
    val fg = if (c.isDark) lerp(base, Color.White, 0.10f) else lerp(base, Color(0xFF111111), 0.55f)
    return bg to fg
}

/** 角标符号色 */
fun genderMark(gender: VoiceProfile.Gender): Color = when (gender) {
    VoiceProfile.Gender.FEMALE -> FemaleMark
    VoiceProfile.Gender.MALE -> MaleMark
    VoiceProfile.Gender.NONE -> NeutralBase
}

private object AvatarCache {
    private val cache = LruCache<String, ImageBitmap>(48)

    fun get(path: String): ImageBitmap? {
        cache.get(path)?.let { return it }
        val bmp = runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull()
        if (bmp != null) cache.put(path, bmp)
        return bmp
    }
}

@Composable
fun rememberAvatarBitmap(path: String?): ImageBitmap? =
    remember(path) { if (path.isNullOrEmpty()) null else AvatarCache.get(path) }

/**
 * 音色头像。自定义头像 > 名字首字。
 *
 * @param size 头像直径；角标与字号按它等比缩放
 * @param selected 选中态：加一圈琥珀描边
 * @param showBadge 是否显示右下角性别角标
 * @param badgeBackground 角标外圈颜色，用来「挖空」头像边缘，跟随所在容器底色
 */
@Composable
fun VoiceAvatar(
    name: String,
    gender: VoiceProfile.Gender,
    avatarPath: String? = null,
    size: Dp = 44.dp,
    selected: Boolean = false,
    showBadge: Boolean = true,
    badgeBackground: Color = Breeze.colors.surface,
    modifier: Modifier = Modifier,
) {
    val (bg, fg) = genderPalette(gender)
    val bitmap = rememberAvatarBitmap(avatarPath)
    val initial = name.trim().firstOrNull()?.toString() ?: tr("音")

    Box(modifier.size(size)) {
        Box(
            Modifier
                .size(size)
                .clip(CircleShape)
                .background(bg)
                .then(
                    when {
                        selected -> Modifier.border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                        bitmap == null -> Modifier.border(
                            1.dp, fg.copy(alpha = 0.18f), CircleShape,
                        )
                        else -> Modifier
                    },
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (bitmap != null) {
                Image(
                    bitmap,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Text(
                    initial,
                    color = fg,
                    fontSize = (size.value * 0.38f).sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }

        if (showBadge && gender != VoiceProfile.Gender.NONE) {
            val badge = size * 0.36f
            GenderBadge(
                gender = gender,
                size = badge.coerceAtLeast(14.dp),
                borderColor = badgeBackground,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = size * 0.03f, y = size * 0.03f),
            )
        }
    }
}

/** 圆形性别角标：底色描边 + 实心符号 */
@Composable
fun GenderBadge(
    gender: VoiceProfile.Gender,
    size: Dp,
    borderColor: Color,
    modifier: Modifier = Modifier,
) {
    val mark = genderMark(gender)
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(borderColor),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(size * 0.80f)
                .clip(CircleShape)
                .background(mark),
            contentAlignment = Alignment.Center,
        ) {
            GenderGlyph(
                gender = gender,
                tint = Color(0xFF12100C),
                modifier = Modifier.size(size * 0.50f),
            )
        }
    }
}

/** ♀ / ♂ 的描边图形。用 Canvas 画而不是 emoji，避免不同系统字体差异。 */
@Composable
fun GenderGlyph(
    gender: VoiceProfile.Gender,
    tint: Color,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier) {
        val w = size.minDimension
        val sw = w * 0.14f
        val cap = StrokeCap.Round
        if (gender == VoiceProfile.Gender.MALE) {
            drawCircle(
                tint, radius = w * 0.235f, center = Offset(w * 0.37f, w * 0.64f),
                style = Stroke(width = sw),
            )
            drawLine(tint, Offset(w * 0.55f, w * 0.46f), Offset(w * 0.93f, w * 0.08f), sw, cap)
            drawLine(tint, Offset(w * 0.66f, w * 0.08f), Offset(w * 0.93f, w * 0.08f), sw, cap)
            drawLine(tint, Offset(w * 0.93f, w * 0.08f), Offset(w * 0.93f, w * 0.35f), sw, cap)
        } else {
            drawCircle(
                tint, radius = w * 0.235f, center = Offset(w * 0.5f, w * 0.33f),
                style = Stroke(width = sw),
            )
            drawLine(tint, Offset(w * 0.5f, w * 0.57f), Offset(w * 0.5f, w * 0.95f), sw, cap)
            drawLine(tint, Offset(w * 0.29f, w * 0.76f), Offset(w * 0.71f, w * 0.76f), sw, cap)
        }
    }
}

/** 性别文案 */
fun genderLabel(gender: VoiceProfile.Gender): String = when (gender) {
    VoiceProfile.Gender.FEMALE -> tr("女声")
    VoiceProfile.Gender.MALE -> tr("男声")
    VoiceProfile.Gender.NONE -> tr("未设置")
}
