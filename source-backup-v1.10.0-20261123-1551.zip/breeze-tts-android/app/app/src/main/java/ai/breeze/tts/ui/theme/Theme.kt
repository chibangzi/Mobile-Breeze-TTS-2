package ai.breeze.tts.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ============================================================
// 设计令牌（v2）
//
// 三条规则，界面里所有取值都从这里来：
//   1. 只用一种强调色（香槟金），一屏最多出现三处：下划线、选中态、主按钮；
//   2. 层级靠「1px 分隔线 + 字重 + 行高」建立，不靠卡片叠卡片；
//   3. 圆角只有 7 / 9 / 13 / 24 四档，字号只有 21 / 15 / 14.5 / 12.5 / 11 五档。
//
// 深浅两套同时提供：浅色不是把深色反相，而是各自重新定值——
// 深色主按钮用香槟金实心，浅色改用近黑（金压在白底上会显廉价）。
// ============================================================

@Immutable
data class BreezeColors(
    /** 页面底色 */
    val bg: Color,
    /** 卡片 / 输入区 / 浮层内的面 */
    val surface: Color,
    /** 浮层背板：比 surface 再亮/暗一档，叠在虚化画面上不糊成一片 */
    val surface2: Color,
    /** 1px 分隔线与细描边 */
    val line: Color,
    /** 需要被看见的描边（按钮、选中框） */
    val line2: Color,
    /** 主文字 */
    val t1: Color,
    /** 次要文字 */
    val t2: Color,
    /** 三级文字 / 标签 */
    val t3: Color,
    /** 强调色 */
    val accent: Color,
    /** 压在强调色上的字色 */
    val onAccent: Color,
    /** 强调色的浅底 */
    val accentSoft: Color,
    /** 主按钮底色（深色=金，浅色=近黑） */
    val btnBg: Color,
    /** 主按钮字色 */
    val btnInk: Color,
    /** 轻填充：小按钮、搜索框 */
    val fill: Color,
    /** 重填充：分段控件、内嵌块 */
    val fill2: Color,
    /** 破坏性操作（停止 / 删除） */
    val warn: Color,
    val warnSoft: Color,
    val warnLine: Color,
    val isDark: Boolean,
)

private val DarkBreeze = BreezeColors(
    bg = Color(0xFF08080A),
    surface = Color(0xFF0E0E11),
    surface2 = Color(0xFF131317),
    line = Color.White.copy(alpha = 0.065f),
    line2 = Color.White.copy(alpha = 0.11f),
    t1 = Color(0xFFEDEDEF),
    t2 = Color(0xFF8E8E97),
    t3 = Color(0xFF6B6B75),
    accent = Color(0xFFD8B27E),
    onAccent = Color(0xFF191106),
    accentSoft = Color(0xFFD8B27E).copy(alpha = 0.15f),
    btnBg = Color(0xFFD8B27E),
    btnInk = Color(0xFF191106),
    fill = Color.White.copy(alpha = 0.05f),
    fill2 = Color.White.copy(alpha = 0.085f),
    warn = Color(0xFFE0925C),
    warnSoft = Color(0xFFE0925C).copy(alpha = 0.13f),
    warnLine = Color(0xFFE0925C).copy(alpha = 0.30f),
    isDark = true,
)

private val LightBreeze = BreezeColors(
    bg = Color(0xFFF2F1EE),
    surface = Color(0xFFFFFFFF),
    surface2 = Color(0xFFFBFBFA),
    line = Color.Black.copy(alpha = 0.075f),
    line2 = Color.Black.copy(alpha = 0.13f),
    t1 = Color(0xFF16161A),
    t2 = Color(0xFF6E6E77),
    t3 = Color(0xFF97979F),
    accent = Color(0xFF8B6A32),
    onAccent = Color(0xFFFFFFFF),
    accentSoft = Color(0xFF8B6A32).copy(alpha = 0.09f),
    btnBg = Color(0xFF1B1A18),
    btnInk = Color(0xFFFAF8F4),
    fill = Color.Black.copy(alpha = 0.038f),
    fill2 = Color.Black.copy(alpha = 0.07f),
    warn = Color(0xFFB5633C),
    warnSoft = Color(0xFFB5633C).copy(alpha = 0.09f),
    warnLine = Color(0xFFB5633C).copy(alpha = 0.22f),
    isDark = false,
)

private val LocalBreezeColors = staticCompositionLocalOf { DarkBreeze }

/** 令牌入口：`Breeze.colors.accent`。只在 @Composable 里读。 */
object Breeze {
    val colors: BreezeColors
        @Composable @ReadOnlyComposable get() = LocalBreezeColors.current
}

// ---- 尺寸令牌 ----

object BreezeSize {
    /** 表单行高 */
    val rowHeight = 54.dp
    /** 单行紧凑行高（参数行） */
    val rowSlim = 46.dp
    /** 主按钮高 */
    val button = 48.dp
    /** 浮层/弹窗内按钮高 */
    val buttonSmall = 44.dp
    /** 弹窗内紧凑按钮高 */
    val buttonTiny = 40.dp
    /** 输入区高度 */
    val editor = 168.dp
    /** 浮层顶部圆角 */
    val sheet = 24.dp
    /** 页面水平边距 */
    val gutter = 18.dp
}

private fun breezeScheme(c: BreezeColors, dark: Boolean) = if (dark) {
    darkColorScheme(
        primary = c.accent,
        onPrimary = c.onAccent,
        primaryContainer = c.accentSoft,
        onPrimaryContainer = c.accent,
        secondary = c.accent,
        onSecondary = c.onAccent,
        secondaryContainer = c.accentSoft,
        onSecondaryContainer = c.accent,
        tertiary = c.t2,
        onTertiary = c.t1,
        error = Color(0xFFE5484D),
        onError = Color(0xFF2B0808),
        background = c.bg,
        onBackground = c.t1,
        surface = c.surface,
        onSurface = c.t1,
        surfaceVariant = c.surface2,
        onSurfaceVariant = c.t2,
        outline = c.line2,
        outlineVariant = c.line,
        inverseSurface = c.t1,
        inverseOnSurface = c.bg,
        scrim = Color.Black,
    )
} else {
    lightColorScheme(
        primary = c.accent,
        onPrimary = c.onAccent,
        primaryContainer = c.accentSoft,
        onPrimaryContainer = c.accent,
        secondary = c.accent,
        onSecondary = c.onAccent,
        secondaryContainer = c.accentSoft,
        onSecondaryContainer = c.accent,
        tertiary = c.t2,
        onTertiary = c.t1,
        error = Color(0xFFC0392B),
        onError = Color.White,
        background = c.bg,
        onBackground = c.t1,
        surface = c.surface,
        onSurface = c.t1,
        surfaceVariant = c.surface2,
        onSurfaceVariant = c.t2,
        outline = c.line2,
        outlineVariant = c.line,
        inverseSurface = c.t1,
        inverseOnSurface = c.bg,
        scrim = Color.Black,
    )
}

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(7.dp),
    small = RoundedCornerShape(9.dp),
    medium = RoundedCornerShape(13.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp),
)

/**
 * 字号只有五档，层级靠字重与颜色区分。
 * 行高按 1.55–1.78 倍给足，中文密集时不会挤。
 */
private val AppTypography = Typography(
    headlineLarge = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.SemiBold, lineHeight = 33.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontSize = 21.sp, fontWeight = FontWeight.SemiBold, lineHeight = 27.sp, letterSpacing = (-0.3).sp),
    headlineSmall = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.SemiBold, lineHeight = 24.sp, letterSpacing = (-0.2).sp),
    titleLarge = TextStyle(fontSize = 15.5.sp, fontWeight = FontWeight.SemiBold, lineHeight = 22.sp),
    titleMedium = TextStyle(fontSize = 14.5.sp, fontWeight = FontWeight.Medium, lineHeight = 21.sp),
    titleSmall = TextStyle(fontSize = 13.5.sp, fontWeight = FontWeight.Medium, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontSize = 14.5.sp, fontWeight = FontWeight.Normal, lineHeight = 26.sp, letterSpacing = 0.05.sp),
    bodyMedium = TextStyle(fontSize = 13.5.sp, fontWeight = FontWeight.Normal, lineHeight = 22.sp),
    bodySmall = TextStyle(fontSize = 12.5.sp, fontWeight = FontWeight.Normal, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.SemiBold, lineHeight = 18.sp),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium, lineHeight = 16.sp),
    labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Normal, lineHeight = 15.sp, letterSpacing = 0.02.sp),
)

/**
 * 渐变只剩两处用途：播放键的圆形底、以及少数「正在播放」的强调。
 * 不再是「所有主按钮都套一层渐变」——纯色更稳，也更像工具软件。
 */
object BreezeGradients {
    val brand: Brush = Brush.linearGradient(listOf(Color(0xFFD8B27E), Color(0xFFC79E68)))
    val warm: Brush = Brush.linearGradient(listOf(Color(0xFFE3C193), Color(0xFFD8B27E)))
    val mint: Brush = Brush.linearGradient(listOf(Color(0xFFD8B27E), Color(0xFFC79E68)))
    /** 浮层与卡片顶部的一条极细暖光 */
    val hairline: Brush = Brush.horizontalGradient(
        listOf(Color(0xFFD8B27E).copy(alpha = 0.42f), Color(0xFFD8B27E).copy(alpha = 0.08f), Color.Transparent),
    )
    val transparent: Brush = Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
}

// ---- 旧名兼容：文件里还有引用，值随主题走 ----

val Amber: Color get() = Color(0xFFD8B27E)
val AmberDeep: Color get() = Color(0xFFC79E68)
val AmberSoft: Color get() = Color(0xFFE3C193)
val Gold: Color get() = Color(0xFFC79A4A)
val Sand: Color get() = Color(0xFFD8C79A)
val Ink: Color get() = Color(0xFF08080A)
val Coal: Color get() = Color(0xFF0E0E11)
val Ash: Color get() = Color(0xFF131317)
val Hairline: Color get() = Color(0x14FFFFFF)
val SheetSurface: Color get() = Color(0xFF131317)
val SheetOutline: Color get() = Color(0x1CFFFFFF)

val BrandBlue: Color get() = Color(0xFFD8B27E)
val BrandViolet: Color get() = Color(0xFFC79E68)
val BrandMint: Color get() = Color(0xFFD8B27E)
val BrandWarm: Color get() = Color(0xFFE3C193)

@Composable
fun BreezeTheme(
    darkTheme: Boolean = androidx.compose.foundation.isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val c = if (darkTheme) DarkBreeze else LightBreeze
    CompositionLocalProvider(LocalBreezeColors provides c) {
        MaterialTheme(
            colorScheme = breezeScheme(c, darkTheme),
            typography = AppTypography,
            shapes = AppShapes,
        ) {
            // Material3 的 LocalTextStyle 默认取 bodyLarge（14.5sp / 行高 26sp）。
            // 直接写 Text(fontSize = 11.sp) 时字号变了、行高却仍是 26sp，
            // 放进 28–32dp 的胶囊 / 标签行就会被上下裁掉半截（「已全选」只剩上半）。
            // 这里把默认行高还原成 Unspecified，让每个 Text 按自身字号取自然行距；
            // 段落类文字本来就显式写了 lineHeight，不受影响。
            CompositionLocalProvider(
                LocalTextStyle provides LocalTextStyle.current.copy(lineHeight = TextUnit.Unspecified),
            ) {
                content()
            }
        }
    }
}
