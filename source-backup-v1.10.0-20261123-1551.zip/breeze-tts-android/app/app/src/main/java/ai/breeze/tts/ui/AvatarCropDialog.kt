package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.draw.clip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 头像裁切。
 *
 * 旧流程是「选图即保存」，仓库里再做一次居中裁方——用户想留的那半张脸经常被切掉。
 * 现在选完图先进这个裁剪框：双指缩放、单指拖动，圆形区域内就是最终头像；
 * 确认后才以 256×256 JPEG 落盘。
 */
@Composable
fun AvatarCropDialog(
    uri: Uri,
    onConfirm: (Bitmap) -> Unit,
    onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    var source by remember(uri) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(uri) { mutableStateOf(false) }

    LaunchedEffect(uri) {
        val bmp = withContext(Dispatchers.IO) { decodeForCrop(ctx, uri) }
        source = bmp
        failed = bmp == null
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
        ),
    ) {
        // 裁切界面在两套主题下都用深色：照片边缘需要暗底才看得准，
        // 用页面底色会出现「浅色主题下白底衬一张暗图」的割裂感。
        Box(Modifier.fillMaxSize().background(CropBg)) {
            val bmp = source
            when {
                failed -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(tr("这张图片读不出来，换一张试试"), fontSize = 13.sp, color = CropTextDim)
                }
                bmp == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = CropAccent,
                    )
                }
                else -> CropStage(bmp, onConfirm, onDismiss)
            }
        }
    }
}

@Composable
private fun CropStage(source: Bitmap, onConfirm: (Bitmap) -> Unit, onDismiss: () -> Unit) {
    val img = remember(source) { source.asImageBitmap() }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    // 屏幕像素 / 源像素：缩放 1 时短边刚好铺满圆形区域
    fun baseScale(sidePx: Float) = sidePx / min(source.width, source.height).toFloat()

    fun clampedPan(sidePx: Float, z: Float): Offset {
        val b = baseScale(sidePx) * z
        val maxX = max(0f, (source.width * b - sidePx) / 2f)
        val maxY = max(0f, (source.height * b - sidePx) / 2f)
        return Offset(pan.x.coerceIn(-maxX, maxX), pan.y.coerceIn(-maxY, maxY))
    }

    fun crop(): Bitmap? {
        val cw = canvasSize.width
        val ch = canvasSize.height
        if (cw <= 0 || ch <= 0) return null
        val side = min(cw, ch).toFloat()
        val scale = baseScale(side) * zoom
        if (scale <= 0f) return null
        val p = clampedPan(side, zoom)
        val dw = source.width * scale
        val dh = source.height * scale
        val left = (cw - dw) / 2f + p.x
        val top = (ch - dh) / 2f + p.y
        val sx = ((cw - side) / 2f - left) / scale
        val sy = ((ch - side) / 2f - top) / scale
        val sSide = side / scale

        val x = sx.roundToInt().coerceIn(0, (source.width - 1).coerceAtLeast(0))
        val y = sy.roundToInt().coerceIn(0, (source.height - 1).coerceAtLeast(0))
        val edge = min(
            sSide.roundToInt().coerceAtLeast(1),
            min(source.width - x, source.height - y),
        )
        return runCatching {
            val cropped = Bitmap.createBitmap(source, x, y, edge, edge)
            val out = Bitmap.createScaledBitmap(cropped, 256, 256, true)
            if (out !== cropped) cropped.recycle()
            out
        }.getOrNull()
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(26.dp))
        Text(tr("调整头像"), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = CropText)
        Spacer(Modifier.height(5.dp))
        Text(tr("双指缩放，拖动选择要用的部分"), fontSize = 11.5.sp, lineHeight = 16.sp, color = CropTextDim)

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(source) {
                        detectTransformGestures { _, panDelta, zoomDelta, _ ->
                            val side = min(size.width, size.height).toFloat()
                            val nz = (zoom * zoomDelta).coerceIn(1f, 4f)
                            val maxX = max(0f, (source.width * baseScale(side) * nz - side) / 2f)
                            val maxY = max(0f, (source.height * baseScale(side) * nz - side) / 2f)
                            zoom = nz
                            pan = Offset(
                                (pan.x + panDelta.x).coerceIn(-maxX, maxX),
                                (pan.y + panDelta.y).coerceIn(-maxY, maxY),
                            )
                        }
                    },
            ) {
                val side = min(size.width, size.height)
                val scale = baseScale(side)
                val dw = source.width * scale
                val dh = source.height * scale
                val p = clampedPan(side, zoom)
                val left = (size.width - dw) / 2f + p.x
                val top = (size.height - dh) / 2f + p.y
                val dst = IntOffset(left.roundToInt(), top.roundToInt())
                val dstSize = IntSize(dw.roundToInt(), dh.roundToInt())
                val srcSize = IntSize(source.width, source.height)

                // 先铺一层图，再用半透明黑压暗，最后在圆形区域内重绘一次——
                // 三步合起来才是「圆外变暗、圆内保持原亮度」的效果。
                drawImage(img, IntOffset.Zero, srcSize, dst, dstSize, filterQuality = FilterQuality.Medium)
                drawRect(Color.Black.copy(alpha = 0.68f))
                val center = Offset(size.width / 2f, size.height / 2f)
                val circle = Path().apply { addOval(Rect(center = center, radius = side / 2f)) }
                clipPath(circle) {
                    drawImage(
                        img, IntOffset.Zero, srcSize, dst, dstSize,
                        filterQuality = FilterQuality.Medium,
                    )
                }
                drawCircle(
                    Color.White.copy(alpha = 0.3f),
                    radius = side / 2f,
                    center = center,
                    style = Stroke(1.4.dp.toPx()),
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("缩放"), fontSize = 11.sp, color = CropTextDim)
            Slider(
                value = zoom,
                onValueChange = {
                    zoom = it
                    val side = min(canvasSize.width, canvasSize.height).toFloat()
                    if (side > 0) pan = clampedPan(side, it)
                },
                valueRange = 1f..4f,
                modifier = Modifier.weight(1f).height(34.dp).padding(horizontal = 6.dp),
                colors = SliderDefaults.colors(
                    thumbColor = CropAccent,
                    activeTrackColor = CropAccent,
                    inactiveTrackColor = Color.White.copy(alpha = 0.16f),
                ),
            )
            Text("%.1f×".format(zoom), fontSize = 11.sp, color = CropTextDim, modifier = Modifier.width(30.dp))
        }

        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            CropButton(
                text = tr("取消"),
                onClick = onDismiss,
                filled = false,
                modifier = Modifier.weight(1f),
            )
            CropButton(
                text = tr("使用这张"),
                onClick = { crop()?.let(onConfirm) },
                filled = true,
                modifier = Modifier.weight(1.4f),
            )
        }
        Spacer(Modifier.height(22.dp))
    }
}

/** 解码到最长边 ~1600，够裁切用又不至于吃掉几十 MB 内存 */
private fun decodeForCrop(ctx: Context, uri: Uri): Bitmap? = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

    var sample = 1
    while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
}.getOrNull()

private val CropBg = Color(0xFF0B0B0D)
private val CropText = Color(0xFFEDEDEF)
private val CropTextDim = Color(0xFF8E8E97)
private val CropAccent = Color(0xFFD8B27E)

@Composable
private fun CropButton(
    text: String,
    onClick: () -> Unit,
    filled: Boolean,
    modifier: Modifier = Modifier,
) {
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(13.dp)
    Box(
        modifier
            .height(44.dp)
            .clip(shape)
            .background(if (filled) CropAccent else Color.White.copy(alpha = 0.07f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            fontSize = 13.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (filled) Color(0xFF191106) else CropTextDim,
            maxLines = 1,
            softWrap = false,
        )
    }
}
