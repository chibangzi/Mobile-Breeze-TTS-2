package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.breeze.tts.ui.theme.Breeze
import kotlin.math.roundToInt

/**
 * 左滑露出操作按钮（导出 / 删除）。手指横拖跟手，松手按位移决定吸附到展开还是收起。
 *
 * 操作区宽度按按钮个数算，所以「一个按钮」和「两个按钮」共用同一套逻辑；
 * 点击任意按钮后先收起再执行，避免下一次滑动从展开态开始、看起来像卡住。
 *
 * v2 的变化：行本身不再有圆角和 `surface` 底色——收藏列表是「清单」，
 * 每行和页面同色，只有 1px 分隔线；底色由调用方通过 [rowBackground] 传入。
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SwipeToDeleteRow(
    onDelete: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onExport: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    rowBackground: Color = Breeze.colors.bg,
    content: @Composable RowScope.() -> Unit,
) {
    val c = Breeze.colors
    val density = LocalDensity.current
    val actionWidth = 84.dp
    val revealPx = with(density) { (actionWidth * (if (onExport != null) 2 else 1)).toPx() }
    var offset by remember { mutableFloatStateOf(0f) }
    val animated by animateFloatAsState(targetValue = offset, label = "swipe")
    val revealed = offset < -revealPx / 2

    Box(modifier.fillMaxWidth()) {
        Row(
            Modifier.matchParentSize(),
            horizontalArrangement = Arrangement.End,
        ) {
            if (onExport != null) {
                SwipeAction(tr("导出"), Icons.Outlined.Share, c.fill2, c.t1, actionWidth) {
                    offset = 0f
                    onExport()
                }
            }
            SwipeAction(tr("删除"), Icons.Outlined.Delete, c.warn, Color.White, actionWidth) {
                offset = 0f
                onDelete()
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .offset { IntOffset(animated.roundToInt(), 0) }
                .background(rowBackground)
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragEnd = { offset = if (offset < -revealPx / 2) -revealPx else 0f },
                        onHorizontalDrag = { _, delta ->
                            offset = (offset + delta).coerceIn(-revealPx, 0f)
                        },
                    )
                }
                .combinedClickable(
                    onClick = { if (revealed) offset = 0f else onClick() },
                    onLongClick = onLongClick,
                )
                .padding(horizontal = 18.dp)
                .height(66.dp),
            verticalAlignment = Alignment.CenterVertically,
            content = content,
        )
    }
}

/** 左滑操作区里的一个按钮：图标 + 文案，整格可点。 */
@Composable
private fun SwipeAction(
    label: String,
    icon: ImageVector,
    background: Color,
    tint: Color,
    width: Dp,
    onClick: () -> Unit,
) {
    Box(
        Modifier
            .width(width)
            .fillMaxHeight()
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(19.dp))
            Spacer(Modifier.height(3.dp))
            Text(label, fontSize = 11.sp, color = tint)
        }
    }
}
