package ai.breeze.tts.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeSize

/**
 * 全 App 统一的按钮（v2）。
 *
 * 旧版有三套并存：琥珀渐变的 GradientButton(52dp)、胶囊 SmallPill(32dp)、
 * 浮层里的 SheetButton(46dp)。同一屏并排时高度、圆角、字重都不一样。
 *
 * 现在只有一种形状：**圆角 13 / 13sp SemiBold / 单行不换行**，高度只分三档
 * （48 主操作 · 44 浮层 · 40 弹窗内并排）。主次全靠底色区分：
 *   Primary 主按钮底色（深色=香槟金 / 浅色=近黑）
 *   Soft    灰底 + 描边，用于「再次生成」这类会改变状态的次要动作
 *   Ghost   无底无边，纯文字，用于「取消」
 *   Warn    橙底橙字，只用于「停止 / 删除」这类破坏性操作
 */
enum class BreezeTone { Primary, Soft, Ghost, Warn }

@Composable
fun BreezeButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tone: BreezeTone = BreezeTone.Ghost,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    height: Dp = BreezeSize.buttonSmall,
) {
    val c = Breeze.colors
    val bg = when (tone) {
        BreezeTone.Primary -> c.btnBg
        BreezeTone.Soft -> c.fill2
        BreezeTone.Ghost -> Color.Transparent
        BreezeTone.Warn -> c.warnSoft
    }
    val fg = when (tone) {
        BreezeTone.Primary -> c.btnInk
        BreezeTone.Soft -> c.t1
        BreezeTone.Ghost -> c.t2
        BreezeTone.Warn -> c.warn
    }
    val borderColor = when (tone) {
        BreezeTone.Primary -> Color.Transparent
        BreezeTone.Soft -> c.line2
        BreezeTone.Ghost -> Color.Transparent
        BreezeTone.Warn -> c.warnLine
    }
    val shape = RoundedCornerShape(13.dp)

    Row(
        modifier
            .height(height)
            .alpha(if (enabled) 1f else 0.34f)
            .clip(shape)
            .background(bg)
            .border(1.dp, borderColor, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(
            text,
            fontSize = 13.sp,
            lineHeight = 16.sp,
            fontWeight = if (tone == BreezeTone.Primary) FontWeight.SemiBold else FontWeight.Medium,
            color = fg,
            // 四个字在 1/3 宽度里曾被折成两行：这里同时锁单行和锁软换行
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}

/** 全宽主按钮：合成页底部那一颗，也用于浮层的「应用」 */
@Composable
fun BreezePrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    height: Dp = BreezeSize.button,
) {
    val c = Breeze.colors
    val shape = RoundedCornerShape(13.dp)
    Row(
        modifier
            .height(height)
            .alpha(if (enabled) 1f else 0.34f)
            .clip(shape)
            .background(c.btnBg)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = c.btnInk, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(7.dp))
        }
        Text(
            text,
            fontSize = 15.sp,
            lineHeight = 19.sp,
            fontWeight = FontWeight.SemiBold,
            color = c.btnInk,
            letterSpacing = 0.3.sp,
            maxLines = 1,
            softWrap = false,
        )
    }
}

/**
 * 文字页签（下划线式）。
 *
 * 取代原来的分段胶囊：胶囊在顶部会造出第二个视觉焦点，让人以为那是「模式开关」；
 * 文字 tab 只改颜色和一条 1.5dp 的下划线，页头才是唯一焦点。
 */
@Composable
fun WordTabs(
    labels: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    gap: Dp = 24.dp,
) {
    val c = Breeze.colors
    Box(modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
            labels.forEachIndexed { i, label ->
                val on = i == selectedIndex
                Column(
                    Modifier
                        // 下划线要贴着文字宽度走：Column 取子项固有宽度，
                        // 否则里面的 fillMaxWidth 会把整行撑满、把后面的 tab 挤出去
                        .width(IntrinsicSize.Max)
                        .clickable { onSelect(i) }
                        .padding(top = 2.dp),
                ) {
                    Text(
                        label,
                        fontSize = 13.5.sp,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (on) c.t1 else c.t3,
                        maxLines = 1,
                    )
                    Spacer(Modifier.height(9.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(1.5.dp)
                            .background(if (on) c.accent else Color.Transparent),
                    )
                }
            }
            Spacer(Modifier.weight(1f))
        }
        // 整行的基线：1px，选中项用 accent 覆盖在上面 1.5dp 处
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .height(1.dp)
                .background(c.line),
        )
    }
}

/** 圆形勾选：19dp。未选中留空环，选中变实心 + 白勾，右边缘不会随状态抖动。 */
@Composable
fun CircleCheck(
    selected: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 19.dp,
    color: Color? = null,
) {
    val c = Breeze.colors
    val tint = color ?: c.accent
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(if (selected) tint else Color.Transparent)
            .border(1.5.dp, if (selected) tint else c.line2, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Icon(
                Icons.Outlined.Check,
                contentDescription = null,
                tint = if (tint == c.accent) c.onAccent else Color.White,
                modifier = Modifier.size(size * 0.52f),
            )
        }
    }
}

/** 浮层/弹窗顶部：标题 17sp + 可选右上角文字动作 + 关闭 */
@Composable
fun SheetTopBar(
    title: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    action: String? = null,
    onAction: (() -> Unit)? = null,
) {
    val c = Breeze.colors
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 16.dp, top = 4.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            color = c.t1,
            letterSpacing = (-0.2).sp,
            modifier = Modifier.weight(1f),
            maxLines = 1,
        )
        if (action != null && onAction != null) {
            Text(
                action,
                fontSize = 12.5.sp,
                color = c.accent,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(7.dp))
                    .clickable(onClick = onAction)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
            )
            Spacer(Modifier.width(2.dp))
        }
        CircleClose(onClose)
    }
}

/** 32dp 圆形关闭钮 */
@Composable
fun CircleClose(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = Breeze.colors
    Box(
        modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(c.fill)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        // 用两条 1.5dp 的线画叉，避免依赖 material-icons-extended
        androidx.compose.foundation.Canvas(Modifier.size(12.dp)) {
            val sw = 1.5.dp.toPx()
            drawLine(
                c.t2,
                androidx.compose.ui.geometry.Offset(0f, 0f),
                androidx.compose.ui.geometry.Offset(size.width, size.height),
                sw,
                androidx.compose.ui.graphics.StrokeCap.Round,
            )
            drawLine(
                c.t2,
                androidx.compose.ui.geometry.Offset(size.width, 0f),
                androidx.compose.ui.geometry.Offset(0f, size.height),
                sw,
                androidx.compose.ui.graphics.StrokeCap.Round,
            )
        }
    }
}

/** 1px 分隔线，行与行之间唯一的边界。 */
@Composable
fun HairlineDivider(modifier: Modifier = Modifier, startPadding: Dp = 0.dp) {
    Box(
        modifier
            .fillMaxWidth()
            .padding(start = startPadding)
            .height(1.dp)
            .background(Breeze.colors.line),
    )
}

/**
 * 无下划线的文字筛选器（浮层内用）。
 *
 * 和 [WordTabs] 的区别：不带基线，只靠颜色和字重区分选中项。
 * 浮层里已经有一条顶部圆角和一颗主按钮，再多一条横线会显得碎。
 */
@Composable
fun InlineTabs(
    labels: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    gap: Dp = 20.dp,
) {
    val c = Breeze.colors
    Row(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(gap),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        labels.forEachIndexed { i, label ->
            val on = i == selectedIndex
            Text(
                label,
                fontSize = 13.sp,
                fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                color = if (on) c.t1 else c.t3,
                maxLines = 1,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable { onSelect(i) }
                    .padding(vertical = 3.dp),
            )
        }
    }
}

@Composable
fun RowScope.FlexSpacer() {
    Spacer(Modifier.weight(1f))
}
