package ai.breeze.tts.data

import ai.breeze.tts.i18n.tr

import android.content.Context
import android.util.Log
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineSenseVoiceModelConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import ai.breeze.tts.audio.AudioDecoder
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * 端上离线 ASR：sherpa-onnx + SenseVoice（中/英/日/韩/粤）。
 *
 * 相比 1.1 版的 Vosk small-cn（42 MB），SenseVoice 是阿里 FunAudioLLM 的大模型，
 * 中文带标点、抗噪、专名与长句准确率都高一个量级。模型更大，但用户可接受：
 *  - 标准 int8：约 239 MB（默认，精度损失极小、手机跑得快）
 *  - 高精度 FP32：约 938 MB
 * 两个档位按需下载、可切换；识别全程本地，音频不上传。
 *
 * 参考音频（含 mp3/m4a/aac/ogg）已由 AudioDecoder 归一成 24 kHz WAV，
 * 这里再重采样到 16 kHz float 喂给识别器。
 */
class SpeechRepository(private val app: Context) {

    data class Variant(
        val id: String,
        val title: String,
        val subtitle: String,
        val remoteName: String,
        val approximateBytes: Long,
    )

    private val dir: File get() = File(app.filesDir, "asr/sense-voice").apply { if (!exists()) mkdirs() }
    private val tokens: File get() = File(dir, "tokens.txt")
    private val sp = app.getSharedPreferences("breeze_asr", Context.MODE_PRIVATE)

    private val _installing = MutableStateFlow<String?>(null)
    val installing: StateFlow<String?> = _installing.asStateFlow()

    private val _variantId = MutableStateFlow(sp.getString(KEY_VARIANT, "int8") ?: "int8")
    val variantId: StateFlow<String> = _variantId.asStateFlow()

    private fun modelFile(v: Variant) = File(dir, v.remoteName)

    fun variants(): List<Variant> = VARIANTS
    fun variant(id: String = _variantId.value): Variant =
        VARIANTS.firstOrNull { it.id == id } ?: VARIANTS.first()

    fun selectVariant(id: String) {
        _variantId.value = id
        sp.edit().putString(KEY_VARIANT, id).apply()
    }

    /** 当前选中档位是否已完整安装（也用于 UI 显示各档位状态）。 */
    fun isInstalled(id: String = _variantId.value): Boolean {
        val v = VARIANTS.firstOrNull { it.id == id } ?: return false
        return tokens.isFile && tokens.length() > 10_000 && modelFile(v).length() > MIN_MODEL_BYTES
    }

    fun installedSize(id: String): Long {
        val v = VARIANTS.firstOrNull { it.id == id } ?: return 0
        return if (isInstalled(id)) modelFile(v).length() + tokens.length() else 0
    }

    /** 删除某档位模型文件（tokens 共用，保留）。 */
    fun delete(id: String): Boolean {
        val v = VARIANTS.firstOrNull { it.id == id } ?: return false
        val f = modelFile(v)
        return !f.exists() || f.delete()
    }

    /** 下载 tokens + 指定档位模型；多源回退、Range 续传、失败清理半成品。 */
    suspend fun install(id: String = _variantId.value): Result<Unit> = withContext(Dispatchers.IO) {
        val v = variant(id)
        try {
            dir.mkdirs()
            if (!tokens.isFile || tokens.length() < 10_000) {
                _installing.value = tr("正在下载词表…")
                fetchAny(v, "tokens.txt", tokens) { _, _ -> }
            }
            if (tokens.length() < 10_000) error(tr("词表下载不完整，请重试"))

            val target = modelFile(v)
            if (target.length() > MIN_MODEL_BYTES) return@withContext Result.success(Unit)
            fetchAny(v, v.remoteName, target) { done, total ->
                _installing.value = if (total > 0) {
                    tr("下载识别模型 ${done / 1_000_000} / ${total / 1_000_000} MB", "Downloading recognition model ${done / 1_000_000} / ${total / 1_000_000} MB")
                } else tr("下载识别模型 ${done / 1_000_000} MB…", "Downloading recognition model ${done / 1_000_000} MB…")
            }
            if (target.length() <= MIN_MODEL_BYTES) error(tr("模型文件不完整，请重试"))
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.e(TAG, "install asr model", t)
            Result.failure(t)
        } finally {
            _installing.value = null
        }
    }

    /** 依次尝试 hf-mirror / 官方源，任一成功即返回。 */
    private fun fetchAny(v: Variant, remote: String, target: File, onProgress: (Long, Long) -> Unit) {
        var last: Throwable? = null
        for (base in roots()) {
            try {
                download("$base/$remote", target, onProgress)
                return
            } catch (t: Throwable) {
                last = t
                Log.w(TAG, "asr $remote via $base failed: ${t.message}")
                target.delete()
            }
        }
        throw last ?: IllegalStateException(tr("下载失败"))
    }

    private fun roots(): List<String> {
        val official = "https://huggingface.co/$REPO/resolve/main"
        val mirror = "https://hf-mirror.com/$REPO/resolve/main"
        return listOf(mirror, official)
    }

    private fun download(urlStr: String, target: File, onProgress: (Long, Long) -> Unit) {
        val resume = if (target.isFile) target.length() else 0L
        val c = URL(urlStr).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 90_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "BreezeTTS-Android/1.2")
        if (resume > 0) c.setRequestProperty("Range", "bytes=$resume-")
        try {
            c.connect()
            val code = c.responseCode
            if (code !in 200..299) error("HTTP $code")
            val append = code == HttpURLConnection.HTTP_PARTIAL && resume > 0
            if (!append && resume > 0) target.delete()
            val effectiveStart = if (append) resume else 0L
            val total = c.getHeaderFieldLong("Content-Length", -1L) + effectiveStart

            target.parentFile?.mkdirs()
            FileOutputStream(target, append).use { fos ->
                c.inputStream.use { ins ->
                    val buf = ByteArray(256 * 1024)
                    var done = 0L
                    var last = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n <= 0) break
                        fos.write(buf, 0, n)
                        done += n
                        if (done - last >= 512 * 1024) {
                            last = done
                            onProgress(effectiveStart + done, total)
                        }
                    }
                    onProgress(effectiveStart + done, total)
                }
            }
            if (target.length() < 1000) error(tr("下载内容过小，疑似错误页"))
        } finally {
            c.disconnect()
        }
    }

    /** 转写归一化后的 24 kHz WAV。在 IO 线程调用；识别器用完即释放，不长期占内存。 */
    suspend fun transcribe(wav: File): Result<String> = withContext(Dispatchers.IO) {
        val id = _variantId.value
        if (!isInstalled(id)) {
            return@withContext Result.failure(IllegalStateException(tr("尚未安装离线识别模型")))
        }
        var recognizer: OfflineRecognizer? = null
        var stream: com.k2fsa.sherpa.onnx.OfflineStream? = null
        try {
            val samples = AudioDecoder.toAsrFloat(wav)
                ?: return@withContext Result.failure(IllegalStateException(tr("参考音频不是有效的 PCM WAV")))
            if (samples.isEmpty()) {
                return@withContext Result.failure(IllegalStateException(tr("参考音频为空")))
            }

            val sense = OfflineSenseVoiceModelConfig().apply {
                model = modelFile(variant(id)).absolutePath
                language = "auto"
                useInverseTextNormalization = true
            }
            val modelCfg = OfflineModelConfig().apply {
                senseVoice = sense
                tokens = this@SpeechRepository.tokens.absolutePath
                numThreads = 2
                debug = false
                provider = "cpu"
                modelType = ""
            }
            val cfg = OfflineRecognizerConfig().apply {
                featConfig = FeatureConfig()
                modelConfig = modelCfg
                decodingMethod = "greedy_search"
            }
            // assetManager = null → 走 newFromFile，直接读绝对路径
            recognizer = OfflineRecognizer(null, cfg)
            stream = recognizer.createStream()
            stream.acceptWaveform(samples, AudioDecoder.ASR_RATE)
            recognizer.decode(stream)
            val raw = recognizer.getResult(stream).text
            val clean = normalize(raw)
            if (clean.isEmpty()) {
                return@withContext Result.failure(IllegalStateException(tr("没有识别到语音，请检查音频后重试")))
            }
            Result.success(clean)
        } catch (t: Throwable) {
            Log.e(TAG, "transcribe", t)
            Result.failure(t)
        } finally {
            runCatching { stream?.release() }
            runCatching { recognizer?.release() }
        }
    }

    /** 去掉 SenseVoice 的 <|zh|><|NEUTRAL|><|Speech|> 等标签，并处理中英文空格。 */
    private fun normalize(raw: String): String {
        var s = raw.trim().replace(Regex("<\\|[^|]*\\|>"), "")
        s = s.replace(Regex("\\s+"), " ").trim()
        val cjk = s.count { it in '\u4e00'..'\u9fff' }
        return if (s.isNotEmpty() && cjk * 2 >= s.length) s.replace(" ", "") else s
    }

    companion object {
        private const val TAG = "SpeechRepo"
        private const val KEY_VARIANT = "variant"
        private const val MIN_MODEL_BYTES = 1L shl 20
        private const val REPO = "csukuangfj/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17"

        val VARIANTS = listOf(
            Variant(
                id = "int8",
                title = tr("标准 · SenseVoice int8"),
                subtitle = tr("推荐。体积小，中文带标点，适合大多数场景"),
                remoteName = "model.int8.onnx",
                approximateBytes = 239_000_000L,
            ),
            Variant(
                id = "fp32",
                title = tr("高精度 · SenseVoice FP32"),
                subtitle = tr("未量化，识别效果最好，占用与内存开销更大"),
                remoteName = "model.onnx",
                approximateBytes = 938_000_000L,
            ),
        )

        val MODEL_SIZE_HINT = tr("约 239 MB")
    }
}
