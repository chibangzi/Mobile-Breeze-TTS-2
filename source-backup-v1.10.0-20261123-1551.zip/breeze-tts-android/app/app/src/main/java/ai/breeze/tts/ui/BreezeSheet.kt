package ai.breeze.tts.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeSize

/**
 * 底部浮层（v2）。
 *
 * 结构没变：遮罩 + 面板上滑 + 底下页面失焦。改的是这几处：
 *  - 面板底色改用 `surface2`，和页面底只差一档，靠 24dp 顶部圆角与一条 line2 描边
 *    划出边界，不再用「明显更亮的暖灰」把自己做成另一张卡片；
 *  - 去掉顶部那条渐变暖光（叠在圆角上会显脏），只留 34×4 的抓握条；
 *  - 遮罩颜色跟随主题：深色压暗、浅色提亮，浅色下不会糊成一块灰。
 */
@Composable
fun BreezeSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    heightFraction: Float = 0.78f,
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = Breeze.colors
    BackHandler(enabled = visible, onBack = onDismiss)

    val shape = RoundedCornerShape(topStart = BreezeSize.sheet, topEnd = BreezeSize.sheet)
    val noRipple = remember { MutableInteractionSource() }

    Box(modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(durationMillis = 260, easing = FastOutSlowInEasing)),
            exit = fadeOut(tween(durationMillis = 200, easing = FastOutLinearInEasing)),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        if (c.isDark) c.bg.copy(alpha = 0.58f) else c.bg.copy(alpha = 0.68f),
                    )
                    .pointerInput(Unit) { detectTapGestures { onDismiss() } },
            )
        }

        AnimatedVisibility(
            visible = visible,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(heightFraction),
            enter = slideInVertically(
                animationSpec = tween(durationMillis = 360, easing = FastOutSlowInEasing),
                initialOffsetY = { it },
            ) + fadeIn(tween(durationMillis = 220)),
            exit = slideOutVertically(
                animationSpec = tween(durationMillis = 240, easing = FastOutLinearInEasing),
                targetOffsetY = { it },
            ) + fadeOut(tween(durationMillis = 160)),
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .clip(shape)
                    .background(c.surface2)
                    .border(1.dp, c.line2, shape)
                    .clickable(interactionSource = noRipple, indication = null) {}
                    .padding(bottom = 14.dp),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 9.dp, bottom = 5.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        Modifier
                            .size(width = 34.dp, height = 4.dp)
                            .clip(CircleShape)
                            .background(c.line2),
                    )
                }
                content()
            }
        }
    }
}

/**
 * 页面内容在浮层弹出时的虚化。
 *
 * 用 `graphicsLayer { renderEffect }` 而不是 `Modifier.blur(dp)`：后者要按帧重组
 * 整个页面才能把新的半径传下去，而这里把半径读在 layer 块里——每帧只重绘一层，
 * 长列表滚动时也不会因为动画卡一下。
 *
 * 半径比旧版小（18 → 12dp）：虚化太重会让背后的布局变成一团暖色噪点，
 * 轻一点反而更像「失焦」，也更能看出下面还有一页内容。
 */
@Composable
fun Modifier.backdropBlur(visible: Boolean, maxRadius: Dp = 12.dp): Modifier {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(visible) {
        progress.animateTo(
            targetValue = if (visible) 1f else 0f,
            animationSpec = tween(
                durationMillis = if (visible) 300 else 230,
                easing = FastOutSlowInEasing,
            ),
        )
    }
    val maxPx = with(LocalDensity.current) { maxRadius.toPx() }
    return this.graphicsLayer {
        val r = progress.value * maxPx
        renderEffect = if (r > 0.5f) BlurEffect(r, r) else null
    }
}
