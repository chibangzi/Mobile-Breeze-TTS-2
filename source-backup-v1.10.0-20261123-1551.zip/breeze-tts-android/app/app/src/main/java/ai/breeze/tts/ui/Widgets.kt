package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeGradients
import ai.breeze.tts.ui.theme.BreezeSize

/**
 * 分区块（v2）。
 *
 * 原来是「一张 20dp 圆角、带顶部暖光、带 38dp 图标徽章的卡片」，设置页一屏
 * 摞四张，每张都在抢注意力。现在退化成一块 13dp 圆角的面：标题 15.5sp，
 * 图标缩到 15dp 单色，没有暖光、没有徽章底色。层级交给留白，不交给装饰。
 */
@Composable
fun SectionCard(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    badge: String? = null,
    badgeColor: Color = Breeze.colors.accent,
    accent: Brush = BreezeGradients.brand,
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = Breeze.colors
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(c.surface)
            .border(1.dp, c.line, RoundedCornerShape(13.dp))
            .padding(horizontal = 14.dp, vertical = 13.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = c.t3, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(7.dp))
            }
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                color = c.t1,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (badge != null) {
                Spacer(Modifier.width(8.dp))
                StatusPill(badge, badgeColor)
            }
        }
        if (!subtitle.isNullOrBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(
                subtitle,
                fontSize = 11.5.sp,
                lineHeight = 17.sp,
                color = c.t3,
            )
        }
        Spacer(Modifier.height(12.dp))
        content()
    }
}

/** 可折叠的分区块：整行标题可点，右侧箭头指示状态。 */
@Composable
fun CollapsibleSectionCard(
    title: String,
    subtitle: String? = null,
    summary: String? = null,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    badge: String? = null,
    badgeColor: Color = Breeze.colors.accent,
    initiallyExpanded: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = Breeze.colors
    val expandedState = androidx.compose.runtime.saveable.rememberSaveable {
        androidx.compose.runtime.mutableStateOf(initiallyExpanded)
    }
    val expanded = expandedState.value
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(c.surface)
            .border(1.dp, c.line, RoundedCornerShape(13.dp)),
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { expandedState.value = !expandedState.value },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (icon != null) {
                    Icon(icon, contentDescription = null, tint = c.t3, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(7.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleLarge, color = c.t1)
                    val line = if (!expanded) summary ?: subtitle else subtitle
                    if (!line.isNullOrBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(line, fontSize = 11.5.sp, color = c.t3, lineHeight = 17.sp)
                    }
                }
                if (badge != null) {
                    Spacer(Modifier.width(8.dp))
                    StatusPill(badge, badgeColor)
                }
                Spacer(Modifier.width(6.dp))
                Icon(
                    if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                    contentDescription = if (expanded) tr("收起") else tr("展开"),
                    tint = c.t3,
                    modifier = Modifier.size(16.dp),
                )
            }
            AnimatedVisibility(visible = expanded) {
                Column(Modifier.padding(top = 12.dp)) { content() }
            }
        }
    }
}

/** 小状态标签：无描边、无圆点，`fill` 底 + 10.5sp 字。 */
@Composable
fun StatusPill(
    text: String,
    color: Color = Breeze.colors.accent,
    modifier: Modifier = Modifier,
) {
    Text(
        text,
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.10f))
            .padding(horizontal = 7.dp, vertical = 3.dp),
        fontSize = 10.5.sp,
        lineHeight = 13.sp,
        color = color,
        fontWeight = FontWeight.Medium,
        maxLines = 1,
        softWrap = false,
    )
}

/**
 * 页面大标题：只有标题和一行副标题。
 *
 * 旧版左侧有 46dp 的琥珀描边图标方块，是页面上第二个「最重的元素」。
 * v2 的页头只允许有一个焦点：标题本身。
 */
@Composable
fun ScreenHeader(
    title: String,
    subtitle: String,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier,
) {
    val c = Breeze.colors
    Column(modifier.fillMaxWidth()) {
        Text(title, style = MaterialTheme.typography.headlineMedium, color = c.t1)
        if (subtitle.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(subtitle, fontSize = 12.5.sp, lineHeight = 18.sp, color = c.t3)
        }
    }
}

/**
 * 主按钮。
 *
 * 名字保留成 GradientButton 是为了不动 10 个调用点，但实现已经换成纯色：
 * 深色主题是香槟金实心 + 深色字，浅色主题是近黑实心 + 米白字。
 * 渐变在 48dp 的按钮高度里读不出方向，只会让字显得脏。
 */
@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    brush: Brush = BreezeGradients.brand,
    height: Dp = BreezeSize.button,
) {
    val c = Breeze.colors
    val shape = RoundedCornerShape(13.dp)
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(height),
        shape = shape,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            disabledContainerColor = Color.Transparent,
        ),
        contentPadding = PaddingValues(0.dp),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(height)
                .alpha(if (enabled) 1f else 0.34f)
                .clip(shape)
                .background(c.btnBg),
            contentAlignment = Alignment.Center,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = c.btnInk,
                        modifier = Modifier.size(15.dp),
                    )
                    Spacer(Modifier.width(7.dp))
                }
                Text(
                    text,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = c.btnInk,
                    maxLines = 1,
                    softWrap = false,
                )
            }
        }
    }
}

/** 空状态占位。 */
@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
) {
    val c = Breeze.colors
    Column(
        modifier.fillMaxWidth().padding(vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = c.t3,
            modifier = Modifier.size(26.dp),
        )
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = c.t1)
        Spacer(Modifier.height(5.dp))
        Text(
            subtitle,
            fontSize = 12.sp,
            lineHeight = 18.sp,
            color = c.t3,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

@Composable
fun TagChip(text: String, selected: Boolean = false, onClick: () -> Unit) {
    val c = Breeze.colors
    Text(
        text = text,
        fontSize = 11.5.sp,
        fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
        color = if (selected) c.accent else c.t2,
        maxLines = 1,
        modifier = Modifier
            .clip(RoundedCornerShape(7.dp))
            .background(if (selected) c.accentSoft else c.fill)
            .border(
                1.dp,
                if (selected) c.accent.copy(alpha = 0.28f) else Color.Transparent,
                RoundedCornerShape(7.dp),
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChipFlow(items: List<String>, selected: String?, onSelect: (String) -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items.forEach { TagChip(it, selected == it) { onSelect(it) } }
    }
}

@Composable
fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    onChange: (Float) -> Unit,
    steps: Int = 0,
    caption: String? = null,
) {
    val c = Breeze.colors
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontSize = 12.5.sp, color = c.t2, modifier = Modifier.weight(1f))
            Text(
                valueText,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = c.t1,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(c.fill)
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            )
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            modifier = Modifier.height(32.dp),
            colors = androidx.compose.material3.SliderDefaults.colors(
                thumbColor = c.accent,
                activeTrackColor = c.accent,
                inactiveTrackColor = c.line2,
            ),
        )
        if (caption != null) {
            Text(caption, fontSize = 11.sp, lineHeight = 16.sp, color = c.t3)
        }
    }
}

@Composable
fun KeyValueRow(
    key: String,
    value: String,
    valueColor: Color = Color.Unspecified,
    modifier: Modifier = Modifier,
) {
    val c = Breeze.colors
    Row(modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(
            key,
            fontSize = 12.5.sp,
            color = c.t3,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(0.8f),
        )
        Spacer(Modifier.width(12.dp))
        // 值也要参与分配宽度：否则像「NEON · DOTPROD · FP16 · …」这种长串会按
        // 固有宽度铺满整行，把左边的 key 挤成一列竖排单字（1.9.40 的「CPU 特性」）。
        Text(
            value,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Medium,
            color = if (valueColor == Color.Unspecified) c.t2 else valueColor,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1.5f),
        )
    }
}
