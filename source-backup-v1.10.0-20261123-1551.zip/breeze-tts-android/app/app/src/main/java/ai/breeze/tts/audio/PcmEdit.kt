package ai.breeze.tts.audio

import java.io.File
import java.io.RandomAccessFile
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/**
 * 一段可编辑的 24 kHz 单声道 PCM。
 *
 * 编辑页的删除操作就是把 [samples] 切成两段再拼回去，所以整个类不可变：
 * 每次 cut 返回新实例，撤销栈里存旧实例即可，不需要深拷贝两次。
 */
class PcmClip(val samples: ShortArray, val sampleRate: Int = 24_000) {

    val durationMs: Long get() = samples.size * 1000L / sampleRate
    val durationSec: Double get() = samples.size.toDouble() / sampleRate

    fun sampleAt(sec: Double): Int =
        (sec * sampleRate).toInt().coerceIn(0, samples.size)

    fun timeOf(sample: Int): Double =
        sample.toDouble() / sampleRate

    /** 删掉 [from, to) 这一段。 */
    fun cut(from: Int, to: Int): PcmClip {
        val a = from.coerceIn(0, samples.size)
        val b = to.coerceIn(a, samples.size)
        if (b <= a) return this
        val out = ShortArray(samples.size - (b - a))
        samples.copyInto(out, 0, 0, a)
        samples.copyInto(out, a, b, samples.size)
        return PcmClip(out, sampleRate)
    }

    /** 只保留 [from, to) 这一段。 */
    fun trim(from: Int, to: Int): PcmClip {
        val a = from.coerceIn(0, samples.size)
        val b = to.coerceIn(a, samples.size)
        if (b <= a) return this
        return PcmClip(samples.copyOfRange(a, b), sampleRate)
    }

    fun toWav(file: File) {
        file.parentFile?.mkdirs()
        val w = WavWriter(file, sampleRate)
        w.write(samples)
        w.close()
    }

    companion object {
        /** 读取 16-bit PCM WAV（App 自己产出的文件都是这个格式）。 */
        fun fromWav(file: File): PcmClip? = runCatching {
            RandomAccessFile(file, "r").use { raf ->
                if (raf.length() < 44) return null
                val head = ByteArray(12)
                raf.readFully(head)
                if (String(head, 0, 4, Charsets.US_ASCII) != "RIFF" ||
                    String(head, 8, 4, Charsets.US_ASCII) != "WAVE"
                ) return null
                raf.seek(12)
                var rate = 24_000
                var channels = 1
                var bits = 16
                var format = 1
                var dataOff = -1L
                var dataLen = 0L
                val hdr = ByteArray(8)
                while (raf.filePointer + 8 <= raf.length()) {
                    raf.readFully(hdr)
                    val id = String(hdr, 0, 4, Charsets.US_ASCII)
                    val size = le32(hdr, 4)
                    val body = raf.filePointer
                    when (id) {
                        "fmt " -> {
                            val f = ByteArray(16)
                            raf.readFully(f)
                            format = le16(f, 0)
                            channels = le16(f, 2)
                            rate = le32(f, 4)
                            bits = le16(f, 14)
                        }
                        "data" -> {
                            dataOff = body
                            // 流式 WAV 的 data 长度可能写成 0 或 0xFFFFFFFF，按文件剩余算
                            dataLen = if (size <= 0 || body + size > raf.length()) {
                                raf.length() - body
                            } else size.toLong()
                            break
                        }
                    }
                    raf.seek(body + size + (size and 1))
                }
                if (dataOff < 0 || format != 1 || bits != 16) return null
                val avail = min(dataLen, raf.length() - dataOff).coerceAtLeast(0)
                val n = (avail / 2).toInt()
                if (n <= 0) return null
                val raw = ByteArray(n * 2)
                raf.seek(dataOff)
                raf.readFully(raw)
                val shorts = ShortArray(n) { i ->
                    ((raw[i * 2].toInt() and 0xFF) or (raw[i * 2 + 1].toInt() shl 8)).toShort()
                }
                val mono = if (channels <= 1) shorts else downmix(shorts, channels)
                PcmClip(mono, if (rate > 0) rate else 24_000)
            }
        }.getOrNull()

        private fun downmix(data: ShortArray, channels: Int): ShortArray {
            val frames = data.size / channels
            val out = ShortArray(frames)
            for (i in 0 until frames) {
                var v = 0
                for (c in 0 until channels) v += data[i * channels + c].toInt()
                out[i] = (v / channels).toShort()
            }
            return out
        }

        private fun le16(b: ByteArray, o: Int): Int =
            (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

        private fun le32(b: ByteArray, o: Int): Int =
            (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
                ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)
    }
}

/**
 * 波形峰值金字塔。
 *
 * 编辑页要支持缩放到 0.3 秒的视野：一屏 1000 列，每列可能只覆盖几个样本；
 * 反过来全景时每列覆盖上万个样本。每次重绘直接扫原始 PCM 的话，全景下
 * 一帧要读上千万个 short，滚动会掉帧。
 *
 * 这里预先算出 64/256/1024/… 样本一桶的多级峰值，绘制时按「每列跨度」
 * 选一级，单列最多读 4 个桶——重绘成本只跟屏幕宽度有关，与音频长度无关。
 */
class PeakPyramid(private val samples: ShortArray) {

    private val base = 64
    private val levels: Array<FloatArray>
    private val peak: Float

    init {
        val list = ArrayList<FloatArray>(6)
        var w = base
        while (true) {
            val n = ((samples.size + w - 1) / w).coerceAtLeast(1)
            val arr = FloatArray(n)
            for (i in 0 until n) {
                val s = i * w
                val e = min(samples.size, s + w)
                var mx = 0
                var j = s
                while (j < e) {
                    val a = abs(samples[j].toInt())
                    if (a > mx) mx = a
                    j++
                }
                arr[i] = mx / 32768f
            }
            list.add(arr)
            if (n <= 1024) break
            w *= 4
        }
        levels = list.toTypedArray()
        peak = levels[0].maxOrNull() ?: 0f
    }

    /** [from, to) 区间内的峰值，已做开方压缩，值域 0..1。 */
    fun column(from: Int, to: Int): Float {
        if (samples.isEmpty() || peak <= 1e-4f) return 0f
        val span = (to - from).coerceAtLeast(1)
        var idx = 0
        var w = base
        while (idx + 1 < levels.size && span / w > 3) {
            idx++
            w *= 4
        }
        val arr = levels[idx]
        val i0 = (from / w).coerceIn(0, arr.size - 1)
        val i1 = (to / w).coerceIn(0, arr.size - 1)
        var mx = 0f
        var i = i0
        while (i <= i1) {
            if (arr[i] > mx) mx = arr[i]
            i++
        }
        return sqrt((mx / peak).coerceIn(0f, 1f))
    }
}
