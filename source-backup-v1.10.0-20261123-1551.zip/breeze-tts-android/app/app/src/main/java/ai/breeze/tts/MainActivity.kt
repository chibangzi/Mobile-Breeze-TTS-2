package ai.breeze.tts

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import ai.breeze.tts.i18n.Lang
import ai.breeze.tts.i18n.tr
import ai.breeze.tts.ui.HistoryScreen
import ai.breeze.tts.ui.SettingsScreen
import ai.breeze.tts.ui.SynthesizeScreen
import ai.breeze.tts.ui.VoiceScreen
import ai.breeze.tts.ui.theme.Breeze
import ai.breeze.tts.ui.theme.BreezeTheme
import ai.breeze.tts.vm.AppViewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 1.10.0：界面语言在建 Compose 树之前定下来，避免首帧闪一下中文。
        val app = application as BreezeApplication
        Lang.init(this, app.settings.language.value)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            BreezeTheme {
                val vm: AppViewModel = viewModel()
                var tab by remember { mutableIntStateOf(0) }

                // 生成 / 转换 / 测试期间保持屏幕常亮：一是让用户看到进度（现在是 1 Hz 的静态卡片），
                // 二是避免灭屏后部分机型把进程降频，把测出来的 RTF 弄成不可比的数据。
                val rootView = LocalView.current
                val busy = vm.generating || vm.converting || vm.diagRunning || vm.expRunning
                DisposableEffect(busy) {
                    rootView.keepScreenOn = busy
                    onDispose { rootView.keepScreenOn = false }
                }

                // 状态栏 / 手势条图标跟随主题：深色背景要用浅色图标，否则看不见
                val dark = isSystemInDarkTheme()
                SideEffect {
                    WindowCompat.getInsetsController(window, window.decorView).apply {
                        isAppearanceLightStatusBars = !dark
                        isAppearanceLightNavigationBars = !dark
                    }
                }

                var toastOn by remember { mutableStateOf(false) }
                LaunchedEffect(vm.messageSeq) {
                    if (vm.message != null) {
                        toastOn = true
                        delay(2_000)
                        toastOn = false
                        delay(240)
                        vm.consumeMessage()
                    }
                }

                val navBottom = WindowInsets.navigationBars
                    .asPaddingValues().calculateBottomPadding()

                Box(Modifier.fillMaxSize()) {
                    Scaffold(
                        containerColor = MaterialTheme.colorScheme.background,
                        bottomBar = { BottomTabs(tab) { tab = it } },
                    ) { pad ->
                        Box(Modifier.padding(pad)) {
                            when (tab) {
                                0 -> SynthesizeScreen(
                                    vm,
                                    onOpenVoices = { tab = 2 },
                                    onOpenModels = { tab = 3 },
                                    onOpenSettings = { tab = 3 },
                                )
                                1 -> HistoryScreen(vm)
                                2 -> VoiceScreen(vm)
                                else -> SettingsScreen(vm)
                            }
                        }
                    }

                    AnimatedVisibility(
                        visible = toastOn,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = navBottom + 86.dp),
                        enter = fadeIn(tween(160)) + slideInVertically(tween(220)) { it / 2 },
                        exit = fadeOut(tween(180)) + slideOutVertically(tween(200)) { it / 2 },
                    ) {
                        ToastPill(vm.message ?: "")
                    }
                }
            }
        }
    }
}

/**
 * 底部导航（v2）：自绘四列，不再用 Material 的 NavigationBar。
 *
 * 后者的「选中项胶囊指示器」是 Material 3 的默认语言，和这套「文字 + 1px 线」
 * 的设计不搭；它的高度（80dp）也比内容需要的多 20dp。
 * 现在只有：一条 1px 顶线、56dp 的四列、10sp 标签，选中项整体变强调色。
 */
@Composable
private fun BottomTabs(tab: Int, onSelect: (Int) -> Unit) {
    val c = Breeze.colors
    Column(
        Modifier
            .fillMaxWidth()
            .background(c.bg)
            .navigationBarsPadding(),
    ) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.line))
        Row(Modifier.fillMaxWidth().height(56.dp)) {
            TabItem(0, tr("合成", "Create"), tab == 0) { onSelect(0) }
            TabItem(1, tr("收藏", "Saved"), tab == 1) { onSelect(1) }
            TabItem(2, tr("音色", "Voices"), tab == 2) { onSelect(2) }
            TabItem(3, tr("设置", "Settings"), tab == 3) { onSelect(3) }
        }
    }
}

@Composable
private fun RowScope.TabItem(index: Int, label: String, selected: Boolean, onClick: () -> Unit) {
    val c = Breeze.colors
    val tint = if (selected) c.accent else c.t3
    Column(
        Modifier
            .weight(1f)
            .fillMaxSize()
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        NavGlyph(index = index, tint = tint)
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            fontSize = 10.sp,
            color = tint,
            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
            letterSpacing = 0.4.sp,
            maxLines = 1,
        )
    }
}

/** 四个图标：合成用波形（自绘 5 根线），其余用 core 里现成的。 */
@Composable
private fun NavGlyph(index: Int, tint: Color) {
    when (index) {
        0 -> Canvas(Modifier.size(19.dp)) {
            val w = size.width
            val h = size.height
            val sw = 1.6.dp.toPx()
            val heights = listOf(0.34f, 0.68f, 1f, 0.52f, 0.24f)
            heights.forEachIndexed { i, f ->
                val x = w * (0.14f + i * 0.18f)
                val half = h * 0.5f * f
                drawLine(tint, Offset(x, h * 0.5f - half), Offset(x, h * 0.5f + half), sw, StrokeCap.Round)
            }
        }
        1 -> Icon(Icons.Outlined.Star, contentDescription = null, tint = tint, modifier = Modifier.size(19.dp))
        2 -> Icon(Icons.Outlined.Person, contentDescription = null, tint = tint, modifier = Modifier.size(19.dp))
        else -> Icon(Icons.Outlined.Settings, contentDescription = null, tint = tint, modifier = Modifier.size(19.dp))
    }
}

/** 轻量提示条：一行文字 + 小勾，浮在底部导航之上 */
@Composable
private fun ToastPill(text: String) {
    val c = Breeze.colors
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = c.surface2,
        border = BorderStroke(1.dp, c.line2),
        shadowElevation = 6.dp,
        modifier = Modifier.padding(horizontal = 24.dp),
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Outlined.CheckCircle,
                contentDescription = null,
                tint = c.accent,
                modifier = Modifier.padding(end = 8.dp).size(15.dp),
            )
            Text(
                text,
                fontSize = 12.5.sp,
                color = c.t1,
                maxLines = 2,
            )
        }
    }
}
