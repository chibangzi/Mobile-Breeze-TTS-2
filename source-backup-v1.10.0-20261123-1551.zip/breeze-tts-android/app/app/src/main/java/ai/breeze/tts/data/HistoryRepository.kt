package ai.breeze.tts.data

import ai.breeze.tts.i18n.tr

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** 一条生成记录。wav 文件常驻 App 私有目录，卸载 App 才会清掉。 */
data class HistoryItem(
    val id: String,
    val title: String,
    val path: String,
    val createdAt: Long,
    val durationMs: Long,
    val text: String,
    val voiceName: String,
    val bytes: Long,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("path", path)
        put("createdAt", createdAt)
        put("durationMs", durationMs)
        put("text", text)
        put("voiceName", voiceName)
        put("bytes", bytes)
    }

    companion object {
        fun fromJson(o: JSONObject) = HistoryItem(
            id = o.getString("id"),
            title = o.optString("title", tr("语音")),
            path = o.getString("path"),
            createdAt = o.optLong("createdAt", 0L),
            durationMs = o.optLong("durationMs", 0L),
            text = o.optString("text", ""),
            voiceName = o.optString("voiceName", ""),
            bytes = o.optLong("bytes", 0L),
        )
    }
}

/**
 * 生成历史：index.json 存元信息，wav 存同目录。所有写操作串行化，
 * 避免「刚生成完就删除」时索引与文件不一致。
 */
class HistoryRepository(private val app: Context) {

    private val dir: File get() = File(app.filesDir, "history").apply { if (!exists()) mkdirs() }
    private val index: File get() = File(dir, "index.json")

    private val _items = MutableStateFlow<List<HistoryItem>>(emptyList())
    val items: StateFlow<List<HistoryItem>> = _items.asStateFlow()

    suspend fun load() = withContext(Dispatchers.IO) {
        synchronized(this@HistoryRepository) {
            val list = readIndex().filter { File(it.path).isFile }
            _items.value = list
            if (list.size != readRaw().size) writeIndex(list)
        }
    }

    fun newWav(id: String): File = File(dir, "$id.wav")

    /** 生成完成后落一条记录；返回持久化后的 wav 文件。 */
    suspend fun add(
        source: File,
        text: String,
        voiceName: String,
        durationMs: Long,
        fixedTitle: String? = null,
    ): HistoryItem = withContext(Dispatchers.IO) {
        synchronized(this@HistoryRepository) {
            val id = UUID.randomUUID().toString().take(12)
            val dst = newWav(id)
            source.copyTo(dst, overwrite = true)
            val stamp = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date())
            val brief = text.trim().replace(Regex("\\s+"), " ").take(14)
            val item = HistoryItem(
                id = id,
                title = fixedTitle?.takeIf { it.isNotBlank() }
                    ?: if (brief.isEmpty()) tr("语音 $stamp", "Speech $stamp") else "$brief · $stamp",
                path = dst.absolutePath,
                createdAt = System.currentTimeMillis(),
                durationMs = durationMs,
                text = text.trim(),
                voiceName = voiceName,
                bytes = dst.length(),
            )
            val list = (listOf(item) + readIndex()).take(MAX_ITEMS)
            writeIndex(list)
            _items.value = list
            // 只保留 MAX_ITEMS 个 wav，其余清掉
            val keep = list.map { it.id }.toSet()
            dir.listFiles { f -> f.extension == "wav" && f.nameWithoutExtension !in keep }
                ?.forEach { it.delete() }
            item
        }
    }

    suspend fun delete(item: HistoryItem) = withContext(Dispatchers.IO) {
        synchronized(this@HistoryRepository) {
            runCatching { File(item.path).delete() }
            val list = readIndex().filter { it.id != item.id }
            writeIndex(list)
            _items.value = list
        }
    }

    suspend fun clear() = withContext(Dispatchers.IO) {
        synchronized(this@HistoryRepository) {
            dir.listFiles { f -> f.extension == "wav" }?.forEach { it.delete() }
            writeIndex(emptyList())
            _items.value = emptyList()
        }
    }

    private fun readRaw(): List<HistoryItem> = runCatching {
        if (!index.isFile) return emptyList()
        val arr = JSONArray(index.readText())
        (0 until arr.length()).mapNotNull { i ->
            runCatching { HistoryItem.fromJson(arr.getJSONObject(i)) }.getOrNull()
        }
    }.getOrDefault(emptyList())

    private fun readIndex(): List<HistoryItem> =
        readRaw().sortedByDescending { it.createdAt }

    private fun writeIndex(list: List<HistoryItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        val tmp = File(dir, "index.json.tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(index)) tmp.copyTo(index, overwrite = true)
    }

    companion object {
        private const val MAX_ITEMS = 200
    }
}
