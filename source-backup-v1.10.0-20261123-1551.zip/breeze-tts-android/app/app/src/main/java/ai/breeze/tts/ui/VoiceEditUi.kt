package ai.breeze.tts.ui

import ai.breeze.tts.i18n.tr

import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ai.breeze.tts.engine.VoiceProfile
import ai.breeze.tts.ui.theme.BreezeGradients
import ai.breeze.tts.ui.theme.Gold
import ai.breeze.tts.vm.AppViewModel
import kotlinx.coroutines.delay

/**
 * 性别选择：两段式。再点一次已选中的项即取消（回到未指定），
 * 所以三个状态都能到达，又不用摆第三个按钮。
 */
@Composable
fun GenderSelector(
    value: VoiceProfile.Gender,
    onChange: (VoiceProfile.Gender) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GenderOption(tr("女声"), VoiceProfile.Gender.FEMALE, value == VoiceProfile.Gender.FEMALE, Modifier.weight(1f)) {
            onChange(if (value == VoiceProfile.Gender.FEMALE) VoiceProfile.Gender.NONE else VoiceProfile.Gender.FEMALE)
        }
        GenderOption(tr("男声"), VoiceProfile.Gender.MALE, value == VoiceProfile.Gender.MALE, Modifier.weight(1f)) {
            onChange(if (value == VoiceProfile.Gender.MALE) VoiceProfile.Gender.NONE else VoiceProfile.Gender.MALE)
        }
    }
}

@Composable
private fun GenderOption(
    label: String,
    gender: VoiceProfile.Gender,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val (bg, fg) = genderPalette(gender)
    val accent = genderMark(gender)
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier
            .height(52.dp)
            .clip(shape)
            .background(if (selected) bg else MaterialTheme.colorScheme.surfaceVariant)
            .then(
                if (selected) Modifier.border(1.5.dp, accent.copy(alpha = 0.55f), shape)
                else Modifier.border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape),
            )
            .clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GenderGlyph(gender, if (selected) fg else MaterialTheme.colorScheme.onSurfaceVariant, Modifier.size(15.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) fg else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

/** 可点击的头像：虚线环 + 相机角标，说明这里能换 */
@Composable
fun AvatarEditField(
    name: String,
    gender: VoiceProfile.Gender,
    avatarPath: String?,
    size: androidx.compose.ui.unit.Dp = 88.dp,
    onClick: () -> Unit,
) {
    Box(contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(size)
                .clip(CircleShape)
                .then(
                    if (avatarPath == null) Modifier.dashedBorder(
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.34f), size / 2,
                    ) else Modifier,
                ),
        ) {
            VoiceAvatar(
                name = name,
                gender = gender,
                avatarPath = avatarPath,
                size = size,
                showBadge = false,
            )
        }
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .size(30.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.background)
                .padding(3.dp)
                .clip(CircleShape)
                .background(BreezeGradients.brand)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Outlined.Add,
                contentDescription = tr("更换头像"),
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(14.dp),
            )
        }
    }
}

/**
 * 试听样本播放器：编辑页与新建页共用。
 * 以前两处各写一份 MediaPlayer 生命周期，容易漏 release。
 */
@androidx.compose.runtime.Stable
internal class SamplePlayer(
    private val playingState: androidx.compose.runtime.MutableState<Boolean>,
    private val player: MediaPlayer,
) {
    val playing: Boolean get() = playingState.value

    fun play(path: String) {
        if (path.isBlank()) return
        runCatching {
            player.reset()
            player.setDataSource(path)
            player.prepare()
            player.start()
            playingState.value = true
        }
    }

    fun stop() {
        runCatching { player.pause() }
        playingState.value = false
    }
}

@Composable
internal fun rememberSamplePlayer(): SamplePlayer {
    val playing = remember { mutableStateOf(false) }
    val player = remember { MediaPlayer() }
    DisposableEffect(Unit) {
        player.setOnCompletionListener { playing.value = false }
        onDispose { runCatching { player.release() } }
    }
    return remember(player) { SamplePlayer(playing, player) }
}

/**
 * 音色编辑页（全屏）。
 *
 * 新建和编辑共用同一套字段，区别只在于新建时直接写进仓库、编辑时走 updateVoice。
 * 设计音色的「锁定」也在这里：录一条试听样本，满意的就把码本留下来。
 */
@Composable
fun VoiceEditorDialog(
    vm: AppViewModel,
    voice: VoiceProfile,
    onDismiss: () -> Unit,
) {
    var name by remember(voice.id) { mutableStateOf(voice.name) }
    var prompt by remember(voice.id) { mutableStateOf(voice.designPrompt ?: "") }
    var gender by remember(voice.id) { mutableStateOf(voice.gender) }
    var confirmDelete by remember { mutableStateOf(false) }
    val player = rememberSamplePlayer()
    val playing = player.playing

    // 选完图先进裁切框，确认后才落盘
    var cropUri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) cropUri = uri
    }

    // 每次都从 vm.voices 里取最新的那一份：锁样本之后 id 不变但字段变了
    val live = vm.voices.firstOrNull { it.id == voice.id } ?: voice
    val busy = vm.auditioningVoiceId == voice.id
    val preview = vm.previewVoiceId == voice.id
    val samplePath = vm.sampleWavPath(live)

    // 样本一生成好就自动播一遍：用户点完「生成试听样本」最想听到的就是它，
    // 不该再让他找播放键。
    LaunchedEffect(preview, samplePath) {
        if (preview && samplePath != null) player.play(samplePath)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                // 顶栏
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(onClick = onDismiss) { Text(tr("取消")) }
                    Spacer(Modifier.weight(1f))
                    Text(tr("编辑音色"), style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.weight(1f))
                    TextButton(
                        onClick = {
                            vm.updateVoice(
                                live.copy(
                                    name = name.ifBlank { tr("未命名音色") },
                                    gender = gender,
                                    designPrompt = if (live.kind == VoiceProfile.Kind.DESIGN)
                                        prompt.trim() else live.designPrompt,
                                ),
                            )
                            onDismiss()
                        },
                    ) { Text(tr("保存"), fontWeight = FontWeight.Bold) }
                }

                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 18.dp)
                        .padding(bottom = 28.dp),
                ) {
                    // 头像
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            AvatarEditField(name, gender, live.avatarPath) {
                                picker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                                )
                            }
                            Spacer(Modifier.height(12.dp))
                            Text(
                                tr("点击更换头像 · 不上传则显示名字首字"),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Spacer(Modifier.height(24.dp))

                    FieldLabel(tr("名字"))
                    ImeAwareTextField(
                        value = name,
                        onValueChange = { name = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                    Spacer(Modifier.height(18.dp))

                    FieldLabel(tr("性别"), tr("决定列表分类与头像底色"))
                    GenderSelector(value = gender, onChange = { gender = it })
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (gender == VoiceProfile.Gender.NONE)
                            tr("未指定也能用，只是不会出现在「女声 / 男声」分类里")
                        else tr("已选${genderLabel(gender)}，可在合成页按性别筛选", "${genderLabel(gender)} selected; filter by gender on the Create page"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(18.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            tr("音色来源"),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            if (live.kind == VoiceProfile.Kind.CLONE) tr("克隆音色") else tr("设计音色"),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f))
                                .padding(horizontal = 8.dp, vertical = 3.dp),
                        )
                    }
                    Spacer(Modifier.height(18.dp))

                    if (live.kind == VoiceProfile.Kind.CLONE) {
                        FieldLabel(tr("参考音频"))
                        Text(
                            live.refText?.let { tr("文本稿：${it.take(60)}", "Transcript: ${it.take(60)}") } ?: tr("无文本稿"),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(18.dp))
                    } else {
                        FieldLabel(tr("音色描述"), tr("锁定前，音色由这段文字 + 随机采样共同决定"))
                        ImeAwareTextField(
                            value = prompt,
                            onValueChange = { prompt = it },
                            modifier = Modifier.fillMaxWidth().height(120.dp),
                            placeholder = { Text(tr("例如：三十岁左右的女性，声音温和偏低，说话带一点气声。")) },
                        )
                        Spacer(Modifier.height(20.dp))

                        // ---- 锁定音色 ----
                        LockSection(
                            vm = vm,
                            voice = live,
                            busy = busy,
                            preview = preview,
                            playing = playing,
                            samplePath = samplePath,
                            seconds = vm.auditionSeconds,
                            promptOverride = prompt,
                            onPlay = {
                                if (playing) player.stop()
                                else samplePath?.let { player.play(it) }
                            },
                        )
                        Spacer(Modifier.height(18.dp))
                    }

                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { confirmDelete = true }
                            .padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Outlined.Delete, contentDescription = null,
                                tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(15.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                tr("删除这个音色"),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(tr("删除音色"), style = MaterialTheme.typography.titleLarge) },
            text = { Text(tr("「${live.name}」及其参考音频、样本都会被删除，无法恢复。", "\"${live.name}\" will be deleted along with its reference audio and samples; this can't be undone.")) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.deleteVoice(live)
                    onDismiss()
                }) { Text(tr("删除"), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(tr("取消")) } },
        )
    }

    cropUri?.let { u ->
        AvatarCropDialog(
            uri = u,
            onConfirm = { bmp ->
                vm.saveVoiceAvatar(live, bmp)
                cropUri = null
            },
            onDismiss = { cropUri = null },
        )
    }
}

@Composable
private fun FieldLabel(text: String, hint: String? = null) {
    Row(Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (hint != null) {
            Spacer(Modifier.width(8.dp))
            Text(
                hint,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            )
        }
    }
}

/**
 * 锁定区。
 *
 * 核心逻辑只有一句：把一条试听样本的码本留下来，之后音色由码本决定，
 * 与文本、情绪都无关。
 *
 * 1.9.3 之前这里没有任何「成功」反馈：生成完把样本写进 profile，界面却还是
 * 那句「生成试听样本」——用户根本不知道自己刚才等了 25 秒换来了什么。
 * 现在三件事都摆出来：状态条（生成中 / 已生成 / 已锁定）、试听键、下一步动作。
 */
@Composable
internal fun LockSection(
    vm: AppViewModel,
    voice: VoiceProfile,
    busy: Boolean,
    preview: Boolean,
    playing: Boolean,
    samplePath: String?,
    seconds: Float,
    /** 当前输入框里的描述：生成与锁定都按它走，不要求先保存 */
    promptOverride: String = "",
    onPlay: () -> Unit,
) {
    val locked = voice.locked

    // 生成中的秒表：没有进度回调，至少让人看见「还在动」
    var elapsed by remember(busy) { mutableIntStateOf(0) }
    LaunchedEffect(busy) {
        if (!busy) return@LaunchedEffect
        elapsed = 0
        while (true) {
            delay(1_000)
            elapsed++
        }
    }

    val accent = if (locked) MaterialTheme.colorScheme.primary
    else MaterialTheme.colorScheme.onSurfaceVariant

    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (locked) MaterialTheme.colorScheme.primary.copy(alpha = 0.07f)
                else MaterialTheme.colorScheme.surfaceVariant,
            )
            .border(
                1.dp,
                if (locked) MaterialTheme.colorScheme.primary.copy(alpha = 0.30f)
                else MaterialTheme.colorScheme.outlineVariant,
                RoundedCornerShape(16.dp),
            )
            .padding(14.dp),
    ) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Outlined.Lock,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(15.dp),
                )
                Spacer(Modifier.width(7.dp))
                Text(
                    if (locked) tr("音色已锁定") else tr("锁定音色"),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (locked) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.weight(1f))
                if (locked) {
                    Text(
                        tr("每次都一样"),
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (locked)
                    tr("每次合成都从这里出发，音色不会再变；情绪仍然可以自由改。")
                else tr("设计音色的音色是逐帧采样出来的，同一句描述每次都是「同一类人里的另一个」。") +
                    tr("录一条样本并锁定后，音色就固定下来了。"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 17.sp,
            )

            // ---- 状态条 ----
            when {
                busy -> {
                    Spacer(Modifier.height(12.dp))
                    StatusBanner(
                        tint = MaterialTheme.colorScheme.primary,
                        icon = null,
                    ) {
                        CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(9.dp))
                        Column {
                            Text(
                                tr("正在生成试听样本…已 ${elapsed} 秒", "Generating a sample… ${elapsed} s"),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                tr("首次约 20–30 秒，生成完会自动播放"),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                preview -> {
                    Spacer(Modifier.height(12.dp))
                    StatusBanner(tint = MaterialTheme.colorScheme.primary) {
                        Icon(
                            Icons.Outlined.CheckCircle, contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp),
                        )
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                (if (locked) tr("新样本已生成") else tr("样本已生成")) +
                                    if (seconds > 0.2f) tr("（%.1f 秒）").format(seconds) else "",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                if (locked) tr("听一下，满意再决定要不要替换")
                                else tr("听一下是不是你要的声音"),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        PlayPill(playing = playing, enabled = samplePath != null, onClick = onPlay)
                    }
                }
            }

            vm.auditionError?.let {
                Spacer(Modifier.height(10.dp))
                StatusBanner(tint = MaterialTheme.colorScheme.error) {
                    Icon(
                        Icons.Outlined.Info, contentDescription = null,
                        tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        it,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            // ---- 动作 ----
            if (!busy) {
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    when {
                        preview -> {
                            SampleButton(
                                text = if (playing) tr("停止") else tr("试听"),
                                icon = Icons.Outlined.PlayArrow,
                                modifier = Modifier.weight(1f),
                                enabled = samplePath != null,
                                onClick = onPlay,
                            )
                            SampleButton(
                                text = tr("换一条"),
                                icon = Icons.Outlined.Refresh,
                                modifier = Modifier.weight(1f),
                            ) { vm.recordVoiceSample(voice, promptOverride) }
                            GradientButton(
                                text = if (locked) tr("用这条替换") else tr("锁定这个"),
                                onClick = { vm.confirmVoiceSample(voice, promptOverride) },
                                height = 42.dp,
                                modifier = Modifier.weight(1.3f),
                            )
                        }
                        locked -> {
                            SampleButton(
                                text = if (playing) tr("停止") else tr("试听"),
                                icon = Icons.Outlined.PlayArrow,
                                modifier = Modifier.weight(1f),
                                enabled = samplePath != null,
                                onClick = onPlay,
                            )
                            SampleButton(
                                text = tr("换一条"),
                                icon = Icons.Outlined.Refresh,
                                modifier = Modifier.weight(1f),
                            ) { vm.recordVoiceSample(voice, promptOverride) }
                            SampleButton(
                                text = tr("解除锁定"),
                                icon = null,
                                modifier = Modifier.weight(1f),
                                onClick = { vm.unlockVoice(voice) },
                            )
                        }
                        else -> {
                            GradientButton(
                                text = tr("生成试听样本"),
                                onClick = { vm.recordVoiceSample(voice, promptOverride) },
                                height = 42.dp,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    when {
                        preview && locked -> tr("不点「用这条替换」的话，现在锁定的音色不会变。")
                        preview -> tr("满意就点「锁定这个」；不满意点「换一条」再生成一个。")
                        locked -> tr("换一条只生成候选样本，不点「用这条替换」就不会影响现在的音色。")
                        else -> tr("样本约 5 秒，用来判断这个音色像不像你要的人。")
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** 状态条：带底色的整行提示，比一行小字更容易被看见 */
@Composable
private fun StatusBanner(
    tint: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(11.dp))
            .background(tint.copy(alpha = 0.10f))
            .border(1.dp, tint.copy(alpha = 0.22f), RoundedCornerShape(11.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(8.dp))
        }
        content()
    }
}

/** 状态条右侧的小播放胶囊 */
@Composable
private fun PlayPill(playing: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    Row(
        Modifier
            .height(28.dp)
            .clip(CircleShape)
            .background(accent.copy(alpha = if (enabled) 0.18f else 0.06f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (playing) Icons.Outlined.Close else Icons.Outlined.PlayArrow,
            contentDescription = if (playing) tr("停止") else tr("试听"),
            tint = accent.copy(alpha = if (enabled) 1f else 0.4f),
            modifier = Modifier.size(13.dp),
        )
        Spacer(Modifier.width(4.dp))
        Text(
            if (playing) tr("停止") else tr("试听"),
            style = MaterialTheme.typography.labelSmall,
            color = accent.copy(alpha = if (enabled) 1f else 0.4f),
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun SampleButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector?,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Row(
        modifier
            .height(42.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(
                icon, contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(14.dp),
            )
            Spacer(Modifier.width(5.dp))
        }
        Text(
            text,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/** 锁定状态的小标签，列表里用 */
@Composable
fun LockedPill() {
    Text(
        tr("已锁定"),
        fontSize = 9.5.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier
            .clip(RoundedCornerShape(5.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
            .padding(horizontal = 5.dp, vertical = 1.dp),
    )
}

@Composable
fun BuiltinPill() {
    Text(
        tr("内置"),
        fontSize = 9.5.sp,
        fontWeight = FontWeight.Bold,
        color = Gold,
        modifier = Modifier
            .border(1.dp, Gold.copy(alpha = 0.35f), RoundedCornerShape(5.dp))
            .padding(horizontal = 5.dp, vertical = 1.dp),
    )
}
