package ai.breeze.tts.diag

import android.util.Log
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * 诊断/实验的自带日志。
 *
 * 为什么不能只靠 Logcat：手机不在电脑边上，出问题时用户只能截图。
 * 之前 1.9.69 的对照实验每一行都显示「失败」，界面上没有原因、Logcat 也拿不到，
 * 只能靠猜。所以这里做两件事：
 *   1) 把每次运行的关键事实（请求参数、native 返回值、计时是否到达、错误栈）
 *      写进内存环形缓冲，诊断页能直接看、能一键复制；
 *   2) 同时追加到 filesDir/diag/diag.log，进程被杀或重启后现场还在。
 *
 * 体量很小（一次实验几十行），所以同步写盘不引入协程/队列；只在测试路径调用。
 */
object DiagLog {

    private const val MAX_LINES = 1500
    private const val ANDROID_TAG = "BreezeDiag"

    private val lock = Any()
    private val lines = ArrayDeque<String>()
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val day = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)

    private var file: File? = null
    private var out: BufferedWriter? = null

    /** 绑定落盘文件。多次调用以最后一次为准（换路径时关掉旧流）。 */
    fun attach(f: File) {
        synchronized(lock) {
            if (file?.absolutePath == f.absolutePath && out != null) return
            runCatching { out?.close() }
            out = null
            file = f
            runCatching {
                f.parentFile?.mkdirs()
                out = BufferedWriter(FileWriter(f, true))
            }
        }
    }

    val logFile: File? get() = file

    /** 开一批新测试：内存缓冲清空，文件里留一条会话分隔线（历史记录保留）。 */
    fun begin(title: String) {
        synchronized(lock) {
            lines.clear()
            write('I', "===== $title · ${day.format(Date())} =====")
        }
    }

    fun i(tag: String, msg: String) = log('I', tag, msg, null)
    fun w(tag: String, msg: String) = log('W', tag, msg, null)
    fun e(tag: String, msg: String, t: Throwable? = null) = log('E', tag, msg, t)

    fun log(level: Char, tag: String, msg: String, t: Throwable? = null) {
        synchronized(lock) {
            write(level, "${ts.format(Date())} $level/$tag $msg")
            if (t != null) {
                // 栈整段留下：崩溃类问题的价值全在这里
                for (line in t.stackTraceToString().lineSequence()) {
                    if (line.isBlank()) continue
                    write('E', "    " + line.take(300))
                }
            }
        }
    }

    private fun write(level: Char, line: String) {
        when (level) {
            'E' -> Log.e(ANDROID_TAG, line)
            'W' -> Log.w(ANDROID_TAG, line)
            else -> Log.i(ANDROID_TAG, line)
        }
        if (lines.size >= MAX_LINES) lines.removeFirst()
        lines.addLast(line)
        runCatching {
            out?.apply { write(line); newLine(); flush() }
        }
    }

    fun dump(): String = synchronized(lock) { lines.joinToString("\n") }

    fun lineCount(): Int = synchronized(lock) { lines.size }

    /** 清空内存缓冲（文件保留，方便事后回看）。 */
    fun clear() {
        synchronized(lock) { lines.clear() }
    }
}
