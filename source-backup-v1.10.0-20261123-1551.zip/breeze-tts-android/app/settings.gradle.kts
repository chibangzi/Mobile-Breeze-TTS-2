pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    // 允许外部 init 脚本追加仓库（CI / 国内镜像），但以 settings 里声明的为准
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
        // 国内网络可打开阿里云镜像
        maven("https://maven.aliyun.com/repository/public")
    }
}

rootProject.name = "BreezeTTS"
include(":app")
