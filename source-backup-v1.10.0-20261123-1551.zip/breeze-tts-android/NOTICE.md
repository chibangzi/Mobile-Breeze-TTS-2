# 许可与合规提示

## 1. 模型权重

Breeze TTS 2 的推理代码以 Apache-2.0 发布，但**模型权重、派生模型（包括社区发布的
`.gguf` 量化文件，如 Q4_K / Q8_0）、自托管输出**遵循 BreezeBlue Research and Non-Commercial License：

> Source code is licensed under Apache 2.0. Breeze TTS 2 model weights, derivative models,
> and self-hosted outputs are for research and non-commercial use only.

含义：

- 只能用于研究与非商业用途；
- 量化、蒸馏、剪枝后的权重仍受同一许可约束，**不能因为"我改了格式"就主张不受约束**；
- 商业使用必须向 BreezeBlue 取得书面授权；
- 本项目**不分发任何权重，也不再需要自行转换**。App 内的下载与导入只负责把使用者
  自行获取的 GGUF 放到手机本地；权重来源、授权与使用方式的合规责任在使用者。

## 2. 声音与人格权

音色克隆涉及他人人格利益。使用本 App 时你确认：

- 只克隆**你本人**或**已获得明确书面授权**的声音；
- 不用于冒充、诈骗、伪造证据、制作误导性内容；
- 遵守当地关于深度合成内容标识的规定（中国境内需按《深度合成规定》添加显著标识）。

「音色」页的克隆流程界面会持续显示这一提醒；使用者需在每次克隆前自行确认。

## 3. 离线语音识别（ASR）模型

克隆音色的「自动识别文本稿」使用 **sherpa-onnx + SenseVoice**
（`csukuangfj/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17`）多语种大模型，
提供 int8（约 239 MB）与 FP32（约 938 MB）两档。模型由使用者在 App 内按需下载，
按其发布方许可仅用于本机离线转写，音频不会上传到任何服务器。
本项目不分发该模型文件。

## 4. 第三方组件

| 组件 | 许可 |
| --- | --- |
| Breeze-TTS-2.cpp（`libbreeze_gguf.so`） | Apache-2.0 |
| ggml / ggml-cpu / ggml-base | MIT |
| Breeze TTS 2 官方推理代码 | Apache-2.0 |
| T5Gemma2 / Qwen3 / Qwen3-TTS Tokenizer（权重） | 随 Breeze 权重一并受非商用许可约束 |
| sherpa-onnx / onnxruntime | Apache-2.0 |
| SenseVoice 识别模型 | 按其 HF 仓库许可（FunAudioLLM / 社区导出） |
| AndroidX / Jetpack Compose | Apache-2.0 |

## 5. 免责

本项目是工程参考实现：端上推理依赖硬件、驱动与 ggml / GGUF 版本，作者不对音质、
稳定性、生成内容的合法性作任何担保。使用前请自行评估合规风险。

**1.4 起 GPU（Vulkan）加速已完全移除，App 只使用 CPU 后端。** 原因是实测在骁龙 8 Elite
上 Vulkan 既不提速（Adreno 830 在当前 Android 驱动下不向应用暴露矩阵单元与整数点积，
逐帧自回归解码又是 DRAM 带宽瓶颈），还会因 FP16 数值路径把声码器输出变成噪声，
并在部分驱动上于 device 初始化阶段直接崩溃。相关评估见
`docs/10-v1.4-remove-gpu.md`。音频回调仍保留逐样本 `isfinite` 拦截，
任何来源的 NaN/Inf 都不会被写入 WAV。
