# Breeze TTS Local · Android 原生端侧语音合成（GGUF 版）

把 **Breeze TTS 2**（3.5B，中英双语，音色克隆 / 音色设计 / 情绪指令）跑在手机本地。
**导入一个量化 `.gguf` 就能用**——不需要 PC 转换、不需要清单文件。

- 后端：[Breeze-TTS-2.cpp](https://github.com/pcloth/Breeze-TTS-2.cpp) / ggml 的 C API，GGUF 原生格式
- 基线：**12 GB 内存 / 骁龙 8 Elite / Android 13+**（不为低端机做妥协）
- 能力：克隆任意音色、设计音色、用自然语言指令控制情绪与表达、内联语气事件
- 形态：Kotlin + Jetpack Compose 单 Activity + C++17 JNI + `libbreeze_gguf.so`
- 权重：**App 不内置**。模型页可同时下载多个量化档位并随时切换，也可直接导入本地 `.gguf`

> **1.9.12 版**新增 **AI 扩写**：单人朗读与多角色剧本的输入框各有一个「AI 扩写」按钮，
> 把输入内容当需求，调用你配置的 OpenAI 兼容接口生成可朗读的正文或剧本；结果可取消、
> 再次生成或一键替换。设置页新增 **AI 接口**，支持多家厂商模板与自定义 OpenAI 兼容
> 地址，可保存多条、启用/编辑/删除（同时只启用一条）。另外：单人/多角色输入不再共通；
> 生成结果**不再自动入库**，改为点「收藏」才进入**收藏夹**（导航「历史」→「收藏」），
> 长按可多选、全选/反选、批量导出与删除；导出命名统一为
> `音色名_台词前十字_0001.wav`。详见 [`docs/30`](docs/30-v1.9.12-ai-expand-favorites.md)。
>
> **1.9.11 版**彻底删除 GPU 相关设置与代码（探测已证实不值得写后端），同时新增
> **CPU 优化：参考前缀 embedding 复用**（默认关闭的独立开关）。开启后，同一音色的
> 参考文本与参考码本只在首次生成时编码一次，后续每句、CFG 两条分支都直接复用缓存，
> 只重算本次要说的话（含情绪/指令尾段）。关闭时逐位等价于稳定管线。
> 设置页新增「实验性优化」卡片。详见 [`docs/29`](docs/29-v1.9.11-gpu-removal-and-prefix-emb.md)。
>
> **1.9.10 版**修正了 1.9.9 探测里的一个**测量错误**：CPU 基线在计时循环里每轮
> 新建并 join 8 个线程（30 轮 = 240 次 `pthread_create` / `join`，约 0.3–0.6 ms 假开销），
> 把 `GPU / CPU = 1.51x` 明显高估了。现在改成与 ggml 同构的持久线程池 + 屏障。
> 同时补齐四项口径：逐帧小 dispatch 往返、优化版 GEMV shader 对照、
> **fp16 激活 + 大 α 的 sin 链路**（复现 1.3 整段噪声的机制）、GEMM 512³ 算力。
> 协作矩阵设备报「有」，但 NDK r26c 的 glslang 不支持该扩展，无法现场验证；
> 且 decode 是 M=1 GEMV，本就用不上。详见 [`docs/28`](docs/28-v1.9.10-vulkan-probe-fix.md)。
>
> **1.9.9 版**把 GPU 这条路一次性测清：设置 → 推理与性能 → **GPU 可行性诊断** →
> 「运行 GPU 能力探测」。Vulkan 探测跑在 `:gpuprobe` **独立进程**里（驱动 SIGSEGV 也不会
> 打死主程序），报告设备能力（协作矩阵 / 整数点积 / 子组 / 显存）并现场跑三个微基准：
> 纯带宽、主干形状的 **Q8 GEMV 2048²** GPU vs 8 线程 CPU、声码器 `sin` 精度对拍。
> 同时修正 1.9.8 探测报告的归因错误：`/vendor/lib64/libOpenCL.so` 是**存在但被
> linker namespace 隔离挡住**，不是「没有 GPU 驱动」。本版不接后端、不改推理路径。
> 详见 [`docs/27`](docs/27-v1.9.9-vulkan-probe.md)。
>
> **1.9.8 版**加了 **OpenCL 只读探测**（设置 → 推理与性能 → GPU 加速 → 运行 OpenCL 探测）：
> 一次点击测出三件决定 GPU 能不能做的事——`libOpenCL.so` 能否加载、单次 buffer 上限
> （模型内存占用 1772 MB 能不能整块放下）、GPU 的 `sin` 与 libm 的误差。探测不碰任何
> 计算路径。同时把**角色名括号从 `[名字]` 改成 `【名字】`**，与内联事件 `[笑]` 分开。
> 详见 [`docs/26`](docs/26-v1.9.8-opencl-probe-and-brackets.md)。
>
> **1.9.7 版**做掉**参考前缀的 KV 复用**：一次生成的 prompt 前半段（`[S0]`+参考文本、
> 参考码本、eos）只由音色决定，换句子也不变，过去却每句都重算一遍。现在把它算出的
> K/V 存下来，下次直接把位置指到前缀末尾、只跑新增的尾巴——复用的是同一批数值，
> 与全量预填充逐位相同，不涉及任何近似。面板会显示 `参考前缀复用 x/y tokens`。
> 顺带修掉了构建脚本重复打补丁会把代码写重的隐患。GPU 这一版仍未接入，
> 收益账与下一步的最小验证方案见 [`docs/25`](docs/25-v1.9.7-prefix-kv-cache.md)。
>
> **1.9.6 版**把每句生成里固定浪费的 **4.1 秒**拿掉了：参考音频过去每次都要重新过
> 一遍 Mimi encoder，现在首次合成后把码本缓存到 `<音色 id>.codes`，之后直接复用。
> 顺手删掉了深度卷积里的一个 `GGML_OP_ROLL`（等价于左填充，逐元素对拍一致），
> 为 GPU 清掉一个拦路算子。GPU 本体这一版**没有做**，审计结果见
> [`docs/24`](docs/24-v1.9.6-codes-cache-and-gpu-audit.md)：OpenCL 能编、Q8_0 算子在、
> 但声码器缺 `SIN`，且 3.3 GB 权重放不进 GPU buffer，只做声码器只值 1.8 秒。
>
> **1.9.5 版**把声码器的 6 层**转置卷积改成 GEMM**（主机实测 1.75–2.2×，数值对拍 14 组
> 误差 1e-7；真机声码器 −21%）、**编入 KleidiAI**、**设置页拆成二级分类**。
> KleidiAI 后来证实是死代码——加载器只认名字含 `REPACK` 的 buffer，`CPU_KLEIDIAI`
> 匹配不上，那 124 个符号一次都没执行过。详见
> [`docs/23`](docs/23-v1.9.5-convtr-kleidiai-settings.md)。
>
> **1.9.4 版**加了**多角色对话**：在剧本里用 `【名字】(情绪): 台词` 逐行写，
> 每句自动切到同名音色的声音，句间留 260 ms 换人停顿，最后合成为一个 WAV。
> 同时修掉六处交互问题：设计音色「生成试听样本」现在有状态条、试听键并自动播放
> （样本先落暂存位，不确认不会改掉已锁定的音色）；提示从 10 秒缩到 2 秒；
> 生成/停止按钮从通栏改成右侧 44 dp 主操作、导出挪进播放卡片；情绪输入框回来了，
> 上方多了「预设库 / 存为预设」两个按钮；音色与预设浮层换了更亮的底色并给背景加真虚化。
> 详见 [`docs/20-v1.9.4-dialogue-and-sheets.md`](docs/20-v1.9.4-dialogue-and-sheets.md)。
>
> **1.9.3 版**给音色加上**头像与性别**，并把两处选择改成浮层：音色点开是
> 男女分栏的三列网格（头像右下角带 ♀/♂ 角标），情绪点开是竖排预设列表；
> 新建与编辑音色时都能设置头像、性别。更关键的是**设计音色可以锁定了**——
> 录一条试听样本，把它的码本留下来，之后音色由码本决定，不再每次都不一样，
> 而情绪仍然可以自由改。详见
> [`docs/19-v1.9.3-voice-avatar-and-locking.md`](docs/19-v1.9.3-voice-avatar-and-locking.md)。
>
> **1.9.2 版**重做合成页的两块交互：情绪指令可以**存成预设**（内置六条只是种子，
> 之后随便改、随便删，`恢复默认` 能找回），单击套用、长按就地编辑或删除；
> 音色选择从一排胶囊换成**头像卡片**，克隆/设计不再靠一个 6dp 的小圆点区分。
> 只改界面与本地存储，推理链路与 1.9 完全一致。详见
> [`docs/17-v1.9.2-emotion-presets-and-voice-tiles.md`](docs/17-v1.9.2-emotion-presets-and-voice-tiles.md)。
>
> **1.9 版**修掉「切到 Q4/Q6 模型立刻闪退」：1.7 的 repack 加载把主干输出头
> `bb.lm_head.weight`（2048 → **2052** 行）也放进了 8 行交错的 buffer，而 2052 % 8 = 4，
> ggml 选不到内核、把 nullptr 存进 `tensor->extra`，写入时通过空指针调用纯虚函数。
> Q8_0 只要求 4 行一组，所以一直正常。现在按「量化类型的行数倍数」筛选候选，
> 并在分配后逐个核对 `tensor->extra` 兜底回退。详见
> [`docs/15-v1.9-q4-repack-crash.md`](docs/15-v1.9-q4-repack-crash.md)。
> **1.8 版**修掉「设计音色一填情绪就被覆盖」：上游只有一个 instruction 槽位，
> 旧代码在有情绪指令时把音色描述整体丢掉，于是没有参考音频的设计音色失去年龄/性别依据，
> 小孩退回中性成人声。现在改成「音色描述在前、表达在后」合并，身份先落地、表达只改语气。
> 同版把生成页参数区改为默认折叠（标题行显示当前值），历史条目左滑增加「导出」。
> 详见 [`docs/14-v1.8-design-voice-priority.md`](docs/14-v1.8-design-voice-priority.md)。
> **1.7 版**接上了一直没接通的加速通道：编译时开了 `+i8mm`、`GGML_CPU_REPACK=ON`，
> 但权重是按默认 buffer 加载的，`should_repack()` 从未被问到，所有矩阵乘都在跑标量解包。
> 现在 matmul 权重按 8 行交错装进 repack buffer，`q4_K_8x8_q8_K` 等 i8mm 内核才会被调用，
> 逐帧解码预计快 1.3–1.6×。加载时用磁盘原始字节对拍，布局不对就自动退回普通路径。
> 模型页「计算后端」会显示 `CPU · i8mm 84块/1063MB`。详见
> [`docs/13-v1.7-i8mm-repack.md`](docs/13-v1.7-i8mm-repack.md)。
> **1.6 版**修掉「生成完还要卡几十秒」：模型在最后一个字之后会继续空转全 pad 帧，
> 这些帧不产音频却每帧都要跑主干 + 深度解码，取消也看不到（只在 flush 里检查）。
> 现在每帧检查取消、连续 16 帧空帧即收尾，播放尾音改成后台线程；顺带把分块调度
> （首块 4 → 16 帧、块增速 ×1.5、上限 72）重排，5 秒短句的声码器解码量少 45%。
> 详见 [`docs/12-v1.6-tail-fix-and-speed.md`](docs/12-v1.6-tail-fix-and-speed.md)。
> **1.5 版**解决「念几个字停一段」：根因是生成慢于实时（RTF > 1）+ 边生成边播 +
> 声码器每次 flush 都要重算 88 帧上下文。现在把流式块从 25 帧提到 64 帧、
> 播放端改成「先攒够再开播」并修掉结尾被截断的 bug，界面换成**黑 + 琥珀**并重做音色列表。
> 详见 [`docs/11-v1.5-speed-and-ui.md`](docs/11-v1.5-speed-and-ui.md)。
> **1.4 版**修复「开 Vulkan 后启动即闪退、之后再也进不去」，并彻底移除 GPU 加速，
> 见 [`docs/10-v1.4-remove-gpu.md`](docs/10-v1.4-remove-gpu.md)。
> 1.3 的 Vulkan 杂音取证与 NPU 评估见 [`docs/08-v1.3-vulkan-npu.md`](docs/08-v1.3-vulkan-npu.md)；
> Nexa SDK / CloneTTS 调研见 [`docs/09-nexa-clonetts-npu-evaluation.md`](docs/09-nexa-clonetts-npu-evaluation.md)；
> 1.2 的六项修复见 [`docs/07-v1.2-changes.md`](docs/07-v1.2-changes.md)。

## 直接安装

| 文件 | 说明 |
| --- | --- |
| `dist/BreezeTTS-1.9.12/BreezeTTS-1.9.12-release.apk` | zipalign + apksigner 签名的正式包（推荐） |
| `dist/BreezeTTS-1.9.12/BreezeTTS-1.9.12-debug.apk` | debug 包，带日志、可调试 |

```bash
adb install -r dist/BreezeTTS-1.9.12/BreezeTTS-1.9.12-release.apk
```

- 仅 `arm64-v8a`，`minSdk 33` / `targetSdk 35`，`versionCode 24 / versionName 1.9.12`
- 包内自带原生库：`libbreeze.so`（JNI 桥接）、`libbreeze_gguf.so`、`libggml*.so`（纯 CPU）、
  **`libsherpa-onnx-jni.so` / `libonnxruntime.so`**（离线 ASR）。**无 GPU 后端库**。
- **首启动不含任何权重**，也不含 ASR 模型（用时再下载）
- release 使用 `signing/breeze-test.jks` 的**测试签名**（口令 `breezetest`），仅用于自测分发；
  与 1.0–1.4 同一 keystore，**可直接覆盖安装**
- **1.3 闪退循环的用户**：不用卸载，直接覆盖安装新版即可。
  so 里没有任何 Vulkan 代码，旧的 `use_gpu=true` 设置项已不再被读取。模型与音色库保留。

## 三步用起来

1. 安装 APK。
2. 「模型」页任选一个档位 → **下载此模型**（默认 hf-mirror，断点续传 + GGUF 文件头校验）；
   可同时装多个，点「**切换使用**」换模型；或点「从本地导入 GGUF」离线安装。
3. 回「合成」页输入文本、写表达/情绪指令、点开音色浮层挑一个，点生成；
   想做多人对话就把顶部切到「多角色对话」，按 `[名字](情绪): 台词` 逐行写剧本。

生成后的音频可**反复播放**、**导出 WAV**（成功会提示完整路径，位置在「模型」页设置），
并自动进入「**历史**」页；历史条目可点击播放、左滑导出或删除。

## 功能一览（1.2 基础 + 1.9）

| 页面 | 能做什么 |
| --- | --- |
| **合成** | **单人朗读 / 多角色对话**切换：多角色按剧本 `[名字](情绪): 台词` 逐句换音色；音色与情绪都是**浮层**（三列头像网格 / 竖排预设列表，背景虚化）；情绪既能手写也能从预设挑、一键存成预设；内联语气事件 `[笑] [叹气]`；生成中实时显示 **RTF** 与当前句；生成后可播放/暂停/拖动/重播/导出 |
| **历史** | 所有生成过的音频，点击播放；向左滑动露出「导出 / 删除」；自动保留最近 200 条 |
| **音色** | 分段切换「克隆音色 / 音色设计」；音色可设**头像与性别**（无头像显示名字首字，男女不同底色）；设计音色可**锁定音色**：录一条试听样本自动试听，满意再锁定，之后每次都一样；克隆支持 **WAV / MP3 / M4A / AAC / OGG / FLAC** 自动转码，并用 **SenseVoice 离线大模型**自动识别文本稿 |
| **模型与设置** | 多档位下载 / 删除 / 切换使用；**分阶段线程优化**；**CFG 指令遵从强度**（默认 4.0，与 PC 一致）；CPU 线程数；启动预热；WAV 导出目录；ASR 档位（int8 / FP32） |
| **外观** | **黑 + 琥珀**配色，固定深色主题；卡片用细描边分层，主按钮深色字压琥珀渐变 |

### 关键修复：为什么「老头」会变成年轻人声音

上游 `build_segments` 只在**条件分支**把 `<ins_bos>描述<ins_eos>` 拼进 prompt，
CFG 的作用是放大「带指令 / 不带指令」的 logits 差：`unc + cfg * (cond - unc)`。
1.1 版把 `cfg_scale` 写死成 **1.0**，`use_cfg=false`，连非条件分支都不构建，
描述被模型默认先验稀释 → 输入「一个年迈的老头苍老的声音」退化成偏年轻的中性声音。

PC 端用的是 **cfg=4**，输入同样是中文、同样是那句描述，所以正常。
1.2 版把 CFG 透传并**默认设为 4.0**（可在模型页 1–6 调整），instruction 原样传递不改写，
并让 `breeze_warmup` 同时预热 CFG / 非 CFG 两条路径。
**纯克隆且没有任何指令时自动不使用 CFG**，以保证音色保真并省掉第二份 KV cache。

### 性能（1.5 调整：流式块与播放缓冲）

- **流式块 25 → 64 帧**。声码器每次 flush 都要重算 `sliding_window(72)+16 = 88` 帧上下文，
  25 帧块等于做 113 帧卷积只吐 25 帧（4.5 倍冗余），64 帧降到 2.4 倍。
  为此在 `breeze_request` 里新增 `chunk_first/chunk_max/pace` 三个字段。
- **播放端预缓冲**：`AudioTrack` 容量 1 秒 → 8 秒，并改成「攒够 `prebufferMs` 才开播」，
  把周期性断流换成一次起始等待；预缓冲长度按**上次实测 RTF** 自适应
  （`2000 + (RTF-1)×6000` ms，上限 12 s，且不超过预估时长的一半）。
- **修掉结尾截断**：结束时不直接 `stop()`，而是等尾音播完再释放 —— 1.6 起这段等待
  挪到后台线程，只影响尾音、不再拖住「生成完成」。
- **RTF 可见**：生成卡片直接显示实时率，并按它解释为什么会长短不一。
- 详细原因链条与剩余优化空间见 [`docs/11-v1.5-speed-and-ui.md`](docs/11-v1.5-speed-and-ui.md)。

### 性能（1.4：纯 CPU）

- **GPU 已彻底移除**。1.3 修好了 Vulkan 的数值错误（强制 FP32 + GPU/CPU 对拍自检），
  但真机反馈是「开关一开就闪退、之后永久闪退」——GPU backend 在 device 初始化阶段
  直接崩在 native 层，而 `use_gpu=true` 是持久化的，于是每次都崩在启动自动加载那一步。
  按照「不能大幅提速就删」的判据，1.4 删掉了开关、自检、回退、JNI 入口、`gpu_probe.*`
  与 35 MB 的 `libggml-vulkan.so`，运行时重新按 `BREEZE_VULKAN=OFF` 交叉编译。
  提速上限的量化推导（Amdahl + 各阶段耗时占比）见
  [`docs/10-v1.4-remove-gpu.md`](docs/10-v1.4-remove-gpu.md)：乐观上限约 **1.30×**，
  且在 FP32 强制后必然回落，实际持平或更慢——不具备做的价值。
- **CPU 分阶段线程**（可随时开关）：prefill 用满线程做计算密集大 GEMM，
  首个音频块吐出后自动降到 2–4 线程做逐帧 decode，减少 ggml barrier 空转与降频。
- **ARM 量化内核**：`-DGGML_CPU_ARM_ARCH=armv8.6-a+dotprod+i8mm+fp16`，
  反汇编 `libggml-cpu.so` 含 1167 条 `sdot`/`smmla`/`ummla` 指令（1.0 版为 0）。
  但**指令在库里不等于在跑**：直到 1.7 才发现权重是按默认 buffer 加载的，
  `should_repack()` 从未被调用，这些内核一直是死代码，见 `docs/13`。
- **可调线程数**（1–8，即时生效）与**启动预热**（覆盖两条 CFG 路径）。
- 手机 **NPU 加速可行性**的完整评估见 [`docs/08-v1.3-vulkan-npu.md`](docs/08-v1.3-vulkan-npu.md)：
  硬件算力够用，但 GGUF 量化格式、四阶段自回归架构、当前 QNN 算子覆盖与分发许可
  使整链路 NPU 化短期不划算；短期收益最大的是 CPU 侧优化。
- 补充调研 [`docs/09-nexa-clonetts-npu-evaluation.md`](docs/09-nexa-clonetts-npu-evaluation.md)：
  Nexa SDK 的 GGUF 与 NPU 互斥、CloneTTS 实际为闭源 APK；但 CloneTTS 验证了
  「小体量非自回归 TTS + QNN 静态图」在 8 Elite 上约 2× 可行，据此给出双引擎落地方案。

## 架构

```
Kotlin / Compose（合成 · 历史 · 音色 · 模型与设置）
   │  BreezeEngine.kt ── JNI
   ▼
libbreeze.so              本工程桥接层（cfg_scale / 分阶段线程 / 后端查询）
   │  breeze_init / set_threads / warmup / generate（C API）
   ▼
libbreeze_gguf.so         Breeze-TTS-2.cpp
   ├─ GGUF 读取 + tokenizer + 长文本切分
   ├─ T5Gemma2 文本编码器 → Qwen3 主干（KV cache，CFG 时两份）
   ├─ 15 步帧内深度解码器
   ├─ Mimi codec 编码（克隆）/ 声码器解码（24 kHz）
   └─ ggml CPU 后端（ARM dotprod / i8mm）
   ▲
models/<档位>/model.gguf   单文件，2.4 – 5.9 GB（可同时装多个）

旁支：sherpa-onnx + SenseVoice（离线 ASR，克隆时转写参考音频文本稿）
      AudioDecoder（MediaCodec 把 mp3/m4a/… 统一转成 24 kHz PCM WAV）
```

音频以 `float32` 分块回调（25 帧 ≈ 2 秒），JNI 转 PCM16 后交给 `AudioTrack` 流式播放。
完整契约与交叉编译细节见 [`docs/02-gguf-backend.md`](docs/02-gguf-backend.md)。

## 模型档位

默认仓库 [`HoppouAI/Breeze-TTS-2.cpp`](https://huggingface.co/HoppouAI/Breeze-TTS-2.cpp)，
这些 GGUF **自带 codec，单文件即可推理**：

| id | 文件 | 大小 | 说明 |
| --- | --- | --- | --- |
| `q4_k` | `breeze-tts-2-q4_k.gguf` | ~2.4 GB | 默认推荐，占用最小 |
| `q6_k` | `breeze-tts-2-q6_k.gguf` | ~2.9 GB | 音质 / 体积折中 |
| `q8_0` | `breeze-tts-2-q8_0.gguf` | ~3.3 GB | 上游推荐，接近 F16 |
| `f16` | `breeze-tts-2-f16.gguf` | ~5.9 GB | 未量化，明显更慢 |

两点避坑：

- 不要用 `-dd2` / `-dd4` 变体（连深度解码器一起量化，误差沿帧累积）。
- [cstr/breeze-tts-2-GGUF](https://huggingface.co/cstr/breeze-tts-2-GGUF) 等打包
  **不含 codec**，`breeze_init` 会失败；请用上面的完整单文件版。

## 离线 ASR 模型

[`csukuangfj/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17`](https://huggingface.co/csukuangfj/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17)，
可在模型页或克隆页选择档位：

| 档位 | 文件 | 大小 |
| --- | --- | --- |
| 标准 int8 | `model.int8.onnx` + `tokens.txt` | ~239 MB |
| 高精度 FP32 | `model.onnx` + `tokens.txt` | ~938 MB |

中文带标点，抗噪、专名与长句准确率远高于旧版 Vosk small-cn（42 MB）。
下载源 hf-mirror 优先、官方回退，支持 Range 续传；识别全程本地，音频不上传。

## 从源码构建

环境：JDK 17+（实测 20）、Android SDK 35 / Build-Tools 35.0.0 / NDK 27.1.12297006 /
CMake 3.22.1 / Gradle 8.9+（实测 9.3）。

```bash
# 1) 交叉编译 GGUF 运行时（纯 CPU + ARM 量化内核，so 自动放入 jniLibs）
ANDROID_HOME=/path/to/android-sdk ./tools/build_breeze_android.sh

# 2) 构建 APK
cd app
gradle :app:assembleDebug
gradle :app:assembleRelease    # release 需 zipalign + apksigner
```

预编译 so、C API 头文件与 `libs/sherpa-onnx-classes.jar` 已随工作区提供，
只改 Kotlin / JNI 业务代码时无需重跑第 1 步。

### 源码备份包（`backups/`）

工作区不带 git，所以每个版本都在 `backups/` 打一份 `source-backup-v<版本>-full-<时间>.zip`
（约 0.9 MB / 250 个文件）。包内结构：

| 路径 | 内容 |
| --- | --- |
| `app/` | 完整 Android 工程：Kotlin（41 个 `.kt`）、JNI 桥与引擎（`src/main/cpp/`）、C API 头、Gradle 脚本、`libs/sherpa-onnx-classes.jar` |
| `native-src/` | Breeze-TTS-2.cpp 的**已打补丁源码快照**（`src` + `include` + `cmake` + CMakeLists），39 个文件 |
| `tools/` | 交叉编译脚本 + `patches/breeze-vendor.patch` + `patches/native-1.9.43.patch` |
| `docs/` | 全部版本的设计与根因文档 |
| 根目录 | `README.md`、`LICENSE`、`NOTICE.md` |

**包内刻意不含**：`jniLibs/*.so`（31 MB，可由第 1 步重建）、模型 `.gguf`、`signing/*.jks`、
`build/`、`.cxx/`、`.gradle/`、`local.properties`。

拿到包后能复现的路径：

```bash
unzip source-backup-v1.9.62-full-*.zip -d breeze && cd breeze
ANDROID_HOME=/path/to/android-sdk ./tools/build_breeze_android.sh   # 拉上游 + 打两个补丁 + 编 so
cd app && gradle :app:assembleRelease                              # 产出未签名 APK
```

`native-src/` 是「补丁已完成」的快照，用于对照或离线构建；正常路径不用它，
脚本会重新拉上游 main 并逐项打补丁。

## 目录

| 路径 | 说明 |
| --- | --- |
| `dist/*.apk` | 已编译并签名的安装包 |
| `signing/` | 测试用 keystore |
| `docs/01-research-breeze-tts-2.md` | 模型结构、prompt 模板、特殊 token id |
| `docs/02-gguf-backend.md` | C API 契约、字段映射、交叉编译、限制 |
| `docs/06-features-and-performance.md` | 1.1 功能与 ARM 量化内核优化 |
| `docs/07-v1.2-changes.md` | 1.2 六个问题的根因分析与修复 |
| `docs/08-v1.3-vulkan-npu.md` | 1.3 Vulkan 杂音取证 / 数值自检，以及手机 NPU 加速可行性评估 |
| `docs/09-nexa-clonetts-npu-evaluation.md` | **Nexa SDK / CloneTTS 调研：能否借 NPU 提速、双引擎方案与代价** |
| `docs/10-v1.4-remove-gpu.md` | 1.4 闪退根因、GPU 提速上限量化评估、移除清单 |
| `docs/11-v1.5-speed-and-ui.md` | 1.5 卡顿原因链条、流式块与预缓冲优化、黑金界面改版 |
| `docs/12-v1.6-tail-fix-and-speed.md` | 1.6 收尾卡几十秒的根因（尾部空帧空转）、进度条与停止语义修复、分块调度加速账 |
| `docs/13-v1.7-i8mm-repack.md` | 1.7 权重没走进 i8mm 内核的断点、repack 加载与对拍回退、剩余优化空间清单 |
| `docs/14-v1.8-design-voice-priority.md` | 1.8 设计音色被情绪指令覆盖的根因与合并策略、参数折叠、历史左滑导出 |
| `docs/15-v1.9-q4-repack-crash.md` | **1.9 Q4/Q6 切模型闪退的根因（输出头 2052 行 × 8 行交错 → 空内核）、两道回退闸门** |
| `docs/16-v1.10-vocoder-and-depth-speed.md` | 1.10 的三项提速尝试（声码器分块 / 深度单分支 / F16 权重）。**已整体回退**，保留作数据与推导记录 |
| `docs/17-v1.9.2-emotion-presets-and-voice-tiles.md` | 1.9.2 情绪预设的存储与增删改、音色头像卡片、虚线入口的语义 |
| `docs/18-v1.9.3-voice-avatar-gender-and-design-lock.md` | 1.9.3 设计稿：头像/性别/两个浮层的设计决策，设计音色固定不下来的根因与三种方案 |
| `docs/19-v1.9.3-voice-avatar-and-locking.md` | **1.9.3 实现：头像纯色规则、码本输入输出（C API 改动）、锁定的完整流程** |
| `docs/ui-preview-1.5.html` | 界面预览（浏览器打开，三个页面的实际配色与布局） |
| `docs/ui-preview-1.9.2.html` | 1.9.2 合成页设计稿：新旧音色选择对比、预设条、长按菜单 |
| `docs/ui-preview-1.9.3.html` | 1.9.3 设计稿：音色浮层（男女分栏）、情绪浮层、音色编辑页 |
| `docs/legacy-mnn/`、`tools/legacy-mnn/` | 旧 MNN / ONNX 转换路线（已归档） |
| `tools/build_breeze_android.sh` | GGUF 运行时 arm64 交叉编译脚本（默认纯 CPU；`BREEZE_VULKAN=ON` 可开回 Vulkan） |
| `app/` | Android 工程（Compose UI + JNI + 预编译 so） |

## 验证过的部分

- **完整推理已由用户在真机验证**：能正确生成音频。
- **完整 APK 构建链路**：Kotlin（Compose）、C++17、JNI、CMake、打包、zipalign、apksigner 签名通过。
- **原生依赖链**：`libbreeze.so → libbreeze_gguf.so → libggml*.so`（不含 Vulkan）；
  1.4 的 8 个 JNI 入口（`nativeCreate` / `nativeDestroy` / `nativeSynthesize` /
  `nativeCancel` / `nativeWarmup` / `nativeSetThreads` / `nativeBackendName` /
  `nativeSetPhaseThreads`）齐全，`libbreeze.so` 引用的 8 个 `breeze_*` 符号
  **全部可解析、0 缺失**；`libsherpa-onnx-jni.so` 的 JNI 符号与其 so 依赖齐全。
- **APK 内已无任何 Vulkan 文件**：`libggml-vulkan.so` 不再打入包内，包体从 41 MB 降到 31 MB；
  `libbreeze_gguf.so` / `libggml.so` 的 `DT_NEEDED` 里也已无 `libggml-vulkan.so` / `libvulkan.so`。

## 还没验证 / 需要真机的部分

- **1.4 未做真机推理实测**：沙箱无 2.4 GB 权重、无 Android 设备。1.4 相对 1.2 的
  CPU 推理路径完全没变（same so 编译选项、same 调用链），预期与已验证可用的 1.2 一致。
  唯一的行为变化是「不再有任何 GPU 代码」，而这正是修复闪退的关键。
- **闪退修复的验证方式**：从 1.3 直接覆盖安装 1.4，确认能正常启动并进入合成页；
  这一步不依赖模型下载，装完就能验证。
- **CPU 分阶段线程的实际收益**：思路有第三方实测支撑，但 8 Elite 的具体最优
  decode 线程数需真机 A/B；设置页可随时开关对比耗时。
- **CFG=4 的耗时**：CFG 会多一份 KV cache 与第二分支深度解码，理论上更慢；
  建议真机对比 CFG 1 / 4 的 RTF。
- **SenseVoice 中文识别准确率**：大模型但对专名、方言仍有误差，克隆文本稿务必人工核对。
- 导出到自定义 SAF 目录在不同厂商文件选择器上的兼容性。

## 已知限制

- `breeze_context` 不可重入，引擎用 mutex 串行化；同一时刻只跑一个合成任务。
- 每次生成仍会重建 KV cache 与计算图（上游实现所限），深度解码器每帧 15 次小图提交。
- CFG > 1 时需要两份 KV cache，F16 档位 + 长文本在大内存机型外可能吃紧。
- 分块大小由 C API 固定为 25 帧，不可调。

## 许可与伦理

推理代码 Apache-2.0 / ggml MIT / sherpa-onnx Apache-2.0；**Breeze TTS 2 的权重与
GGUF 量化派生模型仅限研究与非商业用途**（BreezeBlue Research and Non-Commercial License）。
SenseVoice 模型按其仓库许可使用。禁止未授权的音色克隆、冒充与欺诈；
商用需向 BreezeBlue 取得书面授权。详见 [`NOTICE.md`](NOTICE.md)。
