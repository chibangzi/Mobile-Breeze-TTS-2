#!/usr/bin/env bash
#
# 交叉编译 Breeze-TTS-2.cpp（GGUF / ggml / CPU）→ Android arm64-v8a。
# 1.4 起默认只产出 4 个纯 CPU so，直接放入 app/app/src/main/jniLibs/arm64-v8a/：
#   libbreeze_gguf.so  libggml.so  libggml-base.so  libggml-cpu.so
# 不再包含 libggml-vulkan.so（GPU 加速已整体移除）。
#
# 依赖：Android NDK 27+（含 shader-tools/glslc）、CMake 3.22+、Ninja、Python3、curl、tar
# 用法：
#   ANDROID_HOME=/path/to/android-sdk ./tools/build_breeze_android.sh   # 默认 CPU-only
#   BREEZE_SRC=/tmp/xxx ./tools/build_breeze_android.sh   # 复用已打过补丁的源码目录
#   BREEZE_VULKAN=ON ./tools/build_breeze_android.sh     # 仅供历史复现，1.4 起不再使用
#
# 与上游 main 的差异（由本脚本自动打补丁）：
#   1) 运行时改名 breeze_gguf，避免与 JNI 桥接库 libbreeze.so 冲突；
#   2) Android 不需要 breeze-quantize CLI；
#   3) 增加 breeze_set_threads / breeze_warmup / breeze_backend_name /
#      breeze_backend_is_gpu 四个 C API（线程、双 CFG 路径预热、后端查询）；
#   4) 编译时启用 ARMv8.6 dotprod / i8mm / fp16 量化内核（骁龙 8 Elite）；
#   5) 可选 Vulkan（历史路径，1.4 起不再使用）：glslc 生成 SPIR-V 并补齐头文件。
#
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/app/app/src/main/jniLibs/arm64-v8a"
SRC="${BREEZE_SRC:-/tmp/breeze2cpp-src}"
CACHE="${BREEZE_CACHE:-/tmp/breeze-deps}"

# 源码固定到已验证的组合：pcloth/main + ggml 指定 commit。
BREEZE_TARBALL="https://codeload.github.com/pcloth/Breeze-TTS-2.cpp/tar.gz/refs/heads/main"
GGML_SHA="${GGML_SHA:-36da57138425487184aa1da2eee2cde155909c6f}"
VULKAN_HPP_TAG="${VULKAN_HPP_TAG:-v1.3.275}"

ANDROID_NDK="${ANDROID_NDK:-${ANDROID_HOME:-}/ndk/27.1.12297006}"
ANDROID_ABI="${ANDROID_ABI:-arm64-v8a}"
ANDROID_PLATFORM="${ANDROID_PLATFORM:-android-33}"
JOBS="${JOBS:-$(nproc)}"
ARM_ARCH="${ARM_ARCH:-armv8.6-a+dotprod+i8mm+fp16}"
WANT_VULKAN="${BREEZE_VULKAN:-OFF}"
# KleidiAI：ARM 的矩阵微内核库。ggml 默认 OFF，打开后 q8_0 / q4_0 / f16 的
# MUL_MAT 改走 KleidiAI，在带 SME（骁龙 8 Elite Gen 5、天玑 9500）的机器上
# 会选中 SME2 内核，用上那颗一直闲着的矩阵单元。SME 内核是独立 .S 编译单元，
# 带自己的 -march，所以主库仍兼容 armv8.6，老设备不会 SIGILL。
WANT_KLEIDIAI="${BREEZE_KLEIDIAI:-OFF}"
KLEIDIAI_SRC="${BREEZE_KLEIDIAI_SRC:-$CACHE/kleidiai}"

TOOL="$ANDROID_NDK/toolchains/llvm/prebuilt/linux-x86_64"
SYSINC="$TOOL/sysroot/usr/include"
GLSLC="$ANDROID_NDK/shader-tools/linux-x86_64/glslc"

if [ ! -f "$ANDROID_NDK/build/cmake/android.toolchain.cmake" ]; then
    echo "找不到 NDK toolchain：$ANDROID_NDK" >&2
    echo "请设置 ANDROID_HOME / ANDROID_NDK" >&2
    exit 1
fi

fetch() {  # fetch <url> <out> —— 直连失败时走 gh-proxy
    local url="$1" out="$2" ok=0
    for u in "$url" "https://gh-proxy.com/$url"; do
        if curl -sL --fail --max-time 300 -o "$out" "$u"; then ok=1; break; fi
    done
    [ "$ok" = 1 ] || { echo "下载失败：$url" >&2; return 1; }
}

mkdir -p "$CACHE"
if [ -z "${BREEZE_SRC:-}" ]; then
    echo "== 1/5 拉取源码（pinned ggml ${GGML_SHA:0:12}）=="
    rm -rf "$SRC"
    mkdir -p "$SRC/third_party/ggml"
    fetch "$BREEZE_TARBALL" "$CACHE/breeze.tgz"
    tar xzf "$CACHE/breeze.tgz" -C "$SRC" --strip-components=1
    fetch "https://codeload.github.com/ggml-org/ggml/tar.gz/$GGML_SHA" "$CACHE/ggml.tgz"
    tar xzf "$CACHE/ggml.tgz" -C "$SRC/third_party/ggml" --strip-components=1
else
    echo "== 1/5 复用源码目录 $SRC =="
fi

echo "== 2/5 打补丁（C API / 分块 / 尾帧保护）=="
# 与上游 main 的全部差异都固化在 tools/patches/breeze-vendor.patch：
#   1) 运行时改名 breeze_gguf，避免与 JNI 桥接库 libbreeze.so 冲突；
#   2) Android 不需要 breeze-quantize CLI；
#   3) 新增 breeze_set_threads / breeze_warmup / breeze_backend_name /
#      breeze_backend_is_gpu / breeze_get_timings / breeze_estimate_frames；
#   4) breeze_request 增加 chunk_first / chunk_max / pace / pad_stop
#      （流式分块粒度 + 尾部空帧保护，见 docs/12）；
#   5) generate_chunk 每帧检查取消、连续空帧提前收尾、记录分阶段耗时；
#   6) 权重加载走 CPU repack buffer（8 行交错），否则 i8mm 的 matmul 内核永远不会被调用，
#      见 docs/13。加载后用「磁盘原始字节 vs 实际 mul_mat」对拍，不符则退回普通布局。
# 只打一次。--forward 靠不住：本地改动让前几个 hunk 匹配失败时，后面的 hunk 会以
# fuzz 再应用一遍，把只该出现一次的代码写重（generation.h 的访问器就这样重过）。
# 用一个标记文件记住「这棵树已经打过」，避免每次构建都重打。
if [ -f "$SRC/.breeze_patched" ]; then
    echo "   源码目录已打过补丁，跳过"
else
    if patch -p1 --batch --forward -d "$SRC" < "$ROOT/tools/patches/breeze-vendor.patch"; then
        touch "$SRC/.breeze_patched"
    else
        echo "   补丁有失败项，见 $SRC 下的 .rej" >&2
        exit 1
    fi
fi

# 1.9.43 起 on top of breeze-vendor.patch 的全部改动：后段降 CFG、声码器独立线程、
# 深度解码器动态分支数、1.9.51 逐阶段 trace、1.9.54 convert_voice / breeze_convert、
# 1.9.57 转换进度的两阶段回调（逐帧 / 声码器窗口，后者也能取消）。
# 文件名沿用 1.9.43，内容和上游 breeze-base 对拍过，可完整复现当前这棵树。
if [ -f "$SRC/.breeze_patched_1943" ]; then
    echo "   1.9.43 补丁已应用，跳过"
else
    if patch -p1 --batch -d "$SRC" < "$ROOT/tools/patches/native-1.9.43.patch"; then
        touch "$SRC/.breeze_patched_1943"
    else
        echo "   1.9.43 补丁失败，见 $SRC 下的 .rej" >&2
        exit 1
    fi
fi

# 1.9.100：THP 调度实验。给 C API 加 breeze_set_thp / breeze_thp_bytes /
# breeze_thp_mode，并在 gguf_loader 分配权重区之后、写入之前打 MADV_HUGEPAGE。
# 只动这一处，正式合成路径的行为完全不变（默认不开）。
# 复用已打补丁的源码树时，改动可能已经在了：先看文件里有没有符号再决定要不要打，
# 否则 patch 会检测成「反向补丁」并把这些代码删掉。
if [ -f "$SRC/.breeze_patched_19100" ] || grep -q "breeze_set_thp" "$SRC/include/breeze/breeze.h" 2>/dev/null; then
    echo "   1.9.100 改动已在源码树里，跳过"
    touch "$SRC/.breeze_patched_19100"
else
    if patch -p1 --batch -d "$SRC" < "$ROOT/tools/patches/native-1.9.100.patch"; then
        touch "$SRC/.breeze_patched_19100"
    else
        echo "   1.9.100 补丁失败，见 $SRC 下的 .rej" >&2
        exit 1
    fi
fi

# 1.9.103：把 prefill 的 token 数报上来。之前 breeze_timings.prefill_tokens 一直是 0，
# 因为 generation 从没数过 —— 只有毫秒数，算不出 tok/s，也就判断不了
# 「首声慢是 GEMM 没吃到矩阵单元，还是文本编码器本来就慢」。
if [ -f "$SRC/.breeze_patched_19103" ] || grep -q "tm.prefill_tokens" "$SRC/src/generation.cpp" 2>/dev/null; then
    echo "   1.9.103 改动已在源码树里，跳过"
    touch "$SRC/.breeze_patched_19103"
else
    if patch -p1 --batch -d "$SRC" < "$ROOT/tools/patches/native-1.9.103.patch"; then
        touch "$SRC/.breeze_patched_19103"
    else
        echo "   1.9.103 补丁失败，见 $SRC 下的 .rej" >&2
        exit 1
    fi
fi

# 1.9.104：文本编码器的权重也放进复排 buffer。26 层 × 7 个 matmul 之前全走普通
# Q8_0 布局，batch≈100 的 GEMM 被当成逐行 dot 在算，prompt 阶段 734 ms 只有峰值 1.4%。
if [ -f "$SRC/.breeze_patched_19104" ] || grep -q 'rfind("te.blk."' "$SRC/src/gguf_loader.cpp" 2>/dev/null; then
    echo "   1.9.104 改动已在源码树里，跳过"
    touch "$SRC/.breeze_patched_19104"
else
    if patch -p1 --batch -d "$SRC" < "$ROOT/tools/patches/native-1.9.104.patch"; then
        touch "$SRC/.breeze_patched_19104"
    else
        echo "   1.9.104 补丁失败，见 $SRC 下的 .rej" >&2
        exit 1
    fi
fi

# 1.9.105：参考前缀（参考文本 + 参考音频）的 KV 快照。这一段只取决于音色，
# 但每个请求都要在主干上重算，实测占 prefill 的六到八成。
if [ -f "$SRC/.breeze_patched_19105" ] || grep -q "struct PrefixCache" "$SRC/include/breeze/generation.h" 2>/dev/null; then
    echo "   1.9.105 改动已在源码树里，跳过"
    touch "$SRC/.breeze_patched_19105"
else
    if patch -p1 --batch -d "$SRC" < "$ROOT/tools/patches/native-1.9.105.patch"; then
        touch "$SRC/.breeze_patched_19105"
    else
        echo "   1.9.105 补丁失败，见 $SRC 下的 .rej" >&2
        exit 1
    fi
fi

# 1.9.106：码本截断实验。深度解码占整帧 65%，而它每帧必须把同一份 333 M
# 权重读 15 遍；字节量是结构决定的，唯一能减的是遍数。
if [ -f "$SRC/.breeze_patched_19106" ] || grep -q "num_codebooks" "$SRC/include/breeze/breeze.h" 2>/dev/null; then
    echo "   1.9.106 改动已在源码树里，跳过"
    touch "$SRC/.breeze_patched_19106"
else
    if patch -p1 --batch -d "$SRC" < "$ROOT/tools/patches/native-1.9.106.patch"; then
        touch "$SRC/.breeze_patched_19106"
    else
        echo "   1.9.106 补丁失败，见 $SRC 下的 .rej" >&2
        exit 1
    fi
fi

if [ "$WANT_VULKAN" = "ON" ]; then
    echo "== 3/5 准备 Vulkan 头文件与 shader 工具 =="
    [ -x "$GLSLC" ] || { echo "NDK 缺少 glslc：$GLSLC" >&2; exit 1; }

    # Vulkan-Hpp（NDK 只带 C 头）
    if [ ! -f "$CACHE/vkh/include/vulkan/vulkan.hpp" ]; then
        fetch "https://codeload.github.com/KhronosGroup/Vulkan-Headers/tar.gz/refs/tags/$VULKAN_HPP_TAG" "$CACHE/vkh.tgz"
        mkdir -p "$CACHE/vkh" && tar xzf "$CACHE/vkh.tgz" -C "$CACHE/vkh" --strip-components=1
    fi
    # SPIRV-Headers（ggml-vulkan.cpp 需要 spirv/unified1/spirv.hpp）
    if [ ! -f "$CACHE/spirv/include/spirv/unified1/spirv.hpp" ]; then
        fetch "https://codeload.github.com/KhronosGroup/SPIRV-Headers/tar.gz/refs/heads/main" "$CACHE/spirv.tgz"
        mkdir -p "$CACHE/spirv" && tar xzf "$CACHE/spirv.tgz" -C "$CACHE/spirv" --strip-components=1
    fi

    # ggml-vulkan 用 #include <vulkan/vulkan.hpp> 与 <spirv/unified1/spirv.hpp>。
    # 用独立 include 目录，避免污染 NDK sysroot。
    EXTRA="$SRC/.extra_include"
    mkdir -p "$EXTRA/vulkan" "$EXTRA/spirv"
    cp -n "$CACHE"/vkh/include/vulkan/*.hpp "$EXTRA/vulkan/" 2>/dev/null || true
    cp -n "$CACHE"/vkh/include/vulkan/vk_enum_string_helper.h "$EXTRA/vulkan/" 2>/dev/null || true
    cp -rn "$CACHE"/spirv/include/spirv "$EXTRA/" 2>/dev/null || true

    # ggml 的 vulkan-shaders-gen 是 host 工具，用 host toolchain 单独构建
    cat > "$CACHE/host-toolchain.cmake" <<CFG
set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_C_COMPILER gcc)
set(CMAKE_CXX_COMPILER g++)
CFG
    # find_package(SPIRV-Headers) 的伪 Config（只提供头文件路径）
    mkdir -p "$CACHE/cmake-pkgs/SPIRV-Headers"
    cat > "$CACHE/cmake-pkgs/SPIRV-Headers/SPIRV-HeadersConfig.cmake" <<CFG
add_library(SPIRV-Headers::SPIRV-Headers INTERFACE IMPORTED)
set_target_properties(SPIRV-Headers::SPIRV-Headers PROPERTIES
  INTERFACE_INCLUDE_DIRECTORIES "$EXTRA")
set(SPIRV-Headers_FOUND TRUE)
CFG
else
    EXTRA=""
fi

echo "== 4/5 交叉编译（Vulkan=$WANT_VULKAN，KleidiAI=$WANT_KLEIDIAI，ARM 量化内核全开）=="
BUILD="$SRC/build_android_vk"
rm -rf "$BUILD"
CMAKE_ARGS=(
    -S "$SRC" -B "$BUILD" -G Ninja
    -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake"
    -DANDROID_ABI="$ANDROID_ABI"
    -DANDROID_PLATFORM="$ANDROID_PLATFORM"
    -DANDROID_STL=c++_shared
    -DCMAKE_BUILD_TYPE=Release
    -DBREEZE_VULKAN="$WANT_VULKAN" -DBREEZE_CUDA=OFF
    -DBREEZE_BUILD_CLI=OFF -DBREEZE_BUILD_SERVER=OFF -DBREEZE_BUILD_TESTS=OFF
    -DBREEZE_MP3=OFF -DBREEZE_BUILD_SHARED=ON
    -DGGML_NATIVE=OFF -DGGML_OPENMP=OFF -DGGML_LLAMAFILE=OFF
    -DGGML_CPU_ARM_ARCH="$ARM_ARCH"
    -DGGML_BUILD_EXAMPLES=OFF -DGGML_BUILD_TESTS=OFF
)
if [ "$WANT_KLEIDIAI" = "ON" ]; then
    CMAKE_ARGS+=(-DGGML_CPU_KLEIDIAI=ON)
    # 离线/内网构建时直接指向已解压的 KleidiAI 源码，跳过 FetchContent 下载
    if [ -d "$KLEIDIAI_SRC" ]; then
        CMAKE_ARGS+=(-DFETCHCONTENT_SOURCE_DIR_KLEIDIAI_DOWNLOAD="$KLEIDIAI_SRC")
        echo "   KleidiAI 源码：$KLEIDIAI_SRC（离线复用）"
    else
        echo "   KleidiAI：构建时联网拉取 v1.24.0"
    fi
fi
if [ "$WANT_VULKAN" = "ON" ]; then
    CMAKE_ARGS+=(
        -DCMAKE_CXX_FLAGS="-I$EXTRA"
        -DGGML_VULKAN_SHADERS_GEN_TOOLCHAIN="$CACHE/host-toolchain.cmake"
        -DVulkan_INCLUDE_DIR="$SYSINC"
        -DVulkan_LIBRARY="$TOOL/sysroot/usr/lib/aarch64-linux-android/33/libvulkan.so"
        -DVulkan_GLSLC_EXECUTABLE="$GLSLC"
        -DSPIRV-Headers_DIR="$CACHE/cmake-pkgs/SPIRV-Headers"
    )
fi
cmake "${CMAKE_ARGS[@]}"

# Vulkan 后端的 shader 生成（vulkan-shaders-gen）与它自己的编译步骤存在依赖竞态：
# 高并发下会出现 mul_mm.comp.cpp.o 编译失败且不报错（编译器读到的头文件还没落全）。
# 先把 ggml-vulkan 单线程建完，再并行建其余目标 —— 实测 24/8 并发都会踩，
# 单线程这一步只多花 20 秒，换来构建可复现。
if [ "$WANT_VULKAN" = "ON" ]; then
    # shader 生成物里 mul_mm.comp.cpp 是 93 MB 的 `unsigned char x[N] = {0x..,..}`：
    # clang 给每个初始化元素建 AST 节点，8 GB 的 cgroup 下 -j1 也会被 OOM killer 干掉
    # （exit 137，日志里只有一行 Killed）。先让它把 shader 生成完（编译必然失败，
    # 忽略），再把数组改写成字符串字面量——同样 93 MB 数据只占一份字节缓冲。
    cmake --build "$BUILD" -j 1 --target ggml-vulkan >/dev/null 2>&1 || true
    python3 - "$BUILD/third_party/ggml/src/ggml-vulkan" <<'PYSHADER'
import os, re, sys
root = sys.argv[1]
pat = re.compile(r'const unsigned char (\w+)\[(\d+)\] = \{(.*?)\};', re.S)
for name in os.listdir(root):
    if not name.endswith('.comp.cpp'):
        continue
    p = os.path.join(root, name)
    if os.path.getsize(p) < (4 << 20):
        continue
    s = open(p, encoding='utf-8').read()
    def repl(m):
        n, size, body = m.group(1), int(m.group(2)), m.group(3)
        vals = [int(x, 16) for x in re.findall(r'0x[0-9a-fA-F]+', body)]
        if len(vals) != size:
            return m.group(0)
        return 'const unsigned char %s[] = "%s";' % (name if False else n, ''.join('\\x%02x' % v for v in vals))
    out = pat.sub(repl, s)
    if out != s:
        open(p, 'w', encoding='utf-8').write(out)
        print('shader blobs -> string literals:', name)
PYSHADER
    cmake --build "$BUILD" -j 1 --target ggml-vulkan
fi
cmake --build "$BUILD" -j "$JOBS"

echo "== 5/5 安装 so 并裁剪 =="
mkdir -p "$OUT"
cp "$BUILD/libbreeze_gguf.so" "$OUT/"
cp "$BUILD"/third_party/ggml/src/libggml.so \
   "$BUILD"/third_party/ggml/src/libggml-base.so \
   "$BUILD"/third_party/ggml/src/libggml-cpu.so "$OUT/"
STRIP="$TOOL/bin/llvm-strip"
FILES=(libbreeze_gguf.so libggml.so libggml-base.so libggml-cpu.so)
if [ "$WANT_VULKAN" = "ON" ]; then
    cp "$BUILD"/third_party/ggml/src/ggml-vulkan/libggml-vulkan.so "$OUT/"
    FILES+=(libggml-vulkan.so)
else
    rm -f "$OUT/libggml-vulkan.so"
fi
for f in "${FILES[@]}"; do "$STRIP" --strip-unneeded "$OUT/$f"; done
ls -lh "$OUT"
echo "完成。ARM arch: $ARM_ARCH；Vulkan=$WANT_VULKAN；KleidiAI=$WANT_KLEIDIAI。"
