#!/usr/bin/env bash
# 核对 Breeze-TTS-2 用到的 ggml 算子与 llama.cpp ggml-hexagon 后端的支持范围。
#
# 用途：评估能否把 Hexagon NPU 后端（PR #16547，2025-10 合入 llama.cpp）
#       移植进 BreezeTTS 做端侧加速之前，先看算子层面有多少缺口。
#
# 与 check_opencl_op_coverage.sh 的关键差异：
#   - hexagon 后端的 supports_op 是动态委托 htp_kparams_solve()，没有静态 switch；
#     真正的算子白名单在 htp-kparams.cpp 的 htp_op_remap() 里（GGML_OP → HTP_OP）。
#   - 所以本脚本从 htp-kparams.cpp 提取 case 标签作为「支持列表」，而不是从 supports_op。
#   - 白名单取自 llama.cpp master（含 2026 年新增算子），比 PR #16547 初版大得多。
#
# 注意：这只是「算子级别」的缺口。htp_kparams_solve() 里对每种 op 还有形状 / 类型 /
#       步长的条件（比如 MUL_MAT 要求特定量化档、RMS_NORM 要求 ne0 对齐），
#       以及 max_vmem 限制；脚本不判定这些，仍需人读 htp-kparams.cpp 对应 case。
#
#   ./tools/check_hexagon_op_coverage.sh
#   BREEZE_SRC=/path/to/Breeze-TTS-2.cpp/src ./tools/check_hexagon_op_coverage.sh
#
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BREEZE_SRC="${BREEZE_SRC:-/tmp/breeze2cpp-src/src}"
# llama.cpp 里 hexagon 后端源码的固定引用版本；master 代表当前算子全集
LLAMA_REF="${LLAMA_REF:-master}"
CACHE="${TMPDIR:-/tmp}/llama-hexagon-$LLAMA_REF"

if [ ! -f "$CACHE/htp-kparams.cpp" ]; then
    echo "== 下载 htp-kparams.cpp @ llama.cpp $LLAMA_REF =="
    mkdir -p "$CACHE"
    BASE="https://raw.githubusercontent.com/ggml-org/llama.cpp/$LLAMA_REF/ggml/src/ggml-hexagon"
    ok=0
    for u in "$BASE/htp-kparams.cpp" "https://gh-proxy.com/$BASE/htp-kparams.cpp"; do
        if curl -fsSL --max-time 120 -o "$CACHE/htp-kparams.cpp" "$u"; then ok=1; break; fi
    done
    [ "$ok" = 1 ] || { echo "下载失败" >&2; exit 1; }
fi

if [ ! -d "$BREEZE_SRC" ]; then
    echo "找不到 Breeze 源码：$BREEZE_SRC（用 BREEZE_SRC=... 指定）" >&2
    exit 1
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# 1) hexagon 白名单：htp_op_remap() 里所有 case GGML_OP_* / GGML_UNARY_OP_* / GGML_GLU_OP_*
awk '/htp_op_code htp_op_remap\(/{f=1} f{print} f&&/^}/{exit}' "$CACHE/htp-kparams.cpp" > "$CACHE/op_remap.cpp"
grep -oE 'GGML_OP_[A-Z_0-9]+' "$CACHE/op_remap.cpp" | sort -u > "$TMP/ops.txt"
grep -oE 'GGML_UNARY_OP_[A-Z_0-9]+' "$CACHE/op_remap.cpp" | sort -u > "$TMP/unary.txt"
grep -oE 'GGML_GLU_OP_[A-Z_0-9]+' "$CACHE/op_remap.cpp" | sort -u > "$TMP/glu.txt"

# 2) Breeze 侧的算子调用名
grep -rhoE 'ggml_[a-z0-9_]+\(' "$BREEZE_SRC"/*.cpp | tr -d '(' | sort -u | sed 's/^ggml_//' > "$TMP/calls.txt"

# 3) 调用名 → ggml op 的映射（延续 opencl 脚本的约定）
cat > "$TMP/map.sed" <<'EOF'
s/^conv_1d$/IM2COL MUL_MAT/
s/^conv_transpose_1d$/CONV_TRANSPOSE_1D/
s/^conv_transpose_2d$/CONV_TRANS_2D/
s/^conv_2d$/CONV_2D/
s/^gelu$/_UNARY/
s/^gelu_erf$/_UNARY/
s/^elu$/_UNARY/
s/^sin$/_UNARY/
s/^exp$/_UNARY/
s/^swiglu_split$/_GLU/
s/^rms_norm$/RMS_NORM/
s/^norm$/NORM/
s/^mul_mat$/MUL_MAT/
s/^soft_max_ext$/SOFT_MAX/
s/^top_k$/TOP_K/
s/^argmax$/ARGMAX/
s/^rope_ext$/ROPE/
s/^pad$/PAD/
s/^pad_ext$/PAD/
s/^add$/ADD/
s/^add_id$/ADD_ID/
s/^sub$/SUB/
s/^mul$/MUL/
s/^div$/DIV/
s/^sqr$/SQR/
s/^sum_rows$/SUM_ROWS/
s/^concat$/CONCAT/
s/^repeat$/REPEAT/
s/^get_rows$/GET_ROWS/
s/^scale$/SCALE/
s/^clamp$/CLAMP/
s/^roll$/ROLL/
EOF

# 4) 过滤掉非算子的构造 / 后端 API 调用
{
    while read -r c; do
        case "$c" in
            init|free|new_tensor_*|view_*|reshape_*|build_forward_expand|backend_*|gallocr_*|tallocr_*|\
            graph_overhead_custom|new_graph_custom|get_type_traits|nbytes|nelements|n_dims|is_contiguous|\
            is_quantized|get_tensor|get_first_tensor|get_next_tensor|repack_get_optimal_repack_type|\
            set_output|set_input|cont|cont_2d|permute|cpy|none|tensor_overhead) echo "SKIP $c";;
            *) echo "MAP $c";;
        esac
    done < "$TMP/calls.txt"
} > "$TMP/plan.txt"

echo
echo "== Breeze-TTS-2 算子 vs ggml-hexagon 支持白名单 @ llama.cpp $LLAMA_REF =="
printf '%-22s %s\n' "调用" "状态 (缺=需回退 CPU)"
echo "------------------------------------------------------------"

miss=0
total=0
while read -r kind call; do
    [ "$kind" = "MAP" ] || continue
    total=$((total + 1))
    ops="$(echo "$call" | sed -f "$TMP/map.sed" | tr -d '\n')"
    [ "$ops" = "$call" ] && ops="$(echo "$call" | tr '[:lower:]' '[:upper:]')"
    bad=""
    for o in $ops; do
        case "$o" in
            _UNARY) : ;;  # 二级算子单独判定
            _GLU)   : ;;
            *)      grep -qx "GGML_OP_$o" "$TMP/ops.txt" || bad="$bad $o";;
        esac
    done
    case "$call" in
        gelu|gelu_erf|elu|sin|exp)
            sub="$(echo "$call" | tr '[:lower:]' '[:upper:]')"
            grep -qx "GGML_UNARY_OP_$sub" "$TMP/unary.txt" || bad="$bad UNARY_$sub";;
        swiglu_split)
            grep -qx "GGML_GLU_OP_SWIGLU" "$TMP/glu.txt" || bad="$bad GLU_SWIGLU";;
    esac
    if [ -n "$bad" ]; then
        printf '%-22s ❌ 缺:%s\n' "ggml_$call" "$bad"
        miss=$((miss + 1))
    else
        printf '%-22s ✅\n' "ggml_$call"
    fi
done < "$TMP/plan.txt"

echo "------------------------------------------------------------"
echo "共 $total 个算子，缺口 $miss 个"
echo
echo "== hexagon 支持白名单（本脚本提取自 htp_op_remap）=="
cat "$TMP/ops.txt" | sed 's/GGML_OP_//' | tr '\n' ' '; echo
echo
echo "注 1: conv_1d 在 ggml 里展开成 im2col + mul_mat，两者 hexagon 都支持。"
echo "注 2: conv_transpose_1d / elu / sin 在 hexagon 白名单里不存在 → 需回退 CPU。"
echo "      这些算子集中在 codec_conv.cpp（声码器），是 TTS 的关键耗时段。"
echo "注 3: 本脚本只看算子级别；类型/形状/vmem 条件仍需读 htp-kparams.cpp 对应 case。"
