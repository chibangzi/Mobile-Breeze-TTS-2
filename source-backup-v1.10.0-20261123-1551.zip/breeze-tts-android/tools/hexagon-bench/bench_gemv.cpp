// 单层 GEMV 微基准：判定 NPU（Hexagon HTP）在「批=1 的权重扫描」上到底比 CPU 快还是慢。
//
// 为什么是 GEMV：Breeze 的深度解码每帧要为 15 个码本各跑一遍 12 层前向，
// 每一步的 token 数都是 1 —— 就是纯 GEMV，读一遍权重、每个元素只做一次乘加。
// 这个形态下算力完全用不上，只看「每字节要花多少指令 / 多少延迟」。
//
// 输出每个组合的 ms/次 与有效带宽 GB/s。判据：
//   HTP 的 GB/s 明显高于 CPU → NPU 能解除 Q4 的解包瓶颈，值得往 NPU 走；
//   HTP 与 CPU 持平或更低   → NPU 在这条负载上无效，Q4 和 NPU 一起收摊。

#include "ggml.h"
#include "ggml-alloc.h"
#include "ggml-backend.h"
#include "ggml-cpu.h"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <random>
#include <vector>

using clk = std::chrono::steady_clock;

static double ms_since(clk::time_point t0) {
    return std::chrono::duration<double, std::milli>(clk::now() - t0).count();
}

// 跑一个 [n_in, n_out] 的权重 × [n_in, 1] 的输入。
// 权重与输入都分配在同一个 backend 上，测的是纯 compute（不含每轮的主机拷贝）。
static bool bench(ggml_backend_t be, const char * tag, int n_in, int n_out,
                  ggml_type wtype, int iters) {
    const size_t wsize = ggml_row_size(wtype, n_in) * (size_t) n_out;

    // 主机侧：造权重并量化
    std::vector<float> host((size_t) n_in * n_out);
    std::mt19937 rng(1234);
    std::normal_distribution<float> nd(0.0f, 0.02f);
    for (auto & v : host) v = nd(rng);

    std::vector<uint8_t> qw(wsize);
    const size_t wrote = ggml_quantize_chunk(wtype, host.data(), qw.data(), 0, n_out, n_in, nullptr);
    if (wrote != wsize) {
        printf("  %-8s %-6s %5d x %-5d  量化失败（写入 %zu / 期望 %zu）\n",
               tag, ggml_type_name(wtype), n_in, n_out, wrote, wsize);
        return false;
    }

    ggml_init_params ip = {
        /*.mem_size   =*/ ggml_tensor_overhead() * 16 + ggml_graph_overhead(),
        /*.mem_buffer =*/ nullptr,
        /*.no_alloc   =*/ true,
    };
    ggml_context * ctx = ggml_init(ip);
    if (!ctx) { printf("  %s 建 ctx 失败\n", tag); return false; }

    ggml_tensor * w = ggml_new_tensor_2d(ctx, wtype, n_in, n_out);
    ggml_tensor * x = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, n_in, 1);
    ggml_tensor * y = ggml_mul_mat(ctx, w, x);
    ggml_set_output(y);

    ggml_backend_buffer_t buf = ggml_backend_alloc_ctx_tensors(ctx, be);
    if (!buf) {
        printf("  %-8s %-6s %5d x %-5d  该后端分配不了这些张量（多半不支持这个权重类型）\n",
               tag, ggml_type_name(wtype), n_in, n_out);
        ggml_free(ctx);
        return false;
    }

    ggml_backend_tensor_set(w, qw.data(), 0, qw.size());
    std::vector<float> xv((size_t) n_in, 0.5f);
    ggml_backend_tensor_set(x, xv.data(), 0, xv.size() * sizeof(float));

    ggml_cgraph * gf = ggml_new_graph(ctx);
    ggml_build_forward_expand(gf, y);

    // 预热：第一次会触发算子编译 / 会话建立，不能计入
    for (int i = 0; i < 5; i++) {
        if (ggml_backend_graph_compute(be, gf) != GGML_STATUS_SUCCESS) {
            printf("  %-8s %-6s %5d x %-5d  计算返回失败\n", tag, ggml_type_name(wtype), n_in, n_out);
            ggml_backend_buffer_free(buf);
            ggml_free(ctx);
            return false;
        }
    }

    double best = 1e30;
    double total = 0.0;
    for (int i = 0; i < iters; i++) {
        const auto t0 = clk::now();
        const ggml_status st = ggml_backend_graph_compute(be, gf);
        const double dt = ms_since(t0);
        if (st != GGML_STATUS_SUCCESS) {
            printf("  %-8s %-6s 第 %d 次计算失败\n", tag, ggml_type_name(wtype), i);
            break;
        }
        total += dt;
        if (dt < best) best = dt;
    }

    const double avg = total / iters;
    const double gb_avg = (double) wsize * iters / (total / 1000.0) / 1e9;
    const double gb_best = (double) wsize / (best / 1000.0) / 1e9;

    printf("  %-8s %-6s %5d x %-5d  %7.3f ms/次  %6.1f GB/s  （最好 %6.3f ms / %6.1f GB/s）\n",
           tag, ggml_type_name(wtype), n_in, n_out, avg, gb_avg, best, gb_best);

    ggml_backend_buffer_free(buf);
    ggml_free(ctx);
    return true;
}

int main(int argc, char ** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0);

    int iters = 200;
    const char * only = nullptr;      // 只跑名字里含这个子串的后端
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-n") == 0 && i + 1 < argc) iters = atoi(argv[++i]);
        else if (strcmp(argv[i], "-b") == 0 && i + 1 < argc) only = argv[++i];
    }

    // 后端插件与本程序同目录：adb push 到同一个文件夹即可
    {
        char dir[1024];
        snprintf(dir, sizeof(dir), "%s", argv[0]);
        char * slash = strrchr(dir, '/');
        if (slash) *slash = 0; else snprintf(dir, sizeof(dir), ".");
        ggml_backend_load_all_from_path(dir);
    }

    printf("ggml %s\n", ggml_version());
    printf("后端列表：\n");
    for (size_t i = 0; i < ggml_backend_dev_count(); i++) {
        ggml_backend_dev_t d = ggml_backend_dev_get(i);
        size_t free_b = 0, total_b = 0;
        ggml_backend_dev_memory(d, &free_b, &total_b);
        printf("  [%zu] %-10s %s  (mem %.0f/%.0f MB)\n", i,
               ggml_backend_dev_name(d), ggml_backend_dev_description(d),
               free_b / 1048576.0, total_b / 1048576.0);
    }

    // 三个贴近实际的形状：depth 的 FFN 半宽、qkv 合并后的宽度、以及一个方阵做对照
    const int shapes[][2] = { {1024, 2816}, {1024, 3072}, {2048, 2048} };
    const ggml_type types[] = { GGML_TYPE_Q8_0, GGML_TYPE_Q4_0, GGML_TYPE_Q4_K };

    for (size_t di = 0; di < ggml_backend_dev_count(); di++) {
        ggml_backend_dev_t dev = ggml_backend_dev_get(di);
        const char * name = ggml_backend_dev_name(dev);
        if (only && !strstr(name, only)) continue;
        if (ggml_backend_dev_type(dev) == GGML_BACKEND_DEVICE_TYPE_ACCEL &&
            !strstr(ggml_backend_dev_description(dev), "Hexagon")) {
            // 其他加速器不管
        }

        ggml_backend_t be = ggml_backend_dev_init(dev, nullptr);
        if (!be) { printf("\n%s：初始化失败\n", name); continue; }

        // CPU 固定 4 线程，与 App 里的默认值一致
        if (ggml_backend_dev_type(dev) == GGML_BACKEND_DEVICE_TYPE_CPU) {
            ggml_backend_cpu_set_n_threads(be, 4);
        }

        printf("\n===== %s =====\n", name);
        for (auto & s : shapes)
            for (ggml_type t : types)
                bench(be, name, s[0], s[1], t, iters);

        ggml_backend_free(be);
    }
    printf("\n完成。判据：HTP 的 GB/s 明显高于 CPU 才有必要往下走；持平或更低就收手。\n");
    return 0;
}
