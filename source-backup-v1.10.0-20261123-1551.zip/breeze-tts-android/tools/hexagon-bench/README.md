# 单层 GEMV 微基准（CPU vs Hexagon NPU）

> **先看这个**：如果只是想知道结果，不用装 adb —— 用 `dist/BreezeNpuBench-1.0.apk`，
> 装上点两下就出数，测量逻辑与本目录逐行一致。说明见 `docs/114-apk-gemv-bench.md`。
> 本目录的命令行版留给「APK 里 FastRPC 被拦、需要看完整 stderr」的情况。

一个不依赖 App 的独立可执行文件，用同一套 ggml 内核，在手机上量「批 = 1 的权重扫描」到底能跑多快。

## 这个数字决定什么

Breeze 的深度解码每帧要为 15 个码本各跑一遍 12 层前向，每步 token 数都是 1 —— 纯 GEMV，读一遍权重、每个元素只做一次乘加。

你的 Q4 实测没提速，我推断原因是 **CPU 在这条负载上是指令发射受限，不是带宽受限**：Q8 时 55 GB/s 接近峰值，Q4 时有效带宽掉到 28 GB/s，字节省一半被解包指令吃掉了。

如果这个推断成立，那 NPU 是唯一能让 Q4 复活的地方（4 bit 解包是硬件做的，不占指令端口）。**但这个推断需要验证，验证方法就是看 HTP 在同样形状下能不能跑出比 55 GB/s 更高的带宽。**

| HTP 结果 | 结论 |
| --- | --- |
| ≥ 70 GB/s | NPU 路线成立，Q4 值得做，depth 96 ms → 40 ms 量级 |
| 50–70 GB/s | 打平，只值做 backbone（没有 15 遍放大，收益更直接） |
| < 50 GB/s | NPU 在这条负载上无效，Q4 和 NPU 一起收手，CPU 侧再榨 5% 收尾 |

## 怎么跑

需要有 adb（USB 调试），因为 FastRPC 访问 CDSP 通常不给普通 App。

```sh
adb push out /data/local/tmp/hvx
adb shell
cd /data/local/tmp/hvx
chmod 755 bench_gemv run.sh
sh run.sh -b CPU          # 先确认程序本身能起来
sh run.sh -b HTP          # 再测 NPU
```

第一次跑 CPU 大概 40 秒，HTP 会多花十几秒建会话。输出样例：

```
===== CPU =====
  CPU      Q8_0   1024 x 2816    0.512 ms/次    55.3 GB/s  （最好 0.498 ms /  56.9 GB/s）
  CPU      Q4_0   1024 x 2816    0.489 ms/次    29.1 GB/s  （最好 0.481 ms /  29.6 GB/s）
```

**重点看 GB/s，不是 ms/次**：不同权重类型的字节数不同，只有折算成带宽才能横向比。

## 跑不起来怎么查

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| `后端列表` 里没有 Hexagon | `libggml-hexagon.so` 没被加载 | 确认它和 `bench_gemv` 在同一目录，`LD_LIBRARY_PATH` 已设置（`run.sh` 会自动设） |
| 初始化失败 / `0x80000406` | FastRPC 不让 shell 之外的进程访问 | 必须在 `adb shell` 里跑，不要在 Termux 或 App 里跑 |
| `failed to get CDSP domain` | SELinux 拦截 | `adb shell getenforce`，需要 Permissive 或 userdebug 版本 |
| `Hexagon Arch version v73` 但设备是 8 Elite | 架构探测失败 | 已经带了 v73/v75/v79/v81 四份 skel，能跑但性能偏低，结果只作参考 |
| `0x8000040b` 或 `unsupported` | 该权重类型在这个 arch 上没 kernel | 只跑 `-b HTP -n 20`，看哪些类型能过 |

## 文件

| 文件 | 说明 |
| --- | --- |
| `bench_gemv` | 主程序，arm64 |
| `bench_gemv.cpp` | 源码，在上一级目录 |
| `libggml*.so` | ggml 运行时（CPU + Hexagon 后端） |
| `libggml-htp-v7x.so` | HTP skel，四个 arch 全带 |
| `libc++_shared.so` | C++ 运行时 |
| `run.sh` | 设好环境变量再启动 |

构建来源：ggml 0.22.0 + Hexagon SDK 6.4.0.2 + NDK 27.1，`GGML_HEXAGON=ON`，`-DANDROID_PLATFORM=android-28`。
