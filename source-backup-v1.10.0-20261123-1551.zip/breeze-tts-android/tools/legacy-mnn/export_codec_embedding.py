#!/usr/bin/env python3
"""
把 16×2051 的码本嵌入表压成 int8 + 每行 scale 的二进制（端上 mmap 后按需解 16 行）。

表本身约 32816×2048 个参数：fp32 要 269 MB，int8 只要 67 MB。端上每帧只需要 16 行，
解量化成本可以忽略。

布局：
    "BZCE1\0\0\0"   8B
    u32 num_codebooks, u32 vocab, u32 dim
    i8  data[num_codebooks][vocab][dim]      行优先
    f32 scale[num_codebooks][vocab]

用法：
    python export_codec_embedding.py --model /path/to/Breeze-TTS-2 --code /path/to/breeze-tts --out out/codec_embedding.bin
"""
from __future__ import annotations

import argparse
import struct
import sys
from pathlib import Path

import numpy as np
import torch

MAGIC = b"BZCE1\0\0\0"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--code", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--dtype", default="bfloat16")
    args = ap.parse_args()

    sys.path.insert(0, str(Path(args.code).resolve()))
    from models.breeze import BreezeForConditionalGeneration  # type: ignore

    m = BreezeForConditionalGeneration.from_pretrained(
        args.model, torch_dtype=torch.float32, low_cpu_mem_usage=True
    )
    w = m.backbone_model.embed_tokens.weight.detach().float().cpu().numpy()
    num_cb = m.config.num_codebooks
    vocab = m.config.vocab_size
    dim = w.shape[1]
    if w.shape[0] != num_cb * vocab:
        raise SystemExit(f"形状不符: {w.shape} != ({num_cb}*{vocab}, {dim})")
    w = w.reshape(num_cb, vocab, dim)

    absmax = np.abs(w).max(axis=2)                      # [cb, vocab]
    scale = np.where(absmax > 1e-8, absmax / 127.0, 1e-8).astype(np.float32)
    q = np.clip(np.rint(w / scale[:, :, None]), -127, 127).astype(np.int8)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("wb") as f:
        f.write(MAGIC)
        f.write(struct.pack("<III", num_cb, vocab, dim))
        f.write(q.tobytes(order="C"))
        f.write(scale.tobytes(order="C"))
    print(f"[ok] {out} ({out.stat().st_size/1e6:.1f} MB) codebooks={num_cb} vocab={vocab} dim={dim}")


if __name__ == "__main__":
    main()
