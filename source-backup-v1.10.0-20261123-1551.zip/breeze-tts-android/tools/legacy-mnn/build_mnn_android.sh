#!/usr/bin/env bash
#
# 编译 MNN 的 Android arm64 运行时（libMNN / libMNN_Express / libMNN_CL / libllm），
# 并把头文件与 .so 放进 app 工程的对应位置。
#
# 依赖：Android NDK r27（或任意 r25+）、cmake 3.22、ninja、git。
#
# 用法：
#   ./tools/build_mnn_android.sh                 # 自动找 $ANDROID_NDK / $ANDROID_HOME/ndk
#   NDK=/path/to/ndk ./tools/build_mnn_android.sh
#
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="${WORK:-$HOME/.cache/breeze-mnn}"
MNN_TAG="${MNN_TAG:-master}"
ABI="${ABI:-arm64-v8a}"
API="${API:-33}"
JOBS="${JOBS:-$(nproc)}"

# ---- 定位 NDK ----
NDK="${NDK:-${ANDROID_NDK:-}}"
if [[ -z "$NDK" ]]; then
    for cand in "$ANDROID_HOME/ndk"/* "$ANDROID_SDK_ROOT/ndk"/*; do
        [[ -d "$cand" ]] && NDK="$cand"
    done
fi
if [[ -z "$NDK" || ! -f "$NDK/build/cmake/android.toolchain.cmake" ]]; then
    echo "找不到 NDK，请设置 NDK=/path/to/android-ndk" >&2
    exit 1
fi
echo "== NDK: $NDK"

# ---- 拉源码 ----
mkdir -p "$WORK"
if [[ ! -d "$WORK/MNN/.git" ]]; then
    echo "== clone MNN ($MNN_TAG)"
    git clone --depth 1 --branch "$MNN_TAG" https://github.com/alibaba/MNN.git "$WORK/MNN" \
        || git clone --depth 1 https://github.com/alibaba/MNN.git "$WORK/MNN"
fi
SRC="$WORK/MNN"

# ---- 配置 + 编译 ----
BUILD="$SRC/build_android_$ABI"
cmake -S "$SRC" -B "$BUILD" -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$ABI" \
    -DANDROID_PLATFORM="android-$API" \
    -DANDROID_STL=c++_shared \
    -DCMAKE_BUILD_TYPE=Release \
    -DMNN_OPENCL=ON \
    -DMNN_ARM82=ON \
    -DMNN_BUILD_LLM=ON \
    -DMNN_BUILD_SHARED_LIBS=ON \
    -DMNN_SUPPORT_TRANSFORMER_FUSE=ON \
    -DMNN_BUILD_CONVERTER=OFF \
    -DMNN_BUILD_TOOLS=OFF \
    -DMNN_BUILD_TEST=OFF \
    -DMNN_BUILD_BENCHMARK=OFF \
    -DMNN_USE_SSE=OFF \
    -DMNN_KLEIDIAI=OFF \
    -DMNN_SEP_BUILD=ON

cmake --build "$BUILD" -j "$JOBS"

# ---- 收集产物 ----
JNILIBS="$REPO_ROOT/app/app/src/main/jniLibs/$ABI"
INCLUDE="$REPO_ROOT/app/app/libs/mnn/include"
mkdir -p "$JNILIBS" "$INCLUDE"

find "$BUILD" -name libMNN.so -o -name libMNN_Express.so -o -name libMNN_CL.so -o -name libllm.so \
    | while read -r so; do
        cp -f "$so" "$JNILIBS/"
        echo "   $(basename "$so") <- ${so#$BUILD/}"
    done

rm -rf "$INCLUDE/MNN" "$INCLUDE/llm"
cp -r "$SRC/include/MNN" "$INCLUDE/"
mkdir -p "$INCLUDE/llm"
cp "$SRC"/transformers/llm/engine/include/llm/*.hpp "$INCLUDE/llm/"

STRIP="$(dirname "$NDK")/../toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"
[[ -x "$STRIP" ]] || STRIP="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"
if [[ -x "$STRIP" ]]; then
    for so in "$JNILIBS"/*.so; do "$STRIP" --strip-unneeded "$so"; done
    echo "== stripped"
fi

echo
echo "完成："
ls -lh "$JNILIBS"
