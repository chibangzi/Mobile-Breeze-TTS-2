#!/usr/bin/env python3
"""
ONNX -> MNN，并按模块决定量化位宽。

面向 12GB / 骁龙 8 Elite 基线：
  * backbone      INT4（带宽瓶颈，4bit 换速度）
  * depth_decoder INT4（每秒 200 次前向，最大的带宽黑洞）
  * text_encoder  INT8（每句只跑一次，保精度）
  * speech_decoder INT8（音质敏感）
  * codec_encoder  INT8（克隆用，跑得少）

用法：
    python onnx_to_mnn.py --onnx onnx/ --out mnn/                 # 标准档
    python onnx_to_mnn.py --onnx onnx/ --out mnn/ --profile hq    # 全部 INT8
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

DEFAULT_BITS = {
    "backbone": 4,
    "depth_decoder": 4,
    "text_encoder": 8,
    "speech_decoder": 8,
    "codec_encoder": 8,
}
HQ_BITS = {k: 8 for k in DEFAULT_BITS}


def find_mnnconvert(explicit: str | None) -> list[str]:
    if explicit:
        return [explicit]
    for cand in ("mnnconvert", "MNNConvert"):
        p = shutil.which(cand)
        if p:
            return [p]
    # pymnn 自带的转换器
    try:
        import MNN  # noqa: F401
        return [sys.executable, "-m", "MNN.tools.mnnconvert"]
    except Exception:  # noqa: BLE001
        pass
    raise SystemExit("找不到 mnnconvert：请编译 MNN 或用 pip install MNN，并 --mnnconvert 指定路径")


def convert(cmd: list[str], onnx: Path, mnn: Path, bits: int, threads: int) -> None:
    args = cmd + [
        "-f", "ONNX",
        "--modelFile", str(onnx),
        "--MNNModel", str(mnn),
        "--bizCode", "MNN",
        "--optimizeLevel", "2",
        "--weightQuantBits", str(bits),
        "--weightQuantAsymmetric", "1",
        "--weightQuantBlock", "64",
    ]
    print("$", " ".join(args))
    subprocess.run(args, check=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--onnx", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--profile", choices=["standard", "hq"], default="standard")
    ap.add_argument("--mnnconvert", default=None)
    ap.add_argument("--bits", type=int, default=None, help="覆盖所有模块的位宽（调试用）")
    args = ap.parse_args()

    cmd = find_mnnconvert(args.mnnconvert)
    bits_map = HQ_BITS if args.profile == "hq" else DEFAULT_BITS
    src, dst = Path(args.onnx), Path(args.out)
    dst.mkdir(parents=True, exist_ok=True)

    total = 0
    for onnx in sorted(src.glob("*.onnx")):
        name = onnx.stem
        if name not in bits_map and args.bits is None:
            print(f"[skip] {name}（不在量化表里）")
            continue
        bits = args.bits or bits_map[name]
        mnn = dst / f"{name}.mnn"
        convert(cmd, onnx, mnn, bits, 4)
        size = mnn.stat().st_size
        total += size
        print(f"[ok] {name}: int{bits}  {size/1e6:.1f} MB")

    print(f"\n合计 {total/1e6:.0f} MB -> {dst}")


if __name__ == "__main__":
    main()
