#!/usr/bin/env python3
"""
把 HuggingFace 的 tokenizer.json 压成端上可直接 mmap 的 tokenizer.bin（BZTK2）。

用法:
    python export_tokenizer.py --model /path/to/Breeze-TTS-2 --out out/tokenizer.bin

BZTK2 布局:
    "BZTK2\0"                    8B
    u32 vocab_size
    u32 merge_count
    u32 added_count
    u32 byte_token_id[256]       "<0xXX>" 的 id，缺失为 0xFFFFFFFF
    added × {u32 id, u32 len, bytes}
    vocab × {u32 len, bytes}
    merges × {u32 left, u32 right, u32 merged, u32 rank}
"""
from __future__ import annotations

import argparse
import json
import struct
from pathlib import Path

MAGIC = b"BZTK2\0\0\0"


def u32(x: int) -> bytes:
    return struct.pack("<I", x)


def put_str(s: str) -> bytes:
    b = s.encode("utf-8")
    return u32(len(b)) + b


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="Breeze 模型目录（含 tokenizer.json）")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    src = Path(args.model) / "tokenizer.json"
    d = json.loads(src.read_text(encoding="utf-8"))
    model = d["model"]
    if model.get("type") != "BPE":
        raise SystemExit(f"只支持 BPE，实际为 {model.get('type')}")

    vocab: dict[str, int] = model["vocab"]
    # added_tokens 的 id 可能大于 model.vocab，需要并入
    for a in d.get("added_tokens", []):
        vocab.setdefault(a["content"], a["id"])

    max_id = max(vocab.values())
    vocab_size = max_id + 1
    id2tok: list[str | None] = [None] * vocab_size
    for tok, i in vocab.items():
        if id2tok[i] is not None and id2tok[i] != tok:
            print(f"[warn] id {i} 冲突: {id2tok[i]!r} vs {tok!r}")
        id2tok[i] = tok

    merges = []
    for rank, mg in enumerate(model["merges"]):
        a, b = mg.split(" ") if isinstance(mg, str) else mg
        ia, ib = vocab.get(a), vocab.get(b)
        mid = vocab.get(a + b)
        if ia is None or ib is None or mid is None:
            continue
        merges.append((ia, ib, mid, rank))

    bytes_tbl = []
    for b in range(256):
        bytes_tbl.append(vocab.get(f"<0x{b:02X}>", 0xFFFFFFFF))

    added = [(a["id"], a["content"]) for a in d.get("added_tokens", [])]
    added.sort(key=lambda x: -len(x[1]))  # 端上按长度降序做最长匹配

    buf = bytearray()
    buf += MAGIC
    buf += u32(vocab_size)
    buf += u32(len(merges))
    buf += u32(len(added))
    for v in bytes_tbl:
        buf += u32(v)
    for i, s in added:
        buf += u32(i)
        buf += put_str(s)
    for i in range(vocab_size):
        tok = id2tok[i]
        buf += put_str(tok if tok is not None else "")
    for m in merges:
        buf += struct.pack("<IIII", *m)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(bytes(buf))
    print(f"vocab={vocab_size} merges={len(merges)} added={len(added)} -> {out} ({len(buf)/1e6:.2f} MB)")


if __name__ == "__main__":
    main()
