#!/usr/bin/env python3
"""
把 Breeze TTS 2 的四个辅助子模块导出成 ONNX（主干单独由 export_backbone.py 处理）。

模块与端上契约（必须与 docs/03-architecture.md 完全一致）：
    text_encoder    input_ids[1,S] int32, attention_mask[1,S] int32 -> text_embeds[1,S,2048]
    depth_decoder   input_ids[1,16] int32, backbone_hidden[1,2048] f32 -> logits[1,15,2051]
    speech_decoder  codes[1,16,T] int32 -> waveform[1,1,T*1920]
    codec_encoder   waveform[1,1,N] f32 -> codes[1,16,N/1920] int32

用法：
    python export_modules.py --model /path/to/Breeze-TTS-2 --code /path/to/breeze-tts --out onnx/
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F


# ------------------------------------------------------------------ 兼容层
def _first_tensor(x):
    """HF 的不同版本可能返回 Tensor / dict / tuple，这里统一取张量。"""
    if isinstance(x, torch.Tensor):
        return x
    if isinstance(x, dict):
        for k in ("audio_values", "waveform", "audio", "last_hidden_state"):
            if k in x and isinstance(x[k], torch.Tensor):
                return x[k]
        for v in x.values():
            if isinstance(v, torch.Tensor):
                return v
    if isinstance(x, (tuple, list)):
        for v in x:
            if isinstance(v, torch.Tensor):
                return v
    raise TypeError(f"无法从 {type(x)} 中取出张量")


def decode_audio(tokenizer, codes: torch.Tensor) -> torch.Tensor:
    """codes [1,16,T] -> waveform [1,1,T*1920]。"""
    for call in (
        lambda: tokenizer.decode(codes),
        lambda: tokenizer.decode(codes.transpose(1, 2)),
        lambda: tokenizer.decode(audio_codes=codes),
    ):
        try:
            w = _first_tensor(call())
            if w.dim() == 2:
                w = w.unsqueeze(1)
            if w.dim() == 3 and w.shape[1] != 1 and w.shape[-1] == 1:
                w = w.transpose(1, 2)
            return w.float()
        except Exception:  # noqa: BLE001
            continue
    raise RuntimeError("Qwen3TTSTokenizer 的 decode 接口不匹配，请按上游版本调整 decode_audio()")


def encode_audio(tokenizer, wav: torch.Tensor) -> torch.Tensor:
    """waveform [1,1,N] -> codes [1,16,N/1920]。"""
    for call in (
        lambda: tokenizer.encode(wav.squeeze(1), 24000),
        lambda: tokenizer.encode(wav, 24000),
    ):
        try:
            out = call()
            codes = out["audio_codes"] if isinstance(out, dict) else out
            codes = _first_tensor(codes)
            if codes.shape[-1] != 16:
                codes = codes.transpose(1, 2)
            return codes.int()
        except Exception:  # noqa: BLE001
            continue
    raise RuntimeError("Qwen3TTSTokenizer 的 encode 接口不匹配，请按上游版本调整 encode_audio()")


# ------------------------------------------------------------------ 包装
class TextEncoderExport(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.m = model
        assert model.text_encoder_layer_projs is None, "本导出脚本未实现 layer-wise 融合，请检查配置"
        assert not getattr(model, "text_encoder_dimfusion_fuse_first_layer", False)

    def forward(self, input_ids, attention_mask):
        out = self.m.text_encoder(
            input_ids=input_ids, attention_mask=attention_mask, return_dict=True
        )
        return self.m.text_encoder_proj(out.last_hidden_state).float()


class DepthDecoderExport(nn.Module):
    """固定 16 长度，输出 15 个位置（c1..c15）的 logits。"""

    def __init__(self, model):
        super().__init__()
        self.d = model.depth_decoder
        self.num_codebooks = model.config.num_codebooks
        self.vocab = model.config.vocab_size

    def forward(self, input_ids, backbone_hidden):
        out = self.d.model(
            input_ids=input_ids,
            backbone_last_hidden_state=backbone_hidden,
            use_cache=False,
            return_dict=True,
        )
        hs = out.last_hidden_state  # [1,16,1024]
        w = self.d.codebooks_head.weight  # [15,1024,2051]
        logits = torch.stack(
            [F.linear(hs[:, i, :], w[i - 1]) for i in range(1, self.num_codebooks)], dim=1
        )
        return logits.float()


class SpeechDecoderExport(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.tk = model.codec_model

    def forward(self, codes):
        return decode_audio(self.tk, codes)


class CodecEncoderExport(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.tk = model.codec_model

    def forward(self, wav):
        return encode_audio(self.tk, wav)


# ------------------------------------------------------------------ 主流程
def export(module, args, path: Path, inames, onames, dynamic=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.onnx.export(
        module,
        args,
        str(path),
        input_names=inames,
        output_names=onames,
        dynamic_axes=dynamic or {},
        opset_version=17,
        do_constant_folding=True,
        dynamo=False,
    )
    print(f"[ok] {path} ({path.stat().st_size/1e6:.1f} MB)")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--code", required=True, help="breeze-tts 仓库路径（提供 models 包）")
    ap.add_argument("--out", required=True)
    ap.add_argument("--fp16", action="store_true", help="导出 fp16（GPU 路线可开，默认 fp32 更稳）")
    args = ap.parse_args()

    sys.path.insert(0, str(Path(args.code).resolve()))
    from models.breeze import BreezeForConditionalGeneration  # type: ignore

    dtype = torch.float16 if args.fp16 else torch.float32
    model = BreezeForConditionalGeneration.from_pretrained(
        args.model, torch_dtype=dtype, low_cpu_mem_usage=True
    ).eval()
    out = Path(args.out)

    with torch.no_grad():
        # 1) 文本编码器
        export(
            TextEncoderExport(model).eval(),
            (torch.zeros(1, 24, dtype=torch.long), torch.ones(1, 24, dtype=torch.long)),
            out / "text_encoder.onnx",
            ["input_ids", "attention_mask"],
            ["text_embeds"],
            {"input_ids": {1: "seq"}, "attention_mask": {1: "seq"}, "text_embeds": {1: "seq"}},
        )
        # 2) 深度解码器（固定 16）
        export(
            DepthDecoderExport(model).eval(),
            (torch.zeros(1, 16, dtype=torch.long), torch.zeros(1, 2048, dtype=dtype)),
            out / "depth_decoder.onnx",
            ["input_ids", "backbone_hidden"],
            ["logits"],
        )
        # 3) 声码器（帧数动态）
        export(
            SpeechDecoderExport(model).eval(),
            (torch.zeros(1, 16, 4, dtype=torch.long),),
            out / "speech_decoder.onnx",
            ["codes"],
            ["waveform"],
            {"codes": {2: "frames"}, "waveform": {2: "samples"}},
        )
        # 4) 音频编码器（采样点动态，克隆用）
        export(
            CodecEncoderExport(model).eval(),
            (torch.zeros(1, 1, 2400, dtype=dtype),),
            out / "codec_encoder.onnx",
            ["waveform"],
            ["codes"],
            {"waveform": {2: "samples"}, "codes": {2: "frames"}},
        )


if __name__ == "__main__":
    main()
