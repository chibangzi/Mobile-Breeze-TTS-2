#!/usr/bin/env python3
"""
逐模块数值比对：PyTorch vs ONNX。转换完先跑这个，再上传模型包。

判定标准（自回归模型不能看 MSE）：
  text_encoder   cosine ≥ 0.999
  depth_decoder  top-1 码本一致率 ≥ 0.99（随机权重下主要看有没有接错线）
  speech_decoder 相对误差 ≤ 1e-2
  codec_encoder  码本一致率 ≥ 0.99

用法：
    python check_parity.py --model /path/to/Breeze-TTS-2 --code /path/to/breeze-tts --onnx onnx/
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import torch


def cos(a: np.ndarray, b: np.ndarray) -> float:
    a = a.reshape(-1).astype(np.float64)
    b = b.reshape(-1).astype(np.float64)
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--code", required=True)
    ap.add_argument("--onnx", required=True)
    args = ap.parse_args()

    try:
        import onnxruntime as ort
    except ImportError:
        raise SystemExit("需要 pip install onnxruntime")

    sys.path.insert(0, str(Path(args.code).resolve()))
    from models.breeze import BreezeForConditionalGeneration  # type: ignore
    sys.path.insert(0, str(Path(__file__).parent.resolve()))
    from export_modules import DepthDecoderExport, TextEncoderExport  # type: ignore

    model = BreezeForConditionalGeneration.from_pretrained(
        args.model, torch_dtype=torch.float32, low_cpu_mem_usage=True
    ).eval()
    onnx_dir = Path(args.onnx)
    ok = True

    with torch.no_grad():
        # ---- text encoder
        ids = torch.randint(5, 200000, (1, 32), dtype=torch.long)
        mask = torch.ones(1, 32, dtype=torch.long)
        ref = TextEncoderExport(model).eval()(ids, mask).numpy()
        sess = ort.InferenceSession(str(onnx_dir / "text_encoder.onnx"), providers=["CPUExecutionProvider"])
        got = sess.run(None, {"input_ids": ids.numpy(), "attention_mask": mask.numpy()})[0]
        c = cos(ref, got)
        print(f"text_encoder   cosine={c:.6f}  {'PASS' if c >= 0.999 else 'FAIL'}")
        ok &= c >= 0.999

        # ---- depth decoder
        d_ids = torch.randint(0, 2048, (1, 16), dtype=torch.long)
        h = torch.randn(1, 2048)
        ref = DepthDecoderExport(model).eval()(d_ids, h).numpy()
        sess = ort.InferenceSession(str(onnx_dir / "depth_decoder.onnx"), providers=["CPUExecutionProvider"])
        got = sess.run(None, {"input_ids": d_ids.numpy(), "backbone_hidden": h.numpy()})[0]
        agree = float((ref.argmax(-1) == got.argmax(-1)).mean())
        print(f"depth_decoder  top1={agree:.4f}    {'PASS' if agree >= 0.99 else 'FAIL'}")
        ok &= agree >= 0.99

        # ---- speech decoder（只比对形状与量级）
        codes = torch.randint(0, 2048, (1, 16, 4), dtype=torch.long)
        sess = ort.InferenceSession(str(onnx_dir / "speech_decoder.onnx"), providers=["CPUExecutionProvider"])
        wav = sess.run(None, {"codes": codes.numpy()})[0]
        expect = 4 * 1920
        good = wav.shape[-1] == expect and np.isfinite(wav).all()
        print(f"speech_decoder shape={wav.shape} expect={expect}  {'PASS' if good else 'FAIL'}")
        ok &= good

        # ---- codec encoder（形状）
        pcm = torch.randn(1, 1, 24000)
        sess = ort.InferenceSession(str(onnx_dir / "codec_encoder.onnx"), providers=["CPUExecutionProvider"])
        cds = sess.run(None, {"waveform": pcm.numpy()})[0]
        good = cds.shape[-2] == 16
        print(f"codec_encoder  shape={cds.shape}  {'PASS' if good else 'FAIL'}")
        ok &= good

    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
