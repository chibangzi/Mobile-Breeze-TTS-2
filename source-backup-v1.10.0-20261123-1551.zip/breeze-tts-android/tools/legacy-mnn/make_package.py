#!/usr/bin/env python3
"""
把 mnn/ 产物 + tokenizer.bin + codec_embedding.bin 组装成一个可上传、可一键下载的模型包。

产物：
    <out>/
      breeze.json        # 端上读取的唯一清单（含每个文件的 sha256 / 字节数）
      config.json        # MNN Llm 配置（backbone）
      backbone.mnn(+.weight) text_encoder.mnn depth_decoder.mnn
      speech_decoder.mnn codec_encoder.mnn
      codec_embedding.bin tokenizer.bin
      tokenizer.json     # 仅供 MNN Llm 加载器使用（可选）
      voices/            # 预置音色（可选）

用法：
    python make_package.py --mnn mnn/ --tokenizer out/tokenizer.bin --codes out/codec_embedding.bin \
        --hf-tokenizer /path/to/Breeze-TTS-2/tokenizer.json --out pkg/ --profile standard
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path

MODULES = {
    "backbone": ("backbone.mnn", "backbone.mnn.weight"),
    "text_encoder": ("text_encoder.mnn", None),
    "depth_decoder": ("depth_decoder.mnn", None),
    "speech_decoder": ("speech_decoder.mnn", None),
    "codec_encoder": ("codec_encoder.mnn", None),
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mnn", required=True)
    ap.add_argument("--tokenizer", required=True)
    ap.add_argument("--codes", required=True)
    ap.add_argument("--hf-tokenizer", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--name", default="Breeze TTS 2")
    ap.add_argument("--version", default="2.0")
    ap.add_argument("--profile", default="standard", choices=["standard", "hq"])
    ap.add_argument("--backend", default="opencl", choices=["opencl", "vulkan", "cpu"])
    ap.add_argument("--threads", type=int, default=4)
    args = ap.parse_args()

    src, dst = Path(args.mnn), Path(args.out)
    dst.mkdir(parents=True, exist_ok=True)
    (dst / "voices").mkdir(exist_ok=True)

    files: dict[str, dict] = {}

    def take(path: Path, name: str | None = None) -> None:
        target = dst / (name or path.name)
        if path.suffix == ".mnn" or path.suffix in (".bin", ".json"):
            shutil.copy2(path, target)
        else:
            shutil.copy2(path, target)
        files[target.name] = {"bytes": target.stat().st_size, "sha256": sha256(target)}

    for key, (model, weight) in MODULES.items():
        take(src / model)
        if weight and (src / weight).exists():
            take(src / weight)
    take(Path(args.tokenizer))
    take(Path(args.codes))
    if args.hf_tokenizer:
        take(Path(args.hf_tokenizer))

    # MNN Llm 的最小配置：我们只用它跑 backbone，tokenizer 交给 App 自己的 BPE
    llm_cfg = {
        "llm_model": "backbone.mnn",
        "llm_weight": "backbone.mnn.weight",
        "tokenizer_file": "tokenizer.json" if args.hf_tokenizer else "",
        "backend_type": args.backend,
        "thread_num": args.threads,
        "precision": "low",
        "memory": "low",
        "power": "high",
        "max_all_tokens": 2048,
        "max_new_tokens": 1500,
        "sampler_type": "greedy",
        "reuse_kv": False,
    }
    (dst / "config.json").write_text(json.dumps(llm_cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    files["config.json"] = {"bytes": (dst / "config.json").stat().st_size,
                            "sha256": sha256(dst / "config.json")}

    manifest = {
        "schema": 2,
        "name": args.name,
        "version": args.version,
        "profile": args.profile,
        "license": "BreezeBlue Research and Non-Commercial License（仅限研究/非商用）",
        "audio": {"sampleRate": 24000, "frameRate": 12.5, "numCodebooks": 16,
                  "codebookSize": 2048, "samplesPerFrame": 1920, "channels": 1},
        "tokens": {"audio": 262144, "audioEos": 262145, "speakerPrefix": 262146,
                   "insBos": 262156, "insEos": 262157, "backboneEos": 2051,
                   "pad": 2050, "vocab": 2051},
        "modules": {k: v[0] for k, v in MODULES.items()},
        "files": files,
        "totalBytes": sum(v["bytes"] for v in files.values()),
    }
    (dst / "breeze.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"包已生成: {dst}")
    for n, v in sorted(files.items()):
        print(f"  {n:28s} {v['bytes']/1e6:8.1f} MB")
    print(f"  合计 {manifest['totalBytes']/1e9:.2f} GB")


if __name__ == "__main__":
    main()
