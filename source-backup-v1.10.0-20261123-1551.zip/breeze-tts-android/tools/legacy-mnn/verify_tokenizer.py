#!/usr/bin/env python3
"""
端上分词算法的参考实现 + 一致性校验（C++ 版的“金标准对照物”）。

实现的正是端上跑的那套算法：
    added-token 最长匹配 → 空格换 ▁ → 按块 BPE → 字节回退

用法:
    python verify_tokenizer.py --model /path/to/Breeze-TTS-2
    python verify_tokenizer.py --model /path/to/Breeze-TTS-2 --bin out/tokenizer.bin
"""
from __future__ import annotations

import argparse
import json
import re
import struct
import sys
from pathlib import Path

SP = "\u2581"  # ▁


# ---------------------------------------------------------------- BZTK2 读取
class BinTokenizer:
    """读取 export_tokenizer.py 产出的 tokenizer.bin（与 C++ 侧同一份数据）。"""

    def __init__(self, path: str | Path) -> None:
        raw = Path(path).read_bytes()
        if raw[:8] != b"BZTK2\0\0\0":
            raise SystemExit("不是 BZTK2 文件")
        off = 8
        (vocab_size, merge_count, added_count) = struct.unpack_from("<III", raw, off)
        off += 12
        self.byte_ids = list(struct.unpack_from("<256I", raw, off))
        off += 256 * 4

        def rd_str() -> str:
            nonlocal off
            (n,) = struct.unpack_from("<I", raw, off)
            off += 4
            s = raw[off : off + n].decode("utf-8")
            off += n
            return s

        self.added: list[tuple[int, str]] = []
        for _ in range(added_count):
            (i,) = struct.unpack_from("<I", raw, off)
            off += 4
            self.added.append((i, rd_str()))
        self.tokens = [rd_str() for _ in range(vocab_size)]
        self.vocab = {t: i for i, t in enumerate(self.tokens) if t}
        self.merges: dict[tuple[int, int], tuple[int, int]] = {}
        self.merge_ranks: dict[tuple[int, int], int] = {}
        for _ in range(merge_count):
            a, b, m, r = struct.unpack_from("<IIII", raw, off)
            off += 16
            self.merges[(a, b)] = (r, m)
            self.merge_ranks[(a, b)] = r


# ---------------------------------------------------------------- 算法实现
def split_added(text: str, added: list[tuple[int, str]]):
    """按 added tokens 做最长匹配，返回 [("id", i) | ("text", s)]。"""
    if not added:
        return [("text", text)]
    pat = re.compile("|".join(re.escape(s) for _, s in added))
    out, pos = [], 0
    for m in pat.finditer(text):
        if m.start() > pos:
            out.append(("text", text[pos : m.start()]))
        out.append(("id", dict((s, i) for i, s in added)[m.group(0)]))
        pos = m.end()
    if pos < len(text):
        out.append(("text", text[pos:]))
    return out


def bpe_piece(piece: str, vocab: dict[str, int], merges: dict) -> list[str]:
    """贪心按 rank 合并，返回符号串（可能仍不在词表里，交给字节回退处理）。"""
    syms = list(piece)
    while len(syms) > 1:
        best, best_rank = -1, 1 << 60
        for i in range(len(syms) - 1):
            a, b = vocab.get(syms[i]), vocab.get(syms[i + 1])
            if a is None or b is None:
                continue
            r = merges.get((a, b))
            if r is not None and r[0] < best_rank:
                best_rank, best = r[0], i
        if best < 0:
            break
        syms[best : best + 2] = [syms[best] + syms[best + 1]]
    return syms


def encode(text: str, tk: BinTokenizer | "_HFAdapter") -> list[int]:
    out: list[int] = []
    for kind, val in split_added(text, tk.added):
        if kind == "id":
            out.append(val)
            continue
        s = val.replace(" ", SP)
        for piece in re.findall(SP + r"?[^" + SP + r"]+|" + SP + r"+", s):
            for sym in bpe_piece(piece, tk.vocab, tk.merges):
                hit = tk.vocab.get(sym)
                if hit is not None:
                    out.append(hit)
                    continue
                for b in sym.encode("utf-8"):
                    bid = tk.byte_ids[b]
                    out.append(3 if bid == 0xFFFFFFFF else bid)
    return out


class _HFAdapter:
    """把 HF tokenizer.json 适配成和 BinTokenizer 一样的接口，用于不生成 bin 时的对照。"""

    def __init__(self, model_dir: str | Path) -> None:
        d = json.loads((Path(model_dir) / "tokenizer.json").read_text(encoding="utf-8"))
        m = d["model"]
        vocab = dict(m["vocab"])
        for a in d.get("added_tokens", []):
            vocab.setdefault(a["content"], a["id"])
        self.vocab = vocab
        self.added = sorted(
            ((a["id"], a["content"]) for a in d.get("added_tokens", [])),
            key=lambda x: -len(x[1]),
        )
        self.merges = {}
        for rank, mg in enumerate(m["merges"]):
            a, b = mg.split(" ") if isinstance(mg, str) else mg
            ia, ib, mid = vocab.get(a), vocab.get(b), vocab.get(a + b)
            if ia is not None and ib is not None and mid is not None:
                self.merges[(ia, ib)] = (rank, mid)
        self.byte_ids = [vocab.get(f"<0x{b:02X}>", 0xFFFFFFFF) for b in range(256)]


CASES = [
    "这是中文参考音频的准确文字稿。",
    "[叹气] 没想到过了这么久，你还记得我的声音。",
    "(sigh) It is good to hear your voice again after all this time.",
    "A warm, thoughtful young woman with a clear voice and a calm, reflective delivery.",
    "2026年11月14日，价格是 1,299.50 元。",
    "Hello, world! How's it going? I'll be there at 9:30.",
    "今天天气不错😀，我们去公园吧！",
    "《三体》读后感：宇宙很大，生活更大。",
    "[S0]<ins_bos>用低沉沙哑的嗓音，缓慢地说<ins_eos>你终于来了。",
    "MNN + OpenCL 在骁龙 8 Elite 上跑 3B 模型，RTF 约为 1.2。",
    " 前导空格 和 尾随空格 ",
    "多行文本\n第二行\n\n第三行",
    "<|AUDIO|><|AUDIO|><|audio_eos|>[S0]",
]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--bin", default=None, help="若提供则同时校验 tokenizer.bin")
    args = ap.parse_args()

    try:
        from tokenizers import Tokenizer
    except ImportError:
        raise SystemExit("需要 pip install tokenizers 才能对照")

    ref = Tokenizer.from_file(str(Path(args.model) / "tokenizer.json"))
    targets = [("json", _HFAdapter(args.model))]
    if args.bin:
        targets.append(("bin", BinTokenizer(args.bin)))

    failed = False
    for name, tk in targets:
        ok = 0
        for c in CASES:
            want = ref.encode(c, add_special_tokens=False).ids
            got = encode(c, tk)
            if want == got:
                ok += 1
            else:
                failed = True
                print(f"[{name}] MISMATCH {c!r}")
                for i in range(max(len(want), len(got))):
                    a = want[i] if i < len(want) else None
                    b = got[i] if i < len(got) else None
                    if a != b:
                        print(f"   idx {i}: want {a} got {b}")
                        break
        print(f"[{name}] {ok}/{len(CASES)} 完全一致")

    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
