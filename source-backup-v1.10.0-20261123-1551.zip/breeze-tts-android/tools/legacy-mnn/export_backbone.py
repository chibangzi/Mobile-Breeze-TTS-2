#!/usr/bin/env python3
"""
导出 backbone（Breeze TTS 2 的 Qwen3 主干）为 MNN LLM 图。

为什么不能直接 `torch.onnx.export(HF 模型)`：
  MNN 的 LLM 运行时期望的图契约是固定的 —— 4 个输入
  `(input_embeds, attention_mask, position_ids, logits_index)`，
  `logits_index` 用来把输出裁到「只需要的位置」，KV cache 则由 MNN 的
  `KVCACHE_INFO` 机制在转换阶段接管。这些改写都在 MNN 的 `llmexport.py` 里做过，
  自己重写一遍只会引入偏差。

所以这里的做法是：
  1) 把 Breeze 权重里的 `backbone_model.*` + `lm_head` 抽出来，重命名成标准 Qwen3
     checkpoint（Breeze 的 backbone 就是 Qwen3 结构：28 层 / 2048 / 16 heads / 8 kv / head_dim 128）；
  2) 直接调 MNN 的 llmexport 导出 + 量化。

关键点：Breeze 的主干是「嵌入入」而不是「token 入」。MNN 的 LLM 图里第一个输入
本来就叫 input_ids，但实际承载的是 embeddings（见 MNN `utils/model.py` 的
`hidden_states = input_ids  # llm forward without embedding`），
运行时要走 `Llm::forward(VARP input_embeds)`。这正好对上 Breeze 的需求。

用法：
    git clone https://github.com/alibaba/MNN
    python export_backbone.py --model /path/to/Breeze-TTS-2 \
        --mnn /path/to/MNN --out onnx/ --bits 4
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

import torch
from safetensors.torch import load_file, save_file


def build_qwen3_config(cfg: dict, vocab: int) -> dict:
    bb = cfg["backbone_config"]
    return {
        "architectures": ["Qwen3ForCausalLM"],
        "model_type": "qwen3",
        "hidden_size": bb["hidden_size"],
        "intermediate_size": bb["intermediate_size"],
        "num_hidden_layers": bb["num_hidden_layers"],
        "num_attention_heads": bb["num_attention_heads"],
        "num_key_value_heads": bb["num_key_value_heads"],
        "head_dim": bb.get("head_dim", 128),
        "vocab_size": vocab,
        "max_position_embeddings": 40960,
        "rope_theta": cfg.get("rope_theta", 500000.0),
        "rope_scaling": cfg.get("rope_scaling"),
        "rms_norm_eps": cfg.get("rms_norm_eps", 1e-5),
        "hidden_act": cfg.get("hidden_act", "silu"),
        "tie_word_embeddings": False,
        "attention_bias": False,
        "mlp_bias": False,
        "bos_token_id": cfg.get("bos_token_id", 2),
        "eos_token_id": cfg.get("eos_token_id", 1),
        "pad_token_id": cfg.get("pad_token_id", 0),
        "torch_dtype": "float32",
    }


def prepare(model_dir: Path, out_dir: Path) -> Path:
    """抽主干权重 -> 标准 Qwen3 checkpoint 目录。"""
    cfg = json.loads((model_dir / "config.json").read_text())
    vocab = cfg["vocab_size"] + 1  # 2051 + audio-eos 类

    out_dir.mkdir(parents=True, exist_ok=True)

    # 权重可能被切成多个 safetensors
    tensors: dict[str, torch.Tensor] = {}
    for f in sorted(model_dir.glob("*.safetensors")):
        tensors.update(load_file(str(f)))

    mapped: dict[str, torch.Tensor] = {}
    for k, v in tensors.items():
        if k.startswith("backbone_model."):
            mapped["model." + k[len("backbone_model."):]] = v
        elif k == "lm_head.weight":
            mapped["lm_head.weight"] = v

    if "lm_head.weight" not in mapped:
        raise SystemExit("权重里没有 lm_head.weight")
    if mapped["lm_head.weight"].shape[0] != vocab:
        raise SystemExit(f"lm_head 行数 {mapped['lm_head.weight'].shape[0]} != vocab {vocab}")

    # MNN 导出器会按 config 建模型，需要 embed_tokens 占位；
    # 运行时走 embeds 入，这张表不会被用到，用零填充即可（别让它参与量化）。
    if "model.embed_tokens.weight" not in mapped:
        mapped["model.embed_tokens.weight"] = torch.zeros(
            vocab, cfg["hidden_size"], dtype=mapped["lm_head.weight"].dtype
        )

    missing = [n for n in ("model.norm.weight", "model.layers.0.self_attn.q_proj.weight") if n not in mapped]
    if missing:
        raise SystemExit(f"权重不完整，缺少 {missing}")

    save_file({k: v.contiguous() for k, v in mapped.items()}, str(out_dir / "model.safetensors"))
    (out_dir / "config.json").write_text(json.dumps(build_qwen3_config(cfg, vocab), indent=2, ensure_ascii=False))
    # llmexport 会尝试加载 tokenizer，给一份最小的
    for name in ("tokenizer.json", "tokenizer_config.json", "special_tokens_map.json"):
        src = model_dir / name
        if src.exists():
            shutil.copy2(src, out_dir / name)
    print(f"[prepare] {out_dir}  ({len(mapped)} tensors, vocab={vocab})")
    return out_dir


def export(hf_dir: Path, mnn_repo: Path, out_dir: Path, bits: int) -> None:
    exporter = mnn_repo / "transformers" / "llm" / "export" / "llmexport.py"
    if not exporter.exists():
        raise SystemExit(f"找不到 {exporter}，请检查 --mnn 指向 MNN 仓库根目录")

    out_dir.mkdir(parents=True, exist_ok=True)
    dst = out_dir / "backbone"
    dst.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable, str(exporter),
        "--path", str(hf_dir),
        "--export", "mnn",
        "--dst_path", str(dst),
        "--quant_bit", str(bits),
        "--quant_block", "64",
        "--seperate_embed",
    ]
    print("[export]", " ".join(cmd))
    subprocess.run(cmd, check=True, cwd=str(exporter.parent))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="Breeze-TTS-2 权重目录")
    ap.add_argument("--mnn", required=True, help="MNN 仓库根目录")
    ap.add_argument("--out", default="onnx", help="输出目录")
    ap.add_argument("--bits", type=int, default=4, choices=[4, 8])
    ap.add_argument("--prepare-only", action="store_true")
    args = ap.parse_args()

    model_dir = Path(args.model)
    out_dir = Path(args.out)
    hf_dir = out_dir / "backbone_qwen3"

    prepare(model_dir, hf_dir)
    if not args.prepare_only:
        export(hf_dir, Path(args.mnn), out_dir, args.bits)

    print("\n完成。接下来：")
    print("  1) 把 backbone.mnn 与 llmexport 生成的 config.json 放进模型包")
    print("  2) 确认 config.json 里有 \"hidden_states\": true（深度解码器要用主干隐状态）")


if __name__ == "__main__":
    main()
