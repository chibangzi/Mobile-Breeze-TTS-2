#!/usr/bin/env python3
"""
给模型包补一个 HuggingFace 仓库首页（README），并打印上传命令。

App 的「一键下载」就是按 HuggingFace 仓库协议拉 `breeze.json` + 清单里的文件，
所以仓库根目录必须是 make_package.py 的产物原样（不要套一层子目录）。

用法：
    python publish_package.py --pkg pkg/ --repo your-name/breeze-tts-2-mnn-int4
    # 然后：hf upload your-name/breeze-tts-2-mnn-int4 pkg/ --repo-type model
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

CARD = """---
language:
  - zh
  - en
tags:
  - text-to-speech
  - mnn
  - on-device
  - voice-cloning
license: other
license_name: breezeblue-research-and-non-commercial-license
---

# {name} · MNN {profile} 量化版

这是 [BreezeBlue/Breeze-TTS-2](https://huggingface.co/BreezeBlue/Breeze-TTS-2) 的 MNN 端侧转换产物，
供 [Breeze TTS Local](https://github.com/) Android App 直接下载使用。

- 采样率 {sr} Hz，帧率 {fr} Hz，{cb} 码本
- 精度档位：**{profile}**
- 总大小：{size} GB
- 目标机型：12 GB 内存 / 骁龙 8 Elite 级别

## 目录说明

| 文件 | 说明 |
| --- | --- |
| `breeze.json` | 清单（App 校验用，含每个文件的 sha256） |
| `config.json` | MNN Llm 配置（backbone） |
| `backbone.mnn` | Qwen3 主干，`inputs_embeds` 入 / `logits`+`hidden_states` 出 |
| `text_encoder.mnn` | T5Gemma2 + proj |
| `depth_decoder.mnn` | 帧内 RVQ（固定 16 长度） |
| `speech_decoder.mnn` | 16 码本 → 24 kHz 波形 |
| `codec_encoder.mnn` | 参考音频 → 16 码本 |
| `codec_embedding.bin` | int8 码本嵌入表 |
| `tokenizer.bin` | 端上 BPE 词表 |

## 许可

权重与派生模型遵循 **BreezeBlue Research and Non-Commercial License**：仅限研究与
非商业用途，禁止未授权的音色克隆、冒充与欺诈。商用需向 BreezeBlue 取得书面授权。
"""


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pkg", required=True)
    ap.add_argument("--repo", required=True)
    args = ap.parse_args()

    pkg = Path(args.pkg)
    manifest = json.loads((pkg / "breeze.json").read_text(encoding="utf-8"))
    card = CARD.format(
        name=manifest["name"],
        profile=manifest.get("profile", "standard"),
        sr=manifest["audio"]["sampleRate"],
        fr=manifest["audio"]["frameRate"],
        cb=manifest["audio"]["numCodebooks"],
        size=f"{manifest['totalBytes']/1e9:.2f}",
    )
    (pkg / "README.md").write_text(card, encoding="utf-8")
    print(f"已写入 {pkg/'README.md'}")
    print("\n上传：")
    print(f"  hf upload {args.repo} {pkg} --repo-type model")
    print("\n提示：App 里把「模型仓库」填成同一个 repo id；国内网络可在设置里切 hf-mirror 镜像。")


if __name__ == "__main__":
    main()
