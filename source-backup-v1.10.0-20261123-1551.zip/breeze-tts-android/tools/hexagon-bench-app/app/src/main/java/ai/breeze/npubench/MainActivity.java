package ai.breeze.npubench;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * 单层 GEMV 微基准。
 *
 * 目的只有一个：判定 Hexagon HTP 在「批=1 的权重扫描」上到底比 CPU 快还是慢。
 * 不测音质、不测整句，只测同样一层矩阵乘的 GB/s —— 这是 NPU 路线成立与否的唯一判据。
 */
public class MainActivity extends Activity implements Bench.Sink {

    private TextView out;
    private ScrollView scroll;
    private Button btnCpu, btnHtp, btnAll, btnShare;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final StringBuilder all = new StringBuilder();
    private volatile boolean running;
    private long lastScroll;
    private File resultFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = dp(16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#12141A"));
        root.setPadding(pad, dp(28), pad, pad);

        TextView title = new TextView(this);
        title.setText("单层 GEMV 基准");
        title.setTextColor(Color.parseColor("#EDEFF5"));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText("同样的矩阵乘，分别跑在 CPU 与 Hexagon NPU 上，比有效带宽。\n"
                + "三组：小张量（3 MB，作对照）· 大张量（30 MB，真带宽）· 一层形态（7 个 matmul / 次）。\n"
                + "判据：NPU 的大张量 GB/s 高于 CPU 才值得往那边走；持平或更低就收手。\n"
                + "每组 3–5 次预热，之后 100–200 次计时，全跑完约 2–4 分钟。");
        desc.setTextColor(Color.parseColor("#8B93A7"));
        desc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        desc.setPadding(0, dp(8), 0, dp(14));
        root.addView(desc);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        btnCpu = mkButton("① 只测 CPU");
        btnHtp = mkButton("② 只测 NPU");
        btnAll = mkButton("③ 全部");
        row.addView(btnCpu, weight());
        row.addView(btnHtp, weight());
        row.addView(btnAll, weight());
        root.addView(row);

        btnCpu.setOnClickListener(v -> start("cpu"));
        btnHtp.setOnClickListener(v -> start("htp"));
        btnAll.setOnClickListener(v -> start("all"));

        scroll = new ScrollView(this);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        slp.topMargin = dp(12);
        scroll.setLayoutParams(slp);
        scroll.setBackgroundColor(Color.parseColor("#1A1D26"));

        out = new TextView(this);
        out.setTextColor(Color.parseColor("#C9D1E3"));
        out.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        out.setTypeface(Typeface.MONOSPACE);
        out.setPadding(dp(10), dp(10), dp(10), dp(10));
        out.setTextIsSelectable(true);
        out.setText(arch());
        scroll.addView(out);
        root.addView(scroll);

        btnShare = mkButton("分享结果");
        btnShare.setEnabled(false);
        btnShare.setOnClickListener(v -> share());
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        blp.topMargin = dp(10);
        root.addView(btnShare, blp);

        setContentView(root);
    }

    private String arch() {
        String h;
        try {
            h = Bench.archHint();
        } catch (Throwable t) {
            h = String.valueOf(t);
        }
        return "准备就绪 · " + h + "\n\n先点「① 只测 CPU」确认程序能跑通，\n再点「② 只测 NPU」。\n";
    }

    private Button mkButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return b;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void start(String mode) {
        if (running) return;
        running = true;
        btnCpu.setEnabled(false);
        btnHtp.setEnabled(false);
        btnAll.setEnabled(false);
        btnShare.setEnabled(false);
        all.setLength(0);
        out.setText("");
        btnShare.setText("分享结果");

        final String dir = getApplicationInfo().nativeLibraryDir;
        new Thread(() -> {
            try {
                Bench.runNative(dir, mode, this);
            } catch (Throwable t) {
                onLine("× 运行中断：" + t);
            }
            running = false;
            ui.post(() -> {
                btnCpu.setEnabled(true);
                btnHtp.setEnabled(true);
                btnAll.setEnabled(true);
                btnShare.setEnabled(true);
                save();
            });
        }, "bench").start();
    }

    @Override
    public void onLine(String line) {
        ui.post(() -> {
            all.append(line).append('\n');
            out.append(line + "\n");
            long now = System.currentTimeMillis();
            if (now - lastScroll > 150) {
                lastScroll = now;
                scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
            }
        });
    }

    private void save() {
        try {
            File dir = getExternalFilesDir(null);
            if (dir == null) dir = getFilesDir();
            resultFile = new File(dir, "gemv-bench.txt");
            try (FileOutputStream fos = new FileOutputStream(resultFile)) {
                fos.write(all.toString().getBytes(StandardCharsets.UTF_8));
            }
            btnShare.setText("分享结果（已存 " + resultFile.getAbsolutePath() + "）");
        } catch (Throwable t) {
            btnShare.setText("分享结果");
        }
    }

    private void share() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "单层 GEMV 基准结果");
        i.putExtra(Intent.EXTRA_TEXT, all.toString());
        startActivity(Intent.createChooser(i, "分享结果"));
    }
}
