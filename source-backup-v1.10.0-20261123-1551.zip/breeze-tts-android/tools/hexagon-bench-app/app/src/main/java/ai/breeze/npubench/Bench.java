package ai.breeze.npubench;

/** JNI 入口。实现在 libhvxbench.so（cpp/bench_jni.cpp）。 */
public final class Bench {

    public interface Sink {
        void onLine(String line);
    }

    /** mode: "cpu" | "htp" | "all" */
    public static native void runNative(String libDir, String mode, Sink sink);

    public static native String archHint();

    static {
        System.loadLibrary("hvxbench");
    }

    private Bench() {}
}
