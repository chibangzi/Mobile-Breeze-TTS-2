// 单层 GEMV 微基准 · Android 版（JNI 包装）
//
// 与命令行版 bench_gemv.cpp 完全相同的测量逻辑，只把 printf 换成往界面回推的回调。
// 目的：不需要 adb、不需要电脑 —— 装上点一下就能出数。
//
// 两个后端：CPU（4 线程，与 App 默认一致）与 Hexagon HTP。
// 判据：HTP 的 GB/s 明显高于 CPU 才值得往 NPU 走；持平或更低就收手。

#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <unistd.h>

#include <chrono>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

#include "ggml.h"
#include "ggml-alloc.h"
#include "ggml-backend.h"
#include "ggml-cpu.h"

using clk = std::chrono::steady_clock;

static JavaVM *   g_vm    = nullptr;
static jobject    g_cb    = nullptr;
static jmethodID  g_line  = nullptr;

// ---------------------------------------------------------------- 日志回推

static void emit_line(const char * s) {
    __android_log_print(ANDROID_LOG_INFO, "hvxbench", "%s", s);
    if (!g_cb || !g_vm) return;
    JNIEnv * env = nullptr;
    if (g_vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) != JNI_OK) return;
    jstring js = env->NewStringUTF(s);
    if (js) {
        env->CallVoidMethod(g_cb, g_line, js);
        env->DeleteLocalRef(js);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
}

static void logf(const char * fmt, ...) {
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    emit_line(buf);
}

static double ms_since(clk::time_point t0) {
    return std::chrono::duration<double, std::milli>(clk::now() - t0).count();
}

// ---------------------------------------------------------------- 单个用例

// 跑一个 [n_in, n_out] 的权重 × [n_in, 1] 的输入。
// 权重与输入都分配在同一个 backend 上，测的是纯 compute（不含每轮的主机拷贝）。
static void bench(ggml_backend_t be, const char * tag, int n_in, int n_out,
                  ggml_type wtype, int iters, int warmup = 5) {
    const size_t wsize = ggml_row_size(wtype, n_in) * (size_t) n_out;

    std::vector<float> host((size_t) n_in * n_out);
    std::mt19937 rng(1234);
    std::normal_distribution<float> nd(0.0f, 0.02f);
    for (auto & v : host) v = nd(rng);

    std::vector<uint8_t> qw(wsize);
    const size_t wrote = ggml_quantize_chunk(wtype, host.data(), qw.data(), 0, n_out, n_in, nullptr);
    if (wrote != wsize) {
        logf("  %-6s %-6s %5d x %-5d  量化失败（写入 %zu / 期望 %zu）",
             tag, ggml_type_name(wtype), n_in, n_out, wrote, wsize);
        return;
    }

    ggml_init_params ip = {
        /*.mem_size   =*/ ggml_tensor_overhead() * 16 + ggml_graph_overhead(),
        /*.mem_buffer =*/ nullptr,
        /*.no_alloc   =*/ true,
    };
    ggml_context * ctx = ggml_init(ip);
    if (!ctx) { logf("  %s 建 ctx 失败", tag); return; }

    ggml_tensor * w = ggml_new_tensor_2d(ctx, wtype, n_in, n_out);
    ggml_tensor * x = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, n_in, 1);
    ggml_tensor * y = ggml_mul_mat(ctx, w, x);
    ggml_set_output(y);

    ggml_backend_buffer_t buf = ggml_backend_alloc_ctx_tensors(ctx, be);
    if (!buf) {
        logf("  %-6s %-6s %5d x %-5d  该后端分配不了（多半不支持这个权重类型）",
             tag, ggml_type_name(wtype), n_in, n_out);
        ggml_free(ctx);
        return;
    }

    ggml_backend_tensor_set(w, qw.data(), 0, qw.size());
    std::vector<float> xv((size_t) n_in, 0.5f);
    ggml_backend_tensor_set(x, xv.data(), 0, xv.size() * sizeof(float));

    ggml_cgraph * gf = ggml_new_graph(ctx);
    ggml_build_forward_expand(gf, y);

    // 预热：第一次会触发算子下发 / 会话建立，不能计入
    for (int i = 0; i < warmup; i++) {
        if (ggml_backend_graph_compute(be, gf) != GGML_STATUS_SUCCESS) {
            logf("  %-6s %-6s %5d x %-5d  计算返回失败", tag, ggml_type_name(wtype), n_in, n_out);
            ggml_backend_buffer_free(buf);
            ggml_free(ctx);
            return;
        }
    }

    double best = 1e30;
    double total = 0.0;
    int done = 0;
    for (int i = 0; i < iters; i++) {
        const auto t0 = clk::now();
        const ggml_status st = ggml_backend_graph_compute(be, gf);
        const double dt = ms_since(t0);
        if (st != GGML_STATUS_SUCCESS) {
            logf("  %-6s %-6s 第 %d 次计算失败", tag, ggml_type_name(wtype), i);
            break;
        }
        total += dt;
        if (dt < best) best = dt;
        done++;
    }

    if (done > 0) {
        const double avg = total / done;
        const double gb_avg = (double) wsize * done / (total / 1000.0) / 1e9;
        const double gb_best = (double) wsize / (best / 1000.0) / 1e9;
        logf("  %-6s %-6s %5d x %-5d  %7.3f ms  %6.1f GB/s（最好 %6.3f ms / %6.1f GB/s）",
             tag, ggml_type_name(wtype), n_in, n_out, avg, gb_avg, best, gb_best);
    }

    ggml_backend_buffer_free(buf);
    ggml_free(ctx);
}

// 一层 depth 的真实形态：一次 graph_compute 里做 7 次矩阵乘（q/k/v/o/gate/up/down）。
//
// 为什么必须按这个形态测：ggml 每次 graph_compute 有固定的调度与同步开销（0.15 ms 量级），
// 单 matmul 一张图时这份开销全压在一个 3 MB 的权重上，算出来的「带宽」只有真实的三分之一。
// 真实推理是一层一次 launch，7 个 matmul 共用一次开销，所以这里也这么建。
static void bench_layer(ggml_backend_t be, const char * tag, int n_in, int n_out,
                        ggml_type wtype, int iters) {
    const int kMats = 7;
    const size_t wsize = ggml_row_size(wtype, n_in) * (size_t) n_out;

    std::vector<float> host((size_t) n_in * n_out);
    std::mt19937 rng(4321);
    std::normal_distribution<float> nd(0.0f, 0.02f);
    for (auto & v : host) v = nd(rng);

    std::vector<uint8_t> qw(wsize);
    const size_t wrote = ggml_quantize_chunk(wtype, host.data(), qw.data(), 0, n_out, n_in, nullptr);
    if (wrote != wsize) {
        logf("  %-6s layer 量化失败", tag);
        return;
    }

    ggml_init_params ip = {
        /*.mem_size   =*/ ggml_tensor_overhead() * 40 + ggml_graph_overhead() * 4,
        /*.mem_buffer =*/ nullptr,
        /*.no_alloc   =*/ true,
    };
    ggml_context * ctx = ggml_init(ip);
    if (!ctx) { logf("  %s 建 ctx 失败", tag); return; }

    ggml_tensor * w[kMats];
    for (int i = 0; i < kMats; i++) w[i] = ggml_new_tensor_2d(ctx, wtype, n_in, n_out);
    ggml_tensor * x = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, n_in, 1);
    // 7 个独立输出，不用 add 合并：一是真实一层本来就是各算各的，
    // 二是这样图里只有 matmul，不会因为后端缺 elementwise 算子整组失败。
    ggml_tensor * y[kMats];
    for (int i = 0; i < kMats; i++) {
        y[i] = ggml_mul_mat(ctx, w[i], x);
        ggml_set_output(y[i]);
    }

    ggml_backend_buffer_t buf = ggml_backend_alloc_ctx_tensors(ctx, be);
    if (!buf) {
        logf("  %-6s layer %dx%d  分配不了（%d 个张量 × %.0f MB）",
             tag, n_in, n_out, kMats, wsize / 1048576.0);
        ggml_free(ctx);
        return;
    }

    for (int i = 0; i < kMats; i++) ggml_backend_tensor_set(w[i], qw.data(), 0, qw.size());
    std::vector<float> xv((size_t) n_in, 0.5f);
    ggml_backend_tensor_set(x, xv.data(), 0, xv.size() * sizeof(float));

    ggml_cgraph * gf = ggml_new_graph(ctx);
    for (int i = 0; i < kMats; i++) ggml_build_forward_expand(gf, y[i]);

    for (int i = 0; i < 3; i++) {
        if (ggml_backend_graph_compute(be, gf) != GGML_STATUS_SUCCESS) {
            logf("  %-6s layer 计算失败", tag);
            ggml_backend_buffer_free(buf);
            ggml_free(ctx);
            return;
        }
    }

    const double layerBytes = (double) wsize * kMats;
    double best = 1e30, total = 0.0;
    int done = 0;
    for (int i = 0; i < iters; i++) {
        const auto t0 = clk::now();
        const ggml_status st = ggml_backend_graph_compute(be, gf);
        const double dt = ms_since(t0);
        if (st != GGML_STATUS_SUCCESS) break;
        total += dt;
        if (dt < best) best = dt;
        done++;
    }
    if (done > 0) {
        const double avg = total / done;
        logf("  %-6s 一层×7  %5d x %-5d  %7.3f ms/层  %6.1f GB/s（最好 %6.3f ms / %6.1f GB/s）",
             tag, n_in, n_out, avg, layerBytes / (avg / 1000.0) / 1e9,
             best, layerBytes / (best / 1000.0) / 1e9);
    }

    ggml_backend_buffer_free(buf);
    ggml_free(ctx);
}

// ---------------------------------------------------------------- 主流程

// ggml 的 hexagon 后端里写死了 dlopen("libcdsprpc.so")。
// 普通 App 的 linker namespace 看不到 /vendor/lib64，所以先在进程里把驱动库
// 用绝对路径塞进去：一旦同一个 SONAME 已加载，后面按名字找就会命中。
// 设备是否把 FastRPC 库列为「公开库」，直接决定 App 能不能碰 NPU。
// 这两个文件是可读的，读完就能提前判断，不用等 dlopen 报错再猜。
static void report_public_libs() {
    const char * files[] = {
        "/vendor/etc/public.libraries.txt",
        "/system/etc/public.libraries.txt",
        "/vendor/etc/public.libraries-google.txt",
    };
    bool hit = false;
    for (const char * f : files) {
        FILE * fp = fopen(f, "r");
        if (!fp) { logf("  %s 读不到", f); continue; }
        char line[256];
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, "cdsprpc") || strstr(line, "fastrpc") || strstr(line, "Qnn")) {
                logf("  %s 含 %s", f, line);
                hit = true;
            }
        }
        fclose(fp);
    }
    if (!hit) logf("  ⚠ 白名单里没有 FastRPC / QNN 库，App 进程很可能加载不了驱动");
}

static void preload_fastrpc() {
    report_public_libs();

    const char * cands[] = {
        "libcdsprpc.so",
        "/vendor/lib64/libcdsprpc.so",
        "/vendor/lib/libcdsprpc.so",
        "/system/lib64/libcdsprpc.so",
    };
    bool ok = false;
    for (const char * p : cands) {
        if (access(p, R_OK) != 0 && p[0] == '/') {
            logf("  驱动候选 %s：文件不存在", p);
            continue;
        }
        void * h = dlopen(p, RTLD_NOW | RTLD_GLOBAL);
        if (h) {
            logf("  驱动已加载：%s", p);
            ok = true;
            break;
        }
        logf("  驱动 %s 失败：%s", p, dlerror());
    }
    if (!ok) logf("  ⚠ 没能加载 libcdsprpc.so，NPU 那组大概率直接失败");

    // 设备节点是否可见，决定 SELinux 那边会不会放行
    const char * devs[] = { "/dev/fastrpc-cdsp", "/dev/fastrpc-cdsp-secure",
                            "/dev/fastrpc-cdsp-secure-nonwd", "/dev/fastrpc-smd" };
    for (const char * d : devs) {
        logf("  %s %s", d, access(d, R_OK | W_OK) == 0 ? "可读写" : "不可访问");
    }
}

static bool load_backends(const char * lib_dir) {
    // base 先全局加载，hexagon 插件的 NEEDED 才找得到
    void * h = dlopen("libggml-base.so", RTLD_NOW | RTLD_GLOBAL);
    logf("libggml-base.so %s", h ? "已加载" : dlerror());

    preload_fastrpc();

    // FastRPC 从 ADSP_LIBRARY_PATH 里按名字找 skel（libggml-htp-v79.so）。
    // 必须在第一次调用 HTP 之前设置，所以放在这里。
    const char * old = getenv("ADSP_LIBRARY_PATH");
    std::string p = lib_dir ? lib_dir : "";
    if (old && *old) { p += ":"; p += old; }
    setenv("ADSP_LIBRARY_PATH", p.c_str(), 1);
    logf("ADSP_LIBRARY_PATH=%s", p.c_str());

    ggml_backend_load_all_from_path(lib_dir);
    return true;
}

static void run_bench(const char * lib_dir, const char * mode) {
    logf("ggml %s", ggml_version());
    logf("模式：%s", mode);

    load_backends(lib_dir);

    logf("检测到 %zu 个后端：", ggml_backend_dev_count());
    for (size_t i = 0; i < ggml_backend_dev_count(); i++) {
        ggml_backend_dev_t d = ggml_backend_dev_get(i);
        size_t free_b = 0, total_b = 0;
        ggml_backend_dev_memory(d, &free_b, &total_b);
        logf("  [%zu] %-10s %s（mem %.0f / %.0f MB）", i,
             ggml_backend_dev_name(d), ggml_backend_dev_description(d),
             free_b / 1048576.0, total_b / 1048576.0);
    }

    // 三个贴近实际的形状：depth 的 FFN 半宽、qkv 合并后的宽度、方阵对照
    const int shapes[][2] = { {1024, 2816}, {1024, 3072}, {2048, 2048} };
    const ggml_type types[] = { GGML_TYPE_Q8_0, GGML_TYPE_Q4_0, GGML_TYPE_Q4_K };
    const int iters = 200;

    for (size_t di = 0; di < ggml_backend_dev_count(); di++) {
        ggml_backend_dev_t dev = ggml_backend_dev_get(di);
        const char * name = ggml_backend_dev_name(dev);
        const char * desc = ggml_backend_dev_description(dev);
        const bool is_htp = strstr(desc, "Hexagon") != nullptr;
        const bool is_cpu = ggml_backend_dev_type(dev) == GGML_BACKEND_DEVICE_TYPE_CPU;

        if (strcmp(mode, "cpu") == 0 && !is_cpu) continue;
        if (strcmp(mode, "htp") == 0 && !is_htp) continue;
        if (!is_cpu && !is_htp) continue;   // 其他加速器不管

        logf("");
        logf("===== %s · %s =====", name, desc);

        ggml_backend_t be = nullptr;
        try {
            be = ggml_backend_dev_init(dev, nullptr);
        } catch (const std::exception & e) {
            logf("初始化抛异常：%s", e.what());
        } catch (...) {
            logf("初始化抛未知异常");
        }
        if (!be) {
            logf("%s：初始化失败", name);
            continue;
        }

        // CPU 固定 4 线程，与 App 里的默认值一致
        if (is_cpu) ggml_backend_cpu_set_n_threads(be, 4);

        logf("  — 小张量（3 MB 级）：固定开销占比高，只作对照 —");
        for (const auto & s : shapes) {
            for (ggml_type t : types) {
                try {
                    bench(be, name, s[0], s[1], t, iters);
                } catch (const std::exception & e) {
                    logf("  %s %d x %d 抛异常：%s", ggml_type_name(t), s[0], s[1], e.what());
                } catch (...) {
                    logf("  %s %d x %d 抛未知异常", ggml_type_name(t), s[0], s[1]);
                }
            }
        }

        // 30 MB 的单个权重：一次调用要读 30 MB，0.15 ms 的固定开销只占 1% 左右，
        // 测出来的才是真带宽。这一组是「NPU 到底能不能超过 CPU」的唯一判据。
        logf("  — 大张量（30 MB 级）：固定开销占比 <1%，这是真实带宽 —");
        for (ggml_type t : { GGML_TYPE_Q8_0, GGML_TYPE_Q4_0 }) {
            try {
                bench(be, name, 1024, 28160, t, 100, 3);
            } catch (const std::exception & e) {
                logf("  大张量 %s 抛异常：%s", ggml_type_name(t), e.what());
            } catch (...) {
                logf("  大张量 %s 抛未知异常", ggml_type_name(t));
            }
        }

        // 与真实深度同构：一次 launch 做 7 个 matmul，7 × 4.2 M 参数 ≈ 真实一层。
        // 这一组的 ms/层 可以直接和 App 里的 0.53 ms/层 对比。
        logf("  — 一层形态（一次 launch × 7 个 matmul）—");
        for (ggml_type t : { GGML_TYPE_Q8_0, GGML_TYPE_Q4_0 }) {
            try {
                bench_layer(be, name, 1024, 4096, t, 100);
            } catch (const std::exception & e) {
                logf("  一层 %s 抛异常：%s", ggml_type_name(t), e.what());
            } catch (...) {
                logf("  一层 %s 抛未知异常", ggml_type_name(t));
            }
        }

        ggml_backend_free(be);
    }

    logf("");
    logf("完成。判据：HTP 的 GB/s 明显高于 CPU 才有必要往下走；持平或更低就收手。");
}

// ---------------------------------------------------------------- JNI

extern "C" JNIEXPORT void JNICALL
Java_ai_breeze_npubench_Bench_runNative(JNIEnv * env, jclass, jstring lib_dir, jstring mode, jobject cb) {
    env->GetJavaVM(&g_vm);
    g_cb = env->NewGlobalRef(cb);

    jclass cb_cls = env->GetObjectClass(cb);
    g_line = env->GetMethodID(cb_cls, "onLine", "(Ljava/lang/String;)V");

    const char * c_dir  = lib_dir ? env->GetStringUTFChars(lib_dir, nullptr) : nullptr;
    const char * c_mode = mode ? env->GetStringUTFChars(mode, nullptr) : nullptr;

    try {
        run_bench(c_dir ? c_dir : "", c_mode ? c_mode : "all");
    } catch (const std::exception & e) {
        logf("整体失败：%s", e.what());
    } catch (...) {
        logf("整体失败：未知异常");
    }

    if (c_dir)  env->ReleaseStringUTFChars(lib_dir, c_dir);
    if (c_mode) env->ReleaseStringUTFChars(mode, c_mode);
    if (g_cb) {
        env->DeleteGlobalRef(g_cb);
        g_cb = nullptr;
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_ai_breeze_npubench_Bench_archHint(JNIEnv * env, jclass) {
    // 给界面一个提示，便于对照日志里的 skel 版本
    char buf[128];
    snprintf(buf, sizeof(buf), "abi arm64-v8a · 页面 %d", (int) sysconf(_SC_PAGESIZE));
    return env->NewStringUTF(buf);
}
