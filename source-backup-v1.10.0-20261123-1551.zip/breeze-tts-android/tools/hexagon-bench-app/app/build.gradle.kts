plugins {
    id("com.android.application")
}

android {
    namespace = "ai.breeze.npubench"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.breeze.npubench"
        // Android 15 起 targetSdk < 24 的包直接拒绝安装，所以不能靠压版本绕
        // linker 的 namespace 隔离。能不能碰 Hexagon 取决于设备把 libcdsprpc.so
        // 放没放进 public.libraries.txt —— App 会把这份白名单读出来告诉我们。
        minSdk = 33
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
        ndk {
            abiFilters += "arm64-v8a"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // 本机测试用，不发布，跳过 Play 的 targetSdk 检查
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    // 必须解压 so：Hexagon 的 skel 由 FastRPC 按文件路径加载，
    // 直接从 APK 里映射（useLegacyPackaging=false）拿不到真实路径。
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}
