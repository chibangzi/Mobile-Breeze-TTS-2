#!/bin/sh
# 重编 NPU 判定基准 App。产物：dist/BreezeNpuBench-1.1.apk
#
# 依赖沙箱里已有的东西：
#   /root/android-sdk/ndk/27.1.12297006    NDK
#   /tmp/build-hvx                         ggml（含 hexagon 后端）的交叉编译产物
#   /opt/gradle-8.9                        Gradle（本地发行版，不走 wrapper 下载）
# 换机器时这三个路径要改。

set -e

ROOT=$(cd "$(dirname "$0")/../.." && pwd)
APP="$ROOT/tools/hexagon-bench-app"
NDK=/root/android-sdk/ndk/27.1.12297006
GGML_BUILD=/tmp/build-hvx
GGML_SRC=/tmp/ggml_src

CLANGXX="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/clang++"
JNI="$APP/app/src/main/jniLibs/arm64-v8a"

echo "[1/4] 编译 JNI 库"
"$CLANGXX" --target=aarch64-linux-android33 -O2 -std=c++17 -fPIC -shared \
    -I"$GGML_SRC/include" -I"$GGML_BUILD/include" \
    "$APP/app/src/main/cpp/bench_jni.cpp" \
    -L"$GGML_BUILD/src" -lggml -lggml-base -lggml-cpu -llog \
    -o "$JNI/libhvxbench.so"

echo "[2/4] 同步 ggml 动态库"
cp "$GGML_BUILD/src/libggml.so" "$GGML_BUILD/src/libggml-base.so" \
   "$GGML_BUILD/src/libggml-cpu.so" "$JNI/"
cp "$GGML_BUILD/src/ggml-hexagon/libggml-hexagon.so" "$JNI/"
for v in v73 v75 v79 v81; do
    cp "$GGML_BUILD/src/ggml-hexagon/libggml-htp-$v.so" "$JNI/"
done
cp "$GGML_BUILD/src/ggml-hexagon/ship/libc++_shared.so" "$JNI/"

echo "[3/4] 编译 APK"
cd "$APP"
ANDROID_HOME=/root/android-sdk /opt/gradle-8.9/bin/gradle :app:assembleRelease --offline -q

echo "[4/4] 对齐 + 签名"
BT=/root/android-sdk/build-tools/35.0.0
"$BT/zipalign" -f 4 app/build/outputs/apk/release/app-release-unsigned.apk /tmp/npubench-aligned.apk
"$BT/apksigner" sign --ks "$ROOT/signing/breeze-test.jks" \
    --ks-pass pass:breezetest --ks-key-alias breeze --key-pass pass:breezetest \
    --out "$ROOT/dist/BreezeNpuBench-1.1.apk" /tmp/npubench-aligned.apk
"$BT/apksigner" verify "$ROOT/dist/BreezeNpuBench-1.1.apk"

ls -lh "$ROOT/dist/BreezeNpuBench-1.1.apk"
