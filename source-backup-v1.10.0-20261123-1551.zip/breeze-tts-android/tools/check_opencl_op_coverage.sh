#!/usr/bin/env bash
# 核对 Breeze-TTS-2 用到的 ggml 算子与 ggml-opencl 后端的支持范围。
#
# 用途：升级 ggml / 想启用 -DGGML_OPENCL=ON 之前跑一遍，看缺口有没有变化。
# 结果不是「自动判定可否运行」——supports_op 里还有类型/步长条件（比如 F32 prec 会被拒、
# RMS_NORM 要求 ne0 % 4 == 0），脚本只负责列出「算子级别」的缺口，细节仍需人读。
#
#   ./tools/check_opencl_op_coverage.sh [ggml_sha]
#
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BREEZE_SRC="${BREEZE_SRC:-$ROOT/../breeze2cpp/Breeze-TTS-2.cpp-main/src}"
SHA="${1:-$(grep -m1 '^GGML_SHA=' "$ROOT/tools/build_breeze_android.sh" | grep -oE '[0-9a-f]{40}')}"
CACHE="${TMPDIR:-/tmp}/ggml-opencl-$SHA.cpp"

if [ ! -f "$CACHE" ]; then
    echo "== 下载 ggml-opencl.cpp @ ${SHA:0:12} =="
    curl -fsSL -o "$CACHE" "https://raw.githubusercontent.com/ggml-org/ggml/$SHA/src/ggml-opencl/ggml-opencl.cpp"
fi

if [ ! -d "$BREEZE_SRC" ]; then
    echo "找不到 Breeze 源码：$BREEZE_SRC（用 BREEZE_SRC=... 指定）" >&2
    exit 1
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# supports_op 函数体：从定义到下一个顶格右括号
awk '/^static bool ggml_opencl_supports_op/{f=1} f{print} f&&/^}/{exit}' "$CACHE" > "$TMP/sup.cpp"
grep -oE 'GGML_OP_[A-Z_0-9]+' "$TMP/sup.cpp" | sort -u > "$TMP/ops.txt"
grep -oE 'GGML_UNARY_OP_[A-Z_0-9]+' "$TMP/sup.cpp" | sort -u > "$TMP/unary.txt"

# Breeze 侧的算子：调用名 → 实际 op（ggml 的 conv_1d 展开成 im2col + mul_mat）
grep -rhoE 'ggml_[a-z0-9_]+\(' "$BREEZE_SRC"/*.cpp | tr -d '(' | sort -u | sed 's/^ggml_//' > "$TMP/calls.txt"

cat > "$TMP/map.sed" <<'EOF'
s/^conv_1d$/IM2COL MUL_MAT/
s/^conv_transpose_1d$/CONV_TRANSPOSE_1D/
s/^conv_transpose_2d$/CONV_TRANS_2D/
s/^conv_2d$/CONV_2D/
s/^gelu$/_UNARY/
s/^gelu_erf$/_UNARY/
s/^elu$/_UNARY/
s/^sin$/_UNARY/
s/^exp$/_UNARY/
s/^swiglu_split$/_GLU/
s/^rms_norm$/RMS_NORM/
s/^mul_mat$/MUL_MAT/
s/^soft_max_ext$/SOFT_MAX/
s/^top_k$/TOP_K/
s/^argmax$/ARGMAX/
s/^rope_ext$/ROPE/
s/^pad_ext$/PAD/
EOF

{
    while read -r c; do
        case "$c" in
            # 构造/生命周期/后端 API，不是算子
            init|free|new_tensor_*|view_*|reshape_*|build_forward_expand|backend_*|gallocr_*|tallocr_*|\
            graph_overhead_custom|new_graph_custom|get_type_traits|nbytes|nelements|n_dims|is_contiguous|\
            is_quantized|get_tensor|get_first_tensor|get_next_tensor|repack_get_optimal_repack_type|\
            set_output|set_input|cont_2d|scale|none|tensor_overhead) echo "SKIP $c";;
            *) echo "MAP $c";;
        esac
    done < "$TMP/calls.txt"
} > "$TMP/plan.txt"

echo
echo "== Breeze 声称使用的算子 vs ggml-opencl supports_op @ ${SHA:0:12} =="
printf '%-24s %s\n' "调用" "状态"
echo "-------------------------------------------------------------"

miss=0
while read -r kind call; do
    [ "$kind" = "MAP" ] || continue
    ops="$(echo "$call" | sed -f "$TMP/map.sed" | tr -d '\n')"
    # 没命中映射表的，按「调用名大写」猜 op 名
    if [ "$ops" = "$call" ]; then
        ops="$(echo "$call" | tr '[:lower:]' '[:upper:]')"
    fi
    bad=""
    for o in $ops; do
        case "$o" in
            "_UNARY") grep -q 'GGML_OP_UNARY' "$TMP/ops.txt" || bad="$bad UNARY";;
            "_GLU")   grep -q 'GGML_OP_GLU'   "$TMP/ops.txt" || bad="$bad GLU";;
            *)        grep -qx "GGML_OP_$o" "$TMP/ops.txt" || bad="$bad $o";;
        esac
    done
    # 一元/GLU 还要看二级算子
    case "$call" in
        gelu|gelu_erf|elu|sin|exp)
            sub="$(echo "$call" | tr '[:lower:]' '[:upper:]')"
            grep -qx "GGML_UNARY_OP_$sub" "$TMP/unary.txt" || bad="$bad UNARY_$sub";;
        swiglu_split)
            grep -q "GGML_GLU_OP_SWIGLU" "$TMP/sup.cpp" || bad="$bad GLU_SWIGLU";;
    esac

    if [ -n "$bad" ]; then
        printf '%-24s ❌ 缺:%s\n' "ggml_$call" "$bad"
        miss=$((miss + 1))
    else
        printf '%-24s ✅\n' "ggml_$call"
    fi
done < "$TMP/plan.txt"

echo "-------------------------------------------------------------"
echo "缺口 $miss 个"
echo
echo "注：conv_1d 走 im2col+mul_mat；conv_transpose_1d 若要上 GPU，建议先改写成"
echo "    「零插值 + conv_1d」（见 docs/21）。"
