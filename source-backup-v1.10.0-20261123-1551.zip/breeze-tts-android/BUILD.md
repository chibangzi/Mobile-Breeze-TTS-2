# BreezeTTS 源码包 · 1.9.93（lean）

这是 BreezeTTS Android 端的完整可构建源码，**不含模型权重**。

## 一、包内有什么

```
BreezeTTS-src-1.9.93/
├── app/                  Android 工程（Gradle 根目录）
│   ├── app/
│   │   ├── src/main/java/ai/breeze/tts/     Kotlin 源码（44 个 .kt）
│   │   ├── src/main/cpp/                    JNI 桥 + CMake
│   │   ├── src/main/jniLibs/arm64-v8a/      预编译 .so（ggml / breeze / sherpa / onnx）
│   │   ├── src/main/assets/                 仅 probe_small.tflite（300 KB，自检用）
│   │   └── libs/sherpa-onnx-classes.jar     ASR 的 Java 接口
│   ├── gradlew / gradlew.bat / gradle/      Gradle 8.9 wrapper
│   ├── build.gradle.kts / settings.gradle.kts
├── native-src/           C++ 运行时源码（gguf / codec / generation / c_api）
├── docs/                 设计文档 93 篇，记录每一步的动机与实测
├── tools/                构建脚本、补丁、旧 MNN 方案存档
├── signing/breeze-test.jks   测试签名（见下）
├── README.md / NOTICE.md / LICENSE
└── BUILD.md              本文件
```

**未包含**：`dist/`（历史 APK 与加速包）、`backups/`（旧源码快照）、
`app/app/build/`、`.gradle/`、任何 `.gguf` 权重。

## 二、环境要求

| 项 | 版本 |
| --- | --- |
| JDK | 17 |
| Android SDK Platform | 35 |
| Android Build Tools | 35.0.0 |
| NDK | 27.1.12297006（`ndkVersion` 已固定） |
| CMake | 3.22.1 |
| Gradle | 8.9（wrapper 自带，无需预装） |

`minSdk = 33`，只出 `arm64-v8a`。

## 三、构建

```bash
cd app
echo "sdk.dir=/path/to/Android/Sdk" > local.properties   # 或用 ANDROID_HOME

./gradlew :app:assembleDebug        # 调试包
./gradlew :app:assembleRelease      # 未签名 release
```

产物：`app/app/build/outputs/apk/release/app-release-unsigned.apk`。

release 未开 R8（`isMinifyEnabled = false`），因为 LiteRT 2.3.2 的混淆规则没验证过。

### 签名

包内 `signing/breeze-test.jks` 是**开发测试用**证书，密码 `breezetest`，别名 `breeze`。
可以复现历史安装包的签名，方便覆盖安装；但**不要用于正式分发**，请自建 keystore。

```bash
apksigner sign --ks signing/breeze-test.jks \
  --ks-pass pass:breezetest --key-pass pass:breezetest \
  --ks-key-alias breeze app-release-unsigned.apk
```

## 四、模型（不在包内）

### 1. 主模型 GGUF（2.4 ~ 5.9 GB）

App 首次使用时从 Hugging Face 下载，仓库 `HoppouAI/Breeze-TTS-2.cpp`：

| 档位 | 文件 | 大小 |
| --- | --- | --- |
| 轻量 | `breeze-tts-2-q4_k.gguf` | ~2.4 GB |
| 均衡 | `breeze-tts-2-q6_k.gguf` | ~2.9 GB |
| 高保真 | `breeze-tts-2-q8_0.gguf` | ~3.3 GB |
| 参考 | `breeze-tts-2-f16.gguf` | ~5.9 GB |
| 深度 4bit | `breeze-tts-2-q8_0-dd4.gguf` | ~3.4 GB |
| 最省 | `breeze-tts-2-q4_k-dd2.gguf` | ~2.5 GB |

也可离线：设置 → 模型管理 → 导入本地 `.gguf`（只校验 `GGUF` 文件头）。

### 2. ASR 模型（可选，239 / 938 MB）

`sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17` 仓库的
`model.int8.onnx` 或 `model.onnx`。

### 3. 声码器 GPU 加速包（可选，147 MB）

`BreezeTTS-vocoder-gpu-fp32-t128.zip`，在 App 内「设置 → 推理与性能 →
声码器 GPU 加速」导入。不含它时声码器走 CPU，合成功能完全正常。

## 五、体积说明（为什么包里有 33 MB 的 .so）

`jniLibs/arm64-v8a/` 下的 `.so` 是**预编译**的第三方运行时，源码包里没有它们的
构建脚本：

| 文件 | 大小 | 来源 |
| --- | --- | --- |
| `libonnxruntime.so` | 22 MB | ONNX Runtime（ASR 用） |
| `libsherpa-onnx-jni.so` 等 3 个 | 9.2 MB | sherpa-onnx |
| `libggml*.so` / `libbreeze_gguf.so` | 1.9 MB | 本项目的 native-src 构建产物 |

前两组需要各自上游的源码与构建流程才能重编；`libbreeze_gguf.so` 可以由
`native-src/` + NDK 重新构建（`tools/build_breeze_android.sh` 有参考步骤）。
